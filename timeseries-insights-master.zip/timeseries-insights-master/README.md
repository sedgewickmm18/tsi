TimeSeries Insights Toolkit (Tick)
============

a lazily evaluated time series data pipeline.
---------------------

A TimeSeries pipeline is meant to mimic that of a set of math equations.


### Using the TimeSeries library in your own project

Note: API docs can be found at:

Java:

https://pages.github.ibm.com/Common-TimeSeries-Analytics-Library/time-series-documentation/

Python:

https://pages.github.ibm.com/Common-TimeSeries-Analytics-Library/tspy-docs/html/py-modindex.html

#### Including from Maven Artifactory

The easiest way to include this project is through the artifactory.

##### Add a settings.xml to your ~/.m2 folder with credentials

Make sure to set your MVN_USERNAME AND MVN_PASSWORD to access the artifactory

Note: We are only adding a maven-central repository since it is the only repository that you should need for a general maven project. Overriding settings.xml is mostly needed for setting the server credentials.

```xml
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
  <servers>
    <server>
      <username>${env.MVN_USERNAME}</username>
      <password>${env.MVN_PASSWORD}</password>
      <id>central</id>
    </server>
  </servers>
  <profiles>
    <profile>
      <repositories>
        <repository>
          <snapshots>
            <enabled>false</enabled>
          </snapshots>
          <id>maven-central</id>
          <name>maven-central</name>
          <url>http://central.maven.org/maven2/</url>
        </repository>
      </repositories>
      <id>artifactory</id>
    </profile>
  </profiles>
  <activeProfiles>
    <activeProfile>artifactory</activeProfile>
  </activeProfiles>
</settings>
```

##### Add these remote repositories to your project pom.xml

Note: If you are not using scala or the visualizations, you can omit those repositories

```xml
<repositories>
    <!-- resolves Time Series dependencies -->
    <repository>
        <id>central</id>
        <name>artifactory-dal10-node2.swg-devops.com-releases</name>
        <url>https://na.artifactory.swg-devops.com:443/artifactory/tsal-maven-local</url>
    </repository>
    <!-- resolves scala dependencies -->
    <repository>
      <id>scala-tools.org</id>
      <name>Scala-tools Maven2 Repository</name>
      <url>http://scala-tools.org/repo-releases</url>
    </repository>
    <!-- resolves visualization dependencies -->
    <repository>
      <id>Sonatype Repository</id>
      <name>Sonatype Repository</name>
      <url>https://oss.sonatype.org/content/repositories/releases/</url>
    </repository>
</repositories>
```


#### Build / Install (You only must do this if not going through Artifactory)

If you don't want to include via the artifactory, you can install the libraries the following way

#### Install WatFore (Watson Forecasting)

```
git clone git@github.ibm.com:Common-TimeSeries-Analytics-Library/WatFore.git
cd WatFore
mvn clean install -Dtest=WatForeTestSuite
```

#### Install TimeSeries toolkit (timeseries-insights)

```
git clone git@github.ibm.com:Common-TimeSeries-Analytics-Library/timeseries-insights.git
cd timeseries-insights
mvn clean install
```

#### add maven dependency

Once the libraries resolved via artifactory or through your local m2 repository, you can then include them as dependencies in your pom.xml

*core* (core framework)

```xml
<dependency>
    <groupId>com.ibm.research.time-series</groupId>
    <artifactId>time-series-core</artifactId>
    <version>2.0.5</version>
</dependency>
```

*transforms* (built-in transforms)

```xml
<dependency>
    <groupId>com.ibm.research.time-series</groupId>
    <artifactId>time-series-transforms</artifactId>
    <version>2.0.5</version>
</dependency>
```

#### Installing tspy (python version)

```bash
cd python

python setup.py install
```

---------------------

For TimeSeries REPL information, please visit:

https://github.ibm.com/Common-TimeSeries-Analytics-Library/timeseries-insights/tree/master/repl

Please refer to the wiki for detailed instructions on building and using this library:

https://github.ibm.com/Common-TimeSeries-Analytics-Library/timeseries-insights/wiki
