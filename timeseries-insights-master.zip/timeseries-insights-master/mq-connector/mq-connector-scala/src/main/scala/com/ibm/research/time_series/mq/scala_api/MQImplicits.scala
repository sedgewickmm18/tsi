package com.ibm.research.time_series.mq.scala_api

import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.mq.timeseries.MQTimeSeries

/**
  * Entry point for MQ implicits to be used with [[TimeSeries]]
  */
object MQImplicits {

  object MQFunctions {
    /**
      * create a [[ScalaTimeSeries]] from and MQ connection
      *
      * @param host mq host
      * @param queueName mq queue name
      * @param cacheSize max buffer size
      * @param toTimestampOp function from mq message to timestamp, if empty resort to a count for timestamp
      * @return a new [[ScalaTimeSeries]] of MQ messages
      */
    def mq
    (queueName: String, host: String = "localhost", cacheSize: Long = Long.MaxValue, toTimestampOp: Option[String => Long] = None): ScalaTimeSeries[String] = {
      if (toTimestampOp.isEmpty) {
        MQTimeSeries.mq(host,queueName,cacheSize).asScala
      } else {
        MQTimeSeries.mq(host,queueName,cacheSize,TSFunctionUtils.uMapFunction(toTimestampOp.get(_))).asScala
      }
    }
  }

  implicit def fromScalaTimeSeriesObject(tsEntry:TimeSeries.type): MQFunctions.type = {
    MQFunctions
  }
}
