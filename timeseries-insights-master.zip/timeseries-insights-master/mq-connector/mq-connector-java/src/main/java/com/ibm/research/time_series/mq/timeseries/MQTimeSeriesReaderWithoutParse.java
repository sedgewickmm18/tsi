package com.ibm.research.time_series.mq.timeseries;

import com.ibm.research.time_series.core.observation.Observation;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Special form of MQTimeSeriesReader that uses a synchronized count as the observation timestamp
 */
class MQTimeSeriesReaderWithoutParse extends MQTimeSeriesReader{

    /**
     * synchronized count
     */
    private AtomicLong currentTimestamp;

    /**
     * Create an MQTimeSeries without a parser for Message to Timestamp
     *
     * @param host mq host
     * @param queueName mq queue name
     * @param cacheSize mq max buffer size
     */
    MQTimeSeriesReaderWithoutParse(String host, String queueName, long cacheSize) {
        super(host, queueName, cacheSize);
        this.currentTimestamp = new AtomicLong(0);
    }

    /**
     * gets the current observation given a message
     *
     * <p>Note: It uses the synchronized count to compute timestamp</p>
     *
     * @param message the mq message
     * @return a new Observation
     */
    @Override
    protected Observation<String> getCurrentObservation(String message) {
        return new Observation<>(currentTimestamp.incrementAndGet(),message);
    }
}
