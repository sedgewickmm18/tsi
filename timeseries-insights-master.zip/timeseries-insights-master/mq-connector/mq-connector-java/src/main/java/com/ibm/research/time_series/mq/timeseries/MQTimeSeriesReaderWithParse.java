package com.ibm.research.time_series.mq.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;

/**
 * Special form of MQTimeSeriesReader that uses a message to timestamp parse to extract timestamps
 */
class MQTimeSeriesReaderWithParse extends MQTimeSeriesReader{
    /**
     * message to timestamp function
     */
    private UnaryMapFunction<String,Long> toTimestampOp;

    /**
     * Create an MQTimeSeries with a parser for Message to Timestamp
     *
     * @param host mq host
     * @param queueName mq queue name
     * @param cacheSize mq max buffer size
     * @param toTimestampOp message to timestamp function
     */
    MQTimeSeriesReaderWithParse(
            String host,
            String queueName,
            long cacheSize,
            UnaryMapFunction<String, Long> toTimestampOp) {
        super(host,queueName,cacheSize);
        this.toTimestampOp = toTimestampOp;
    }

    /**
     * gets the current observation given a message
     *
     * <p>Note: The timestamp is computed using the given Message to Timestamp function</p>
     *
     * @param message the mq message
     * @return a new Observation
     */
    @Override
    protected Observation<String> getCurrentObservation(String message) {
        return new Observation<>(toTimestampOp.evaluate(message),message);
    }
}
