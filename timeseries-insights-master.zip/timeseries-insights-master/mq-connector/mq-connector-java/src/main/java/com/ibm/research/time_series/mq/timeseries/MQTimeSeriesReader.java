package com.ibm.research.time_series.mq.timeseries;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.TimeoutException;

/**
 * abstract RabbitMQ TimeSeries reader
 *
 * This reader will create an mq consumer and stream observations into a TimeSeries
 */
abstract class MQTimeSeriesReader implements TimeSeriesReader<String>{

    /**
     * queue name for MQ consumer
     */
    private final String queueName;
    /**
     * buffer max size for reader
     */
    private final long cacheSize;
    /**
     * the buffer of observations to hold
     */
    private NavigableSet<Observation<String>> buffer;

    /**
     * Create an MQ TimeSeries Reader
     * @param host mq host
     * @param queueName mq queue name
     * @param cacheSize buffer max size
     */
    MQTimeSeriesReader(String host, String queueName, long cacheSize) {
        this.queueName = queueName;
        this.buffer = new ConcurrentSkipListSet<>();
        this.cacheSize = cacheSize;

        try {
            setupConnection(host);
        } catch (IOException | TimeoutException e) {
            e.printStackTrace();
        }
    }

    /**
     * given an mq message, extract an Observation
     * @param message the mq message
     * @return an Observation
     */
    protected abstract Observation<String> getCurrentObservation(String message);

    /**
     * read values between floor(t1) and ceiling(t2) from buffer
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return an iterator of Observations in order by timestamp
     */
    @Override
    public Iterator<Observation<String>> read(long t1, long t2,boolean inclusive) {
        if (buffer.isEmpty()) return buffer.iterator();

        final Observation<String> floor = (buffer.first().getTimeTick() < t1 && inclusive)
            ? buffer.floor(new Observation<>(t1,null,null))
            : new Observation<>(t1,null,null);

        final Observation<String> ceiling = (buffer.last().getTimeTick() > t2 && inclusive)
            ? buffer.ceiling(new Observation<>(t2,null,null))
            : new Observation<>(t2,null,null);

        return buffer.subSet(floor,true,ceiling,true).iterator();
    }

    @Override
    public void close() {
        //todo nothing to do here for now
    }

    /**
     * @return first timestamp in our buffer
     */
    @Override
    public long start() {
        return (buffer.isEmpty()) ? Long.MIN_VALUE : buffer.first().getTimeTick();
    }

    /**
     * @return last timestamp in our buffer
     */
    @Override
    public long end() {
        return (buffer.isEmpty()) ? Long.MAX_VALUE : buffer.last().getTimeTick();
    }

    /**
     * setup an mq connection given a host
     * @param host mq host
     * @throws IOException
     * @throws TimeoutException
     */
    private void setupConnection(String host) throws IOException, TimeoutException{
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(host);
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.queueDeclare(queueName, false, false, false, null);
        channel.queuePurge(queueName);

        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
                    throws IOException {
                String message = new String(body, "UTF-8");
                Observation<String> parsedBody = getCurrentObservation(message);

                //this ensures our cache is only ever of size cacheSize
                if(buffer.size() == cacheSize){
                    buffer.remove(buffer.first());
                    buffer.add(parsedBody);
                }else{
                    buffer.add(parsedBody);
                }
            }
        };
        channel.basicConsume(queueName, true, consumer);
    }
}
