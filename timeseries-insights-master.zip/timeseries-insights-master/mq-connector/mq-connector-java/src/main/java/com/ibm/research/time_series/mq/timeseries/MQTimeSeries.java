package com.ibm.research.time_series.mq.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

/**
 * Entry point for MQ {@link TimeSeries} creation
 */
public class MQTimeSeries {

    /**
     * create a {@link TimeSeries} from and MQ connection where timestamps are computed using a function
     * from mq message to timestamp
     *
     * @param host mq host
     * @param queueName mq queue name
     * @param cacheSize max buffer size
     * @param toTimestampOp function from mq message to timestamp, if empty resort to a count for timestamp
     * @return a new {@link TimeSeries} of MQ messages
     */
    public static TimeSeries<String> mq(
            String host,
            String queueName,
            long cacheSize,
            UnaryMapFunction<String,Long> toTimestampOp) {
        return TimeSeries.reader(new MQTimeSeriesReaderWithParse(host,queueName,cacheSize,toTimestampOp));
    }

    public static TimeSeries<String> mq(
            String host,
            String queueName,
            UnaryMapFunction<String,Long> toTimestampOp) {
        return mq(host,queueName,Long.MAX_VALUE,toTimestampOp);
    }

    public static TimeSeries<String> mq(
            String queueName,
            UnaryMapFunction<String,Long> toTimestampOp) {
        return mq("localhost",queueName,toTimestampOp);
    }

    /**
     * create a {@link TimeSeries} from an MQ connection where timestamps are computed based on a synchronized
     * count of messages streaming in to the mq connection
     *
     * @param host mq host
     * @param queueName mq queue name
     * @param cacheSize max buffer size
     * @return a new {@link TimeSeries} of MQ messages
     */
    public static TimeSeries<String> mq(
            String host,
            String queueName,
            long cacheSize) {
        return TimeSeries.reader(new MQTimeSeriesReaderWithoutParse(host,queueName,cacheSize));
    }

    /**
     * create a {@link TimeSeries} from an MQ connection where timestamps are computed based on a synchronized
     * count of messages streaming in to the mq connection
     *
     * @param host mq host
     * @param queueName mq queue name
     * @return a new {@link TimeSeries} of MQ messages
     */
    public static TimeSeries<String> mq(
            String host,
            String queueName) {
        return mq(host,queueName,Long.MAX_VALUE);
    }

    /**
     * create a {@link TimeSeries} from an MQ connection where timestamps are computed based on a synchronized
     * count of messages streaming in to the mq connection
     *
     * @param queueName mq queue name
     * @return a new {@link TimeSeries} of MQ messages
     */
    public static TimeSeries<String> mq(String queueName) {
        return mq("localhost",queueName);
    }
}
