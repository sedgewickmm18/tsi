/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.transform

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.transform.{BinaryTransform, NaryTransform, UnaryTransform}
import com.ibm.research.time_series.core.utils.ObservationCollection
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

import scala.collection.JavaConverters._

/**
  *
  * <p>Created on 8/24/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class TransformTest extends AssertionsForJUnit {
  private val verifier = new ScalaDoubleTimeSeriesVerifier
  private val ts = Observations(
    new Observation[Double](1, 2.0),
    new Observation[Double](3, 3.0),
    new Observation[Double](7, 5.0),
    new Observation[Double](8, 8.0),
    new Observation[Double](10, 5.0),
    new Observation[Double](11, 9.0),
    new Observation[Double](12, 11.0),
    new Observation[Double](14, 1.0)
  )
  private val ts2 = Observations(
    new Observation[Double](1, 6.0),
    new Observation[Double](3, 3.0),
    new Observation[Double](7, 8.0),
    new Observation[Double](8, 3.0),
    new Observation[Double](10, 1.0),
    new Observation[Double](11, 14.0),
    new Observation[Double](12, 12.0),
    new Observation[Double](14, 15.0)
  )
  private val ts3 = Observations(
    new Observation[Double](1, 1.0),
    new Observation[Double](3, 3.0),
    new Observation[Double](7, 7.0),
    new Observation[Double](8, 4.0),
    new Observation[Double](10, 11.0),
    new Observation[Double](11, 12.0),
    new Observation[Double](12, 15.0),
    new Observation[Double](14, 19.0)
  )

  private val addOne = new UnaryTransform[Double,Double] {
    override def evaluate
        (t1: Long, t2: Long,inclusive: Boolean): ObservationCollection[Double] = {
      getTimeSeries.asScala.map(_ + 1).getValues(t1,t2,inclusive)
    }
  }

  private val addBoth = new BinaryTransform[Double,Double,Double] {
    override def evaluate
        (t1: Long, t2: Long,inclusive: Boolean): ObservationCollection[Double] = {
      val left = getTimeSeriesLeft.asScala
      val right = getTimeSeriesRight.asScala
      left.innerJoin(right)((x,y) => x + y).getValues(t1,t2,inclusive)
    }
  }

  private val addAll = new NaryTransform[Double,Double] {
    override def evaluate
        (t1: Long, t2: Long,inclusive: Boolean): ObservationCollection[Double] = {
      val all = getTimeSeriesTail.asScala.map(_.asScala.collect) += getTimeSeriesRoot.asScala.collect

      MultiTimeSeries.fromObservationCollectionList(all)
        .aggregate(Observations.newBuilder[Double].result())(
          (agg,com) => com.collect,
          (agg1,agg2) => agg1.toTimeSeries.innerJoin(agg2.toTimeSeries)((x, y) => x + y).collect
        )
        .toTimeSeries
        .getValues(t1,t2,inclusive)
    }
  }

  @Before def initialize(): Unit = {
  }

  @Test def testUnaryTransform(): Unit = {
    val expected = Observations(Observation(1,3.0),Observation(3,4.0),Observation(7,6.0))
    val actual = ts.toTimeSeries.transform(addOne)
    verifier.verifySeries(expected,actual.getValues(1,7))
  }

  @Test def testBinaryTransform(): Unit = {
    val expected = Observations(Observation(1,8.0),Observation(3,6.0),Observation(7,13.0))
    val actual = ts.toTimeSeries.transform(ts2.toTimeSeries)(addBoth)
    verifier.verifySeries(expected,actual.getValues(1,7))
  }

  @Test def testNaryTransform(): Unit = {
    val expected = Observations(Observation(1,9.0),Observation(3,9.0),Observation(7,20.0))
    val actual = ts.toTimeSeries.transform(Array(ts2.toTimeSeries,ts3.toTimeSeries))(addAll)
    verifier.verifySeries(expected,actual.getValues(1,7))
  }
}
