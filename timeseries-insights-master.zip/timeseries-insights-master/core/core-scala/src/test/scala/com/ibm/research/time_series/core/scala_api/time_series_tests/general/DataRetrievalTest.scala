/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.general

import java.io.File
import java.time.{Instant, ZoneId, ZonedDateTime}

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier
import junit.framework.TestCase.assertEquals
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

/**
  *
  * <p>Created on 8/22/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class DataRetrievalTest extends AssertionsForJUnit{
  val delta = .01
  val GPS_SPEED_FILE = new File("").getAbsolutePath + "/src/test/resources/gps_speed.txt"
  val input = Observations(
    Observation(3, 5.0),
    Observation(10, 6.0),
    Observation(7, 7.0)
  )
  var expectedOutput = Observations(
    Observation(3,5.0),
    Observation(10,6.0),
    Observation(7,7.0)
  )
  val verifier = new ScalaDoubleTimeSeriesVerifier
  val sVerifier = new StringTimeSeriesVerifier

  @Before def initialize(): Unit = {
  }

  @Test def testGetValues(): Unit = {
    val ts = TimeSeries.fromObservations(input)
    verifier.verifySeries(expectedOutput,ts.getValues(3,10))
  }

  @Test def testCollectFromNavigableCollection(): Unit = {
    val ts = TimeSeries.fromObservations(input)
    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testCollectFromTextFile(): Unit = {
    val expectedFirst = Observation(1331667606731L, "1331667606731,40.08918737661366,-88.21121098107939,0.0")
    val expectedLast = Observation(1331670811493L, "1331670811493,40.113572625616335,-88.2243701605378,1.0")

    val ts = TimeSeries.textFile(GPS_SPEED_FILE,s => Some(Observation(s.split(",")(0).toLong,s)))
    val actual = ts.collect

    assertEquals(expectedFirst.getTimeTick, actual.first.getTimeTick)
    assertEquals(expectedFirst.getValue, actual.first.getValue)

    assertEquals(expectedLast.getTimeTick, actual.last.getTimeTick)
    assertEquals(expectedLast.getValue, actual.last.getValue)
  }

  @Test def testGetValuesWithZonedDateTimeMillis(): Unit = {
    val start = ZonedDateTime.ofInstant(Instant.ofEpochMilli(1331667610561L), ZoneId.systemDefault)
    val end = ZonedDateTime.ofInstant(Instant.ofEpochMilli(1331667612429L), ZoneId.systemDefault)
    val ts = TimeSeries.textFile(GPS_SPEED_FILE,s => Some(Observation(s.split(",")(0).toLong,s)))

    val expected = Observations.newBuilder[String]
    expected.add(1331667610561L, "1331667610561,40.08918737661366,-88.21121098107939,0.0")
    expected.add(1331667611538L, "1331667611538,40.08918737661366,-88.21121098107939,0.0")
    expected.add(1331667612429L, "1331667612429,40.08918737661366,-88.21121098107939,0.0")
    sVerifier.verifySeries(expected.result(),ts.getValues(start,end,true))
  }


}
