/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.general_transforms

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.utils.ObservationCollection
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

/**
  *
  * <p>Created on 8/22/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class InterpolateTest extends AssertionsForJUnit {
  private val input1 = Observations(
    Observation(1, 2.0),
    Observation(3, 3.0),
    Observation(7, 5.0),
    Observation(8, 8.0),
    Observation(10, 5.0),
    Observation(11, 9.0),
    Observation(12, 11.0),
    Observation(14, 1.0)
  )

  val verifier = new ScalaDoubleTimeSeriesVerifier

  val interpolate: (ObservationCollection[Double],ObservationCollection[Double],Long) => Double = (h,f,ts) => {
    if (h.isEmpty) {
      f.head.getValue
    } else if (f.isEmpty) {
      h.head.getValue
    } else {
      h.head.getValue + (f.head.getValue - h.head.getValue) * ((ts - h.head.getTimeTick.toDouble) / (f.head.getTimeTick.toDouble - h.head.getTimeTick.toDouble))
    }
  }


  @Before def initialize(): Unit = {
  }

  @Test def testInterpolate(): Unit = {
    val expectedOutput = Observations(
      Observation[Double](0, 2.0),
      Observation[Double](2, 2.5),
      Observation[Double](4, 3.5),
      Observation[Double](6, 4.5)
    )

    val ts = TimeSeries.fromObservations(input1).resample(2)(interpolate)
    verifier.verifySeries(expectedOutput,ts.getValues(1,7))
  }
}
