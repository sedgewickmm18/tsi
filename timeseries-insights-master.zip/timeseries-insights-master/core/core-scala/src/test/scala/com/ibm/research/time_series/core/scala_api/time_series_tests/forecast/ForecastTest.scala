///*
// * ************* Begin Copyright - Do not add comments here **************
// *  * Licensed Materials - Property of IBM
// *  *
// *  *   OCO Source Materials
// *  *
// *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
// *  *
// *  * The source code for this program is not published or other-
// *  * wise divested of its trade secrets, irrespective of what has
// *  * been deposited with the U.S. Copyright Office.
// *  ***************************** End Copyright ***************************
// */
//
//package com.ibm.research.time_series.core.scala_api.time_series_tests.forecast
//
//import java.util.Properties
//
//import com.ibm.research.time_series.core.constants.{BlockMode, ForecastConsts, ForecastModelUpdate}
//import com.ibm.research.time_series.core.scala_api.utils.Implicits._
//import com.ibm.research.time_series.core.timeseries.TimeSeries
//import com.ibm.research.time_series.core.tools.{DummyForecastor, StringTimeSeriesVerifier}
//import com.ibm.research.time_series.core.utils.ObservationCollection
//import org.junit.{Before, Test}
//import org.scalatest.junit.AssertionsForJUnit
//
///**
//  *
//  * <p>Created on 8/24/17.</p>
//  *
//  * @author Joshua Rosenkranz
//  */
//class ForecastTest extends AssertionsForJUnit {
//  private var data: ObservationCollection[String] = _
//  private var data2: ObservationCollection[String] = _
//  private val verifier = new StringTimeSeriesVerifier
//  private val fm = new DummyForecastor(4)
//
//  @Before def initialize(): Unit = {
//    val tsBuilder = Observations.newBuilder[String]
//    tsBuilder.add(1, "2.0")
//    tsBuilder.add(2, "3.0")
//    tsBuilder.add(3, "4.0")
//    tsBuilder.add(4, "5.0")
//    tsBuilder.add(5, "6.0")
//    tsBuilder.add(6, "7.0")
//    data = tsBuilder.result()
//    tsBuilder.clear()
//    tsBuilder.add(1, "2.0")
//    tsBuilder.add(2, "3.0")
//    tsBuilder.add(3, "4.0")
//    tsBuilder.add(4, "5.0")
//    tsBuilder.add(5, "6.0")
//    tsBuilder.add(6, "7.0")
//    tsBuilder.add(7, "8.0")
//    tsBuilder.add(8, "9.0")
//    tsBuilder.add(9, "10.0")
//    tsBuilder.add(10, "11.0")
//    tsBuilder.add(11, "12.0")
//    tsBuilder.add(12, "13.0")
//    tsBuilder.add(13, "14.0")
//    tsBuilder.add(14, "15.0")
//    tsBuilder.add(15, "16.0")
//    tsBuilder.add(16, "17.0")
//    data2 = tsBuilder.result()
//  }
//
//  @Test
//  def testForecastNotInitializedNonBlocking(): Unit = {
//    val expected = Observations(Observation(4,"5.0"),Observation(5,"6.0"),Observation(6,"7.0"))
//    val ts = data.toTimeSeries
//    ts.forecast(fm)
//    val actual = ts.getValues(4, 8)
//    verifier.verifySeries(expected, actual)
//  }
//
//  @Test
//  def testForecastInitializedNonBlocking(): Unit = {
//    val p = new Properties
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR, java.lang.Double.NEGATIVE_INFINITY.asInstanceOf[AnyRef])
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING, java.lang.Double.POSITIVE_INFINITY.asInstanceOf[AnyRef])
//    val tsBuilder = Observations.newBuilder[String]
//    tsBuilder.add(2, "3.0")
//    tsBuilder.add(3, "4.0")
//    tsBuilder.add(4, "5.0")
//    tsBuilder.add(5, "6.0")
//    tsBuilder.add(6, "7.0")
//    tsBuilder.add(Observation(7, "7.0", p))
//    tsBuilder.add(Observation(8, "7.0", p))
//    val expected = tsBuilder.result()
//    val ts = data.toTimeSeries
//    ts.forecast(fm)
//    val actual = ts.getValues(2, 8)
//    verifier.verifySeries(expected, actual)
//  }
//
//  @Test
//  def testForecastInitializedBlocking(): Unit = {
//    val p = new Properties
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR, java.lang.Double.NEGATIVE_INFINITY.asInstanceOf[AnyRef])
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING, java.lang.Double.POSITIVE_INFINITY.asInstanceOf[AnyRef])
//    val tsBuilder = Observations.newBuilder[String]
//    tsBuilder.add(2, "3.0")
//    tsBuilder.add(3, "4.0")
//    tsBuilder.add(4, "5.0")
//    tsBuilder.add(5, "6.0")
//    tsBuilder.add(6, "7.0")
//    tsBuilder.add(Observation(7, "7.0", p))
//    tsBuilder.add(Observation(8, "7.0", p))
//    val expected = tsBuilder.result
//    val ts = data.toTimeSeries
//    ts.forecast(fm)
//    val actual = ts.getValues(2, 8,true, BlockMode.BLOCK)
//    verifier.verifySeries(expected, actual)
//  }
//
//  @Test
//  def testForecastInitializedConditionalBlockingMet(): Unit = {
//    val p = new Properties
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR, 2.0.asInstanceOf[AnyRef])
//    p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING, 4.0.asInstanceOf[AnyRef])
//    val tsBuilder = Observations.newBuilder[String]
//    tsBuilder.add(2, "3.0")
//    tsBuilder.add(3, "4.0")
//    tsBuilder.add(4, "5.0")
//    tsBuilder.add(5, "6.0")
//    tsBuilder.add(6, "7.0")
//    tsBuilder.add(7, "8.0")
//    tsBuilder.add(8, "9.0")
//    tsBuilder.add(9, "10.0")
//    tsBuilder.add(10, "11.0")
//    tsBuilder.add(11, "12.0")
//    tsBuilder.add(12, "13.0")
//    tsBuilder.add(13, "14.0")
//    tsBuilder.add(14, "15.0")
//    tsBuilder.add(15, "16.0")
//    tsBuilder.add(16, "17.0")
//    tsBuilder.add(Observation(17, "17.0", p))
//    tsBuilder.add(Observation(18, "17.0", p))
//    tsBuilder.add(Observation(19, "17.0", p))
//    tsBuilder.add(Observation(20, "17.0", p))
//    val expected = tsBuilder.result()
//    val ts = data2.toTimeSeries
//    ts.forecast(fm,maxSpread = .4)
//    val actual = ts.getValues(2, 20, blockMode = BlockMode.CONDITIONAL_BLOCK)
//    verifier.verifySeries(expected, actual)
//  }
//
//}
