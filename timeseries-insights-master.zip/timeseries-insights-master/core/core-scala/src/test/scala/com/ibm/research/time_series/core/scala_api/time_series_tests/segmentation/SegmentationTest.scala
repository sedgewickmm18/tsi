/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.segmentation

import java.time._

import com.ibm.research.time_series.core.constants.{Padding, ResultingTimeStamp}
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.tools.{SegmentTimeSeriesVerifier, TimeSeriesVerifier}
import com.ibm.research.time_series.core.transform.UnaryTransform
import com.ibm.research.time_series.core.utils.{ObservationCollection, Segment, TRS}
import org.junit.Assert.assertEquals
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit


/**
  *
  * <p>Created on 8/24/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class SegmentationTest extends AssertionsForJUnit {
  private val verifier = new SegmentTimeSeriesVerifier[Int]
  private val iVerifer = new TimeSeriesVerifier[Int] {
    override protected def assertValuesEqual
        (expected: Int, actual: Int): Unit = assertEquals(expected,actual)
  }
  private val observations = Observations(
    new Observation[Int](1, 1),
    new Observation[Int](2, 2),
    new Observation[Int](3, 3),
    new Observation[Int](4, 4),
    new Observation[Int](5, 5)
  )
  private val observations2 = Observations(
    new Observation[Int](1, 1),
    new Observation[Int](3, 3),
    new Observation[Int](4, 4),
    new Observation[Int](6, 6),
    new Observation[Int](8, 8)
  )
  private val addOne = new UnaryTransform[Int, Int]() {
    override def evaluate
        (t1: Long, t2: Long,inclusive: Boolean): ObservationCollection[Int] = {
      new ScalaTimeSeries[Int](getTimeSeries).map(x => x+1).getValues(t1, t2, inclusive)
    }
  }

  @Before def initialize(): Unit = {
  }

  @Test def testSegment(): Unit = {
    val actual = observations.toTimeSeries.segment(3)

    val one = Segment.fromSeries(Observations(Observation(1,1),Observation(2,2),Observation(3,3)))
    val two = Segment.fromSeries(Observations(Observation(2,2),Observation(3,3),Observation(4,4)))
    val three = Segment.fromSeries(Observations(Observation(3,3),Observation(4,4),Observation(5,5)))

    val expected = Observations(Observation(1,one), Observation(2,two), Observation(3,three))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testSegmentWithStep(): Unit = {
    val actual = observations.toTimeSeries.segment(3,2)

    val one = Segment.fromSeries(Observations(Observation(1,1),Observation(2,2),Observation(3,3)))
    val two = Segment.fromSeries(Observations(Observation(3,3),Observation(4,4),Observation(5,5)))

    val expected = Observations(Observation(1,one), Observation(3,two))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testSegmentWithEnforceBoundsFalse(): Unit = {
    val actual = observations.toTimeSeries.segment(3,2,enforceSize = false)

    val one = Segment.fromSeries(Observations(Observation(1,1),Observation(2,2),Observation(3,3)))
    val two = Segment.fromSeries(Observations(Observation(3,3),Observation(4,4),Observation(5,5)))
    val three = Segment.fromSeries(Observations(Observation(5,5)))

    val expected = Observations(Observation(1,one), Observation(3,two), Observation(5,three))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testSegmentByTime(): Unit = {
    val actual = observations2.toTimeSeries.segmentByTime(3,2, Padding.RIGHT)

    val one = Segment.fromSeries(1,3,Observations(Observation(1,1),Observation(3,3)))
    val two = Segment.fromSeries(3,5,Observations(Observation(3,3),Observation(4,4),Observation(6,6)))
    val three = Segment.fromSeries(5,7,Observations(Observation(4,4),Observation(6,6),Observation(8,8)))
    val four = Segment.fromSeries(7,9,Observations(Observation(6,6),Observation(8,8)))

    val expected = Observations(Observation(1,one),Observation(3,two),Observation(5,three),Observation(7,four))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testSegmentByTimeWithNonInclusiveBounds(): Unit = {
    val actual = observations2.toTimeSeries.segmentByTime(3,2, Padding.RIGHT)

    val one = Segment.fromSeries(1,3,Observations(Observation(1,1),Observation(3,3)))
    val two = Segment.fromSeries(3,5,Observations(Observation(3,3),Observation(4,4)))
    val three = Segment.fromSeries(5,7,Observations(Observation(6,6)))
    val four = Segment.fromSeries(7,9,Observations(Observation(8,8)))

    val expected = Observations(Observation(1,one),Observation(3,two),Observation(5,three),Observation(7,four))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testSegmentByTimeWithPaddingLeft(): Unit = {
    val actual = observations2.toTimeSeries.segmentByTime(3,2, padding = Padding.LEFT)

    val one = Segment.fromSeries(-1,1,Observations(Observation(1,1)))
    val two = Segment.fromSeries(1,3,Observations(Observation(1,1),Observation(3,3)))
    val three = Segment.fromSeries(3,5,Observations(Observation(3,3),Observation(4,4),Observation(6,6)))
    val four = Segment.fromSeries(5,7,Observations(Observation(4,4),Observation(6,6),Observation(8,8)))

    val expected = Observations(Observation(-1,one),Observation(1,two),Observation(3,three),Observation(5,four))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testSegmentByTimeWithPaddingBoth(): Unit = {
    val actual = observations2.toTimeSeries.segmentByTime(3,2, padding = Padding.LEFT_AND_RIGHT)

    val one = Segment.fromSeries(-1,1,Observations(Observation(1,1)))
    val two = Segment.fromSeries(1,3,Observations(Observation(1,1),Observation(3,3)))
    val three = Segment.fromSeries(3,5,Observations(Observation(3,3),Observation(4,4),Observation(6,6)))
    val four = Segment.fromSeries(5,7,Observations(Observation(4,4),Observation(6,6),Observation(8,8)))
    val five = Segment.fromSeries(7,9,Observations(Observation(6,6),Observation(8,8)))

    val expected = Observations(Observation(-1,one),Observation(1,two),Observation(3,three),Observation(5,four),Observation(7,five))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testSegmentByTimeWithPaddingNone(): Unit = {
    val actual = observations2.toTimeSeries.segmentByTime(3,2,Padding.NONE,ResultingTimeStamp.END_OF_WINDOW)

    val one = Segment.fromSeries(1,3,Observations(Observation(1,1),Observation(3,3)))
    val two = Segment.fromSeries(3,5,Observations(Observation(3,3),Observation(4,4),Observation(6,6)))
    val three = Segment.fromSeries(5,7,Observations(Observation(4,4),Observation(6,6),Observation(8,8)))

    val expected = Observations(Observation(3,one),Observation(5,two),Observation(7,three))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testSegmentByAnchor(): Unit = {
    val actual = observations2.toTimeSeries.segmentByAnchor(_ % 2 == 0)(1,2)

    val one = Segment.fromSeries(3,6,Observations(Observation(3,3),Observation(4,4),Observation(6,6)))
    val two = Segment.fromSeries(5,8,Observations(Observation(4,4),Observation(6,6),Observation(8,8)))
    val three = Segment.fromSeries(7,10,Observations(Observation(6,6),Observation(8,8)))

    val expected = Observations(Observation(4,one),Observation(6,two),Observation(8,three))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testReduceSegment(): Unit = {
    val actual = observations.toTimeSeries.segment(3).reduceSegments(_.sum)

    val expected = Observations(Observation(1,6),Observation(2,9),Observation(3,12))
    iVerifer.verifySeries(expected,actual.collect(true))
  }

  @Test def testTransformSegment(): Unit = {
    val actual = observations.toTimeSeries.segment(3).transformSegments(addOne)

    val one = Segment.fromSeries(Observations(Observation(1,2),Observation(2,3),Observation(3,4)))
    val two = Segment.fromSeries(Observations(Observation(2,3),Observation(3,4),Observation(4,5)))
    val three = Segment.fromSeries(Observations(Observation(3,4),Observation(4,5),Observation(5,6)))

    val expected = Observations(Observation(1,one), Observation(2,two), Observation(3,three))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testMapSegment(): Unit = {
    val actual = observations.toTimeSeries.segment(3).mapSegments(_ + 1)

    val one = Segment.fromSeries(Observations(Observation(1,2),Observation(2,3),Observation(3,4)))
    val two = Segment.fromSeries(Observations(Observation(2,3),Observation(3,4),Observation(4,5)))
    val three = Segment.fromSeries(Observations(Observation(3,4),Observation(4,5),Observation(5,6)))

    val expected = Observations(Observation(1,one), Observation(2,two), Observation(3,three))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testMapObservationSegment(): Unit = {
    val actual = observations.toTimeSeries.segment(3).mapSegmentObservations(obs => Observation(obs.getTimeTick+1,obs.getValue+1))

    val one = Segment.fromSeries(Observations(Observation(2,2),Observation(3,3),Observation(4,4)))
    val two = Segment.fromSeries(Observations(Observation(3,3),Observation(4,4),Observation(5,5)))
    val three = Segment.fromSeries(Observations(Observation(4,4),Observation(5,5),Observation(6,6)))

    val expected = Observations(Observation(1,one), Observation(2,two), Observation(3,three))
    verifier.verifySeries(expected,actual.collect(true))
  }

  @Test def testSegmentBy(): Unit = {
    val start = ZonedDateTime.of(1990,7,6,0,0,0,0,ZoneId.of("UTC"))
    val timeTick = Duration.ofDays(10)
    val trs = TRS.of(timeTick,start)
    val ts = TimeSeries(1 to 10)(Some(trs))

    val actual = ts
      .segmentBy(obs => {
        val zdt = Instant.ofEpochMilli(trs.toLongLower(obs.timeTick)).atZone(ZoneId.of("UTC"))
        (zdt.getYear,zdt.getMonthValue)
      })

    val days = (0 until 10).map(i => start.plusDays(i*10)).map(_.toInstant.toEpochMilli).toArray

    val july = Segment.fromSeries(Observations(Observation(0,1),Observation(1,2),Observation(2,3))) //july 6,16,26
    val august = Segment.fromSeries(Observations(Observation(3,4),Observation(4,5),Observation(5,6)))//august 5,15,25
    val september = Segment.fromSeries(Observations(Observation(6,7),Observation(7,8),Observation(8,9)))//september 4,14,24
    val october = Segment.fromSeries(Observations(Observation(9,10)))//october 4

    val expected = Observations(
      Observation(july.start,july),
      Observation(august.start,august),
      Observation(september.start,september),
      Observation(october.start,october)
    )

    actual.print()

    expected.toTimeSeries(trs).print()

    verifier.verifySeries(expected,actual.collect(true))
  }

}
