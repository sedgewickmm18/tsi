/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.join

import com.ibm.research.time_series.core.scala_api.tools.{OptionalDoubleTimeSeriesVerifier, OptionalDoubleTupleTimeSeriesVerifier, ScalaDoubleTimeSeriesVerifier}
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.utils.ObservationCollection
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

/**
  *
  * <p>Created on 8/23/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class LeftJoinTest extends AssertionsForJUnit {
  private val input1 = Observations(
    Observation[Double](1, 2.0),
    Observation[Double](3, 3.0),
    Observation[Double](7, 5.0),
    Observation[Double](8, 8.0),
    Observation[Double](10, 5.0),
    Observation[Double](11, 9.0),
    Observation[Double](12, 11.0),
    Observation[Double](14, 1.0)
  )
  private val input2 = Observations(
    Observation[Double](2, 3.0),
    Observation[Double](3, 5.0),
    Observation[Double](4, 9.0),
    Observation[Double](9, 6.0),
    Observation[Double](10, 13.0),
    Observation[Double](11, 14.0),
    Observation[Double](13, 17.0),
    Observation[Double](14, 21.0)
  )
  private val verifier = new OptionalDoubleTupleTimeSeriesVerifier
  private val dVerifier = new OptionalDoubleTimeSeriesVerifier
  private val sdVerifier = new ScalaDoubleTimeSeriesVerifier

  val interpolate: (ObservationCollection[Double],ObservationCollection[Double],Long) => Double = (h,f,ts) => {
    if (h.isEmpty) {
      f.head.getValue
    } else if (f.isEmpty) {
      h.head.getValue
    } else {
      h.head.getValue + (f.head.getValue - h.head.getValue) * ((ts - h.head.getTimeTick.toDouble) / (f.head.getTimeTick.toDouble - h.head.getTimeTick.toDouble))
    }
  }

  @Before def initialize(): Unit = {
  }

  @Test def testLeftJoin(): Unit = {
    val expectedOutput = Observations[(Option[Double],Option[Double])](
      Observation(1, (Some(2.0), None)),
      Observation(3, (Some(3.0), Some(5.0))),
      Observation(7, (Some(5.0), None)),
      Observation(8, (Some(8.0), None)),
      Observation(10,(Some(5.0), Some(13.0))),
      Observation(11,(Some(9.0), Some(14.0))),
      Observation(12,(Some(11.0), None)),
      Observation(14,(Some(1.0), Some(21.0)))
    )

    val ts1 = input1.toTimeSeries
    val ts2 = input2.toTimeSeries

    val actual = ts1.leftJoin(ts2)((x,y) => (Option(x),y))

    verifier.verifySeries(expectedOutput,actual.collect)
  }

  @Test def testLeftJoinWithInterpolation(): Unit = {
    val expectedOutput = Observations[(Option[Double],Option[Double])](
      Observation(1, (Some(2.0), Some(3.0))),
      Observation(3, (Some(3.0), Some(5.0))),
      Observation(7, (Some(5.0), Some(7.2))),
      Observation(8, (Some(8.0), Some(6.6))),
      Observation(10,(Some(5.0), Some(13.0))),
      Observation(11,(Some(9.0), Some(14.0))),
      Observation(12,(Some(11.0), Some(15.5))),
      Observation(14,(Some(1.0), Some(21.0)))
    )

    val ts1 = input1.toTimeSeries
    val ts2 = input2.toTimeSeries

    val actual = ts1.leftJoin(ts2)((x,y) => (Option(x),y))(Some(interpolate))

    verifier.verifySeries(expectedOutput,actual.collect)
  }

  @Test def testLeftAlignWithoutInterpolation(): Unit = {
    val expectedOutput = Observations[(Option[Double],Option[Double])](
      Observation(1, (Some(2.0), None)),
      Observation(3, (Some(3.0), Some(5.0))),
      Observation(7, (Some(5.0), None)),
      Observation(8, (Some(8.0), None)),
      Observation(10,(Some(5.0), Some(13.0))),
      Observation(11,(Some(9.0), Some(14.0))),
      Observation(12,(Some(11.0), None)),
      Observation(14,(Some(1.0), Some(21.0)))
    )

    val expectedLeft = expectedOutput.mapValues(_._1)
    val expectedRight = expectedOutput.mapValues(_._2)

    val ts1 = input1.toTimeSeries.map(Option(_))
    val ts2 = input2.toTimeSeries

    val (left,right) = ts1.leftAlign(ts2)

    dVerifier.verifySeries(expectedLeft,left.collect)
    dVerifier.verifySeries(expectedRight,right.collect)
  }

  @Test def testLeftAlignWithInterpolation(): Unit = {
    val expectedOutput = Observations[(Option[Double],Option[Double])](
      Observation(1, (Some(2.0), Some(3.0))),
      Observation(3, (Some(3.0), Some(5.0))),
      Observation(7, (Some(5.0), Some(7.2))),
      Observation(8, (Some(8.0), Some(6.6))),
      Observation(10,(Some(5.0), Some(13.0))),
      Observation(11,(Some(9.0), Some(14.0))),
      Observation(12,(Some(11.0), Some(15.5))),
      Observation(14,(Some(1.0), Some(21.0)))
    )

    val expectedLeft = expectedOutput.mapValues(_._1)
    val expectedRight = expectedOutput.mapValues(_._2)

    val ts1 = input1.toTimeSeries.map(Option(_))
    val ts2 = input2.toTimeSeries

    val (left,right) = ts1.leftAlign(ts2)(Some(interpolate))

    dVerifier.verifySeries(expectedLeft,left.collect)
    dVerifier.verifySeries(expectedRight,right.collect)
  }
}
