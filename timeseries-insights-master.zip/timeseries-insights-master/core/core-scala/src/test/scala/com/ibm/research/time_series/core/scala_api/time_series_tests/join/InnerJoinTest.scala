/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.join

import com.ibm.research.time_series.core.scala_api.tools.{DoubleTupleTimeSeriesVerifier, ScalaDoubleTimeSeriesVerifier}
import com.ibm.research.time_series.core.scala_api.utils.Implicits.{Observation, _}
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

/**
  *
  * <p>Created on 8/23/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class InnerJoinTest extends AssertionsForJUnit {

  private val input1 = Observations(
    Observation[Double](1, 2.0),
    Observation[Double](3, 3.0),
    Observation[Double](7, 5.0),
    Observation[Double](8, 8.0),
    Observation[Double](10, 5.0),
    Observation[Double](11, 9.0),
    Observation[Double](12, 11.0),
    Observation[Double](14, 1.0)
  )
  private val input2 = Observations(
    Observation[Double](2, 3.0),
    Observation[Double](3, 5.0),
    Observation[Double](4, 9.0),
    Observation[Double](9, 6.0),
    Observation[Double](10, 13.0),
    Observation[Double](11, 14.0),
    Observation[Double](13, 17.0),
    Observation[Double](14, 21.0)
  )
  private val verifier = new DoubleTupleTimeSeriesVerifier
  private val dVerifier = new ScalaDoubleTimeSeriesVerifier

  @Before def initialize(): Unit = {
  }

  @Test def testInnerJoin(): Unit = {
    val expectedOutput = Observations(
      Observation[(Double,Double)](3,(3.0, 5.0)),
      Observation[(Double,Double)](10,(5.0, 13.0)),
      Observation[(Double,Double)](11,(9.0, 14.0)),
      Observation[(Double,Double)](14,(1.0, 21.0))
    )

    val ts = input1.toTimeSeries.innerJoin(input2.toTimeSeries)((x, y) => (x,y))

    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testInnerAlign(): Unit = {
    val expectedLeft = Observations(Observation(3,3.0),Observation(10,5.0),Observation(11,9.0),Observation(14,1.0))
    val expectedRight = Observations(Observation(3,5.0),Observation(10,13.0),Observation(11,14.0),Observation(14,21.0))

    val (left,right) = input1.toTimeSeries.innerAlign(input2.toTimeSeries)

    dVerifier.verifySeries(expectedLeft,left.collect)
    dVerifier.verifySeries(expectedRight,right.collect)
  }
}
