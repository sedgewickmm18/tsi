/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.map

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.utils.ObservationCollection
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit


/**
  *
  * <p>Created on 8/24/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class MapTest extends AssertionsForJUnit {
  private val verifier = new ScalaDoubleTimeSeriesVerifier
  private var ts : ObservationCollection[Double] = _

  @Before def initialize(): Unit = {
    ts = Observations(
      Observation(1, 2.0),
      Observation(3, 3.0),
      Observation(7, 5.0),
      Observation(8, 8.0),
      Observation(10, 5.0),
      Observation(11, 9.0),
      Observation(12, 11.0),
      Observation(14, 1.0)
    )
  }

  @Test def testMap(): Unit = {
    val expected = Observations(
      Observation(1, 3.0),
      Observation(3, 4.0),
      Observation(7, 6.0),
      Observation(8, 9.0),
      Observation(10, 6.0),
      Observation(11, 10.0),
      Observation(12, 12.0),
      Observation(14, 2.0)
    )
    val actual = ts.toTimeSeries.map(_ + 1)
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testMapObservation(): Unit = {
    val expected = Observations(
      Observation(2, 3.0),
      Observation(4, 4.0),
      Observation(8, 6.0),
      Observation(9, 9.0),
      Observation(11, 6.0),
      Observation(12, 10.0),
      Observation(13, 12.0),
      Observation(15, 2.0)
    )
    val actual = ts.toTimeSeries.mapObservation(obs => Observation(obs.getTimeTick+1,obs.getValue+1))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testFlatMapObservation(): Unit = {
    val expected = Observations(
      Observation(1, 2.0),
      Observation(1, 2.0),
      Observation(3, 3.0),
      Observation(3, 3.0),
      Observation(7, 5.0),
      Observation(7, 5.0),
      Observation(8, 8.0),
      Observation(8, 8.0),
      Observation(10, 5.0),
      Observation(10, 5.0),
      Observation(11, 9.0),
      Observation(11, 9.0),
      Observation(12, 11.0),
      Observation(12, 11.0),
      Observation(14, 1.0),
      Observation(14, 1.0)
    )
    val actual = ts.toTimeSeries.flatMapObservation(x => Array(x,x))
    verifier.verifySeries(expected,actual.collect)
  }

  @Test def testFlatMap(): Unit = {
    val expected = Observations(
      Observation(1, 2.0),
      Observation(1, 2.0),
      Observation(3, 3.0),
      Observation(3, 3.0),
      Observation(7, 5.0),
      Observation(7, 5.0),
      Observation(8, 8.0),
      Observation(8, 8.0),
      Observation(10, 5.0),
      Observation(10, 5.0),
      Observation(11, 9.0),
      Observation(11, 9.0),
      Observation(12, 11.0),
      Observation(12, 11.0),
      Observation(14, 1.0),
      Observation(14, 1.0)
    )
    val actual = ts.toTimeSeries.flatMap(x => Array(x,x))
    verifier.verifySeries(expected,actual.collect)
  }
}
