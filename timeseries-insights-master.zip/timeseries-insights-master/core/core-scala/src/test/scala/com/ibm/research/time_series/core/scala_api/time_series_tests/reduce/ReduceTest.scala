/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.reduce

import java.util

import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.transform.{BinaryReducer, NaryReducer, UnaryReducer}
import com.ibm.research.time_series.core.utils.{ObservationCollection, Segment}
import junit.framework.TestCase.assertEquals
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

import scala.collection.JavaConverters._

/**
  *
  * <p>Created on 8/24/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class ReduceTest extends AssertionsForJUnit {
  private var data: ObservationCollection[Double] = _
  private var data2: ObservationCollection[Double] = _
  private var data3: ObservationCollection[Double] = _

  val uReduce = new UnaryReducer[Double,Double] {
    override def reduceSegment(segment: Segment[Double]): Double = segment.size()
  }

  val bReduce = new BinaryReducer[Double,Double,Double] {
    override def reduceSegment
        (leftSegment: Segment[Double], rightSegment: Segment[Double]): Double = {
      leftSegment.size() + rightSegment.size()
    }
  }

  val nReduce = new NaryReducer[Double,Double] {
    override def reduceSegment(segments: util.List[Segment[Double]]): Double = {
      segments.asScala.map(_.size()).sum
    }
  }

  @Before def initialize(): Unit = {
    data = Observations(
      Observation(1, 2.0),
      Observation(2, 3.0),
      Observation(3, 4.0),
      Observation(4, 5.0),
      Observation(5, 6.0),
      Observation(6, 7.0)
    )
    data2 = Observations(
      Observation(1, 7.0),
      Observation(2, 6.0),
      Observation(3, 5.0),
      Observation(4, 4.0),
      Observation(5, 3.0)
    )
    data3 = Observations(
      Observation(2, 6.0),
      Observation(3, 5.0),
      Observation(4, 4.0),
      Observation(5, 3.0)
    )
  }

  @Test def testReduceWithLambda(): Unit = {
    val expected = 6.0
    assertEquals(expected,data.toTimeSeries.reduce(_.size()),.001)
  }

  @Test def testReduceWithUnaryReducer(): Unit = {
    val expected = 6.0
    assertEquals(expected,data.toTimeSeries.reduce(uReduce),.001)
  }

  @Test def testReduceWithUnaryReducerRange(): Unit = {
    val expected = 3.0
    assertEquals(expected,data.toTimeSeries.reduceRange(uReduce)(3,5),.001)
  }

  @Test def testReduceWithBinaryReducer(): Unit = {
    val expected = 11.0
    val actual = data.toTimeSeries.reduce(data2.toTimeSeries)(bReduce)
    assertEquals(expected,actual,.001)
  }

  @Test def testReduceWithBinaryReducerRange(): Unit = {
    val expected = 5.0
    val actual = data.toTimeSeries.reduceRange(data2.toTimeSeries)(bReduce)(4,6)
    assertEquals(expected,actual,.001)
  }

  @Test def testReduceWithNaryReduce(): Unit = {
    val expected = 15.0
    val actual = data.toTimeSeries.reduce(Array(data2.toTimeSeries,data3.toTimeSeries))(nReduce)
    assertEquals(expected,actual,.001)
  }

  @Test def testReduceWithNaryReduceRange(): Unit = {
    val expected = 8.0
    val actual = data.toTimeSeries.reduceRange(Array(data2.toTimeSeries,data3.toTimeSeries))(nReduce)(1,3)
    assertEquals(expected,actual,.001)
  }
}
