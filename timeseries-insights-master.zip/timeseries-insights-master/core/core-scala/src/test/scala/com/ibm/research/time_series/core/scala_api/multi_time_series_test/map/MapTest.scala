/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.multi_time_series_test.map

import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.utils.ObservationCollection
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit
import com.ibm.research.time_series.core.scala_api.utils.Implicits._

import scala.collection.mutable

/**
  *
  * <p>Created on 8/31/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class MapTest extends AssertionsForJUnit {
  private var mts: ScalaMultiTimeSeries[Int,Double] = _
  private val verifier = new ScalaDoubleTimeSeriesVerifier

  @Before def initialize(): Unit = {
    val input1 = Observations(
      Observation(1,2.0),
      Observation(3,3.0),
      Observation(7,5.0)
    )

    val input2 = Observations(
      Observation(2,2.0),
      Observation(3,3.0),
      Observation(8,6.0),
      Observation(10,7.0),
      Observation(11,5.0)
    )

    mts = MultiTimeSeries.fromObservationCollectionList(mutable.Buffer(input1,input2))
  }

  @Test def testMap(): Unit = {
    val expected = Map(
      0 -> Observations(Observation(1,1.0), Observation(3,2.0), Observation(7,4.0)),
      1 -> Observations(
        Observation(2,1.0),
        Observation(3,2.0),
        Observation(8,5.0),
        Observation(10,6.0),
        Observation(11,4.0)
      )
    )

    val actual = mts.map(_ - 1)

    actual.getTimeSeriesMap.foreach(x => {
      verifier.verifySeries(expected(x._1),x._2.collect)
    })
  }
}
