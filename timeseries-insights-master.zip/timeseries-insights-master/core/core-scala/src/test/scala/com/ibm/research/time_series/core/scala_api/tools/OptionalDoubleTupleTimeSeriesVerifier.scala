/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.tools

import com.ibm.research.time_series.core.tools.TimeSeriesVerifier
import junit.framework.TestCase.assertEquals

/**
  *
  * <p>Created on 8/23/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class OptionalDoubleTupleTimeSeriesVerifier extends TimeSeriesVerifier[(Option[Double],Option[Double])]{
  override protected def assertValuesEqual
      (
        expected: (Option[Double], Option[Double]),
        actual: (Option[Double], Option[Double])
      ): Unit = {
    if (expected._1.isDefined) {
      assertEquals(expected._1.get,actual._1.get,.01)
    } else {
      assertEquals(expected._1,actual._1)
    }

    if (expected._2.isDefined) {
      assertEquals(expected._2.get,actual._2.get,.01)
    } else {
      assertEquals(expected._2,actual._2)
    }
  }
}

class OptionalDoubleTimeSeriesVerifier extends TimeSeriesVerifier[Option[Double]] {
  override protected def assertValuesEqual
      (expected: Option[Double], actual: Option[Double]): Unit = {
    if (expected.isDefined) {
      assertEquals(expected.get,actual.get,.01)
    } else {
      assertEquals(expected,actual)
    }
  }
}
