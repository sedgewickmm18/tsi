/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.general_transforms

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit
import com.ibm.research.time_series.core.scala_api.utils.Implicits._

/**
  *
  * <p>Created on 8/22/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class FilterTest extends AssertionsForJUnit {
  private val verifier = new ScalaDoubleTimeSeriesVerifier
  private val input1 = Observations(
    Observation(1, 2.0),
    Observation(3, 3.0),
    Observation(7, 5.0),
    Observation(8, 8.0),
    Observation(10, 5.0),
    Observation(11, 9.0),
    Observation(12, 11.0),
    Observation(14, 1.0)
  )
  @Before def initialize(): Unit = {
  }

  @Test def testFilter(): Unit = {
    val expectedOutput = Observations(
      Observation(1,2.0),
      Observation(3,3.0),
      Observation(14,1.0)
    )

    val ts = TimeSeries.fromObservations(input1).filter(_ < 5)
    verifier.verifySeries(expectedOutput,ts.collect)
  }
}
