/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.time_series_tests.general

import java.io.File

import com.ibm.research.time_series.core.scala_api.tools.ScalaDoubleTimeSeriesVerifier
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import org.junit.{Before, Test}
import org.scalatest.junit.AssertionsForJUnit

/**
  *
  * <p>Created on 8/22/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class ConstructorTest extends AssertionsForJUnit {

  private val verifier = new ScalaDoubleTimeSeriesVerifier
  private val sVerifier = new StringTimeSeriesVerifier
  private val GPS_SPEED_FILE = new File("").getAbsolutePath + "/src/test/resources/gps_speed.txt"
  private val UNSORTED_FILE = new File("").getAbsolutePath + "/src/test/resources/unsorted.txt"

  @Before def initialize(): Unit = {

  }

  @Test def testFromObservationsConstructor(): Unit = {
    val input = Observations(Observation(3,5.0),Observation(10,6.0),Observation(7,7.0))
    val expectedOutput = Observations(Observation(3,5.0),Observation(7,7.0),Observation(10,6.0))
    val ts = TimeSeries.fromObservations(input)
    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testListValueConstructor(): Unit = {
    val expectedOutput = Observations(Observation(0,5.0),Observation(1,6.0),Observation(2,7.0))
    val ts = TimeSeries.list(List(5.0,6.0,7.0))
    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testListWithTimeStampConstructor(): Unit = {
    val expectedOutput = Observations(Observation(3,"3,5.0"),Observation(4,"4,6.0"),Observation(5,"5,7.0"))
    val ts = TimeSeries.list[String](List("3,5.0","4,6.0","5,7.0"),Some(_.split(",")(0).toLong))
    sVerifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testIterableValueConstructor(): Unit = {
    val expectedOutput = Observations(Observation(0,5.0),Observation(1,6.0),Observation(2,7.0))
    val ts = TimeSeries.iter(Array(5.0,6.0,7.0))
    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testIterableWithTimeStampConstructor(): Unit = {
    val expectedOutput = Observations(Observation(3,"3,5.0"),Observation(4,"4,6.0"),Observation(5,"5,7.0"))
    val ts = TimeSeries.iter[String](Array("3,5.0", "4,6.0", "5,7.0"),Some(_.split(",")(0).toLong))
    sVerifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testTextFileConstructor(): Unit = {
    val expectedOutput = Observations(
      Observation(5,1331667611538D),
      Observation(6,1331667612429D),
      Observation(7,1331667613474D)
    )

    val ts = TimeSeries.textFileValues(GPS_SPEED_FILE, s => Some(s.split(",")(0).toDouble))
    verifier.verifySeries(expectedOutput,ts.getValues(5,7))
  }

  @Test def testUnsortedTextFile(): Unit = {
    val expectedOutput = Observations(
      Observation(2,2.0),
      Observation(4,2.0),
      Observation(15,1.0),
      Observation(17,3.0),
      Observation(18,5.0)
    )

    val ts = TimeSeries.textFile(UNSORTED_FILE,s => Some(Observation(s.split(",")(0).toLong,s.split(",")(1).toDouble)),true)

    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testUnsortedTextFileSkipLines(): Unit = {
    val expectedOutput = Observations(
      Observation(2,2.0),
      Observation(4,2.0),
      Observation(17,3.0),
      Observation(18,5.0)
    )

    val ts = TimeSeries.textFile(UNSORTED_FILE,s => Some(Observation(s.split(",")(0).toLong,s.split(",")(1).toDouble)),true)(skipNumLines = 1)

    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testUnsortedTextFileArtificialTimestamps(): Unit = {
    val expectedOutput = Observations(
      Observation(0,1.0),
      Observation(1,3.0),
      Observation(2,2.0),
      Observation(3,5.0),
      Observation(4,2.0)
    )

    val ts = TimeSeries.textFileValues(UNSORTED_FILE, s => Some(s.split(",")(1).toDouble))

    verifier.verifySeries(expectedOutput,ts.collect)
  }

  @Test def testUnsortedTextFileArtificialTimestampsAndSkipLines(): Unit = {
    val expectedOutput = Observations(
      Observation(0,5.0),
      Observation(1,2.0)
    )

    val ts = TimeSeries.textFileValues(UNSORTED_FILE, s => Some(s.split(",")(1).toDouble))(skipNumLines = 3)

    verifier.verifySeries(expectedOutput,ts.collect)
  }

//  @Test def testCSV(): Unit = {
//    val expectedOutput = Observations(
//      Observation(1331667606731L,40.08918737661366),
//      Observation(1331667607486L,40.08918737661366),
//      Observation(1331667608471L,40.08918737661366)
//    )
//
//    val ts = TimeSeries.csv(GPS_SPEED_FILE)(_(0).toLong,_(1).toDouble)
//
//    verifier.verifyOutput(1331667606731L,1331667608471L,BlockMode.NON_BLOCK,expectedOutput,ts.ts)
//  }
//
//  @Test def testUnsortedCSV(): Unit = {
//    val expectedOutput = Observations(
//      Observation(2,2.0),
//      Observation(4,2.0),
//      Observation(15,1.0),
//      Observation(17,3.0),
//      Observation(18,5.0)
//    )
//
//    val ts = TimeSeries.csv(UNSORTED_FILE)(_(0).toLong,_(1).toDouble)(sort = true)
//
//    verifier.verifySeries(expectedOutput,ts.collect)
//  }
//
//  @Test def testUnsortedCSVSkipLines(): Unit = {
//    val expectedOutput = Observations(
//      Observation(2,2.0),
//      Observation(4,2.0),
//      Observation(17,3.0),
//      Observation(18,5.0)
//    )
//
//    val ts = TimeSeries.csv(UNSORTED_FILE)(_(0).toLong,_(1).toDouble)(skipNumLines = 1,sort = true)
//
//    verifier.verifySeries(expectedOutput,ts.collect)
//  }


//
//  @Test
//  public void testUnsortedCSVSkipLines() throws Exception {
//    ObservationCollection<Double> expected = Observations.<Double>newBuilder()
//      .add(2,2.0)
//      .add(4,2.0)
//      .add(17,3.0)
//      .add(18,5.0)
//      .result();
//
//    TimeSeries<Double> ts = TimeSeries.csv(
//      UNSORTED_FILE,
//      ",",
//      x -> Long.valueOf(x[0]),
//    x -> Double.valueOf(x[1]),
//    1,
//    true
//    );
//
//    verifier.verifySeries(expected,ts.collect());
//  }

}
