/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.timeseries

import com.ibm.research.time_series.core.core_transforms.general.{GeneralTransformers, InterpolationTransform}
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers
import com.ibm.research.time_series.core.observation.Observation
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.timeseries.{ObservationValueIterable, SegmentTimeSeries}
import com.ibm.research.time_series.core.transform.{BinaryReducer, NaryReducer, UnaryTransform}
import com.ibm.research.time_series.core.utils.{ObservationCollection, Segment}
import com.ibm.research.time_series.core.scala_api.utils.Implicits._

import scala.collection.JavaConverters._
import scala.reflect.ClassTag

/**
  *
  * <p>Created on 5/23/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class SegmentTimeSeriesFunctions[V:ClassTag](timeSeries: ScalaTimeSeries[Segment[V]]) {

  def transformSegments[V2:ClassTag](transform:UnaryTransform[V,V2]): ScalaTimeSeries[Segment[V2]] = {
    timeSeries.map(segment => {
      Segment.fromSeries(
        segment.start,
        segment.end,
        TimeSeries.fromObservations(segment).transform(transform).collect
      )
    })
  }

  def mapSegments[V2:ClassTag](f: V => V2) : ScalaTimeSeries[Segment[V2]] = {
    transformSegments[V2](MapTransformers.unaryMap[V,V2](TSFunctionUtils.uMapFunction(f)))
  }

  def mapSegmentObservations[V2:ClassTag]
  (f: Observation[V] => Observation[V2]): ScalaTimeSeries[Segment[V2]] = {
    transformSegments[V2](MapTransformers.unaryMapObservation[V,V2](TSFunctionUtils.uMapObsFunction(f)))
  }

  def interpolateSegments
  (period: Long)
  (
    interpolator: (ObservationCollection[V], ObservationCollection[V], Long) => V
  ): ScalaTimeSeries[Segment[V]] = {
    transformSegments[V](
      GeneralTransformers.interpolate[V](
        period.toInt,
        TSFunctionUtils.interpolateFunction(Some(interpolator)),
        true
      )
    )
  }

  def reduceSegments[V2:ClassTag](f: Iterable[V] => V2): ScalaTimeSeries[V2] = {
    import com.ibm.research.time_series.core.scala_api.utils.Implicits._
    timeSeries.map(segment => f(segment.asScala.map(_.value)))
  }

  def transform[V2:ClassTag,V3:ClassTag]
      (other: ScalaTimeSeries[Segment[V2]])(reducer: BinaryReducer[V,V2,V3]): ScalaTimeSeries[V3] = {
    new ScalaTimeSeries[V3](
      timeSeries.ts.asInstanceOf[SegmentTimeSeries[V]].transform(other.ts,reducer)
    )
  }

  def transform[V2:ClassTag]
      (tsArray: Array[ScalaTimeSeries[Segment[V]]])
      (reducer: NaryReducer[V,V2]): ScalaTimeSeries[V2] = {
    new ScalaTimeSeries[V2](
      timeSeries.ts.asInstanceOf[SegmentTimeSeries[V]]
        .transform(tsArray.map(_.ts).toBuffer.asJava,reducer)
    )
  }

  def flatten[K](keyOp: Segment[V] => K,inclusive: Boolean): ScalaMultiTimeSeries[K,V] = {
    new ScalaMultiTimeSeries[K,V](
      timeSeries.ts.asInstanceOf[SegmentTimeSeries[V]].flatten(TSFunctionUtils.uMapFunction(keyOp), inclusive)
    )
  }

  def flatten[K](keyOp: Segment[V] => K): ScalaMultiTimeSeries[K,V] = {
    flatten(keyOp, false)
  }

  def flatten(inclusive: Boolean = false): ScalaMultiTimeSeries[Long,V] = {
    flatten(seg => seg.start,inclusive)
  }
}
