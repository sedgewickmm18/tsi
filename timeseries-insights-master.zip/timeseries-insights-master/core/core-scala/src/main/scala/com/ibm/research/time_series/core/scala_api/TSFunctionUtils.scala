/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api

import java.util.Optional
import java.util.function.{Function => JFunction}
import java.{lang, util}

import com.ibm.research.time_series.core.functions._
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.utils
import com.ibm.research.time_series.core.utils.ObservationCollection

import scala.collection.JavaConverters._

/**
  * A set of utilities for converting java functions to scala functions
  * <p>Created on 3/18/17.</p>
  *
  * @author Joshua Rosenkranz
  */
object TSFunctionUtils {

  def uMapFunction[T,T2](f: T => T2) : UnaryMapFunction[T,T2] = {
    new UnaryMapFunction[T,T2] {
      override def evaluate(input: T): T2 = f.apply(input)
    }
  }

  def uMapFunctionOptional[T,T2](f: T => Option[T2]): UnaryMapFunction[T, Optional[T2]] = {
    new UnaryMapFunction[T, Optional[T2]] {
      /**
       * evaluate an expression that takes one input and returns a single output
       *
       * @param x - the input
       * @return a single output represented from the result of the mapping logic on the input
       */
      override def evaluate(x: T): Optional[T2] = {
        val opt = f(x)
        if (opt.isDefined)
          Optional.of(opt.get)
        else
          Optional.empty()
      }
    }
  }

  def uMapWithIndexFunction[T,T2](f: (Int,T) => T2): BinaryMapFunction[java.lang.Integer,T,T2] = {
    new BinaryMapFunction[java.lang.Integer,T,T2] {
      override def evaluate(x: java.lang.Integer,y: T): T2 = {
        f(x,y)
      }
    }
  }

  def bMapFunction[T,T2,T3](f: (T,T2) => T3) : BinaryMapFunction[T,T2,T3] = {
    new BinaryMapFunction[T,T2,T3] {
      override def evaluate(input1: T, input2: T2): T3 = f.apply(input1,input2)
    }
  }

  def nMapFunction[T,T2](f: Iterable[T] => T2) : NaryMapFunction[T,T2] = {
    new NaryMapFunction[T,T2] {
      override def evaluate(list: util.List[T]): T2 = f.apply(list.asScala)
    }
  }

  def filterFunction[T](f: T => Boolean) : FilterFunction[T] = {
    new FilterFunction[T] {
      override def evaluate(t: T) : Boolean = f.apply(t)
    }
  }

  def interpolateFunction[T]
      (
        f: Option[(ObservationCollection[T], ObservationCollection[T], Long) => T],
        historySize: Int = 1,
        futureSize: Int = 1
      ) : Interpolator[T] = {
    if (f.isEmpty) {
      new Interpolator[T] {
        /**
          * resample a value for a given timestamp
          *
          * @param history   history observations
          * @param future    future observations
          * @param timestamp timestamp to compute value at
          * @return a value signifying the result of interpolation at a given timestamp
          */
        override def interpolate
            (
              history: ObservationCollection[T],
              future: ObservationCollection[T],
              timestamp: Long
            ): T = null.asInstanceOf[T]

        override def getHistorySize: Int = historySize

        override def getFutureSize: Int = futureSize
      }
    } else {
      new Interpolator[T] {
        override def interpolate
            (
              history: ObservationCollection[T],
              future: ObservationCollection[T],
              timeStamp: Long
            ): T = {
          f.get.apply(history, future, timeStamp)
        }
        override def getHistorySize: Int = historySize

        override def getFutureSize: Int = futureSize
      }
    }
  }

  def uMapObsFunction[T,T2](f: Observation[T] => Observation[T2]) : UnaryMapFunction[Observation[T],Observation[T2]] = {
    new UnaryMapFunction[Observation[T],Observation[T2]] {
      override def evaluate(x: Observation[T]): Observation[T2] = {
        f.apply(x)
      }
    }
  }

  def uFlatMapObsFunction[T,T2]
      (
        f: Observation[T] => Iterable[Observation[T2]]
      ) : UnaryMapFunction[Observation[T],java.lang.Iterable[Observation[T2]]] = {
    new UnaryMapFunction[Observation[T],java.lang.Iterable[Observation[T2]]] {
      /**
        * evaluate an expression that takes one input and returns a single output
        *
        * @param x - the input
        * @return a single output represented from the result of the mapping logic on the input
        */
      override def evaluate(x: Observation[T]): lang.Iterable[Observation[T2]] = f.apply(x).asJava
    }
  }

  def jFunction[T,T2](f: T => T2) : JFunction[T,T2] = {
    new JFunction[T,T2] {
      override def apply(t: T): T2 = f.apply(t)
    }
  }

}
