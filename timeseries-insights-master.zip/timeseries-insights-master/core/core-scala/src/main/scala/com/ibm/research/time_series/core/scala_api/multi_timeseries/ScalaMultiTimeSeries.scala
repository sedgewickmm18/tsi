/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.multi_timeseries

import java.io.OutputStream
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit
import java.util.function.Function

import com.ibm.research.time_series.core.cache.Cache
import com.ibm.research.time_series.core.constants.{Padding, ResultingTimeStamp}
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers
import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel
import com.ibm.research.time_series.core.functions.Interpolator
import com.ibm.research.time_series.core.io.{MultiTimeSeriesReader, MultiTimeSeriesWriter}
import com.ibm.research.time_series.core.timeseries.{MultiTimeSeries => JavaMultiTimeSeries}
import com.ibm.research.time_series.core.observation.Observation
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.core.timeseries.{MultiTimeSeries, TimeSeries}
import com.ibm.research.time_series.core.transform.{BinaryTransform, NaryTransform, UnaryReducer, UnaryTransform}
import com.ibm.research.time_series.core.utils.{ObservationCollection, Prediction, Segment, TRS}

import scala.collection.JavaConverters._
import scala.collection.mutable
import scala.reflect.ClassTag


/**
  *
  * <p>Created on 3/27/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class ScalaMultiTimeSeries[K,T](multiTimeSeries: MultiTimeSeries[K,T]){
  val mts : MultiTimeSeries[K,T] = multiTimeSeries

  def write(start: Long, end:Long, inclusive: Boolean): MultiTimeSeriesWriter[K,T] = {
    multiTimeSeries.write(start,end,inclusive)
  }

  def write(start: Long, end: Long): MultiTimeSeriesWriter[K,T] = {
    multiTimeSeries.write(start,end)
  }

  def write(inclusive: Boolean): MultiTimeSeriesWriter[K,T] = {
    multiTimeSeries.write(inclusive)
  }

  def write(): MultiTimeSeriesWriter[K,T] = {
    multiTimeSeries.write()
  }

  def keys: Set[K] = Set(multiTimeSeries.getKeys.asScala.toSeq :_*)

  def timeSeries(key: K): ScalaTimeSeries[T] = new ScalaTimeSeries[T](multiTimeSeries.getTimeSeries(key))

  def trs(key: K): Option[TRS] = Option(multiTimeSeries.getTRS(key))

  def collect(implicit inclusive: Boolean = false): Map[K,ObservationCollection[T]] = {
    multiTimeSeries.collect(inclusive).asScala.toMap
  }

  def getTimeSeriesMap: Map[K, ScalaTimeSeries[T]] = {
    val mapBuilder = Map.newBuilder[K,ScalaTimeSeries[T]]
    multiTimeSeries.getTimeSeriesMap.asScala.foreach(entry => {
      mapBuilder.+=((entry._1,new ScalaTimeSeries[T](entry._2)))
    })
    mapBuilder.result()
  }

  /**
    * gets a list of the evaluated series of Observations from a given time range of t1 to t2
    * <p>Note: Each series is executed in parallel on a single JVM</p>
    *
    * @param t1        time stamp start
    * @param t2        time stamp end
    * @return resulting List of NavigableSets of TimeStampSensors
    */
  def getValues
      (t1: Long, t2: Long, inclusive: Boolean = false): Map[K, ObservationCollection[T]] = {
    multiTimeSeries.getValues(t1,t2,inclusive).asScala.toMap
  }

  def print(): Unit = {
    multiTimeSeries.print()
  }

  /**
    * print each series and its evaluated list of Observations.
    *
    * @param t1        time stamp start
    * @param t2        time stamp end
    */
  def print(t1: Long, t2: Long, inclusive: Boolean=false): Unit = {
    multiTimeSeries.print(t1,t2,inclusive)
  }

  def transform[T2](transform_on: UnaryTransform[T, T2]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](multiTimeSeries.transform(transform_on))
  }

  def transform[T2, T3]
      (timeSeries: ScalaTimeSeries[T2])
      (binaryTransform: BinaryTransform[T, T2, T3]): ScalaMultiTimeSeries[K, T3] = {
    new ScalaMultiTimeSeries[K,T3](multiTimeSeries.transform(timeSeries.ts,binaryTransform))
  }

  def transform[T2]
      (timeSeriesList: mutable.Buffer[ScalaTimeSeries[T]])
      (naryTransform: NaryTransform[T, T2]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.transform(timeSeriesList.map(_.ts).asJava,naryTransform)
    )
  }

  def withTRS(trs: TRS): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.withTRS(trs))
  }

  def pairWiseTransform[T2](binaryTransform: BinaryTransform[T,T,T2]): ScalaMultiTimeSeries[(K,K),T2] = {
    val javaPairWiseMTS = new JavaMultiTimeSeries(
      multiTimeSeries.pairWiseTransform(binaryTransform).getTimeSeriesMap.asScala.map(x => ((x._1.left,x._1.right),x._2)).toMap.asJava
    )
    new ScalaMultiTimeSeries[(K,K),T2](javaPairWiseMTS)
  }

  def resample
      (period: Long)
      (
        interpolator: (ObservationCollection[T], ObservationCollection[T], Long) => T,
        historySize: Int = 1,
        futureSize: Int = 1
      ): ScalaMultiTimeSeries[K, T] = {
    new ScalaMultiTimeSeries[K,T](
      multiTimeSeries.resample(
        period,
        TSFunctionUtils.interpolateFunction[T](Some(interpolator),historySize,futureSize)
      )
    )
  }

  def resample
  (period: Long, interpolator: Interpolator[T]): ScalaMultiTimeSeries[K, T] = {
    new ScalaMultiTimeSeries[K,T](
      multiTimeSeries.resample(
        period,
        interpolator
      )
    )
  }

  def filterSeriesKey(filterFunction: K => Boolean): ScalaMultiTimeSeries[K, T] = {
    new ScalaMultiTimeSeries[K,T](
      multiTimeSeries.filterSeriesKey(TSFunctionUtils.filterFunction(filterFunction))
    )
  }

  def filterSeries(filterFunction: ScalaTimeSeries[T] => Boolean): ScalaMultiTimeSeries[K, T] = {
    new ScalaMultiTimeSeries[K,T](
      multiTimeSeries.filterSeries(TSFunctionUtils.filterFunction(x => filterFunction(new ScalaTimeSeries[T](x))))
    )
  }

  def filter(filterFunction: T => Boolean): ScalaMultiTimeSeries[K, T] = {
    new ScalaMultiTimeSeries[K,T](
      multiTimeSeries.filter(TSFunctionUtils.filterFunction(filterFunction))
    )
  }

  def segment(window: Long,step: Long,enforceSize: Boolean): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segment(window,step,enforceSize)
    )
  }

  def segment(window: Long,step: Long): ScalaMultiTimeSeries[K,Segment[T]] = {
    segment(window,step,enforceSize = true)
  }

  def segment(window: Long): ScalaMultiTimeSeries[K,Segment[T]] = {
    segment(window,window,enforceSize = true)
  }

  def segmentByTime
      (
        window: Long,
        step: Long,
        padding: Padding = Padding.RIGHT,
        resultingTimeStamp: ResultingTimeStamp = ResultingTimeStamp.START_OF_WINDOW
      ): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segmentByTime(window,step,padding,resultingTimeStamp)
    )
  }

  def segmentByAnchor
      (anchor: T => Boolean)
      (leftDelta: Long,rightDelta: Long): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segmentByAnchor(TSFunctionUtils.filterFunction(anchor),leftDelta,rightDelta)
    )
  }

  def segmentBy[KEY](groupByOp: Observation[T] => KEY): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segmentBy(TSFunctionUtils.uMapFunction(groupByOp))
    )
  }

  def segmentByChangePoint(isChangeOp: (T,T) => Boolean): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segmentByChangePoint(TSFunctionUtils.bMapFunction((x,y) => isChangeOp(x,y).asInstanceOf[java.lang.Boolean]))
    )
  }

  def segmentByChangePoint(): ScalaMultiTimeSeries[K,Segment[T]] = {
    new ScalaMultiTimeSeries[K,Segment[T]](
      multiTimeSeries.segmentByChangePoint()
    )
  }

  def flatMapObservation[T2]
      (f: Observation[T] => Iterable[Observation[T2]]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.flatMapObservation(TSFunctionUtils.uFlatMapObsFunction(f))
    )
  }

  def mapSeries[T2](f: ObservationCollection[T] => ObservationCollection[T2]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.mapSeries(TSFunctionUtils.uMapFunction(f))
    )
  }

  def mapSeriesKey[K2](keyOp: K => K2): ScalaMultiTimeSeries[K2, T] = {
    new ScalaMultiTimeSeries[K2,T](multiTimeSeries.mapSeriesKey(TSFunctionUtils.uMapFunction(keyOp)))
  }

  def mapObservation[T2]
      (f: Observation[T] => Observation[T2]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.mapObservation(TSFunctionUtils.uMapObsFunction(f))
    )
  }

  def map[T2](f: T => T2): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.map(TSFunctionUtils.uMapFunction(f))
    )
  }

  def mapSeriesWithKey[T2](f: (K,ObservationCollection[T]) => ObservationCollection[T2]): ScalaMultiTimeSeries[K, T2] = {
    new ScalaMultiTimeSeries[K,T2](
      multiTimeSeries.mapSeriesWithKey(TSFunctionUtils.uMapFunction(x => f(x.left,x.right)))
    )
  }

  def size(): Int = multiTimeSeries.size()

  def align(key: K)(implicit interpolator: Option[(ObservationCollection[T], ObservationCollection[T], Long) => T] = None, historySize: Int = 1, futureSize: Int = 1): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.align(key, TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)))
  }

  def align(key: K, interpolator: Interpolator[T]): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.align(key,interpolator))
  }

  def innerAlign[T2]
      (
        multiTimeSeries: ScalaMultiTimeSeries[K,T2]
      ): (ScalaMultiTimeSeries[K,T],ScalaMultiTimeSeries[K,T2]) = {
    val transformed = mts.innerAlign(multiTimeSeries.mts)
    (
      new ScalaMultiTimeSeries[K,T](transformed.left),
      new ScalaMultiTimeSeries[K,T2](transformed.right)
    )
  }

  def innerJoin[T2,T3]
      (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
      (f: (T,T2) => T3): ScalaMultiTimeSeries[K,T3] = {
    new ScalaMultiTimeSeries[K,T3](
      mts.innerJoin(multiTimeSeries.mts,TSFunctionUtils.bMapFunction(f))
    )
  }

  def fullAlign[T2]
      (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
      (
        implicit
        leftInterpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
        = None,
        rightInterpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
        = None,
        leftHistorySize: Int = 1,
        leftFutureSize: Int = 1,
        rightHistorySize: Int = 1,
        rightFutureSize: Int = 1
      ): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.fullAlign(
        multiTimeSeries.mts,
        TSFunctionUtils.interpolateFunction(leftInterpolator,leftHistorySize,leftFutureSize),
        TSFunctionUtils.interpolateFunction(rightInterpolator,rightHistorySize,rightFutureSize)
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )
  }

  def fullAlign[T2]
  (
    multiTimeSeries: ScalaMultiTimeSeries[K,T2],
    leftInterpolator: Interpolator[T],
    rightInterpolator: Interpolator[T2]
  ): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.fullAlign(
        multiTimeSeries.mts,
        leftInterpolator,
        rightInterpolator
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )
  }

  def fullJoin[T2,T3]
      (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
      (f: (Option[T],Option[T2]) => T3)
      (
        implicit
        leftInterpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
        = None,
        rightInterpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
        = None,
        leftHistorySize: Int = 1,
        leftFutureSize: Int = 1,
        rightHistorySize: Int = 1,
        rightFutureSize: Int = 1
      ): ScalaMultiTimeSeries[K,T3] = {

    val javaCombine : (T, T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,Some(t2))
      else if (t2 == null)
        f(Some(t),None)
      else
        f(Some(t),Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.fullJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(leftInterpolator,leftHistorySize,leftFutureSize),
        TSFunctionUtils.interpolateFunction(rightInterpolator,rightHistorySize,rightFutureSize)
      )
    )
  }

  def fullJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],f: (Option[T],Option[T2]) => T3, leftInterpolator: Interpolator[T], rightInterpolator: Interpolator[T2]): ScalaMultiTimeSeries[K,T3] = {

    val javaCombine : (T, T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,Some(t2))
      else if (t2 == null)
        f(Some(t),None)
      else
        f(Some(t),Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.fullJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        leftInterpolator,
        rightInterpolator
      )
    )
  }

  def leftAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaMultiTimeSeries[K,T],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.leftAlign(
        multiTimeSeries.mts,
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => x),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )

  }

  def leftAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],interpolator:Interpolator[T2]): (ScalaMultiTimeSeries[K,T],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.leftAlign(
        multiTimeSeries.mts,
        interpolator
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => x),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )

  }

  def leftJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (f: (T,Option[T2]) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2] = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        f(t,None)
      else
        f(t,Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.leftJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )
  }

  def leftJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],f: (T,Option[T2]) => T3, interpolator: Interpolator[T2]): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        f(t,None)
      else
        f(t,Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.leftJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }

  def rightAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,T2]) = {
    val (left,right) = {
      val pair = mts.rightAlign(
        multiTimeSeries.mts,
        TSFunctionUtils.interpolateFunction(interpolator, historySize, futureSize)
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => x)
    )

  }

  def rightAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2], interpolator: Interpolator[T]): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,T2]) = {
    val (left,right) = {
      val pair = mts.rightAlign(
        multiTimeSeries.mts,
        interpolator
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => x)
    )

  }

  def rightJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (f: (Option[T],T2) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,t2)
      else
        f(Some(t),t2)
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.rightJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator, historySize, futureSize)
      )
    )
  }

  def rightJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],f: (Option[T],T2) => T3, interpolator: Interpolator[T]): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,t2)
      else
        f(Some(t),t2)
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.rightJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }


  ///////


  def leftOuterAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaMultiTimeSeries[K,T],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.leftOuterAlign(
        multiTimeSeries.mts,
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => x),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )

  }

  def leftOuterAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],interpolator:Interpolator[T2]): (ScalaMultiTimeSeries[K,T],ScalaMultiTimeSeries[K,Option[T2]]) = {
    val (left,right) = {
      val pair = mts.leftOuterAlign(
        multiTimeSeries.mts,
        interpolator
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => x),
      new ScalaMultiTimeSeries[K,T2](right).map(x => Option(x))
    )

  }

  def leftOuterJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (f: (T,Option[T2]) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2] = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        f(t,None)
      else
        f(t,Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.leftOuterJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )
  }

  def leftOuterJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],f: (T,Option[T2]) => T3, interpolator: Interpolator[T2]): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        f(t,None)
      else
        f(t,Some(t2))
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.leftOuterJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }

  def rightOuterAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,T2]) = {
    val (left,right) = {
      val pair = mts.rightOuterAlign(
        multiTimeSeries.mts,
        TSFunctionUtils.interpolateFunction(interpolator, historySize, futureSize)
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => x)
    )

  }

  def rightOuterAlign[T2]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2], interpolator: Interpolator[T]): (ScalaMultiTimeSeries[K,Option[T]],ScalaMultiTimeSeries[K,T2]) = {
    val (left,right) = {
      val pair = mts.rightOuterAlign(
        multiTimeSeries.mts,
        interpolator
      )
      (pair.left,pair.right)
    }

    (
      new ScalaMultiTimeSeries[K,T](left).map(x => Option(x)),
      new ScalaMultiTimeSeries[K,T2](right).map(x => x)
    )

  }

  def rightOuterJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2])
  (f: (Option[T],T2) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,t2)
      else
        f(Some(t),t2)
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.rightOuterJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator, historySize, futureSize)
      )
    )
  }

  def rightOuterJoin[T2,T3]
  (multiTimeSeries: ScalaMultiTimeSeries[K,T2],f: (Option[T],T2) => T3, interpolator: Interpolator[T]): ScalaMultiTimeSeries[K,T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        f(None,t2)
      else
        f(Some(t),t2)
    }

    new ScalaMultiTimeSeries[K,T3](
      mts.rightOuterJoin(
        multiTimeSeries.mts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }

  def aggregate[T2](zero: T2)(seqOp: (T2,ScalaTimeSeries[T]) => T2,combOp: (T2,T2) => T2): T2 = {
    multiTimeSeries.aggregate[T2](
      zero,
      TSFunctionUtils.bMapFunction[T2,TimeSeries[T],T2]((t2,ts) => seqOp(t2,new ScalaTimeSeries[T](ts))),
      TSFunctionUtils.bMapFunction[T2,T2,T2](combOp)
    )
  }

  def aggregateSeries[T2](transform: NaryTransform[T, T2]): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](multiTimeSeries.aggregateSeries(transform))
  }

  def aggregateSeries[T2](f: Iterable[T] => T2): ScalaTimeSeries[T2] = {
    aggregateSeries(MapTransformers.naryMap(TSFunctionUtils.nMapFunction(f)))
  }

  def aggregateSeriesWithKey[T2](f: Iterable[(K,T)] => T2): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](
      multiTimeSeries.aggregateSeriesWithKey(
        TSFunctionUtils.uMapFunction[java.util.List[com.ibm.research.time_series.core.utils.Pair[K,T]],T2](l => {
          f(l.asScala.map(x => (x.left,x.right)))
        })
      )
    )
  }

  def reduce[T2](reducer: UnaryReducer[T,T2]): Map[K,T2] = {
    multiTimeSeries.reduce(reducer).asScala.toMap
  }

  def reduceRange[T2](reducer: UnaryReducer[T,T2])(start:Long,end:Long,inclusive: Boolean): Map[K,T2] = {
    multiTimeSeries.reduceRange(reducer,start,end,inclusive).asScala.toMap
  }

  def reduce[T2](reducer: ObservationCollection[T] => T2): Map[K,T2] = {
    multiTimeSeries.reduce(
      TSFunctionUtils.uMapFunction[ObservationCollection[T],T2](ts => reducer(ts))
    ).asScala.toMap
  }

  def reduceRange[T2](reducer: ObservationCollection[T] => T2)(start:Long,end:Long,inclusive: Boolean): Map[K,T2] = {
    multiTimeSeries.reduceRange(
      TSFunctionUtils.uMapFunction[ObservationCollection[T],T2](ts => reducer(ts)),start,end,inclusive
    ).asScala.toMap
  }

  def cache(): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.cache())
  }

  def cache(maxSize: Int): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.cache(maxSize))
  }

  def userDefinedCache(cacheMap: Map[K,Cache[T]], maxSize: Int = Int.MaxValue): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.userDefinedCache(cacheMap.asJava,maxSize))
  }

  def uncache(): ScalaMultiTimeSeries[K,T] = {
    new ScalaMultiTimeSeries[K,T](multiTimeSeries.uncache())
  }

  def getMaximumCacheSizes: Map[K, Integer] = {
    val mapBuilder = Map.newBuilder[K,Integer]
    multiTimeSeries.getMaximumCacheSizes.asScala.foreach(entry => {
      mapBuilder.+=((entry._1,entry._2))
    })
    mapBuilder.result()
  }

  def getCaches: Map[K, Iterator[Observation[T]]] = {
    val mapBuilder = Map.newBuilder[K,Iterator[Observation[T]]]
    multiTimeSeries.getCaches.asScala.foreach(entry => {
      mapBuilder.+=((entry._1,entry._2.asScala))
    })
    mapBuilder.result()
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T], startTime: Long, confidence: Double): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions, model, startTime, confidence).asScala.toMap
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T], startTime: Long): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions, model, startTime, 1.0).asScala.toMap
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T], confidence: Double): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions,model, confidence).asScala.toMap
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T]): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions,model, 1.0).asScala.toMap
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T], startZDT: ZonedDateTime, confidence: Double): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions, model, startZDT, confidence).asScala.toMap
  }

  def forecast(numPredictions: Int, model: ObservationForecastingModel[T], startZDT: ZonedDateTime): Map[K, ObservationCollection[Prediction[T]]] = {
    multiTimeSeries.forecast(numPredictions, model, startZDT, 1.0).asScala.toMap
  }

  override def toString: String = multiTimeSeries.toString
}

object ScalaMultiTimeSeries {
  implicit def toSegmentMultiTimeSeriesFunctions[K,T]
      (mts: ScalaMultiTimeSeries[K,Segment[T]])
      (implicit ktag: ClassTag[K],vtag: ClassTag[T]): ScalaSegmentMultiTimeSeriesFunctions[K,T] = {
    new ScalaSegmentMultiTimeSeriesFunctions[K,T](mts)
  }
}
