/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.utils

import java.io.InputStream
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZoneId, ZonedDateTime}
import java.util
import java.util.{Optional, Properties}
import java.util.concurrent.TimeUnit

import com.ibm.research.time_series.core.core_transforms.duplicate.DuplicateTransformers
import com.ibm.research.time_series.core.core_transforms.general.{GeneralReducers, Stats}
import com.ibm.research.time_series.core.functions.UnaryMapFunction
import com.ibm.research.time_series.core.io.{MultiTimeSeriesReader, TimeSeriesReader}
import com.ibm.research.time_series.core.observation.{Observation => JavaObservation}
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.core_transforms.interpolation.GenericInterpolators
import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.core.timeseries.{TimeSeries => JavaTimeSeries}
import com.ibm.research.time_series.core.utils._
import com.ibm.research.time_series.core.timeseries.{MultiTimeSeries => JavaMultiTimeSeries}

import scala.collection.JavaConverters._
import scala.collection.generic.CanBuildFrom
import scala.collection.{SetLike, SortedSet, SortedSetLike, mutable}
import scala.concurrent.duration.{Duration, TimeUnit}

/**
  * This is all experimental and subject to change
  *
  * a scala friendly set of implicits
  * <p>Created on 8/17/17.</p>
  *
  * @author Joshua Rosenkranz
  */
object Implicits {

  type Observation[T] = com.ibm.research.time_series.core.observation.Observation[T]

  implicit object Observations {
    def empty[T](): ObservationCollection[T] = {
      new TSBuilder[T].result()
    }

    def apply[T](observations: Observation[T]*): ObservationCollection[T] = {
      new TSBuilder[T].addAll(observations.asJava).result()
    }

    def newBuilder[V]: TSBuilder[V] = {
      new TSBuilder[V]
    }
  }

  implicit object TimeSeries {
    def apply[T](vector: Iterable[T])(implicit trs: Option[TRS]=None): ScalaTimeSeries[T] = {
      list(vector.toList)(trs)
    }

    def objectFile[T](inputStream: InputStream): ScalaTimeSeries[T] = {
      new ScalaTimeSeries[T](JavaTimeSeries.objectFile(inputStream))
    }

    def csv
        (path: String, timestampColumn: String, sort: Boolean = false)
        (
          implicit
          header: Boolean = true,
          delim: String = ",",
          timestampFormat: Option[DateTimeFormatter]=None,
          trs: Option[TRS] = None
        ): ScalaTimeSeries[Map[String,String]] = {
      new ScalaTimeSeries[java.util.Map[String, String]](
        JavaTimeSeries.csv(path,timestampColumn,sort,header,delim,timestampFormat.orNull,trs.orNull)
      )
        .map(_.asScala.toMap)
    }

    def csvValues
    (path: String)
    (
      implicit
      header: Boolean = true,
      delim: String = ",",
      trs: Option[TRS] = None
    ): ScalaTimeSeries[Map[String,String]] = {
      new ScalaTimeSeries[java.util.Map[String, String]](
        JavaTimeSeries.csv(path,header,delim,trs.orNull)
      )
        .map(_.asScala.toMap)
    }

//    def csv[T]
//    (path:String)
//    (
//      columnToTimestampOp: Array[String] => Long,
//      columnToValueOp: Array[String] => T
//    )
//    (implicit delim: String = ",",skipNumLines: Int = 0,sort: Boolean = false, trs: Option[TRS] = None): ScalaTimeSeries[T] = {
//      new ScalaTimeSeries[T](
//        JavaTimeSeries.csv(
//          path,
//          delim,
//          TSFunctionUtils.jFunction(x => columnToTimestampOp(x).asInstanceOf[java.lang.Long]),
//          TSFunctionUtils.jFunction[Array[String],T](columnToValueOp(_)),
//          skipNumLines,
//          sort,
//          trs.orNull
//        )
//      )
//    }

    def textFile[T]
    (
      path: String,
      f: String => Option[Observation[T]],
      sort: Boolean = false
    )(implicit
      skipNumLines: Int = 0,
      trs: Option[TRS] = None
    ) : ScalaTimeSeries[T] = {
      new ScalaTimeSeries[T](
        JavaTimeSeries.textFile(path,TSFunctionUtils.uMapFunctionOptional(f),sort,skipNumLines,trs.orNull)
      )
    }

    def textFileValues[T]
    (
      path: String,
      f: String => Option[T]
    )(implicit
      skipNumLines: Int = 0,
      trs: Option[TRS] = None
    ): ScalaTimeSeries[T] = {
      new ScalaTimeSeries[T](
        JavaTimeSeries.textFile(path,TSFunctionUtils.uMapFunctionOptional(f),skipNumLines,trs.orNull)
      )
    }

    def list[T](list: List[T], f: Option[T => Long] = None)(implicit trs: Option[TRS] = None) : ScalaTimeSeries[T] = {

      if (f.isEmpty)
        new ScalaTimeSeries[T](
          JavaTimeSeries.list(list.asJava, trs.orNull)
        )
      else
        new ScalaTimeSeries[T](
          JavaTimeSeries.list(
            list.asJava,
            TSFunctionUtils.uMapFunction[T,java.lang.Long](f.get.asInstanceOf[T => java.lang.Long]),
            trs.orNull
          )
        )
    }

    def iter[T](iterable: Iterable[T],f: Option[T => Long] = None)(implicit trs: Option[TRS] = None) : ScalaTimeSeries[T] = {
      if (f.isEmpty)
        new ScalaTimeSeries[T](JavaTimeSeries.list(iterable.toSeq.asJava, trs.orNull))
      else
        new ScalaTimeSeries[T](
          JavaTimeSeries.list(
            iterable.toSeq.asJava,
            TSFunctionUtils.uMapFunction(f.get.asInstanceOf[T => java.lang.Long]),
            trs.orNull
          )
        )
    }

    def reader[T](reader: TimeSeriesReader[T])(implicit trs: Option[TRS] = None) : ScalaTimeSeries[T] = {
      new ScalaTimeSeries[T](
        JavaTimeSeries.reader(reader, trs.orNull)
      )
    }

    def fromObservations[T]
    (
      navigableCollection: ObservationCollection[T],
      copy: Boolean = true
    )(implicit trs: Option[TRS] = None): ScalaTimeSeries[T] = {
      new ScalaTimeSeries[T](JavaTimeSeries.fromObservations(navigableCollection,trs.orNull))
    }
  }

  implicit object MultiTimeSeries {
    def apply[T](timeSeries: ScalaTimeSeries[T]*): ScalaMultiTimeSeries[Int,T] = {
      fromObservationCollectionList(timeSeries.map(_.collect).toBuffer)(timeSeries.head.trs)
    }

    def apply[K,T](observationCollectionMap: Map[K,ScalaTimeSeries[T]]): ScalaMultiTimeSeries[K,T] = {
      new ScalaMultiTimeSeries[K,T](
        new JavaMultiTimeSeries[K,T](
          observationCollectionMap.mapValues(_.ts).asJava
        )
      )
    }

    def objectFile[K,T](inputStream: InputStream): ScalaMultiTimeSeries[K,T] = {
      new ScalaMultiTimeSeries[K,T](
        JavaMultiTimeSeries.objectFile(inputStream)
      )
    }

    //String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter, TRS trs
    def csvInstants
        (
          path: String,
          timestampColumn: String,
          valueColumns: Set[String] = Set.empty[String],
          groupByColumns: Set[String] = Set.empty[String],
          sort: Boolean = false
        )
        (
          implicit
          header: Boolean = true,
          delimiter: String = ",",
          dateTimeFormatter: Option[DateTimeFormatter]=None,
          trs: Option[TRS]=None
        ): ScalaMultiTimeSeries[(Map[String,String],String),String] = {
      new ScalaMultiTimeSeries[Pair[java.util.Map[String,String],String],String](
        JavaMultiTimeSeries.csvInstants(path,groupByColumns.asJava,timestampColumn,valueColumns.asJava,sort,header,delimiter,dateTimeFormatter.orNull,trs.orNull)
      ).mapSeriesKey(k => (k.left.asScala.toMap,k.right))
    }

//    def csvInstants[T]
//        (file: String, timestampColumn: String, valueColumns:Set[String] = Set.empty[String], groupBy: Set[String] = Set.empty[String])
//        (implicit delimiter: String = ",", trs: Option[TRS] = None): ScalaMultiTimeSeries[(String, Set[String]),T] = {
//      new ScalaMultiTimeSeries[Pair[String, java.util.Set[String]],T](
//        JavaMultiTimeSeries.csvInstants(file, delimiter, timestampColumn, valueColumns.asJava,groupBy.asJava,trs.orNull)
//      ).mapSeriesKey(p => (p.left, p.right.asScala.toSet))
//    }

    def csv
    (path: String, keyColumns: Set[String], timestampColumn: String, sort: Boolean = false)
    (
      implicit
      header: Boolean = true,
      delim: String = ",",
      timestampFormat: Option[DateTimeFormatter]=None,
      trs: Option[TRS] = None
    ): ScalaMultiTimeSeries[Map[String,String],Map[String,String]] = {
      new ScalaMultiTimeSeries[java.util.Map[String, String],java.util.Map[String, String]](
        JavaMultiTimeSeries.csv(path,keyColumns.asJava,timestampColumn,sort,header,delim,timestampFormat.orNull,trs.orNull)
      )
        .mapSeriesKey(_.asScala.toMap)
        .map(_.asScala.toMap)
    }

    def csvValues
    (path: String, keyColumns: Set[String])
    (
      implicit
      header: Boolean = true,
      delim: String = ",",
      trs: Option[TRS] = None
    ): ScalaMultiTimeSeries[Map[String,String],Map[String,String]] = {
      new ScalaMultiTimeSeries[java.util.Map[String, String],java.util.Map[String, String]](
        JavaMultiTimeSeries.csv(path,keyColumns.asJava,header,delim,trs.orNull)
      )
        .mapSeriesKey(_.asScala.toMap)
        .map(_.asScala.toMap)
    }

    def textFile[K,T]
        (
          path: String,
          parseLine: String => Option[(K,Observation[T])],
          sort: Boolean = false,
          skipNumLines: Int = 0,
          trs: Option[TRS] = None
        ): ScalaMultiTimeSeries[K,T] = {
      new ScalaMultiTimeSeries[K,T](
        JavaMultiTimeSeries.textFile(
          path,
          TSFunctionUtils.uMapFunctionOptional(s => parseLine(s).map(t2 => new Pair[K,Observation[T]](t2._1,t2._2))),
          sort,
          skipNumLines,
          trs.orNull
        )
      )
    }

    def textFile[K,T]
    (
      path: String,
      parseLine: String => Option[(K,T)],
      skipNumLines: Int,
      trs: Option[TRS]
    ): ScalaMultiTimeSeries[K,T] = {
      new ScalaMultiTimeSeries[K,T](
        JavaMultiTimeSeries.textFile(
          path,
          TSFunctionUtils.uMapFunctionOptional[String,Pair[K,T]](s => parseLine(s).map(t2 => new Pair[K,T](t2._1,t2._2))),
          skipNumLines,
          trs.orNull
        )
      )
    }

    def textFile[K,T]
    (
      path: String,
      parseLine: String => Option[(K,T)],
      skipNumLines: Int
    ): ScalaMultiTimeSeries[K,T] = {
      textFile(path,parseLine,skipNumLines,None)
    }

    def textFile[K,T]
    (
      path: String,
      parseLine: String => Option[(K,T)],
      trs: Option[TRS]
    ): ScalaMultiTimeSeries[K,T] = {
      textFile(path,parseLine,0,trs)
    }

    def textFile[K,T]
    (
      path: String,
      parseLine: String => Option[(K,T)]
    ): ScalaMultiTimeSeries[K,T] = {
      textFile(path,parseLine,0,None)
    }

//    def csv[KEY,VALUE]
//        (file:String)
//        (keyOp: Array[String] => KEY,timestampOp: Array[String] => Long,valueOp: Array[String] => VALUE)
//        (
//          implicit delimiter: String = ",",
//          skipNumLines: Int = 0,
//          sort: Boolean = false,
//          trs: Option[TRS] = None
//        ): ScalaMultiTimeSeries[KEY,VALUE] = {
//      new ScalaMultiTimeSeries[KEY,VALUE](
//        JavaMultiTimeSeries.csv(
//          file,
//          delimiter,
//          TSFunctionUtils.jFunction(keyOp(_)),
//          TSFunctionUtils.jFunction[Array[String],java.lang.Long](timestampOp(_)),
//          TSFunctionUtils.jFunction(valueOp(_)),
//          skipNumLines,
//          sort,
//          trs.orNull
//        )
//      )
//    }

    def fromObservations[KEY,VALUE](observations: Iterable[(KEY,Observation[VALUE])])(implicit trs: Option[TRS] = None): ScalaMultiTimeSeries[KEY,VALUE] = {
      new ScalaMultiTimeSeries[KEY,VALUE](
        JavaMultiTimeSeries.fromObservations[KEY,VALUE](
          observations.map(x => new com.ibm.research.time_series.core.utils.Pair[KEY,Observation[VALUE]](x._1,x._2))
            .toSeq
            .asJava,
          trs.orNull
        )
      )
    }

    def fromObservationCollectionList[VALUETYPE]
    (
      listTimeSeries: mutable.Buffer[ObservationCollection[VALUETYPE]]
    )(implicit trs: Option[TRS] = None): ScalaMultiTimeSeries[Int, VALUETYPE] = {
      new ScalaMultiTimeSeries[java.lang.Integer,VALUETYPE](JavaMultiTimeSeries.fromObservationCollectionList(listTimeSeries.asJava, trs.orNull))
        .asInstanceOf[ScalaMultiTimeSeries[Int,VALUETYPE]]
    }

    def list[VALUETYPE]
    (
      listValues: mutable.Buffer[mutable.Buffer[VALUETYPE]]
    )
    (implicit trs: Option[TRS] = None): ScalaMultiTimeSeries[Int, VALUETYPE] = {
      new ScalaMultiTimeSeries[java.lang.Integer,VALUETYPE](JavaMultiTimeSeries.list(listValues.map(_.asJava).asJava, trs.orNull))
        .asInstanceOf[ScalaMultiTimeSeries[Int,VALUETYPE]]
    }

    def reader[KEYTYPE, VALUETYPE]
    (
      multiTimeSeriesReader: MultiTimeSeriesReader[KEYTYPE, VALUETYPE]
    )
    (implicit trs: Option[TRS] = None): ScalaMultiTimeSeries[KEYTYPE,VALUETYPE] = {
      new ScalaMultiTimeSeries[KEYTYPE,VALUETYPE](
        JavaMultiTimeSeries.reader(multiTimeSeriesReader, trs.orNull)
      )
    }
  }

  implicit class MultiTimeSeriesFunctions[K,T](mts: ScalaMultiTimeSeries[K,T]) {
    def describe: Map[K,Stats[T]] = {
      mts.mts.describe().asScala.toMap
    }

    def getValues
    (
      start: ZonedDateTime,
      end: ZonedDateTime,
      inclusive: Boolean = false
    ): Map[K, ObservationCollection[T]] = {
      mts.mts.getValues(start,end,inclusive).asScala.toMap
    }

    def print
    (
      start: ZonedDateTime,
      end: ZonedDateTime,
      inclusive: Boolean=false
    ): Unit = {
      mts.mts.print(start,end,inclusive)
    }



    def innerJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (T,T2) => T3): ScalaMultiTimeSeries[K,T3] = {
      new ScalaMultiTimeSeries[K,T3](
        mts.mts.innerJoin(timeSeries.ts,TSFunctionUtils.bMapFunction(f))
      )
    }

    def fullJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (Option[T],Option[T2]) => T3)
    (
      implicit
      leftInterpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
      = None,
      rightInterpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
      = None
    ): ScalaMultiTimeSeries[K,T3] = {

      val javaCombine : (T, T2) => T3 = (t,t2) => {
        if (t == null)
          f(None,Some(t2))
        else if (t2 == null)
          f(Some(t),None)
        else
          f(Some(t),Some(t2))
      }

      new ScalaMultiTimeSeries[K,T3](
        mts.mts.fullJoin(
          timeSeries.ts,
          TSFunctionUtils.bMapFunction(javaCombine),
          TSFunctionUtils.interpolateFunction(leftInterpolator),
          TSFunctionUtils.interpolateFunction(rightInterpolator)
        )
      )
    }

    def leftJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (T,Option[T2]) => T3)
    (
      implicit
      interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2] = None
    ): ScalaMultiTimeSeries[K,T3] = {
      val javaCombine : (T,T2) => T3 = (t,t2) => {
        if (t2 == null)
          f(t,None)
        else
          f(t,Some(t2))
      }

      new ScalaMultiTimeSeries[K,T3](
        mts.mts.leftJoin(
          timeSeries.ts,
          TSFunctionUtils.bMapFunction(javaCombine),
          TSFunctionUtils.interpolateFunction(interpolator)
        )
      )
    }

    def rightJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (Option[T],T2) => T3)
    (
      implicit
      interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None
    ): ScalaMultiTimeSeries[K,T3] = {
      val javaCombine : (T,T2) => T3 = (t,t2) => {
        if (t == null)
          f(None,t2)
        else
          f(Some(t),t2)
      }

      new ScalaMultiTimeSeries[K,T3](
        mts.mts.rightJoin(
          timeSeries.ts,
          TSFunctionUtils.bMapFunction(javaCombine),
          TSFunctionUtils.interpolateFunction(interpolator)
        )
      )
    }



    def leftOuterJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (T,Option[T2]) => T3)
    (
      implicit
      interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2] = None
    ): ScalaMultiTimeSeries[K,T3] = {
      val javaCombine : (T,T2) => T3 = (t,t2) => {
        if (t2 == null)
          f(t,None)
        else
          f(t,Some(t2))
      }

      new ScalaMultiTimeSeries[K,T3](
        mts.mts.leftOuterJoin(
          timeSeries.ts,
          TSFunctionUtils.bMapFunction(javaCombine),
          TSFunctionUtils.interpolateFunction(interpolator)
        )
      )
    }

    def rightOuterJoinSeries[T2,T3]
    (timeSeries: ScalaTimeSeries[T2])
    (f: (Option[T],T2) => T3)
    (
      implicit
      interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None
    ): ScalaMultiTimeSeries[K,T3] = {
      val javaCombine : (T,T2) => T3 = (t,t2) => {
        if (t == null)
          f(None,t2)
        else
          f(Some(t),t2)
      }

      new ScalaMultiTimeSeries[K,T3](
        mts.mts.rightOuterJoin(
          timeSeries.ts,
          TSFunctionUtils.bMapFunction(javaCombine),
          TSFunctionUtils.interpolateFunction(interpolator)
        )
      )
    }
  }

  implicit class ScalaObservationFunctions[T](observation: Observation[T]){
    val timeTick: Long = observation.getTimeTick
    val value: T = observation.getValue
  }

  implicit object Observation {
    def apply[T](ts:Long,value:T): Observation[T] = {
      new Observation[T](ts,value)
    }
    def apply[T](ts:Long,value:T,metadata:Map[String,AnyRef]): Observation[T] = {
      new Observation[T](ts,value,metadata.asJava)
    }
    def apply[T](zdt:ZonedDateTime,value:T): Observation[T] = {
      new Observation[T](zdt,value)
    }
  }

  implicit class TSBuilderImplicits[T](tsBuilder: TSBuilder[T]){
    def +=(elem: JavaObservation[T]): TSBuilder[T] = {
      tsBuilder.add(elem)
      tsBuilder
    }

    def +=(timestamp: Long,value: T): TSBuilder[T] = {
      tsBuilder.add(timestamp,value)
      tsBuilder
    }

    def resultWithCombine(trs: TRS, combineOp: Seq[T] => T): ObservationCollection[T] = {
      val uMap : UnaryMapFunction[java.util.List[T], T] = TSFunctionUtils.uMapFunction(x => combineOp(x.asScala))
      tsBuilder.result(trs, uMap)
    }
  }

  implicit class LongImplicits(length: Long) {

    def hours(implicit timeUnit: TimeUnit = TimeUnit.MILLISECONDS): Long = {
      val duration = Duration(length,TimeUnit.HOURS)
      durationToLong(duration,timeUnit)
    }

    def days(implicit timeUnit: TimeUnit = TimeUnit.MILLISECONDS): Long = {
      val duration = Duration(length,TimeUnit.DAYS)
      durationToLong(duration,timeUnit)
    }

    def minutes(implicit timeUnit: TimeUnit = TimeUnit.MILLISECONDS): Long = {
      val duration = Duration(length,TimeUnit.MINUTES)
      durationToLong(duration,timeUnit)
    }

    def seconds(implicit timeUnit: TimeUnit = TimeUnit.MILLISECONDS): Long = {
      val duration = Duration(length,TimeUnit.SECONDS)
      durationToLong(duration,timeUnit)
    }

    private def durationToLong(duration: Duration,timeUnit: TimeUnit): Long = {
      timeUnit match {
        case TimeUnit.MILLISECONDS => duration.toMillis
        case TimeUnit.SECONDS => duration.toSeconds
        case TimeUnit.MICROSECONDS => duration.toMicros
        case TimeUnit.NANOSECONDS => duration.toNanos
        case _ => duration._1
      }
    }
  }

  implicit class ScalaSegmentTimeSeriesImplicits[T](sts: ScalaTimeSeries[Segment[T]]) {
    def describeSegments: ScalaTimeSeries[Stats[T]] = {
      sts.transform(GeneralReducers.describe())
    }
  }

  implicit class ScalaTimeSeriesImplicits[T](timeSeries: ScalaTimeSeries[T]) {
    def describe: Stats[T] = {
      timeSeries.ts.describe()
    }

    def describe(t1: Long, t2: Long): Stats[T] = {
      timeSeries.ts.describe(t1,t2)
    }

    def getValues
    (
      start: ZonedDateTime,
      end: ZonedDateTime,
      inclusive: Boolean = false
    ): ObservationCollection[T] = {
      timeSeries.ts.getValues(start,end,inclusive)
    }

    def print
    (
      start: ZonedDateTime,
      end: ZonedDateTime,
      inclusive: Boolean = false
    ) : Unit = {
      timeSeries.ts.print(start,end,inclusive)
    }

    def countRange
        (
          start: ZonedDateTime,
          end: ZonedDateTime,
          inclusive: Boolean = false
        ): Long = {
      timeSeries.ts.countRange(start,end,inclusive)
    }

    def resampleNext(period: Long)(implicit nullValue:T = null.asInstanceOf[T]): ScalaTimeSeries[T] = {
      timeSeries.resample(period)(GenericInterpolators.next(nullValue))
    }

    def resamplePrev(period: Long)(implicit nullValue:T = null.asInstanceOf[T]): ScalaTimeSeries[T] = {
      timeSeries.resample(period)(GenericInterpolators.prev(nullValue))
    }

    def resampleNearest(period: Long)(implicit nullValue:T = null.asInstanceOf[T]): ScalaTimeSeries[T] = {
      timeSeries.resample(period)(GenericInterpolators.nearest(nullValue))
    }

    def resampleFill(period: Long)(implicit fillValue:T = null.asInstanceOf[T]): ScalaTimeSeries[T] = {
      timeSeries.resample(period)(GenericInterpolators.fill(fillValue))
    }
  }

  implicit class JavaTimeSeriesImplicits[T](timeSeries: JavaTimeSeries[T]) {
    def asScala: ScalaTimeSeries[T] = new ScalaTimeSeries[T](timeSeries)
  }

  implicit class GenericTimeSeriesImplicits[T](timeSeries: ScalaTimeSeries[T]) {
    def removeConsecutiveDuplicatesValues: ScalaTimeSeries[T] = {
      timeSeries.transform(DuplicateTransformers.removeConsecutiveDuplicateValues())
    }

    def combineDuplicateTimeTicks(combineOp:Seq[T] => T): ScalaTimeSeries[T] = {
      timeSeries.transform(
        DuplicateTransformers.combineDuplicateTimeTicks[T](TSFunctionUtils.uMapFunction[java.util.List[T],T](x => combineOp(x.asScala)))
      )
    }
  }

  //todo don't like how this is done since it re-ingests the time series, will have to figure out
  implicit class SortedSetImplicits[T](sortedSetObservations: SortedSet[Observation[T]])
    extends ObservationCollectionImplicits[T](Observations(sortedSetObservations.toSeq :_*)){

  }

  /**
    * Implicit class to add scala like functionality to [[ObservationCollection]]
    *
    * @param observations the observation collection
    * @tparam T observation value type
    */
  implicit class ObservationCollectionImplicits[T](observations: ObservationCollection[T]) extends Iterable[Observation[T]] {
    def toTimeSeries(implicit trs: TRS = null.asInstanceOf[TRS]): ScalaTimeSeries[T] = TimeSeries.fromObservations(observations)(Some(trs))

    override def iterator: Iterator[Observation[T]] = observations.iterator().asScala

    def mapValues[T2](f: T => T2): ObservationCollection[T2] = {
      observations.toTimeSeries.map(f).collect
    }
  }
}
