/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.timeseries

import java.io.OutputStream
import java.lang
import java.time.{LocalDateTime, ZoneId, ZoneOffset, ZonedDateTime}
import java.util.concurrent.TimeUnit
import java.util.function.{BiFunction, Consumer}

import com.ibm.research.time_series.core.cache.Cache
import com.ibm.research.time_series.core.constants._
import com.ibm.research.time_series.core.core_transforms.general.TimeStats
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers
import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel
import com.ibm.research.time_series.core.functions.Interpolator
import com.ibm.research.time_series.core.io.{TimeSeriesReader, TimeSeriesWriter}
import com.ibm.research.time_series.core.observation.Observation
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.timeseries.{TimeSeries => JavaTimeSeries}
import com.ibm.research.time_series.core.transform._
import com.ibm.research.time_series.core.utils.{ObservationCollection, Prediction, Segment, TRS}

import scala.collection.JavaConverters._
import scala.reflect.ClassTag


/**
  * A Scala api for using TimeSeries
  *
  * <p>Created on 3/27/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class ScalaTimeSeries[T](timeSeries: JavaTimeSeries[T]) extends Serializable{

  val ts: JavaTimeSeries[T] = timeSeries
  val trs: Option[TRS] = if (timeSeries.getTRS == null.asInstanceOf[TRS]) None else Some(timeSeries.getTRS)
  val sourceTrs: Option[TRS] = if (timeSeries.getSourceTRS == null.asInstanceOf[TRS]) None else Some(timeSeries.getSourceTRS)

  def write(start: Long, end:Long, inclusive: Boolean): TimeSeriesWriter[T] = {
    timeSeries.write(start,end,inclusive)
  }

  def write(start: Long, end: Long): TimeSeriesWriter[T] = {
    timeSeries.write(start,end)
  }

  def write(inclusive: Boolean): TimeSeriesWriter[T] = {
    timeSeries.write(inclusive)
  }

  def write(): TimeSeriesWriter[T] = {
    timeSeries.write()
  }

  def poll(): ObservationCollection[T] = {
    timeSeries.poll()
  }

  def poll(processOp: ObservationCollection[T] => Unit,stopConditionOp: ObservationCollection[T] => Boolean = _ => false)(implicit howOften:Long = 1000): Unit = {
    timeSeries.poll(
      howOften,
      new Consumer[ObservationCollection[T]] {
        override def accept(t: ObservationCollection[T]): Unit = processOp(t)
      },
      TSFunctionUtils.jFunction(o => stopConditionOp(o))
    )
  }

  def pollWithState[STATE]
      (zeroState: STATE)
      (
        processOp: (ObservationCollection[T],STATE) => STATE,
        stopConditionOp: (ObservationCollection[T],STATE) => Boolean = (_:ObservationCollection[T],_:STATE) => false
      )
      (implicit howOften:Long = 1000): Unit = {
    timeSeries.pollWithState(
      zeroState,
      howOften,
      new BiFunction[ObservationCollection[T],STATE,STATE] {
        override def apply(t: ObservationCollection[T], u: STATE): STATE = processOp(t,u)
      },
      new BiFunction[ObservationCollection[T],STATE,java.lang.Boolean] {
        override def apply(t: ObservationCollection[T], u: STATE): lang.Boolean = stopConditionOp(t,u)
      }
    )
  }

  def getValues
      (
        start: Long,
        end: Long,
        inclusive: Boolean = false
      ) : ObservationCollection[T] = {
    ts.getValues(start,end)
  }

  def getValues
      (
        start: ZonedDateTime,
        end: ZonedDateTime,
        inclusive: Boolean
      ) : ObservationCollection[T] = {
    ts.getValues(start,end,inclusive)
  }

  def reduce[T2](f: ObservationCollection[T] => T2): T2 = {
    ts.reduce(TSFunctionUtils.uMapFunction(f))
  }

  def reduce[T2](reducer: UnaryReducer[T,T2]): T2 = {
    ts.reduce(reducer)
  }

  def reduceRange[T2](reducer: UnaryReducer[T,T2])(start:Long,end:Long,inclusive: Boolean = false): T2 = {
    ts.reduceRange(reducer,start,end,inclusive)
  }


  def reduce[T2,T3]
      (other: ScalaTimeSeries[T2])
      (reducer: BinaryReducer[T,T2,T3]): T3 = {
    ts.reduce(other.ts,reducer)
  }

  def reduceRange[T2,T3]
      (other: ScalaTimeSeries[T2])
      (reducer: BinaryReducer[T,T2,T3])
      (start:Long,end:Long): T3 = {
    ts.reduceRange(other.ts,reducer,start,end)
  }

  def reduce[T2]
      (tsIterable: Iterable[ScalaTimeSeries[T]])
      (reducer: NaryReducer[T,T2]): T2 = {
    ts.reduce(tsIterable.toBuffer.map((x:ScalaTimeSeries[T]) => x.ts).asJava,reducer)
  }

  def reduceRange[T2]
      (tsIterable: Iterable[ScalaTimeSeries[T]])
      (reducer: NaryReducer[T,T2])
      (start:Long,end:Long): T2 = {
    ts.reduceRange(tsIterable.toBuffer.map((x:ScalaTimeSeries[T]) => x.ts).asJava,reducer,start,end)
  }

  def collect(implicit inclusive: Boolean = false) : ObservationCollection[T] = timeSeries.collect(inclusive)

  def count(implicit inclusive: Boolean = false): Long = timeSeries.count(inclusive)

  def countRange(start: Long,end: Long, inclusive: Boolean = false): Long = timeSeries.countRange(start,end,inclusive)

  def foreach(f:Observation[T] => Unit): Unit = {
    collect.asScala.foreach(f)
  }

  def print() : Unit = timeSeries.print()

  def print
  (
    start: Long,
    end: Long,
    inclusive: Boolean = false
  ) : Unit = {
    timeSeries.print(start,end,inclusive)
  }

  def printDAG : Unit = {
    timeSeries.printDAG()
  }

  def transform[T2](unaryTransform: UnaryTransform[T,T2]): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.transform[T2](unaryTransform))
  }

  def transform[T2,T3]
      (tsIn:ScalaTimeSeries[T2])
      (binaryTransform: BinaryTransform[T,T2,T3]): ScalaTimeSeries[T3] = {
    new ScalaTimeSeries[T3](timeSeries.transform[T2,T3](tsIn.ts,binaryTransform))
  }

  def transform[T2]
      (tsListIn: Iterable[ScalaTimeSeries[T]])
      (naryTransform: NaryTransform[T,T2]) : ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](
      timeSeries.transform[T2](tsListIn.map(_.ts).toBuffer.asJava,naryTransform)
    )
  }

  def lag(lag: Long): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      ts.lag(lag)
    )
  }

  def shift(shift: Int,defaultValue: T): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      ts.shift(shift,defaultValue)
    )
  }

  def fillna
      (
        interpolator: (ObservationCollection[T], ObservationCollection[T], Long) => T,
        historyLength: Int = 1,
        futureLength: Int = 1,
        nullValue: T = null.asInstanceOf[T]
      ): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      timeSeries.fillna(TSFunctionUtils.interpolateFunction(Some(interpolator),historyLength,futureLength),nullValue)
    )
  }

  def fillna
  (
    interpolator: Interpolator[T],
    nullValue: T
  ): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      timeSeries.fillna(interpolator,nullValue)
    )
  }

  def fillna(value: T): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      timeSeries.fillna(value)
    )
  }

  def resample
      (period: Long)
      (
        interpolator: (ObservationCollection[T], ObservationCollection[T], Long) => T,
        historySize: Int = 1,
        futureSize: Int = 1
      ) : ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      timeSeries.resample(
        period,
        TSFunctionUtils.interpolateFunction(Some(interpolator),historySize,futureSize)
      )
    )
  }

  def resample
      (period: Long, interpolator: Interpolator[T]): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](
      timeSeries.resample(period,interpolator)
    )
  }

  def filter(f: T => Boolean) : ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.filter(TSFunctionUtils.filterFunction(f)))
  }

  def toSegments(transform:UnaryTransform[T,Segment[T]]): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](
      timeSeries.toSegments(transform)
    )
  }

  def segment(window: Long): ScalaTimeSeries[Segment[T]] = {
    segment(window,1)
  }

  def segment(window: Long,step: Long): ScalaTimeSeries[Segment[T]] = {
    segment(window,step,enforceSize = true)
  }

  def segment(window: Long,step: Long,enforceSize: Boolean): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](
      timeSeries.segment(window,step,enforceSize)
    )
  }

  def segmentByTime
  (
    window: Long,
    step: Long,
    padding: Padding = Padding.NONE,
    timestampLocation: ResultingTimeStamp = ResultingTimeStamp.START_OF_WINDOW
  ): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](
      timeSeries.segmentByTime(window,step,padding,timestampLocation)
    )
  }

//  def segmentByTime
//  (
//    window: Long,
//    step: Long,
//    timeUnit: TimeUnit
//  ): ScalaTimeSeries[Segment[T]] = {
//    new ScalaTimeSeries[Segment[T]](
//      fromObservationCollectionList.segmentByTime(window,step,timeUnit)
//    )
//  }

  def segmentByAnchor
  (f: T => Boolean)(leftDelta:Long,rightDelta:Long, perc:Double = Double.NaN): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](
      timeSeries.segmentByAnchor(
        TSFunctionUtils.filterFunction(f),
        leftDelta,
        rightDelta,
        perc
      )
    )
  }

  def segmentByChangePoint(isChangeOp: (T,T) => Boolean): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByChangePoint(TSFunctionUtils.bMapFunction((x,y) => isChangeOp(x,y).asInstanceOf[java.lang.Boolean])))
  }

  def segmentByChangePoint(): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByChangePoint())
  }

//  def segmentByMarker
//    (
//      markerOp: T => Boolean,
//      startInclusive: Boolean = true,
//      endInclusive: Boolean = true,
//      startOnFirst: Boolean = false,
//      endOnFirst: Boolean = true
//    ): ScalaTimeSeries[Segment[T]] = {
//    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByMarker(TSFunctionUtils.filterFunction(markerOp), startInclusive,endInclusive,startOnFirst,endOnFirst))
//  }

  def segmentByMarker(f: T => Boolean): ScalaTimeSeries[Segment[T]] = {
    segmentByMarker(f, false, true)
  }

  def segmentByMarker(f: T => Boolean, prevInclusive: Boolean, nextInclusive:Boolean): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByMarker(TSFunctionUtils.filterFunction(f), prevInclusive, nextInclusive))
  }

  def segmentByMarker(f: T => Boolean, prevInclusive: Boolean, nextInclusive:Boolean, requiresStartAndEnd: Boolean): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByMarker(TSFunctionUtils.filterFunction(f), prevInclusive, nextInclusive, requiresStartAndEnd))
  }

  def segmentByMarker
      (
        startOp: T => Boolean,
        endOp: T => Boolean,
        startInclusive: Boolean = true,
        endInclusive: Boolean = true,
        startOnFirst: Boolean = false,
        endOnFirst: Boolean = true
      ) : ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentByMarker(
      TSFunctionUtils.filterFunction(startOp),
      TSFunctionUtils.filterFunction(endOp),
      startInclusive,
      endInclusive,
      startOnFirst,
      endOnFirst
    ))
  }

  def segmentBy[K](groupByOp: Observation[T] => K): ScalaTimeSeries[Segment[T]] = {
    new ScalaTimeSeries[Segment[T]](timeSeries.segmentBy(TSFunctionUtils.uMapFunction(groupByOp)))
  }

  def withTRS(trs: TRS): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.withTRS(trs))
  }

  def mapObservation[T2](f: Observation[T] => Observation[T2]): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.mapObservation(TSFunctionUtils.uMapObsFunction(f)))
  }

  def flatMap[T2](f: T => Iterable[T2]): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.flatMap(TSFunctionUtils.uMapFunction(x => f(x).asJava)))
  }

  def flatMapObservation[T2](f: Observation[T] => Iterable[Observation[T2]]): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.flatMapObservation(TSFunctionUtils.uFlatMapObsFunction(f)))
  }

  def map[T2](f: T => T2): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.map(TSFunctionUtils.uMapFunction(f)))
  }

  def mapWithIndex[T2](f: (Int,T) => T2): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](timeSeries.mapWithIndex(TSFunctionUtils.uMapWithIndexFunction(f)))
  }

  def innerAlign[T2](tsIn:ScalaTimeSeries[T2]): (ScalaTimeSeries[T],ScalaTimeSeries[T2]) = {
    val joined = innerJoin(tsIn)((x: T,y: T2) => (x,y))
    (joined.map(_._1),joined.map(_._2))
  }

  def innerJoin[T2,T3]
      (tsIn:ScalaTimeSeries[T2])
      (combine: (T,T2) => T3): ScalaTimeSeries[T3] = {
    new ScalaTimeSeries[T3](
      timeSeries.innerJoin(tsIn.ts,TSFunctionUtils.bMapFunction(combine))
    )
  }

  def fullAlign[T2]
      (tsIn:ScalaTimeSeries[T2])
      (
        implicit
        leftInterpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
        = None,
        rightInterpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
        = None,
        leftHistorySize: Int = 1,
        leftFutureSize: Int = 1,
        rightHistorySize: Int = 1,
        rightFutureSize: Int = 1
      ): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[Option[T2]]) = {
    val joined = fullJoin(tsIn)((x:Option[T],y:Option[T2]) => (x,y))(leftInterpolator,rightInterpolator,leftHistorySize,leftFutureSize, rightHistorySize, rightFutureSize)
    (joined.map(_._1),joined.map(_._2))
  }

  def fullAlign[T2]
  (tsIn:ScalaTimeSeries[T2], interpolatorLeft: Interpolator[T], interpolatorRight: Interpolator[T2]): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[Option[T2]]) = {
    val joined = fullJoin(tsIn,(x:Option[T],y:Option[T2]) => (x,y),interpolatorLeft,interpolatorRight)
    (joined.map(_._1),joined.map(_._2))
  }

  def fullJoin[T2,T3]
      (tsIn:ScalaTimeSeries[T2])
      (
        combine: (Option[T],Option[T2]) => T3
      )
      (
        implicit
        leftInterpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None,
        rightInterpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2] = None,
        leftHistorySize: Int = 1,
        leftFutureSize: Int = 1,
        rightHistorySize: Int = 1,
        rightFutureSize: Int = 1
      ): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,Some(t2))
      else if (t2 == null)
        combine(Some(t),None)
      else
        combine(Some(t),Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.fullJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(leftInterpolator,leftHistorySize,leftFutureSize),
        TSFunctionUtils.interpolateFunction(rightInterpolator,rightHistorySize,rightFutureSize)
      )
    )

  }

  def fullJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2], combine: (Option[T],Option[T2]) => T3, interpolatorLeft: Interpolator[T], interpolatorRight: Interpolator[T2]): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,Some(t2))
      else if (t2 == null)
        combine(Some(t),None)
      else
        combine(Some(t),Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.fullJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolatorLeft,
        interpolatorRight
      )
    )

  }

  def leftAlign[T2]
      (tsIn:ScalaTimeSeries[T2])
      (
        implicit
        interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
        = None,
        historySize: Int = 1,
        futureSize: Int = 1
      ): (ScalaTimeSeries[T],ScalaTimeSeries[Option[T2]]) = {
    val joined = leftJoin(tsIn)((x: T,y: Option[T2]) => (x,y))(interpolator,historySize, futureSize)
    (joined.map(_._1),joined.map(_._2))
  }

  def leftAlign[T2]
  (tsIn:ScalaTimeSeries[T2], interpolator: Interpolator[T2]): (ScalaTimeSeries[T],ScalaTimeSeries[Option[T2]]) = {
    val joined = leftJoin(tsIn,(x: T,y: Option[T2]) => (x,y),interpolator)
    (joined.map(_._1),joined.map(_._2))
  }

  def leftJoin[T2,T3]
      (tsIn:ScalaTimeSeries[T2])
      (combine: (T,Option[T2]) => T3)
      (
        implicit
        interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
        = None,
        historySize: Int = 1,
        futureSize: Int = 1
      ): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        combine(t,None)
      else
        combine(t,Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.leftJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )

  }

  def leftJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2],combine: (T,Option[T2]) => T3, interpolator: Interpolator[T2]): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        combine(t,None)
      else
        combine(t,Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.leftJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }

  def rightAlign[T2]
      (tsIn:ScalaTimeSeries[T2])
      (
        implicit
        interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
        = None,
        historySize: Int = 1,
        futureSize: Int = 1
      ): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[T2]) = {
    val joined = rightJoin(tsIn)((x,y) => (x,y))(interpolator,historySize, futureSize)
    (joined.map(_._1),joined.map(_._2))
  }

  def rightAlign[T2]
  (tsIn:ScalaTimeSeries[T2], interpolator: Interpolator[T]): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[T2]) = {
    val joined = rightJoin(tsIn,(x: Option[T],y: T2) => (x,y),interpolator)
    (joined.map(_._1),joined.map(_._2))
  }

  def rightJoin[T2,T3]
      (tsIn:ScalaTimeSeries[T2])
      (combine: (Option[T],T2) => T3)
      (
        implicit
        interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
        = None,
        historySize: Int = 1,
        futureSize: Int = 1
      ): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,t2)
      else
        combine(Some(t),t2)
    }

    new ScalaTimeSeries[T3](
      timeSeries.rightJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )

  }

  def rightJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2],combine: (Option[T],T2) => T3, interpolator: Interpolator[T]): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,t2)
      else
        combine(Some(t),t2)
    }

    new ScalaTimeSeries[T3](
      timeSeries.rightJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )

  }

  def leftOuterAlign[T2]
  (tsIn:ScalaTimeSeries[T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaTimeSeries[T],ScalaTimeSeries[Option[T2]]) = {
    val joined = leftOuterJoin(tsIn)((x: T,y: Option[T2]) => (x,y))(interpolator,historySize, futureSize)
    (joined.map(_._1),joined.map(_._2))
  }

  def leftOuterAlign[T2]
  (tsIn:ScalaTimeSeries[T2], interpolator: Interpolator[T2]): (ScalaTimeSeries[T],ScalaTimeSeries[Option[T2]]) = {
    val joined = leftOuterJoin(tsIn,(x: T,y: Option[T2]) => (x,y),interpolator)
    (joined.map(_._1),joined.map(_._2))
  }

  def leftOuterJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2])
  (combine: (T,Option[T2]) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T2],ObservationCollection[T2], Long) => T2]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        combine(t,None)
      else
        combine(t,Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.leftOuterJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )

  }

  def leftOuterJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2],combine: (T,Option[T2]) => T3, interpolator: Interpolator[T2]): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t2 == null)
        combine(t,None)
      else
        combine(t,Some(t2))
    }

    new ScalaTimeSeries[T3](
      timeSeries.leftOuterJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )
  }

  def rightOuterAlign[T2]
  (tsIn:ScalaTimeSeries[T2])
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[T2]) = {
    val joined = rightOuterJoin(tsIn)((x,y) => (x,y))(interpolator,historySize, futureSize)
    (joined.map(_._1),joined.map(_._2))
  }

  def rightOuterAlign[T2]
  (tsIn:ScalaTimeSeries[T2], interpolator: Interpolator[T]): (ScalaTimeSeries[Option[T]],ScalaTimeSeries[T2]) = {
    val joined = rightOuterJoin(tsIn,(x: Option[T],y: T2) => (x,y),interpolator)
    (joined.map(_._1),joined.map(_._2))
  }

  def rightOuterJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2])
  (combine: (Option[T],T2) => T3)
  (
    implicit
    interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T]
    = None,
    historySize: Int = 1,
    futureSize: Int = 1
  ): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,t2)
      else
        combine(Some(t),t2)
    }

    new ScalaTimeSeries[T3](
      timeSeries.rightOuterJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator,historySize, futureSize)
      )
    )

  }

  def rightOuterJoin[T2,T3]
  (tsIn:ScalaTimeSeries[T2],combine: (Option[T],T2) => T3, interpolator: Interpolator[T]): ScalaTimeSeries[T3] = {
    val javaCombine : (T,T2) => T3 = (t,t2) => {
      if (t == null)
        combine(None,t2)
      else
        combine(Some(t),t2)
    }

    new ScalaTimeSeries[T3](
      timeSeries.rightOuterJoin(
        tsIn.ts,
        TSFunctionUtils.bMapFunction(javaCombine),
        interpolator
      )
    )

  }

  def indexJoin[T2]
      (tsListIn: Iterable[ScalaTimeSeries[T]])
      (zeroValue: T2)
      (combineOp: (T2,T) => T2): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](
      timeSeries.indexJoin(tsListIn.toSeq.map(_.ts).asJava,zeroValue,TSFunctionUtils.bMapFunction(combineOp))
    )
  }

  def innerJoin[T2]
      (tsListIn: Iterable[ScalaTimeSeries[T]])
      (zeroValue: T2)
      (combineOp: (T2,T) => T2): ScalaTimeSeries[T2] = {
    new ScalaTimeSeries[T2](
      timeSeries.innerJoin(tsListIn.toSeq.map(_.ts).asJava,zeroValue,TSFunctionUtils.bMapFunction(combineOp))
    )
  }

  //todo figure out how to support this with proper naming (Going to leave as fullNJoin for now)
  def fullNJoin[T2]
      (tsListIn: Iterable[ScalaTimeSeries[T]])
      (zeroValue: T2)
      (combineOp: (T2,Option[T]) => T2)
      (
        implicit
        interpolator: Option[(ObservationCollection[T],ObservationCollection[T], Long) => T] = None
      ): ScalaTimeSeries[T2] = {
    val javaCombine : (T2,T) => T2 = (t2,t) => {
      if (Option(t).isEmpty)
        combineOp(t2,None)
      else
        combineOp(t2,Some(t))
    }
    new ScalaTimeSeries[T2](
      timeSeries.fullJoin(
        tsListIn.toSeq.map(_.ts).asJava,
        zeroValue,
        TSFunctionUtils.bMapFunction(javaCombine),
        TSFunctionUtils.interpolateFunction(interpolator)
      )
    )
  }

  def concat(trailingTimeSeries: ScalaTimeSeries[T]): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.concat(trailingTimeSeries.ts))
  }

  def cache(): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.cache())
  }

  def cache(maxSize: Int): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.cache(maxSize))
  }

  def userDefinedCache(cache: Cache[T], maxSize: Int = Int.MaxValue): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.userDefinedCache(cache,maxSize))
  }

  def uncache(): ScalaTimeSeries[T] = {
    new ScalaTimeSeries[T](timeSeries.uncache())
  }

  //todo this may need to go
  def getMostRecentCacheHitType: CacheHit = timeSeries.getMostRecentCacheHitType

  def getMaximumCacheSize: Int = timeSeries.getMaximumCacheSize

  def getCache: scala.Iterator[Observation[T]] = ts.getCache.asScala

  def forecast
  (numPredictions: Int, model: ObservationForecastingModel[T], startTrainingTime: Long, confidence: Double): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions, model, startTrainingTime, confidence)
  }

  def forecast
  (numPredictions: Int, model: ObservationForecastingModel[T], startTrainingTime: Long): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions, model, startTrainingTime, 1.0)
  }

  def forecast
  (numPredictions: Int, model: ObservationForecastingModel[T], startTrainingTime: ZonedDateTime, confidence: Double): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions, model, startTrainingTime, confidence)
  }

  def forecast
  (numPredictions: Int, model: ObservationForecastingModel[T], startTrainingTime: ZonedDateTime): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions, model, startTrainingTime, 1.0)
  }

  def forecast
  (
    numPredictions: Int,
    model: ObservationForecastingModel[T],
    confidence: Double
  ): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions,model, confidence)
  }

  def forecast
  (
    numPredictions: Int,
    model: ObservationForecastingModel[T]
  ): ObservationCollection[Prediction[T]] = {
    timeSeries.forecast(numPredictions,model, 1.0)
  }

//  def forecast
//      (
//        fm: ObservationForecastingModel[T],
//        updateModel: ForecastModelUpdate = ForecastModelUpdate.CONTINUOUS,
//        confidence: Double = 1.0,
//        maxSpread: Double = Double.MaxValue
//      ): ScalaTimeSeries[T] = {
//    new ScalaTimeSeries[T](ts.forecast(fm,updateModel,confidence,maxSpread))
//  }
//
//  def unForecast: ScalaTimeSeries[T] = new ScalaTimeSeries[T](ts.unForecast())

  override def toString: String = timeSeries.toString
}

object ScalaTimeSeries {

  implicit def toSegmentTimeSeriesFunctions[T]
      (timeSeries: ScalaTimeSeries[Segment[T]])
      (implicit kt: ClassTag[T]): SegmentTimeSeriesFunctions[T] = {
    new SegmentTimeSeriesFunctions[T](timeSeries)
  }
}
