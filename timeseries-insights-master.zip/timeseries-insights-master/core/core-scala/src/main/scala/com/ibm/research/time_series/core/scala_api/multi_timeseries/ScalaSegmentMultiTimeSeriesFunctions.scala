/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.multi_timeseries

//import com.ibm.research.time_series.core.scala_api.timeseries.TimeSeries
import com.ibm.research.time_series.core.scala_api.timeseries.SegmentTimeSeriesFunctions
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.timeseries.{MultiTimeSeries, SegmentMultiTimeSeries}
import com.ibm.research.time_series.core.transform.{BinaryReducer, UnaryTransform}
import com.ibm.research.time_series.core.utils.Segment

import scala.collection.JavaConverters._
import scala.reflect.ClassTag

/**
  *
  * <p>Created on 6/15/17.</p>
  *
  * @author Joshua Rosenkranz
  */
class ScalaSegmentMultiTimeSeriesFunctions[K:ClassTag,V:ClassTag]
    (mts: ScalaMultiTimeSeries[K,Segment[V]]) {

  def transformSegments[V2:ClassTag](transform: UnaryTransform[V,V2]): ScalaSegmentMultiTimeSeriesFunctions[K,V2] = {
    new ScalaSegmentMultiTimeSeriesFunctions[K,V2](
      mts.map(segment => {
        Segment.fromSeries(TimeSeries.fromObservations(segment).transform(transform).collect)
      })
    )
  }

  def mapSegments[V2:ClassTag](f: V => V2): ScalaSegmentMultiTimeSeriesFunctions[K,V2] = {
    new ScalaSegmentMultiTimeSeriesFunctions[K,V2](
      mts.map(segment => {
        Segment.fromSeries(TimeSeries.fromObservations(segment).map(f).collect)
      })
    )
  }

  def reduceSegments[V2:ClassTag](f: Iterable[V] => V2): ScalaMultiTimeSeries[K,V2] = {
    mts.map(segment => f(segment.asScala.map(_.getValue)))
  }

  def transform[V2:ClassTag,V3:ClassTag]
      (segmentMts: ScalaMultiTimeSeries[K,Segment[V2]])
      (transform: BinaryReducer[V,V2,V3]): ScalaMultiTimeSeries[K,V3] = {
    val tsMap = mts.mts.getTimeSeriesMap.asScala.map(x => {
      (x._1,x._2.transform(segmentMts.mts.getTimeSeriesMap.get(x._1),transform))
    }).toMap

    new ScalaMultiTimeSeries[K,V3](
      new MultiTimeSeries[K,V3](tsMap.asJava)
    )
  }

  def flatten(start: Long,end: Long,inclusive: Boolean): ScalaMultiTimeSeries[(K,Long), V] = {
    val tsMap = mts.getTimeSeriesMap.par.flatMap(kv => {
      kv._2.getValues(start, end, inclusive).map(obs => ((kv._1, obs.timeTick), obs.value.toTimeSeriesStream))
    })

    new ScalaMultiTimeSeries[(K,Long),V](
      new MultiTimeSeries[(K,Long), V](tsMap.seq.asJava)
    )
  }

  def flatten(inclusive: Boolean = false): ScalaMultiTimeSeries[(K,Long), V] = {
    val tsMap = mts.getTimeSeriesMap.par.flatMap(kv => {
      kv._2.collect(inclusive).map(obs => ((kv._1, obs.timeTick), obs.value.toTimeSeriesStream))
    })

    new ScalaMultiTimeSeries[(K,Long),V](
      new MultiTimeSeries[(K,Long), V](tsMap.seq.asJava)
    )
  }

  def flatten[K2](secondaryKeyOp: Segment[V] => K2,inclusive: Boolean): ScalaMultiTimeSeries[(K,K2),V] = {
    val tsMap = mts.getTimeSeriesMap.par.flatMap(kv => {
      kv._2.collect(inclusive).map(obs => ((kv._1, secondaryKeyOp(obs.value)), obs.value.toTimeSeriesStream))
    })

    new ScalaMultiTimeSeries[(K,K2),V](
      new MultiTimeSeries[(K,K2), V](tsMap.seq.asJava)
    )
  }

  def flatten[K2](secondaryKeyOp: Segment[V] => K2): ScalaMultiTimeSeries[(K,K2),V] = {
    flatten(secondaryKeyOp, false)
  }
}
