/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.scala_api.core_transforms.interpolation

import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.core.core_transforms.general.{GenericInterpolators => JGenericInterpolators}
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils

/**
  *
  * <p>Created on 3/31/17.</p>
  *
  * @author Joshua Rosenkranz
  */
object GenericInterpolators {
  def create[T]
      (
        interpolateOp: (ObservationCollection[T],ObservationCollection[T], Long) => T,
        fillValue: T = null,
        historySize: Int = 1,
        futureSize: Int = 1
      ) : (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => {
      JGenericInterpolators.create(
        TSFunctionUtils.interpolateFunction(Some(interpolateOp)),
        fillValue,
        historySize,
        futureSize
      ).interpolate(history,future,timestamp)
    }
  }

  def nearest[T](nullValue: T = null) : (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => {
      JGenericInterpolators.nearest(nullValue).interpolate(history,future,timestamp)
    }
  }

  def next[T](nullValue: T = null): (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => {
      JGenericInterpolators.next(nullValue).interpolate(history,future,timestamp)
    }
  }

  def prev[T](nullValue: T = null) : (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => {
      JGenericInterpolators.prev(nullValue).interpolate(history,future,timestamp)
    }
  }

  def nullify[T]: (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => {
      JGenericInterpolators.nullify().interpolate(history, future, timestamp)
    }
  }

  def fill[T](defaultValue: T = null):  (ObservationCollection[T],ObservationCollection[T], Long) => T = {
    (history, future, timestamp) => JGenericInterpolators.fill(defaultValue).interpolate(history, future, timestamp)
  }
}
