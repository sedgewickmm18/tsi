package com.ibm.research.time_series.core.utils;

import java.io.Serializable;
import java.time.*;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

/**
 * Time reference system (TRS) is a local, regional or global system used to identify time. A time reference system
 * defines a specific projection for forward and reverse mapping between timestamp and its numeric representation. A
 * common example that most of us are familiar with is UTC time, which maps a timestamp (Jan 1, 2019 12am midnight GMT)
 * into a 64-bit integer value (1546300800000) that captures the number of milliseconds that have elapsed since
 * Jan 1, 1970 12am (midnight) GMT. Generally speaking, the timestamp value is better suited for human readability,
 * while the numeric representation is better suited for machine processing.
 *
 * <p>
 *     A {@link TRS} is composed of an:
 * </p>
 * <ul>
 *     <li>
 *         (i) granularity that captures time-tick granularity (e.g., 1 minute)
 *     </li>
 *     <li>
 *         (ii) start-time that captures an offset (e.g., 1st Jan 2019 12am midnight US Eastern Daylight Savings
 *         Time) to the start time of the {@link TimeSeries})
 *     </li>
 * </ul>
 *
 * <p>
 *     A timestamp is mapped into a numeric representation by computing the number of elapsed time-ticks since the
 *     offset. A numeric representation is scaled by the time-tick and shifted by the offset when it is mapped back to a
 *     timestamp.
 * </p>
 *
 * <p>
 *     Note that this forward + reverse projections may be lossy. For instance, if the true time granularity of a
 *     {@link TimeSeries} is in seconds, then forward and reverse mapping of timestamps 9:00:01 and 9:00:02 (to be read
 *     as hh:mm:ss) to a time-tick of one minute would result in timestamps 9:00:00 and 9:00:00 (respectively). In this
 *     example a {@link TimeSeries} whose granularity is in seconds is being mapped to minutes and thus the reverse
 *     mapping looses information. However, the mapped granularity is higher than the granularity of the input
 *     {@link TimeSeries} (more specifically if the {@link TimeSeries} granularity is an integral multiple of the mapped
 *     granularity) then the forward + reverse projection is guaranteed to be lossless. For example, mapping a
 *     {@link TimeSeries} whose granularity is in minutes to seconds and reverse projecting it to minutes would result
 *     in lossless reconstruction of the timestamps.
 * </p>
 *
 * <p>
 *     Note: By default, Granularity is one millisecond, and Start-Time is 1st Jan 1970 00:00:00
 * </p>
 */
public class TRS implements Serializable {

    private static final long serialVersionUID = 2238646249033626796L;
    private Duration duration;
    private ZonedDateTime zonedDateTime;

    private TRS(Duration duration, ZonedDateTime zdt) {
        this.zonedDateTime = zdt;
        this.duration = duration;
    }

    /**
     * @return a String representation of this {@link TRS}
     */
    @Override
    public String toString() {
        return "TimeReferenceSystem(granularity=" + duration.toString() + ", start-time=" + zonedDateTime.toString() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TRS)) {
            return false;
        }

        TRS other = (TRS) obj;

        return zonedDateTime.equals(other.zonedDateTime) && duration.equals(other.duration);
    }

    /**
     * @return the granularity of this {@link TRS}
     */
    public Duration getGranularity() {
        return duration;
    }

    /**
     * @return the start-time of this {@link TRS}
     */
    public ZonedDateTime getStartTime() {
        return zonedDateTime;
    }

    /**
     * Get the given time-tick as a millisecond long (lower bound)
     * @param time time tick
     * @return a millisecond long
     */
    public long toLongLower(long time) {
        long offset = zonedDateTime.toInstant().toEpochMilli();
        long tt = duration.toMillis();
        return (tt * time) + offset;
    }

    /**
     * Get the given {@link ZonedDateTime} as a millisecond long (lower bound)
     * @param zdt the {@link ZonedDateTime}
     * @return a millisecond long
     */
    public long toLongLower(ZonedDateTime zdt) {
        return toLongLower(zdt.toInstant().toEpochMilli());
    }

    /**
     * Get the given time-tick as a millisecond long (upper bound)
     * @param time time tick
     * @return a millisecond long
     */
    public long toLongUpper(long time) {
        long offset = zonedDateTime.toInstant().toEpochMilli();
        long tt = duration.toMillis();
        return (tt * time) + offset + (tt - 1);
    }

    /**
     * Get the given {@link ZonedDateTime} as a millisecond long (upper bound)
     * @param zdt the {@link ZonedDateTime}
     * @return a millisecond long
     */
    public long toLongUpper(ZonedDateTime zdt) {
        return toLongLower(zdt.toInstant().toEpochMilli());
    }

    /**
     * Get the given millisecond long as a time-tick index
     * @param time millisecond long
     * @return a time-tick index
     */
    public long toIndex(long time) {
        long offset = zonedDateTime.toInstant().toEpochMilli();
        long tt = duration.toMillis();
        return (time - offset) / tt;
    }

    /**
     * Get the given {@link ZonedDateTime} as a time-tick index
     * @param zdt the {@link ZonedDateTime}
     * @return a time-tick index
     */
    public long toIndex(ZonedDateTime zdt) {
        return toIndex(zdt.toInstant().toEpochMilli());
    }

    /**
     * Create a {@link TRS} from a granularity and start-time
     * @param granularity the lowest granularity of time-tick
     * @param startTime the off-set start-time
     * @return a new {@link TRS}
     */
    public static TRS of(Duration granularity, ZonedDateTime startTime) {
        return new TRS(granularity,startTime);
    }

    /**
     * Create a {@link TRS} from a start-time
     * @param startTime the off-set start-time
     * @return a new {@link TRS}
     */
    public static TRS of(ZonedDateTime startTime) {
        return of(Duration.ofMillis(1),startTime);
    }

    /**
     * Create a {@link TRS} from a granularity
     * @param granularity the lowest granularity of time-tick
     * @return a new {@link TRS}
     */
    public static TRS of(Duration granularity) {
        return of(granularity, ZonedDateTime.of(1970,1,1,0,0,0,0,ZoneId.of("UTC")));
    }

    /**
     * Create a default {@link TRS}
     * @return a new {@link TRS}
     */
    public static TRS ofDefault() {
        return of(Duration.ofMillis(1));
    }
}
