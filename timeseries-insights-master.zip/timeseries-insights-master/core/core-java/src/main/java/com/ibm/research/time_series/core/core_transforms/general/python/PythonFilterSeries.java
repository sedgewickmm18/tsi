package com.ibm.research.time_series.core.core_transforms.general.python;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.List;

public class PythonFilterSeries {
    public static <T> FilterFunction<ObservationCollection<T>> filterSize(int size, String operator) {
        return (observations) -> {
            if (operator.equals("l")) {
                return observations.size() < size;
            } else if (operator.equals("le")) {
                return observations.size() <= size;
            } else if (operator.equals("g")) {
                return observations.size() > size;
            } else if (operator.equals("ge")) {
                return observations.size() >= size;
            } else {
                return observations.size() == size;
            }
        };
    }

    public static <T> FilterFunction<ObservationCollection<T>> filterContains(List<T> values, boolean contains) {
        return (observations) -> {
            for (Observation<T> obs : observations) {
                if (values.contains(obs.getValue())) {
                    return contains;
                }
            }
            return false;
        };
    }
}
