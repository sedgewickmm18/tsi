package com.ibm.research.time_series.core.core_transforms.general.python;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

public class PythonTransforms {
    public static <T> UnaryTransform<T,Long> interArrivalTimes() {
        return new UnaryTransform<T, Long>() {
            @Override
            public ObservationCollection<Long> evaluate(long t1, long t2, boolean inclusive) {
                final ObservationCollection<T> collected = this.timeSeries.getValues(t1, t2, inclusive);
                TSBuilder<Long> tsBuilder = Observations.newBuilder();
                Observation<T> prev = null;
                for (Observation<T> next : collected) {
                    if (prev != null) {
                        tsBuilder.add(next.getTimeTick(), next.getTimeTick() - prev.getTimeTick());
                    }
                    prev = next;
                }
                return tsBuilder.result();
            }
        };
    }
}
