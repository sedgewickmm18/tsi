package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

class BiMarkerBasedSegmentationOnSegment<T> extends UnaryTransform<T, Segment<T>> {

    private UnaryTransform<T, Segment<T>> initialSegmentTransform;
    private FilterFunction<Segment<T>> isMarkerStart;
    private FilterFunction<Segment<T>> isMarkerEnd;
    private boolean startInclusive;
    private boolean endInclusive;
    private boolean isStartingOnFirst;
    private boolean isStoppingOnFirst;

    public BiMarkerBasedSegmentationOnSegment(UnaryTransform<T, Segment<T>> initialSegmentTransform, FilterFunction<Segment<T>> isMarkerStart, FilterFunction<Segment<T>> isMarkerEnd, boolean startInclusive, boolean endInclusive, boolean isStartingOnFirst, boolean isStoppingOnFirst) {
        this.initialSegmentTransform = initialSegmentTransform;
        this.isMarkerStart = isMarkerStart;
        this.isMarkerEnd = isMarkerEnd;
        this.startInclusive = startInclusive;
        this.endInclusive = endInclusive;
        this.isStartingOnFirst = isStartingOnFirst;
        this.isStoppingOnFirst = isStoppingOnFirst;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {

        final ObservationCollection<Segment<T>> segments = timeSeries.toSegments(initialSegmentTransform).getValues(t1, t2, inclusive);
        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();

        //tight bounds
        if (!isStartingOnFirst && isStoppingOnFirst) {
            long startWindow = -1;

            for (Observation<Segment<T>> segmentObs : segments) {
                final boolean startEval = isMarkerStart.evaluate(segmentObs.getValue());
                final boolean endEval = isMarkerEnd.evaluate(segmentObs.getValue());

                if (startEval && endEval) {
                    Segment<T> segment = (!startInclusive || !endInclusive) ? Segment.fromSeries(Observations.empty()) : segmentObs.getValue();
                    tsBuilder.add(segmentObs.getTimeTick(), segment);
                    startWindow = -1;
                } else if (startWindow != -1 && endEval) {
                    long endWindow = (endInclusive) ? segmentObs.getValue().end : segmentObs.getValue().start - 1;
                    Segment<T> segment = Segment.fromSeries(
                            startWindow,
                            endWindow,
                            timeSeries.getValues(startWindow, endWindow)
                    );
                    tsBuilder.add(startWindow, segment);
                } else if (startEval) {
                    startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                }
            }
        //loosest bounds
        } else if (isStartingOnFirst && !isStoppingOnFirst) {

            long startWindow = -1;
            long endWindow = -1;

            for (Observation<Segment<T>> segmentObs : segments) {
                if (isMarkerStart.evaluate(segmentObs.getValue()) && endWindow != -1) { //we have found an end and our next value is a start, so end the window
                    //todo its possible that startWindow > endWindow, we may have to check for that
                    Segment<T> segment = Segment.fromSeries(startWindow,endWindow,timeSeries.getValues(startWindow,endWindow));
                    tsBuilder.add(new Observation<>(startWindow,segment));
                    startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                    endWindow = -1;
                } else if (startWindow == -1 && isMarkerStart.evaluate(segmentObs.getValue())) {
                    startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                } else if (isMarkerEnd.evaluate(segmentObs.getValue())) {
                    endWindow = (endInclusive) ? segmentObs.getValue().end : segmentObs.getValue().start - 1;
                }
            }

            if (startWindow != -1 && endWindow != -1) {
                Segment<T> segment = Segment.fromSeries(startWindow,endWindow,timeSeries.getValues(startWindow,endWindow));
                tsBuilder.add(new Observation<>(startWindow,segment));
            }
        } else if (isStoppingOnFirst) {
            long startWindow = -1;

            for (Observation<Segment<T>> segmentObs : segments) {
                if (startWindow != -1 && isMarkerEnd.evaluate(segmentObs.getValue())) {
                    long endWindow = (endInclusive) ? segmentObs.getValue().end : segmentObs.getValue().start - 1;
                    Segment<T> segment = Segment.fromSeries(startWindow,endWindow,timeSeries.getValues(startWindow,endWindow));
                    tsBuilder.add(new Observation<>(startWindow,segment));
                    startWindow = -1;
                } else if (startWindow == -1 && isMarkerStart.evaluate(segmentObs.getValue())) { //no window has started
                    startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                }
            }
        } else {
            long startWindow = -1;
            long stopWindow = -1;

            for (Observation<Segment<T>> segmentObs : segments) {
                final boolean startEval = isMarkerStart.evaluate(segmentObs.getValue());
                final boolean endEval = isMarkerEnd.evaluate(segmentObs.getValue());

                if (startEval && endEval) {
                    Segment<T> segment = (!startInclusive || !endInclusive) ? Segment.fromSeries(Observations.empty()) : segmentObs.getValue();
                    tsBuilder.add(new Observation<>(startWindow, segment));
                    startWindow = -1;
                    stopWindow = -1;
                } else {
                    if (endEval) {
                        stopWindow = (endInclusive) ? segmentObs.getValue().end : segmentObs.getValue().start - 1;
                    } else if (startEval) {
                        if (stopWindow != -1) { //this is our final case so create a segment
                            Segment<T> segment = Segment.fromSeries(
                                    startWindow,
                                    stopWindow,
                                    timeSeries.getValues(startWindow,stopWindow)
                            );
                            tsBuilder.add(new Observation<>(startWindow, segment));
                            startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                            stopWindow = -1;
                        } else {
                            startWindow = (startInclusive) ? segmentObs.getValue().start : segmentObs.getValue().end + 1;
                        }
                    }
                }
            }

            if (startWindow != -1 && stopWindow != -1) {
                Segment<T> segment = Segment.fromSeries(
                        startWindow,
                        stopWindow,
                        timeSeries.getValues(startWindow,stopWindow)
                );
                tsBuilder.add(new Observation<>(startWindow, segment));
            }
        }

        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new BiMarkerBasedSegmentationOnSegment<>(initialSegmentTransform,isMarkerStart,isMarkerEnd,startInclusive,endInclusive,isStartingOnFirst,isStoppingOnFirst);
    }
}
