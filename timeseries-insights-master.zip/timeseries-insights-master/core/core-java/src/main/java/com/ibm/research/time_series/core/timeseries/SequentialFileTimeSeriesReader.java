package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.io.Utils;
import com.ibm.research.time_series.core.io.partitioner.TSPartitionerUtils;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.input.ReversedLinesFileReader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

abstract class SequentialFileTimeSeriesReader<T> implements TimeSeriesReader<T> {

    private Iterator<String> lines;
    private MutableObservationCollection<T> buffer;
    private String path;
    private boolean hasTimestamp;
    private int skipNumLines;
    private int maxBufferSize;

    public SequentialFileTimeSeriesReader(String path, int maxBufferSize, boolean hasTimestamp, int skipNumLines) {
        this.path = path;
        final InputStream inputStream = Utils.inferInputStream(path);
        this.lines =new LineIterator(new InputStreamReader(inputStream));
        int skipCount = 0;
        while (skipCount < skipNumLines && lines.hasNext()) {
            lines.next();
            skipCount++;
        }
        this.buffer = new MutableObservationCollection<>();
        this.hasTimestamp = hasTimestamp;
        this.skipNumLines = skipNumLines;
        this.maxBufferSize = maxBufferSize;
    }

    protected abstract Optional<Observation<T>> parseLine(String line);

    @Override
    public long start() {
        if (!hasTimestamp)
            return 0;

        long start = Long.MIN_VALUE;
        try {
            BufferedReader buffer = new BufferedReader(new FileReader(path));
            for (int i = 0;i < skipNumLines;i++) {
                buffer.readLine();
            }

            Optional<Observation<T>> o = parseLine(buffer.readLine());
            while (!o.isPresent()) {
                o = parseLine(buffer.readLine());
            }
            start = o.get().getTimeTick();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return start;
    }

    @Override
    public long end() {
        if (!hasTimestamp) {
            try {
                return Files.lines(Paths.get(path)).count() - skipNumLines - 1;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        long end = Long.MAX_VALUE;
        if (Utils.getTextFileType(path) > 0) { //if the file is a compressed file, we redd till end...
            try {
                final long[] startEndTs = TSPartitionerUtils.getStartEndTs(path, x -> {
                    final Optional<Observation<T>> opt = parseLine(x);
                    return opt.map(tObservation -> OptionalLong.of(tObservation.getTimeTick())).orElseGet(OptionalLong::empty);
                });
                end = startEndTs[1];//todo this is reading through whole file as it
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else { //if the file is a regular text file, use a optimized reverse file reader
            try {
                ReversedLinesFileReader rf = new ReversedLinesFileReader(new File(path));
                Optional<Observation<T>> o = parseLine(rf.readLine());
                while (!o.isPresent()) {
                    o = parseLine(rf.readLine());
                }
                end = o.get().getTimeTick();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return end;
    }

    @Override
    public Iterator<Observation<T>> read(long t1, long t2, boolean inclusiveIfBoundsNotExist) {
        ObservationCollection<T> current = Observations.empty();
        //first we must check if we have our values already
        if(!buffer.isEmpty()) {

            if (inclusiveIfBoundsNotExist) {
                //need to create new so not reference
                current = buffer.subSet(TimeSeriesReader.getFloor(buffer, t1), true, TimeSeriesReader.getCeiling(buffer, t2), true);
            } else {
                current = buffer.subSet(t1,true,t2,true);
            }

            if (!current.isEmpty() && current.last().getTimeTick() >= t2){
                return current.iterator();
            }
        }

        Iterator<Observation<T>> currentIter = current.iterator();
        final Iterator<String> finalLines = lines;
        return new Iterator<Observation<T>>() {
            boolean foundFirst;
            boolean foundLast = false;
            Queue<Observation<T>> border = new LinkedList<>();
            Observation<T> lookAhead = null;

            @Override
            public boolean hasNext() {
                if (currentIter.hasNext()) {
                    foundFirst = true;
                    //no need to check range here as if we had full it would have been covered in the return above
                    return true;
                } else {
                    if (foundLast) return false;
                    //do normal processing of lines
                    if (!foundFirst) {
                        Observation<T> prevObs = null;
                        while (lines.hasNext() && !foundFirst) {
                            final Optional<Observation<T>> optObs = parseLine(lines.next());
                            if (prevObs == null) {
                                if (optObs.isPresent()) {
                                    prevObs = optObs.get();
                                    buffer.add(prevObs);
                                    if (buffer.size() > maxBufferSize) {
                                        buffer.remove(buffer.first().getTimeTick());
                                    }

                                    if (prevObs.getTimeTick() >= t1) {
                                        border.add(prevObs);
                                        foundFirst = true;
                                        break;//break here so we dont perform another parseLine
                                    }
                                }
                            } else {
                                if (prevObs.getTimeTick() >= t1) {
                                    border.add(prevObs);
                                    foundFirst = true;
                                    break;
                                } else {
                                    if (optObs.isPresent()) {
                                        final Observation<T> nextObs = optObs.get();
                                        buffer.add(nextObs);
                                        if (buffer.size() > maxBufferSize) {
                                            buffer.remove(buffer.first().getTimeTick());
                                        }
                                        if (nextObs.getTimeTick() > t1) {
                                            //need to use both
                                            border.add(prevObs);
                                            border.add(nextObs);
                                            foundFirst = true;
                                            break;
                                        } else if (nextObs.getTimeTick() == t1) {
                                            border.add(nextObs);
                                            foundFirst = true;
                                            break;
                                        } else {
                                            prevObs = nextObs;
                                        }
                                    }
                                }
                            }
                        }
                        return border.size() != 0;
                    } else {
                        while (lookAhead == null && lines.hasNext()) {
                            parseLine(lines.next()).ifPresent(o -> lookAhead = o);
                        }
                        if (lookAhead != null) {
                            buffer.add(lookAhead);
                            if (buffer.size() > maxBufferSize) {
                                buffer.remove(buffer.first().getTimeTick());
                            }
                            if (lookAhead.getTimeTick() >= t2 || !lines.hasNext()) {
                                foundLast = true;
                            }
                            return true;
                        } else {
                            return false;
                        }
                    }
                }
            }

            @Override
            public Observation<T> next() {
                if (currentIter.hasNext()) {
                    return currentIter.next();
                } else {
                    if (border.size() > 0) {
                        return border.remove();
                    } else {
                        final Observation<T> toReturn = new Observation<>(lookAhead);
                        lookAhead = null;
                        return toReturn;
                    }
                }
            }
        };
    }

    @Override
    public void close() {

    }
}
