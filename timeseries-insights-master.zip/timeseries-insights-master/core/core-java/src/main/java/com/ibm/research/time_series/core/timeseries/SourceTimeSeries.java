/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import java.util.*;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.*;
import org.apache.log4j.Logger;

/**
 * Class to handle SourceTimeSeries, TimeSeries object that retrieves directly from a physical source(TimeSeriesReader,list,etc.)
 *
 * @param <T> the type of sensor reading values
 *
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 * @author Mudhakar Srivatsa
 */
class SourceTimeSeries<T> extends TimeSeries<T> {
	private static final Logger logger = Logger.getLogger(SourceTimeSeries.class);

	private TimeSeriesReader<T> source;//read from this source, could be any type of source(pointer to reader)

	/**
	 * Constructs a SourceTimeSeries whose source is a TimeSeriesReader
	 * @param reader our reader, the physical source of data
	 */
	SourceTimeSeries(TimeSeriesReader<T> reader, TRS trs){
	    source = reader;
        cache = new MemCache<>();//memcache is our default, if someone wants to change cache type, they must be explicit
//        forecastingModeOn = false;
        this.trs = trs;
	}

    protected boolean sourceInMemory() {
        return source instanceof ObservationCollectionReader;
    }

    @Override
    public void printDAG() {
        System.out.print(this.getClass().getName() + "---to source-->" + source.getClass().getName());
    }

    @Override
    protected void mineForBounds(List<Pair<Pair<Long, Long>, TRS>> bounds) {
        final long min = source.start();
        final long max = source.end();
        bounds.add(new Pair<>(new Pair<>(min,max), trs));
    }

    /**
     * build our values from a physical source
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return a NavigableSet produced from our resulting read from source
     */
    @Override
    protected ObservationCollection<T> buildValuesFromSource(long t1, long t2,boolean inclusive){

        //todo we can do some sort of source in memory here, may be dangerous but add performance

        Iterator<Observation<T>> result_from_source = source.read(t1, t2,inclusive);
        TSBuilder<T> tsBuilder = Observations.newBuilder();
        while (result_from_source.hasNext()) {
            tsBuilder.add(result_from_source.next());
        }
        ObservationCollection<T> res = tsBuilder.result(this.trs);
        return res;
    }

}
