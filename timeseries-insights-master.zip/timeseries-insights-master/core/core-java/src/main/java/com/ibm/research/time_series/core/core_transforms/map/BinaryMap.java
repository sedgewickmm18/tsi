/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * <p>Generic Binary Transform that transforms 2 inputs into one output</p>
 * <p>Given a time series with values of type INPUT1 and a time series with values of type INPUT2, return a time series of values of type OUTPUT</p>
 * <pre>{@code (x,y) -> z}</pre>
 * <p>Created on 4/12/16.</p>
 *
 * @param <INPUT1> first TimeSeries Observation value type
 * @param <INPUT2> second TimeSeries Observation value type
 * @param <OUTPUT> resulting Observation value type
 *
 * @author Joshua Rosenkranz
 */
class BinaryMap<INPUT1,INPUT2,OUTPUT> extends BinaryTransform<INPUT1,INPUT2,OUTPUT> {

    private static final long serialVersionUID = -944529437622018092L;
    private BinaryMapFunction<INPUT1,INPUT2,OUTPUT> expression;//the expression to be evaluated
    private long lag;

    /**
     * constructor for BinaryMap
     * @param expression expression to evaluate on a window
     */
    BinaryMap(BinaryMapFunction<INPUT1,INPUT2,OUTPUT> expression){
        this.expression = expression;
        this.lag = 0;
    }

    /**
     * constructor for BinaryMap where the second time series has some lag
     * @param lag lag value
     * @param expression expression to evaluate on a window
     */
    BinaryMap(long lag, BinaryMapFunction<INPUT1,INPUT2,OUTPUT> expression){
        this.expression = expression;
        this.lag = lag;
    }

    /**
     * evaluates the given expression on INPUT1/INPUT2 values and returns OUTPUT
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return a transformed TreeSet of Observation values
     */
    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2, boolean inclusive) {
        TSBuilder<OUTPUT> tsBuilder = Observations.newBuilder();

        Iterator<Observation<INPUT1>> inputSetX = this.getTimeSeriesLeft().getValues(t1,t2,inclusive).iterator();
        Iterator<Observation<INPUT2>> inputSetY = this.getTimeSeriesRight().getValues(t1 + lag,t2 + lag,inclusive).iterator();

        inputSetX.forEachRemaining(tssX -> tsBuilder.add(new Observation<>(tssX.getTimeTick(),expression.evaluate(tssX.getValue(),inputSetY.next().getValue()))));
        return tsBuilder.result();
    }

    /**
     * creates a clone of this class
     * @return the clone of this
     */
    @Override
    public Object clone() {
        return new BinaryMap<>(lag,expression);
    }

}
