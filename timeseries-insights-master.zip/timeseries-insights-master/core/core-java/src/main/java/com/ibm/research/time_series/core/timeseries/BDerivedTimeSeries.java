/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import java.util.List;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.TRS;
import org.apache.log4j.Logger;

import com.ibm.research.time_series.core.transform.BinaryTransform;

/**
 * Class to represent a DerivedTimeSeries that was derived from a binary transform.
 * <p>Note: This class will be evaluating a binary transform</p>
 *
 * @param <T> the type of the sensor reading values
 *
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 * @author Mudhakar Srivatsa
 */
class BDerivedTimeSeries<T> extends DerivedTimeSeries<T> {
	private static Logger logger = Logger.getLogger(BDerivedTimeSeries.class);
	protected BinaryTransform<?,?,T> transform;//this is a binary transform to evaluate on

	/**
	 * Constructs a DerivedTimeSeries that will evaluate on a binary transform.
	 * @param transform_in the transform to evaluate on.
	 */
	BDerivedTimeSeries(BinaryTransform<?,?,T> transform_in) {
	    super();
        transform = transform_in;
    }

    @Override
    public void printDAG() {
        System.out.print(this.getClass().getName() + "----->");
        this.transform.getTimeSeriesLeft().printDAG();
        System.out.println("\n ----->");
        this.transform.getTimeSeriesRight().printDAG();
	}

    @Override
    protected void mineForBounds(List<Pair<Pair<Long, Long>, TRS>> bounds) {
        transform.getTimeSeriesLeft().mineForBounds(bounds);
        transform.getTimeSeriesRight().mineForBounds(bounds);
    }

    /**
     * perform evaluation on a Binary DerivedTimeSeries and return result
     * @param t1 time start
     * @param t2 time end
     * @return the resulting NavigableSet produced from the evaluation
     */
    @Override
    protected ObservationCollection<T> performEvaluation(long t1, long t2, boolean inclusive) {
        return transform.evaluate(t1,t2,inclusive);
    }


}
