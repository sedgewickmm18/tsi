/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.core_transforms.join.JoinTransformers;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.functions.NaryMapFunction;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <p>Generic Nary Transform that transforms multiple inputs into one output</p>
 * <p>Given multiple time series with values of type INPUT, return a time series of values of type OUTPUT</p>
 * <pre>{@code (List(x)) -> x'}</pre>
 * <p>Created on 4/13/16.</p>
 *
 * @param <INPUT> initial TimeSeries Observation value type
 * @param <OUTPUT> resulting Observation value type
 *
 * @author Joshua Rosenkranz
 */
class NaryMap<INPUT,OUTPUT> extends NaryTransform<INPUT,OUTPUT> {

    private static final long serialVersionUID = 6371183776682579316L;
    private NaryMapFunction<INPUT,OUTPUT> expression;//expression to be evaluated

    /**
     * constructor for NaryMap
     * @param expression expression to evaluate on a window
     */
    NaryMap(NaryMapFunction<INPUT,OUTPUT> expression){
        this.expression = expression;
    }

    /**
     * evaluates the given expression on a set of INPUT values and returns OUTPUT
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return a transformed TreeSet of Observation values
     */
    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<OUTPUT> tsBuilder = Observations.newBuilder();

        TimeSeries<List<INPUT>> joinedInput = this.getTimeSeriesRoot()
                .transform(this.getTimeSeriesTail(),JoinTransformers.indexJoin(
                        Collections.emptyList(),
                        (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
                ));

        Iterator<Observation<List<INPUT>>> joinedIter = joinedInput.getValues(t1,t2,inclusive).iterator();

        joinedIter.forEachRemaining(tssList -> {
            tsBuilder.add(
                    new Observation<>(
                            tssList.getTimeTick(),
                            expression.evaluate(tssList.getValue())
                    )
            );
        });

        return tsBuilder.result();
    }

    /**
     * creates a clone of this class
     * @return the clone of this
     */
    @Override
    public Object clone() {
        return new NaryMap<>(expression);
    }

}
