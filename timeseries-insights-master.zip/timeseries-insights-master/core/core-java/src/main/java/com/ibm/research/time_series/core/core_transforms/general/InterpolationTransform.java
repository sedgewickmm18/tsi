/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * <p>Created on 7/19/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class InterpolationTransform<T> extends UnaryTransform<T,T> {
    private static final long serialVersionUID = 1291592182428751888L;
    private Interpolator<T> interpolator;
    private long period;
    private boolean startOnBounds;

    InterpolationTransform(Interpolator<T> interpolator,long period, boolean startOnBounds){
        this.interpolator = interpolator;
        this.period = period;
        this.startOnBounds = startOnBounds;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {

        TSBuilder<T> result = Observations.newBuilder();

        ObservationCollection<T> inputSet = this.getTimeSeries().getValues(t1,t2,inclusive);

        if(inputSet.isEmpty()) return inputSet;

        long firstTimestamp = (startOnBounds)
                ? (t1 / period) * period
                : (inputSet.first().getTimeTick() / period) * period;
        long lastTimestamp = (startOnBounds)
                ? (t2 / period) * period
                : (inputSet.last().getTimeTick() / period) * period;

        Iterator<Observation<T>> iterInputSet = inputSet.iterator();
        Observation<T> current = iterInputSet.next();

        for(long timestamp = firstTimestamp;timestamp <= lastTimestamp;timestamp += period){
            if(timestamp == current.getTimeTick()){
                result.add(current);
                if (iterInputSet.hasNext()) current = iterInputSet.next();
            }else if(timestamp < current.getTimeTick()){
                ObservationCollection<T> history = getHistory(timestamp,inputSet);
                ObservationCollection<T> future = getFuture(timestamp,inputSet);
                result.add(new Observation<>(timestamp,interpolator.interpolate(history,future, timestamp)));
            }else{
                while (current.getTimeTick() < timestamp) {
                    if (iterInputSet.hasNext())
                        current = iterInputSet.next();
                    else {
                        //added this so that if start on bounds is true,
                        //its possible for us to not have a has next, in that case we want to just resample
                        break;
                    }
                }

                if (timestamp == current.getTimeTick()) {
                    result.add(current);
                } else {
                    ObservationCollection<T> history = getHistory(timestamp,inputSet);
                    ObservationCollection<T> future = getFuture(timestamp,inputSet);
                    result.add(new Observation<>(timestamp,interpolator.interpolate(history,future, timestamp)));
                }
            }
        }

        return result.result();
    }

    @Override
    public Object clone(){
        return new InterpolationTransform<>(interpolator,period,startOnBounds);
    }

    private ObservationCollection<T> getHistory(long timestamp, ObservationCollection<T> set){

        //we must check if we are in the range, else we will receive an error from headSet
        if (set.isEmpty() || timestamp < set.first().getTimeTick())
            return Observations.empty();

        TSBuilder<T> builder = Observations.newBuilder();

        long timestampToCheck;

        if (timestamp > set.last().getTimeTick())
            timestampToCheck = set.last().getTimeTick();
        else
            timestampToCheck = timestamp;

        Iterator<Observation<T>> headDescending = set.headSet(timestampToCheck, timestampToCheck != timestamp).descendingIterator();

        while(builder.size() != interpolator.getHistorySize() && headDescending.hasNext()){
            builder.add(headDescending.next());
        }

        return builder.result();
    }

    private ObservationCollection<T> getFuture(long timestamp, ObservationCollection<T> set){

        if (set.isEmpty() || timestamp > set.last().getTimeTick())
            return Observations.empty();

        TSBuilder<T> builder = Observations.newBuilder();

        long timestampToCheck;

        if (timestamp < set.first().getTimeTick())
            timestampToCheck = set.first().getTimeTick();
        else
            timestampToCheck = timestamp;

        Iterator<Observation<T>> tailAscending = set.tailSet(timestampToCheck, timestampToCheck != timestamp).iterator();

        while(builder.size() != interpolator.getFutureSize() && tailAscending.hasNext()){
            builder.add(tailAscending.next());
        }

        return builder.result();
    }
}
