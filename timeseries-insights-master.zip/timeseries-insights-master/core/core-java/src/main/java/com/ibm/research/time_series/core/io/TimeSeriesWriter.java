package com.ibm.research.time_series.core.io;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.writers.CSVTimeSeriesWriterFormat;
import com.ibm.research.time_series.core.io.writers.ObjectFileTimeSeriesWriterFormat;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.HashMap;
import java.util.Map;

/**
 * Builder pattern used for writing a {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to an outside
 * datasource
 *
 * <p>A {@link TimeSeriesWriter} has a few components:</p>
 * <ul>
 *     <li>Observations: the in-memory observations to write to an outside datasource</li>
 *     <li>Options: Key-value String pair in Map of options to be used in writing</li>
 *     <li>Value-Encoder: function to encode a value to a String, by default toString is used</li>
 * </ul>
 *
 * <p>This class works in the following way:</p>
 * <ul>
 *     <li>     1. Builds a blank {@link TimeSeriesWriter} that only contains observations.</li>
 *     <li>     2. Set options and value-encoder (optional)</li>
 *     <li>     3. Save to datasource (will save using {@link TimeSeriesWriteFormat}) given options and value-encoder </li>
 * </ul>
 *
 * @param <T> {@link com.ibm.research.time_series.core.timeseries.TimeSeries} value type
 */
public class TimeSeriesWriter<T> {
    private ObservationCollection<T> observations;
    private Map<String,Object> options;
    private UnaryMapFunction<T,String> valueEncoder;

    public TimeSeriesWriter(ObservationCollection<T> observations) {
        this.observations = observations;
        this.options = new HashMap<>();
        this.valueEncoder = Object::toString;
    }

    /**
     * set function to encode a value to a String
     *
     * @param valueEncoder function to encode a value to String
     * @return this {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> encodeValue(UnaryMapFunction<T,String> valueEncoder) {
        this.valueEncoder = valueEncoder;
        return this;
    }

    /**
     * set an option on this {@link TimeSeriesWriter}
     *
     * @param optionKey option key
     * @param optionValue option value
     * @return this {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> option(String optionKey, Object optionValue) {
        options.put(optionKey,optionValue);
        return this;
    }

    /**
     * save to an outside datasource with the given {@link TimeSeriesWriteFormat}
     * @param timeSeriesWriteFormat the {@link TimeSeriesWriteFormat}
     */
    public void save(TimeSeriesWriteFormat<T> timeSeriesWriteFormat) {
        timeSeriesWriteFormat.write(observations,valueEncoder,options);
    }

    /**
     * save as csv
     * @param path path to save to
     */
    public void csv(String path) {
        CSVTimeSeriesWriterFormat<T> csvTimeSeriesWriterFormat = new CSVTimeSeriesWriterFormat<>(path);
        save(csvTimeSeriesWriterFormat);
    }

    /**
     * save as object file
     * @param path path to save to
     */
    public void objectFile(String path) {
        ObjectFileTimeSeriesWriterFormat<T> tsFormat = new ObjectFileTimeSeriesWriterFormat<>(path);
        save(tsFormat);
    }
}
