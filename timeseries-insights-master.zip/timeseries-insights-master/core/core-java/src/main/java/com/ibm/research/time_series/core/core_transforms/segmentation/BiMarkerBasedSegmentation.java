package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

//todo might want to make this an abstract class, fine for now
class BiMarkerBasedSegmentation<T> extends UnaryTransform<T, Segment<T>> {

    private static final long serialVersionUID = 1283261803139976066L;
    private FilterFunction<T> startOp;
    private FilterFunction<T> endOp;
    private boolean startInclusive;
    private boolean endInclusive;
    private boolean isStartingOnFirst;
    private boolean isStoppingOnFirst;

    public BiMarkerBasedSegmentation(FilterFunction<T> startOp, FilterFunction<T> endOp, boolean startInclusive, boolean endInclusive, boolean isStartingOnFirst, boolean isStoppingOnFirst) {
        this.startOp = startOp;
        this.endOp = endOp;
        this.startInclusive = startInclusive;
        this.endInclusive = endInclusive;
        this.isStartingOnFirst = isStartingOnFirst;
        this.isStoppingOnFirst = isStoppingOnFirst;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();

        //this is the default (tight bounds) - starts segment on last start, ends segment on first end
        if (!isStartingOnFirst && isStoppingOnFirst) {
            long startWindow = -1;

            ObservationCollection<T> observations = timeSeries.getValues(t1, t2, inclusive);

            for (Observation<T> obs : observations) {
                final boolean startEval = startOp.evaluate(obs.getValue());
                final boolean endEval = endOp.evaluate(obs.getValue());

                if (startEval && endEval) { //check for a corner case where it finds on start and end
                    Segment<T> segment = Segment.fromSeries(
                            (!startInclusive || !endInclusive) ? Observations.empty() : Observations.<T>newBuilder().add(obs).result()
                    );
                    tsBuilder.add(new Observation<>(obs.getTimeTick(), segment));
                    startWindow = -1;
                } else if (startWindow != -1 && endEval) { //have our start and stop
                    Segment<T> segment = Segment.fromSeries(
                            observations.subSet(startWindow, startInclusive,obs.getTimeTick(), endInclusive)
                    );
                    tsBuilder.add(new Observation<>(startWindow, segment));
                    startWindow = -1;
                } else if (startEval) {
                    startWindow = obs.getTimeTick();
                }
            }
        //loosest bounds - start segment on first start, ends segment on last end
        } else if (isStartingOnFirst && !isStoppingOnFirst) {

            long startWindow = -1;
            long stopWindow = -1;

            ObservationCollection<T> observations = timeSeries.getValues(t1, t2, inclusive);

            for (Observation<T> obs : observations) {
                if (startOp.evaluate(obs.getValue()) && stopWindow != -1) { //we have found an end and our next value is a start, so end the window
                    Segment<T> segment = Segment.fromSeries(
                            observations.subSet(startWindow, startInclusive,stopWindow, endInclusive)
                    );
                    tsBuilder.add(new Observation<>(startWindow, segment));
                    startWindow = obs.getTimeTick();
                    stopWindow = -1;
                } else if (startWindow == -1 && startOp.evaluate(obs.getValue())) {
                    startWindow = obs.getTimeTick();
                } else if (endOp.evaluate(obs.getValue())) {
                    stopWindow = obs.getTimeTick();
                }

            }

            if (startWindow != -1 && stopWindow != -1) {
                Segment<T> segment = Segment.fromSeries(
                        observations.subSet(startWindow, startInclusive,stopWindow, endInclusive)
                );
                tsBuilder.add(new Observation<>(startWindow, segment));
            }
        // start segment on first start, ends segment on first end
        } else if (isStoppingOnFirst) {

            long startWindow = -1;

            ObservationCollection<T> observations = timeSeries.getValues(t1, t2, inclusive);

            for (Observation<T> obs : observations) {
                if (startWindow != -1 && endOp.evaluate(obs.getValue())) { //have our start and stop
                    Segment<T> segment = Segment.fromSeries(
                            observations.subSet(startWindow, startInclusive,obs.getTimeTick(), endInclusive)
                    );
                    tsBuilder.add(new Observation<>(startWindow, segment));
                    startWindow = -1;
                } else if (startWindow == -1 && startOp.evaluate(obs.getValue())) { //no window has started
                    startWindow = obs.getTimeTick();
                }
            }
        // starts segment on last start, ends segment on last end
        } else {
            long startWindow = -1;
            long stopWindow = -1;
            ObservationCollection<T> observations = timeSeries.getValues(t1, t2, inclusive);

            for (Observation<T> obs : observations) {

                final boolean startEval = startOp.evaluate(obs.getValue());
                final boolean endEval = endOp.evaluate(obs.getValue());

                if (startEval && endEval) {
                    Segment<T> segment = Segment.fromSeries(
                            (!startInclusive || !endInclusive) ? Observations.empty() : Observations.<T>newBuilder().add(obs).result()
                    );
                    tsBuilder.add(new Observation<>(obs.getTimeTick(), segment));
                    startWindow = -1;
                    stopWindow = -1;
                } else {
                    if (endEval) {
                        stopWindow = obs.getTimeTick();
                    } else if (startEval) {
                        if (stopWindow != -1) { //this is our final case so create a segment
                            Segment<T> segment = Segment.fromSeries(
                                    observations.subSet(startWindow, startInclusive,stopWindow, endInclusive)
                            );
                            tsBuilder.add(new Observation<>(startWindow, segment));
                            startWindow = obs.getTimeTick();
                            stopWindow = -1;
                        } else {
                            startWindow = obs.getTimeTick();
                        }
                    }
                }
            }

            if (startWindow != -1 && stopWindow != -1) {
                Segment<T> segment = Segment.fromSeries(
                        observations.subSet(startWindow, startInclusive,stopWindow, endInclusive)
                );
                tsBuilder.add(new Observation<>(startWindow, segment));
            }


        }


        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new BiMarkerBasedSegmentation<>(startOp,endOp,startInclusive,endInclusive,isStartingOnFirst,isStoppingOnFirst);
    }
}
