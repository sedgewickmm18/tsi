/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;
import java.io.Serializable;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * Abstract class to represent a UnaryTransform.
 *
 * A UnaryTransform is a transform that takes a single time series (X) and produces another time
 * series (X')
 *
 * <p>A UnaryTransform has no dependence on a TimeSeries, it can be created without a TimeSeries,
 * 	the purpose of TimeSeries in this class is to hold the time series reference when chaining transforms.</p>
 *
 * <p>Any class that extends this class will require:</p>
 * <p>implementation of evaluate - algorithm to perform to go from TimeSeries t to TimeSeries t_prime</p>
 * <p>Optional - implementation of clone if stateful - this method will require the class to make a copy of itself and return(must be used as to not compromise a transformation chain).</p>
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 *
 * @param <IN> time series type in
 * @param <OUT> time series type out
 */
public abstract class UnaryTransform<IN, OUT> extends Transform implements Serializable,Cloneable{

    private static final long serialVersionUID = -3535936845228864348L;

    /**
     * the current state of our time series at any given time in a transform chain
     */
    protected TimeSeries<IN> timeSeries;

	/**
	 * this is the simple evaluate method.
	 * Use this method to write your own implementation of your transform.
     *
     * Within this method, use this classes {@link TimeSeries} and the given parameters to evaluate and transform
     * your time series.
     *
	 * @param t1 timestamp start
	 * @param t2 timestamp end
	 * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
	 * @return the resulting time series after the transform you wish to implement
	 */
	public abstract ObservationCollection<OUT> evaluate(long t1, long t2, boolean inclusive);

	/**
	 * this method is used to save the state of a transform at any given time in the chain of transforms.
	 * To implement this method, you must create a new (x)UnaryTransform with the properties of the current
     * transform and return this new transform.
	 */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

	/**
     * ~~~~~~DEVELOPER API~~~~~~
	 * this method is used to set an operation on a time series of an already existing transform.
	 * @param t the TimeSeries to operate on
	 */
	public void setOperationOn(TimeSeries<IN> t){
		timeSeries = t;
	}

	/**
	 * @return the current state of our time series at any given time in a transform chain
	 */
	public TimeSeries<IN> getTimeSeries(){
		return timeSeries;
	}

}
