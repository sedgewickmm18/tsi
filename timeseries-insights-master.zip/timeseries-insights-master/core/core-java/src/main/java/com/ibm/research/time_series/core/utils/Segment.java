/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.utils;

/**
 * A container that acts as a form of {@link ObservationCollection} with the addition of how the
 * segment was created (with what start and end the segment was originally produced). For Example, if a segment was
 * created based on hourly windows, start may be the start of an hour, end may be the end of the hour, but the
 * Observations contained in this segment need not start on the hour or end on the hour.
 *
 * This is the main construct that is produced from any form of segmentation transform. Built-in
 * transforms includes: segment, segmentByTime, segmentByAnchor
 *
 * <p>Created on 8/28/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class Segment<T> extends ImmutableObservationCollection<T> {

    /**
     * start of window at instantiation time
     */
    public final long start;
    /**
     * end of window at instantiation time
     */
    public final long end;
    /**
     * data to be contained in the segment
     */
    public final ObservationCollection<T> observations;

    public long start() {
        return start;
    }

    public long end() {
        return end;
    }

    public ObservationCollection<T> observations() {
        return observations;
    }

    /**
     * create a segment from an ExplicitlySortedObservationCollection
     *
     * @param start start of window
     * @param end end of window
     * @param observations collection of observations
     */
    public Segment(long start,long end, ObservationCollection<T> observations) {
        super(observations);
        this.start = start;
        this.end = end;
        this.observations = observations;
    }

    /**
     * A special form of instantiation of a segment where the type of ObservationCollection is
     * inferred (either ImplicitlySorted or ExplicitlySorted)
     *
     * Note: start and end time will be that of the incoming data
     *
     * <p>fromSeries([Observation(0,0),Observation(1,1),Observation(10,10)])</p>
     *
     * <p>Segment with start=0,end=10,data=[Observation(0,0),Observation(1,1),Observation(10,10)]</p>
     *
     * @param series the collection of observations given
     * @param <T> the observation value type
     * @return a new segment
     */
    public static <T> Segment<T> fromSeries(ObservationCollection<T> series) {
            return new Segment<>(
                    (series.isEmpty()) ? Long.MIN_VALUE : series.first().getTimeTick(),
                    (series.isEmpty()) ? Long.MAX_VALUE : series.last().getTimeTick(),
                    series
            );
    }

    /**
     * A special form of instantiation of a segment where the type of ObservationCollection is
     * inferred (either ImplicitlySorted or ExplicitlySorted) and the start time and end time are
     * that of the collection of observations coming in.
     *
     * For Example:
     *
     * <p>fromSeries(0,20,[Observation(1,1),Observation(2,2),Observation(10,10)])</p>
     *
     * <p>Segment with start=0,end=20,data=[Observation(0,0),Observation(1,1),Observation(10,10)]</p>
     *
     * @param start start of window
     * @param end end of window
     * @param series the collection of observations given
     * @param <T> the observation value type
     * @return a new segment
     */
    public static <T> Segment<T> fromSeries(long start,long end,ObservationCollection<T> series) {
            return new Segment<>(
                    start,
                    end,
                    series
            );
    }

    /**
     * @return a human readable representation of a Segment
     */
    @Override
    public String toString() {
        if (observations.isEmpty())
            return "this segment is empty";
        else
            return "original bounds: ("+start+","+end+") " +
                "actual bounds: ("+observations.first().getTimeTick()+","+observations.last().getTimeTick()+") " +
                "observations: "+observations.toString();
    }
}
