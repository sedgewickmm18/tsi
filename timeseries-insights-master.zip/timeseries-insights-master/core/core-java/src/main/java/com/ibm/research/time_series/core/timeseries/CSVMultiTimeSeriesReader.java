package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.Pair;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class CSVMultiTimeSeriesReader extends MultiTimeSeriesReader<Map<String,String>, Map<String,String>> {
    private String path;
    private Set<String> keyColumns;
    private String timestampColumn;
    private String delimiter;
    private DateTimeFormatter dateTimeFormatter;
    private boolean sort;
    private Map<String,Integer> headerMapping;
    private int skipNumLines;

    CSVMultiTimeSeriesReader(String path, Set<String> keyColumns, String timestampColumn, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter, boolean sort) {
        this.path = path;
        this.keyColumns = keyColumns;
        this.timestampColumn = timestampColumn;
        this.delimiter = delimiter;
        this.dateTimeFormatter = dateTimeFormatter;
        this.sort = sort;
        this.skipNumLines = (header) ? 1 : 0;
        this.headerMapping = new HashMap<>();
        try {
            String firstLine = Files.lines(Paths.get(path)).findFirst().get(); //todo throw exception here maybe if empty (will add these checks later)
            String[] split = firstLine.split(delimiter);
            for (int i = 0;i < split.length;i++) {
                this.headerMapping.put((header) ? split[i] : "_" + i,i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Optional<Observation<Map<String,String>>> parseObservation(String line, Map<String,String> keyMap) {
        final String[] split = line.split(delimiter);
        final Map<String, String> value = headerMapping.entrySet().stream()
                .map(e -> new AbstractMap.SimpleEntry<>(e.getKey(), split[e.getValue()]))
                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));

        for (String keyColumn : keyColumns) {
            if (!value.get(keyColumn).equals(keyMap.get(keyColumn))) return Optional.empty();
            value.remove(keyColumn);
        }

        final long timestamp = (dateTimeFormatter == null) ? Long.parseLong(value.get(timestampColumn)) : ZonedDateTime.from(dateTimeFormatter.parse(value.get(timestampColumn))).toInstant().toEpochMilli();
        value.remove(timestampColumn);
        return Optional.of(new Observation<>(timestamp,value));
    }

    @Override
    protected Map<Map<String,String>, TimeSeriesReader<Map<String, String>>> populateMap() {
        Map<Map<String,String>,TimeSeriesReader<Map<String, String>>> result = null;
        try(Stream<String> stream = Files.lines(Paths.get(path)).skip(skipNumLines)) {
            result = stream
                    .map(l -> {
                        final String[] split = l.split(delimiter);
                        return keyColumns.stream().map(k -> new AbstractMap.SimpleEntry<>(k,split[headerMapping.get(k)]))
                                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
                    })
                    .distinct()
                    .map(k -> {
                        TimeSeriesReader<Map<String,String>> textFileReader = (sort)
                                ? new TextFileUnsortedTimeSeriesReader<>(path,s -> parseObservation(s,k),skipNumLines)
                                : new TextFileSequentialTimeSeriesReader<>(path,s -> parseObservation(s,k),skipNumLines);

                        return new Pair<>(k,textFileReader);
                    })
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void close() {

    }
}
