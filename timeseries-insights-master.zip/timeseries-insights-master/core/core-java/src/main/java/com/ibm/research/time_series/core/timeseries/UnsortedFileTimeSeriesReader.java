package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.io.Utils;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

abstract class UnsortedFileTimeSeriesReader<T> implements TimeSeriesReader<T>, Serializable {
    private ObservationCollection<T> buffer;
    private Long start;
    private Long end;
    private final String path;
    private final int skipNumLines;

    UnsortedFileTimeSeriesReader(String path, int skipNumLines) {
        this.path = path;
        this.skipNumLines = skipNumLines;
        this.buffer = null;
        this.start = null;
        this.end = null;
    }

    protected abstract Optional<Observation<T>> parseLine(String line);


    @Override
    public Iterator<Observation<T>> read(long t1, long t2,boolean inclusive) {
        if (buffer == null) {
            collectData();
        }
        if(buffer.isEmpty()) return Observations.<T>empty().iterator();

        long from;
        long to;
        if (inclusive) {
            from = TimeSeriesReader.getFloor(buffer, t1);
            to = TimeSeriesReader.getCeiling(buffer, t2);
        } else {
            from = t1;
            to = t2;
        }

        return buffer.subSet(from,true,to,true).iterator();
    }

    @Override
    public void close() {

    }

    @Override
    public long start() {
        if (start == null) {
            collectData();
        }
        return start;
    }

    @Override
    public long end() {
        if (end == null) {
            collectData();
        }
        return end;
    }

    private void collectData() {
        try {
            TSBuilder<T> tsBuilder = Observations.newBuilder();
            final InputStream inputStream = Utils.inferInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String readLine;
            int skipCount = 0;
            while (skipCount < skipNumLines && br.readLine() != null) skipCount++;

            while ((readLine = br.readLine()) != null) {
                parseLine(readLine).ifPresent(tsBuilder::add);
            }
            buffer = tsBuilder.result();
            //todo have to check for an empty buffer here, should we throw exception or just return empty
            start = buffer.first().getTimeTick();
            end = buffer.last().getTimeTick();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
