package com.ibm.research.time_series.core.utils;

import java.util.Iterator;

//todo replace record with a standard map, but for now will keep
public interface Record {
    Object get(String key);
    void set(String key, Object value);
    Iterator<String> keys();
    boolean contains(String key);
    String toString();
}
