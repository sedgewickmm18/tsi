/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.core_transforms.duplicate.DuplicateTransformers;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

import java.util.Arrays;
import java.util.List;

/**
 * A mutable builder for creating a collection of observations
 *
 * <p>Created on 8/28/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class TSBuilder<T> {
    /**
     * the arraylist of current observations added to this builder in order of insertion
     */
    private MutableObservationCollection<T> buffer;

    public TSBuilder() {
        this.buffer = new MutableObservationCollection<>();
    }

    public TSBuilder(int capacityHint) {
        buffer = new MutableObservationCollection<>(capacityHint);
    }

    /**
     * @return number of observations that are currently sitting in this builders buffer
     */
    public int size() {
        return buffer.size();
    }

    /**
     * @return true if this builder's buffer is empty, otherwise false
     */
    public boolean isEmpty() {
        return buffer.isEmpty();
    }

    public TSBuilder<T> add(long timestamp,T value) {
        buffer.add(new Observation<>(timestamp,value));
        return this;
    }

    public TSBuilder<T> add(Observation<T> observation) {
        buffer.add(observation);
        return this;
    }

    public TSBuilder<T> addAll(Iterable<Observation<T>> observations) {
        observations.forEach(buffer::add);
        return this;
    }

    public TSBuilder<T> addAll(Observation<T>... observations) {
        buffer.addAll(Arrays.asList(observations));
        return this;
    }

    public void clear() {
        buffer = new MutableObservationCollection<>();
    }

    public ObservationCollection<T> result(TRS trs, UnaryMapFunction<List<T>, T> combineOp) {
        return TimeSeries.fromObservations(buffer,false, trs)
                .transform(DuplicateTransformers.combineDuplicateTimeTicks(combineOp))
                .collect();
    }

    public ObservationCollection<T> result(TRS trs) {
        return new ImmutableObservationCollection<>(new MutableObservationCollection<>(buffer, trs));
    }

    public ObservationCollection<T> result() {
        return new ImmutableObservationCollection<>(buffer);
    }

    public ObservationCollection<T> result(UnaryMapFunction<List<T>, T> combineOp) {
        return TimeSeries.fromObservations(buffer,false)
                .transform(DuplicateTransformers.combineDuplicateTimeTicks(combineOp))
                .collect();
    }
}
