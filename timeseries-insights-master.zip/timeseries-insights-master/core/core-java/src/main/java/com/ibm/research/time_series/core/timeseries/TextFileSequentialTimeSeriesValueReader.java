package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

class TextFileSequentialTimeSeriesValueReader<T> extends SequentialFileTimeSeriesReader<T> {
    private UnaryMapFunction<String, Optional<T>> valueOp;
    private AtomicLong currentTs;

    public TextFileSequentialTimeSeriesValueReader(String path, UnaryMapFunction<String, Optional<T>> valueOp, int skipNumLines) {
        super(path, Integer.MAX_VALUE, false, skipNumLines);
        this.valueOp = valueOp;
        this.currentTs = new AtomicLong(0);
    }

    @Override
    protected Optional<Observation<T>> parseLine(String line) {
        return valueOp.evaluate(line).map(v -> new Observation<>(currentTs.getAndIncrement(),v));
    }
}
