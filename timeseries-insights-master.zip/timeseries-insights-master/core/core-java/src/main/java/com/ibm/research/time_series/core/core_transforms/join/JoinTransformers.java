/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.transform.NaryTransform;

import java.util.List;

/**
 * This is the entry point for all core built-in transforms for handling TimeSeries joins
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class JoinTransformers {

    /**
     * This is the inner join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally inner join the 2 time series.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.innerAlign(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param f combine function
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of an inner join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> innerJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new InnerJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is the full join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally full join the 2 time series
     * and resample missing values.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev,GenericInterpolators.next)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1]),Observation(2,[1,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values

     * @param leftInterpolator left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a full join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> fullJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f,
            Interpolator<LEFT> leftInterpolator,
            Interpolator<RIGHT> rightInterpolator) {
        return new FullJoin<>(
                MapTransformers.binaryMap(f),leftInterpolator,rightInterpolator);
    }

    /**
     * This is the full join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally full join the 2 time series.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null]),Observation(2,[null,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a full join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> fullJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new FullJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is the left join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally left join the 2 time series
     * and resample missing values.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.next)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1]),Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a left join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> leftJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f,
            Interpolator<RIGHT> rightInterpolator) {
        return new LeftJoin<>(MapTransformers.binaryMap(f),rightInterpolator);
    }

    /**
     * This is the left join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally left join the 2 time series
     * and resample missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null]),Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a left join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> leftJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new LeftJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is the right join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally right join the 2 time series
     * and resample missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[1,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param leftInterpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a right join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> rightJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f,
            Interpolator<LEFT> leftInterpolator) {
        return new RightJoin<>(MapTransformers.binaryMap(f),leftInterpolator);
    }

    /**
     * This is the right join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally right join the 2 time series.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[null,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a right join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> rightJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new RightJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is the left outer join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally left outer join the 2 time
     * series and resample missing values.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a left outer join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> leftOuterJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f,
            Interpolator<RIGHT> rightInterpolator) {
        return new LeftOuterJoin<>(MapTransformers.binaryMap(f),rightInterpolator);
    }

    /**
     * This is the left outer join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally left outer join the 2 time
     * series.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a left outer join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> leftOuterJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new LeftOuterJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is the right outer join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally right outer join the 2 time
     * series and resample missing values.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev())}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[1,1]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param leftInterpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a right outer join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> rightOuterJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f,
            Interpolator<LEFT> leftInterpolator) {
        return new RightOuterJoin<>(MapTransformers.binaryMap(f),leftInterpolator);
    }

    /**
     * This is the right outer join binary transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will temporally right outer join the 2 time
     * series.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[null,1]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param f binary mapper to join values
     * @param <LEFT> left time series observation type
     * @param <RIGHT> right time series observation type
     * @param <OUT> output time series type
     * @return a single instance of a right outer join transform
     */
    public static <LEFT,RIGHT,OUT> BinaryTransform<LEFT,RIGHT,OUT> rightOuterJoin(
            BinaryMapFunction<LEFT,RIGHT,OUT> f) {
        return new RightOuterJoin<>(MapTransformers.binaryMap(f));
    }

    /**
     * This is a simple n-ary join transform, applied on any n
     * {@link TimeSeries}, it will join over a list of TimeSeries and combine observations from each time series based
     * on a temporal inner join strategy.
     *
     * <p>view {@link TimeSeries#innerJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <IN> observation type out
     * @param <OUT> observation type out
     * @return a single instance of an Nary inner join transform
     */
    public static <IN,OUT> NaryTransform<IN,OUT> innerJoin(OUT zeroValue, BinaryMapFunction<OUT,IN,OUT> combineOp) {
        return new InnerNaryTemporalJoin<>(zeroValue,combineOp);
    }

    /**
     * This is a simple n-ary join transform, applied on any n
     * {@link TimeSeries}, it will perform an N-Ary join over a list of TimeSeries and combine observations from each
     * time series based on a temporal full join strategy that sets missing values to null
     *
     * <p>view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <IN> observation type out
     * @param <OUT> observation type out
     * @return a single instance of an Nary full join transform
     */
    public static <IN,OUT> NaryTransform<IN,OUT> fullJoin(OUT zeroValue, BinaryMapFunction<OUT,IN,OUT> combineOp) {
        return new FullNaryTemporalJoin<>(zeroValue,combineOp);
    }

    /**
     * This is a simple n-ary join transform, applied on any n
     * {@link TimeSeries}, it will perform an N-Ary join over a list of TimeSeries and combine observations from each
     * time series based on a temporal full join strategy that interpolates missing values
     *
     * <p>view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction, Interpolator, Interpolator)} for more
     * details</p>
     *
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param inTypeInterpolator initial time series type interpolator
     * @param <IN> observation type out
     * @param <OUT> observation type out
     * @return a single instance of an Nary full join transform
     */
    public static <IN,OUT> NaryTransform<IN,OUT> fullJoin(
            OUT zeroValue,
            BinaryMapFunction<OUT,IN,OUT> combineOp,
            Interpolator<IN> inTypeInterpolator) {
        return new FullNaryTemporalJoin<>(zeroValue,combineOp,inTypeInterpolator);
    }

    /**
     * This is a simple n-ary join transform, applied on any n
     * {@link TimeSeries}, it will join over a list of TimeSeries and combine observations from each time series based
     * on their index in the TimeSeries
     *
     * <p>view {@link TimeSeries#indexJoin(List, Object, BinaryMapFunction)} for more details</p>
     *
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <IN> observation type out
     * @param <OUT> observation type out
     * @return a single instance of an Nary index join transform
     */
    public static <IN,OUT> NaryTransform<IN,OUT> indexJoin(OUT zeroValue,BinaryMapFunction<OUT,IN,OUT> combineOp) {
        return new IndexNaryJoin<>(zeroValue,combineOp);
    }
}
