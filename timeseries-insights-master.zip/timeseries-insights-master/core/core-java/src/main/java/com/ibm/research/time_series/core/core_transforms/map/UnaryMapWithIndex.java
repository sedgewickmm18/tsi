package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

class UnaryMapWithIndex<INPUT,OUTPUT> extends UnaryTransform<INPUT,OUTPUT> {

    private static final long serialVersionUID = -5726438932293835120L;
    private BinaryMapFunction<Integer,INPUT,OUTPUT> mapFunction;

    UnaryMapWithIndex(BinaryMapFunction<Integer,INPUT,OUTPUT> mapFunction) {
        this.mapFunction = mapFunction;
    }

    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<OUTPUT> result = Observations.newBuilder();

        int index = 0;
        for (Observation<INPUT> obs : timeSeries.getValues(t1, t2,inclusive)) {
            result.add(obs.getTimeTick(),mapFunction.evaluate(index,obs.getValue()));
            index++;
        }
        return result.result();
    }

    @Override
    public Object clone() {
        return new UnaryMapWithIndex<>(mapFunction);
    }
}
