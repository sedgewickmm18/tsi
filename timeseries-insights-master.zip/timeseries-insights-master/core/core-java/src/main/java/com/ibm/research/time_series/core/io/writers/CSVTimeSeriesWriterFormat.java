package com.ibm.research.time_series.core.io.writers;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesWriteFormat;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.*;
import java.util.Map;

public class CSVTimeSeriesWriterFormat<T> implements TimeSeriesWriteFormat<T> {
    private BufferedWriter bufferedWriter;
    public CSVTimeSeriesWriterFormat(String path) {
        File f = new File(path);
        try {
            FileOutputStream fos = new FileOutputStream(f);
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(fos));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void write(
            ObservationCollection<T> observations,
            UnaryMapFunction<T, String> encodeValue,
            Map<String, Object> options) {
        String delimiter = (String) options.getOrDefault("delimiter",",");
        boolean header = (boolean) options.getOrDefault("header", true);

        try {
            if (header) {
                bufferedWriter.write("timetick" + delimiter + "value");
                bufferedWriter.newLine();
            }

            for (Observation<T> observation : observations) {
                bufferedWriter.write(observation.getTimeTick() + delimiter + encodeValue.evaluate(observation.getValue()));
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
