package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.observation.Observation;

/**
 * Immutable Stats Container that contains:
 *
 * <p>timeStats: the {@link TimeStats}</p>
 * <p>top: element that occurs most frequently</p>
 * <p>unique: number of unique elements</p>
 * <p>frequency: occurrences of top element</p>
 * <p>first: first observation</p>
 * <p>last: last observation</p>
 * <p>count: number of elements</p>
 *
 * @param <T> time series observation value type
 */
public class Stats<T> extends TimeStats {

    private static final long serialVersionUID = 6279725496178466196L;
    /**
     * element that occurs most frequently
     */
    public final T top;

    /**
     * number of unique elements
     */
    public final long unique;

    /**
     * occurrences of top element
     */
    public final long frequency;

    /**
     * first observation
     */
    public final Observation<T> first;

    /**
     * last observation
     */
    public final Observation<T> last;

    /**
     * number of elements
     */
    public final long count;

    /**
     * Construct a new Stats object
     *
     * @param timeStats the {@link TimeStats} object
     * @param top element that occurs most frequently
     * @param unique number of unique elements
     * @param frequency occurrences of top element
     * @param first first observation
     * @param last last observation
     * @param count number of elements
     */
    public Stats(TimeStats timeStats,T top,long unique,long frequency,Observation<T> first,Observation<T> last,long count) {
        super(timeStats.minInterArrivalTime,timeStats.maxInterArrivalTime, timeStats.meanInterArrivalTime);
        this.top = top;
        this.unique = unique;
        this.frequency = frequency;
        this.first = first;
        this.last = last;
        this.count = count;
    }

    /**
     * Construct a new Stats object from an existing Stats object
     *
     * @param stats stats object
     */
    public Stats(Stats<T> stats) {
        this(new TimeStats(stats.minInterArrivalTime,stats.maxInterArrivalTime,stats.meanInterArrivalTime),stats.top,stats.unique,stats.frequency,stats.first,stats.last,stats.count);
    }

    public long count() {
        return count;
    }

    public long frequency() {
        return frequency;
    }

    public long unique() {
        return unique;
    }

    public Observation<T> first() {
        return first;
    }

    public Observation<T> last() {
        return last;
    }

    public T top() {
        return top;
    }

    /**
     * @return human readable representation of this class
     */
    @Override
    public String toString() {
        return super.toString() + "\n" +
                "top: " + top + "\n" +
                "unique: " + unique + "\n" +
                "frequency: " + frequency + "\n" +
                "first: " + first.toString() + "\n" +
                "last: " + last.toString() + "\n" +
                "count: " + count;
    }
}
