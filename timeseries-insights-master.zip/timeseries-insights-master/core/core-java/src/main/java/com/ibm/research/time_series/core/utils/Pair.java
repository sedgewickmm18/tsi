package com.ibm.research.time_series.core.utils;

import java.io.Serializable;

/**
 * An immutable container that is used to represent a pair of strongly typed objects, similar to that
 * of a scala Tuple2
 *
 * <p>Created on 8/28/17.</p>
 *
 * @author Joshua Rosenkranz
*/
public class Pair<LEFT, RIGHT> implements Serializable{
    private static final long serialVersionUID = -1937840442124540717L;
    /**
     * the left object in this pair
     */
    public final LEFT left;
    /**
     * the right object in this pair
     */
    public final RIGHT right;

    /**
     * instantiate a pair object
     *
     * @param LEFT type LEFT value
     * @param RIGHT type RIGHT value
     */
    public Pair(LEFT LEFT, RIGHT RIGHT) {
        this.left = LEFT;
        this.right = RIGHT;
    }

    /**
     * @return the left object in this pair
     */
    public LEFT left() {
        return left;
    }

    /**
     * @return the right object in this pair
     */
    public RIGHT right() {
        return right;
    }

    /**
     * @return a human readable representation of a pair
     */
    @Override
    public String toString() {
        return "(" + left + ", " + right + ")";
    }

    @Override
    public boolean equals(Object other) {
        //make sure other isn't null
        if(other ==  null){
            return false;
        }

        //if other's reference is this, they are definitely equal
        if(other == this){
            return true;
        }

        //make sure that others type is of this class
        if(!(other instanceof Pair)){
            return false;
        }

        //we are checking correctness above with instanceof
        Pair<LEFT,RIGHT> pair = (Pair<LEFT,RIGHT>)other;

        return left.equals(pair.left) && right.equals(pair.right);
    }

    @Override
    public int hashCode() {
        return left.hashCode() + right.hashCode();
    }
}
