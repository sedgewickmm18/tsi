/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * <p>Created on 5/23/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class AnchorSliding<IN> extends UnaryTransform<IN,Segment<IN>> {

    private static final long serialVersionUID = 7797298330178414209L;
    private long leftDelta;
    private long rightDelta;
    private FilterFunction<IN> anchorF;
    private double perc;

    AnchorSliding(FilterFunction<IN> anchorF, long leftDelta, long rightDelta, double perc) {
        this.anchorF = anchorF;
        this.leftDelta = leftDelta;
        this.rightDelta = rightDelta;
        this.perc = perc;
    }

    AnchorSliding(FilterFunction<IN> anchorF, long leftDelta, long rightDelta) {
        this.anchorF = anchorF;
        this.leftDelta = leftDelta;
        this.rightDelta = rightDelta;
        this.perc = Double.NaN;
    }

    @Override
    public ObservationCollection<Segment<IN>> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<Segment<IN>> tsBuilder = Observations.newBuilder();

        ObservationCollection<IN> ts = this.getTimeSeries().getValues(t1,t2,inclusive);

        ts.forEach(obs -> {
            if(anchorF.evaluate(obs.getValue()) && satisfiesPerc()) {
                ObservationCollection<IN> window = this.getTimeSeries().getValues(
                        obs.getTimeTick() - leftDelta,
                        obs.getTimeTick() + rightDelta,
                        inclusive
                );

                tsBuilder.add(new Observation<>(
                        obs.getTimeTick(),
                        Segment.fromSeries(obs.getTimeTick() - leftDelta,obs.getTimeTick() + rightDelta,window)
                ));
            }
        });
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new AnchorSliding<>(anchorF,leftDelta,rightDelta,perc);
    }

    @Override
    public long getWindow() {
        return rightDelta + leftDelta + 1;
    }

    private boolean satisfiesPerc() {
        return (Double.isNaN(perc)) || Math.random() < perc;
    }
}
