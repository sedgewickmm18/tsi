/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;

import com.ibm.research.time_series.core.core_transforms.join.JoinTransformers;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A special form of {@link NaryTransform} that works over a list of
 * {@link com.ibm.research.time_series.core.timeseries.SegmentTimeSeries} using the transform method or a list of
 * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} using the reduce method.
 *
 * <p>
 *     In the case of a list of {@link com.ibm.research.time_series.core.timeseries.SegmentTimeSeries}, the output will
 *     be a single {@link com.ibm.research.time_series.core.timeseries.TimeSeries}.
 * </p>
 * <p>
 *     In the case of a list of  {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, the output will be a
 *     single value
 * </p>
 *
 * To extend an NaryReducer, one must implement the single method reduceSegment which given a list of
 * segments as a parameter, produces a single value
 *
 * <p>Created on 6/15/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class NaryReducer<IN,OUT> extends NaryTransform<Segment<IN>,OUT> {
    private static final long serialVersionUID = -5007639930751900786L;

    /**
     * implementation of evaluate for an NaryReducer where each segment in the root and list of tail
     * time series is reduced to a single value. Segments will be paired by like index into their
     * corresponding time series.
     *
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return a new observation collection of type OUT
     */
    @Override
    public ObservationCollection<OUT> evaluate(long t1, long t2,boolean inclusive) {
        List<TimeSeries<Segment<IN>>> tsList = new ArrayList<>(this.getTimeSeriesTail());
        tsList.add(this.getTimeSeriesRoot());

        //we use join transform with ValueToList in order to join all n time series and
        //put like indexes in a list
        TimeSeries<List<Segment<IN>>> joinedTS = this.getTimeSeriesRoot()
                .transform(
                        this.getTimeSeriesTail(),
                        JoinTransformers.indexJoin(
                                Collections.emptyList(),
                                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
                        )
                );

        return joinedTS.map(this::reduceSegment).getValues(t1,t2,inclusive);
    }

    /**
     * method to be implemented by user to reduce a list of segments to a single value
     *
     * @param segments list of time series segments {@link Segment}
     * @return a single value
     */
    public abstract OUT reduceSegment(List<Segment<IN>> segments);
}
