/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.duplicate;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Created on 8/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class CombineDuplicateTimeTicks<T> extends UnaryTransform<T,T> {

    private static final long serialVersionUID = -318189953999852660L;
    private UnaryMapFunction<List<T>,T> combineFunction;

    CombineDuplicateTimeTicks(UnaryMapFunction<List<T>,T> combineFunction) {
        this.combineFunction = combineFunction;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {
        final ObservationCollection<T> input = this.getTimeSeries().getValues(t1, t2, inclusive);
        TSBuilder<T> tsBuilder = Observations.newBuilder();

        if (input.isEmpty()) {
            return tsBuilder.result();
        }

        Observation<T> prev = null;
        List<T> currentList = new ArrayList<>();
        for (Observation<T> obs : input) {
            //initial state
            if (prev != null) {
                //if our incoming timestamp is the same as prev
                if (obs.getTimeTick() == prev.getTimeTick()) {
                    if (currentList.isEmpty()) currentList.add(prev.getValue());
                    currentList.add(obs.getValue());
                } else {
                    //if our incoming timestamp is different than prev
                    if (currentList.isEmpty()) {
                        tsBuilder.add(prev);
                    } else {
                        tsBuilder.add(new Observation<>(prev.getTimeTick(), combineFunction.evaluate(currentList)));
                    }
                    currentList = new ArrayList<>();
                }
            }
            prev = obs;
        }
        //have to get last prev
        if (currentList.isEmpty()) {
            tsBuilder.add(prev);
        } else {
            tsBuilder.add(new Observation<>(prev.getTimeTick(), combineFunction.evaluate(currentList)));
        }
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new CombineDuplicateTimeTicks<>(combineFunction);
    }
}
