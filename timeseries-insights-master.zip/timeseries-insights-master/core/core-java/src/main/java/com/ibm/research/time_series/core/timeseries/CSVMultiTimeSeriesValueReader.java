package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.Pair;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class CSVMultiTimeSeriesValueReader extends MultiTimeSeriesReader<Map<String,String>,Map<String,String>> {
    private String path;
    private Set<String> keyColumns;
    private String delimiter;
    private Map<String,Integer> headerMapping;
    private int skipNumLines;

    public CSVMultiTimeSeriesValueReader(String path, Set<String> keyColumns, boolean header, String delimiter) {
        this.path = path;
        this.keyColumns = keyColumns;
        this.delimiter = delimiter;
        this.skipNumLines = (header) ? 1 : 0;
        this.headerMapping = new HashMap<>();
        try {
            String firstLine = Files.lines(Paths.get(path)).findFirst().get(); //todo throw exception here maybe if empty (will add these checks later)
            String[] split = firstLine.split(delimiter);
            for (int i = 0;i < split.length;i++) {
                this.headerMapping.put((header) ? split[i] : "_" + i,i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Optional<Map<String,String>> parseValue(String line, Map<String,String> keyMap) {
        final String[] split = line.split(delimiter);
        final Map<String, String> value = headerMapping.entrySet().stream()
                .map(e -> new AbstractMap.SimpleEntry<>(e.getKey(), split[e.getValue()]))
                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));

        for (String keyColumn : keyColumns) {
            if (!value.get(keyColumn).equals(keyMap.get(keyColumn))) return Optional.empty();
            value.remove(keyColumn);
        }

        return Optional.of(value);
    }

    @Override
    protected Map<Map<String,String>, TimeSeriesReader<Map<String, String>>> populateMap() {
        Map<Map<String,String>,TimeSeriesReader<Map<String, String>>> result = null;
        try(Stream<String> stream = Files.lines(Paths.get(path))) {
            result = stream
                    .map(l -> {
                        final String[] split = l.split(delimiter);
                        return keyColumns.stream().map(k -> new AbstractMap.SimpleEntry<>(k,split[headerMapping.get(k)]))
                                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
                    })
                    .distinct()
                    .map(k -> {
                        TimeSeriesReader<Map<String,String>> textFileReader = new TextFileSequentialTimeSeriesValueReader<>(path,s -> parseValue(s,k),skipNumLines);
                        return new Pair<>(k,textFileReader);
                    })
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void close() {

    }
}
