package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;

import java.io.Serializable;
import java.util.Optional;

class TextFileUnsortedTimeSeriesReader<T> extends UnsortedFileTimeSeriesReader<T> implements Serializable {
    private UnaryMapFunction<String, Optional<Observation<T>>> observationOp;
    TextFileUnsortedTimeSeriesReader(String path, UnaryMapFunction<String, Optional<Observation<T>>> observationOp, int skipNumLines) {
        super(path, skipNumLines);
        this.observationOp = observationOp;
    }

    @Override
    protected Optional<Observation<T>> parseLine(String line) {
        return observationOp.evaluate(line);
    }
}
