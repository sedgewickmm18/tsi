package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * An implementation of {@link ObservationCollection} that allows for additions of {@link Observation}
 * @param <T> {@link Observation} value type
 */
public class MutableObservationCollection<T> implements ObservationCollection<T> {
    private List<Observation<T>> list;
    private TRS trs;

    /**
     * Min inter-arrival-time used in computation of bounds for fast access
     */
    private Long minIAT = null;
    /**
     * Max inter-arrival-time used in computation of bounds for fast access
     */
    private Long maxIAT = null;

    /**
     * Unsorted until index - the index at which a time-tick was added out of order
     */
    private int unsortedUntilIndex = -1;

    /**
     * The min time-tick from the point of an out of order time-tick being added.
     * This will be used in the computation of the point at which to sort so that the whole collection is not sorted,
     * only one higher than the unsortedMin time-tick
     */
    private long unsortedMinTimeTick = Long.MAX_VALUE;

    /**
     * the max time-tick as a placeholder so that last need not be called (last will enforce sorting)
     */
    private long maxTimeTick;
    /**
     * the min time-tick as a placeholder so that first need not be called (first will enforce sorting)
     */
    private long minTimeTick;

    /**
     * Create an empty {@link MutableObservationCollection} with a {@link TRS}
     * @param trs the source {@link TRS}
     */
    public MutableObservationCollection(TRS trs) {
        this.list = new ArrayList<>();
        this.trs = trs;
        this.maxTimeTick = Long.MIN_VALUE;
        this.minTimeTick = Long.MAX_VALUE;
    }

    /**
     * Create a {@link MutableObservationCollection} from a list of {@link Observation}
     *
     * @param list list of {@link Observation}
     * @param sort if true, sort the collection, otherwise assume sorted
     * @param trs the source {@link TRS}
     */
    public MutableObservationCollection(List<Observation<T>> list, boolean sort, TRS trs) {
        this.list = new ArrayList<>(list.size());
        this.maxTimeTick = Long.MIN_VALUE;
        this.minTimeTick = Long.MAX_VALUE;
        this.addAll(list);
        if (sort) enforceSorting();
        this.trs = trs;
    }

    /**
     * Create an empty {@link MutableObservationCollection}
     */
    public MutableObservationCollection() {
        this.list = new ArrayList<>();
        this.trs = null;
        this.maxTimeTick = Long.MIN_VALUE;
        this.minTimeTick = Long.MAX_VALUE;
    }

    /**
     * Create a {@link MutableObservationCollection} with a capacity hint
     * @param capacityHint the capacity hint
     */
    public MutableObservationCollection(int capacityHint) {
        this.list = new ArrayList<>(capacityHint);
        this.trs = null;
        this.maxTimeTick = Long.MIN_VALUE;
        this.minTimeTick = Long.MAX_VALUE;
    }

    /**
     * Create a {@link MutableObservationCollection} from another {@link MutableObservationCollection}.
     *
     * @param sortedList the {@link MutableObservationCollection}
     * @param trs the source {@link TRS}
     */
    public MutableObservationCollection(MutableObservationCollection<T> sortedList, TRS trs) {
        this.list = sortedList.list;
        this.trs = trs;
        this.maxIAT = sortedList.maxIAT;
        this.minIAT = sortedList.minIAT;
        this.unsortedMinTimeTick = sortedList.unsortedMinTimeTick;
        this.unsortedUntilIndex = sortedList.unsortedUntilIndex;
        this.maxTimeTick = sortedList.maxTimeTick;
        this.minTimeTick = sortedList.minTimeTick;
    }

    /**
     * Developer API
     *
     * Only for use from ImmutableObservationCollection
     *
     */
    MutableObservationCollection(MutableObservationCollection<T> observations, int firstIndex, int lastIndex) {
        this.list = observations.list.subList(firstIndex, lastIndex);
        this.maxIAT = observations.maxIAT;
        this.minIAT = observations.minIAT;
        if (!list.isEmpty()) {
            this.maxTimeTick = list.get(list.size() - 1).getTimeTick();
            this.minTimeTick = list.get(0).getTimeTick();
        } else {
            this.maxTimeTick = Long.MIN_VALUE;
            this.minTimeTick = Long.MAX_VALUE;
        }
        this.unsortedMinTimeTick = Long.MAX_VALUE;
        this.trs = observations.trs;
    }

    /**
     * add an {@link Observation} to the collection
     * @param tObservation the observation to add
     * @return true if the collection changed
     */
    public boolean add(Observation<T> tObservation) {
        // todo might be able to reduce max/min computations rather than to check it on every addition?
        maxTimeTick = Math.max(maxTimeTick, tObservation.getTimeTick());
        minTimeTick = Math.min(minTimeTick, tObservation.getTimeTick());
        list.add(tObservation);

        if (list.size() >= 2) {
            Observation<T> last = list.get(list.size() - 2);

            // if minIAT is neg we are unsorted
            // reset to default
            long iat = tObservation.getTimeTick() - last.getTimeTick();
            if (minIAT == null || maxIAT == null) {
                minIAT = iat;
                maxIAT = iat;
            } else {
                minIAT = Math.min(minIAT, iat);
                maxIAT = Math.max(maxIAT, iat);
            }


            if (minIAT < 0) {
                unsortedMinTimeTick = Math.min(unsortedMinTimeTick, tObservation.getTimeTick());

                if (unsortedUntilIndex == -1) {
                    unsortedUntilIndex = list.size() - 1;
                }
            }
        }

        return true;
    }

    public boolean removeHeadSet(long timestamp, boolean inclusive) {
        enforceSorting();
        int index = (!contains(timestamp) || !inclusive) ? getLowerIndex(timestamp) : getCeilingIndex(timestamp);

        if (index == -1) {
            return false;
        } else {
            if (index >= 0) {
                list.subList(0, index + 1).clear();
            }
            if (!list.isEmpty()) {
                minTimeTick = list.get(0).getTimeTick();
                maxTimeTick = list.get(list.size()-1).getTimeTick();
            } else {
                minTimeTick = Long.MAX_VALUE;
                maxTimeTick = Long.MIN_VALUE;
            }
            return true;
        }
    }

    public boolean removeTailSet(long timestamp, boolean inclusive) {
        enforceSorting();
        int index = (!contains(timestamp) || !inclusive) ? getHigherIndex(timestamp) : getFloorIndex(timestamp);

        if (index == -1) {
            return false;
        } else {
            list.subList(index,list.size()).clear();
            if (!list.isEmpty()) {
                minTimeTick = list.get(0).getTimeTick();
                maxTimeTick = list.get(list.size()-1).getTimeTick();
            } else {
                minTimeTick = Long.MAX_VALUE;
                maxTimeTick = Long.MIN_VALUE;
            }
            return true;
        }
    }

    /**
     * remove all {@link Observation} that have the given time-tick
     * @param timeTick the given time-tick to remove
     * @return true if the collection changed
     */
    public boolean remove(long timeTick) {
        enforceSorting();
        int start = getFloorIndex(timeTick);
        int end = getCeilingIndex(timeTick);
        if (start == -1 || end == -1)
            return false;
        else {
            for (int i = end;i >= start;i--) {
                list.remove(i);
            }
            if (!list.isEmpty()) {
                minTimeTick = list.get(0).getTimeTick();
                maxTimeTick = list.get(list.size()-1).getTimeTick();
            } else {
                minTimeTick = Long.MAX_VALUE;
                maxTimeTick = Long.MIN_VALUE;
            }
            return true;
        }
    }

    public boolean addAll(Collection<? extends Observation<T>> c) {
        c.forEach(this::add);
        return true;
    }

    public boolean removeAll(Collection<? extends Long> c) {
        boolean flag = false;
        for (long l : c) {
            boolean changed = remove(l);
            if(changed) flag = true;
        }
        return flag;
    }

    public boolean retainAll(Collection<? extends Long> c) {
        HashSet<Long> set = new HashSet<>();
        list.forEach(obs -> set.add(obs.getTimeTick()));

        HashSet<Long> cSet = new HashSet<>();
        c.forEach(l -> cSet.add(l));

        boolean flag = false;

        for (long timestamp : set) {
            if (!cSet.contains(timestamp)) {
                if (remove(timestamp))
                    flag = true;
            }
        }

        return flag;
    }

    public void clear() {
        list.clear();
        minIAT = null;
        maxIAT = null;
        unsortedMinTimeTick = Long.MAX_VALUE;
        unsortedUntilIndex = -1;
        minTimeTick = Long.MAX_VALUE;
        maxTimeTick = Long.MIN_VALUE;
    }

    @Override
    public boolean contains(long timestamp) {
        return list.stream().anyMatch(x -> x.getTimeTick() == timestamp);
    }

    @Override
    public boolean containsAll(Collection<? extends Long> c) {
        return c.stream().allMatch(this::contains);
    }

    @Override
    public Iterator<Observation<T>> iterator() {
        enforceSorting();
        return list.iterator();
    }

    @Override
    public Stream<Observation<T>> parallelStream() {
        enforceSorting();
        return list.parallelStream();
    }

    @Override
    public Spliterator<Observation<T>> spliterator() {
        enforceSorting();
        return list.spliterator();
    }

    @Override
    public Stream<Observation<T>> stream() {
        enforceSorting();
        return list.stream();
    }

    @Override
    public Object[] toArray() {
        enforceSorting();
        return list.toArray();
    }

    @Override
    public Observation<T>[] toArray(Observation<T>[] a) {
        enforceSorting();
        return list.toArray(a);
    }

    @Override
    public Observation<T> ceiling(long timestamp) {
        if (list.isEmpty()) throw new TSRuntimeException("cannot get ceiling of empty collection",new NoSuchElementException());

        enforceSorting();

        int result = getCeilingIndex(timestamp);

        if (result == -1) {
            return null;
        } else {
            return list.get(result);
        }
    }

    @Override
    public Observation<T> floor(long timestamp) {
        if (list.isEmpty()) throw new TSRuntimeException("cannot get first observation of empty collection",new NoSuchElementException());

        enforceSorting();

        int result = getFloorIndex(timestamp);

        if (result == -1) {
            return null;
        } else {
            return list.get(result);
        }
    }

    @Override
    public ObservationCollection<T> headSet(long to, boolean toInclusive) {
        if (list.isEmpty()) return new ImmutableObservationCollection<>();

        enforceSorting();

        int lastIndex;

        if (toInclusive) {
            if (maxTimeTick <= to) {
                lastIndex = size();
            } else {
                lastIndex = getHigherIndex(to);
            }
        } else {
            lastIndex = getLowerIndex(to) + 1;
        }

        if (lastIndex == -1) {
            return new ImmutableObservationCollection<>();
//            throw new TSRuntimeException("Cannot get headset of lowest observation", new NoSuchElementException());
        } else {
            return new ImmutableObservationCollection<>(this,0, lastIndex);
        }
    }

    @Override
    public ObservationCollection<T> tailSet(long from, boolean fromInclusive) {
        if (list.isEmpty()) return new ImmutableObservationCollection<>();

        enforceSorting();

        int firstIndex;

        if (fromInclusive) {
            if (minTimeTick >= from) {
                firstIndex = 0;
            } else {
                firstIndex = getLowerIndex(from) + 1;
            }
        } else {
            firstIndex = getHigherIndex(from);
        }

        if (firstIndex == -1) {
            return new ImmutableObservationCollection<>();
//            throw new TSRuntimeException("Cannot get tailset of highest observation", new NoSuchElementException());
        } else {
            return new ImmutableObservationCollection<>(this, firstIndex, list.size());
        }
    }

    @Override
    public Iterator<Observation<T>> descendingIterator() {
        enforceSorting();
        return new Iterator<Observation<T>>() {
            int i = list.size() - 1;

            @Override
            public boolean hasNext() {
                return i >= 0;
            }

            @Override
            public Observation<T> next() {
                Observation<T> res = list.get(i);
                i--;
                return res;
            }
        };
    }

    @Override
    public ObservationCollection<T> subSet(long from, boolean fromInclusive, long to, boolean toInclusive) {
        if (list.isEmpty()) {
            return new ImmutableObservationCollection<>();
        }

        enforceSorting();

        int firstIndex;

        if (fromInclusive) {
            if (minTimeTick >= from) {
                firstIndex = 0;
            } else {
                firstIndex = getLowerIndex(from) + 1;
            }
        } else {
            firstIndex = getHigherIndex(from);
        }

        if (firstIndex == -1) {
            return new ImmutableObservationCollection<>();
//            throw new TSRuntimeException("Cannot get first index of subset", new NoSuchElementException());
        }

        int lastIndex;

        if (toInclusive) {
            if (maxTimeTick <= to) {
                lastIndex = size();
            } else {
                lastIndex = getHigherIndex(to);
            }
        } else {
            lastIndex = getLowerIndex(to) + 1;
        }

        if (lastIndex == -1) {
            return new ImmutableObservationCollection<>();
//            throw new TSRuntimeException("Cannot get last index of subset", new NoSuchElementException());
        }

        return new ImmutableObservationCollection<>(this, firstIndex, lastIndex);
    }

    @Override
    public Observation<T> first() {
        if (list.isEmpty()) {
            throw new TSRuntimeException("cannot get first observation of empty collection",new NoSuchElementException());
        }

        enforceSorting();
        return list.get(0);
    }

    @Override
    public Observation<T> last() {
        if (list.isEmpty()) throw new TSRuntimeException("cannot get last observation of empty collection",new NoSuchElementException());

        enforceSorting();
        return list.get(list.size()-1);
    }

    @Override
    public Observation<T> higher(long timestamp) {
        if (list.isEmpty()) throw new TSRuntimeException("cannot get first observation of empty collection",new NoSuchElementException());

        enforceSorting();

        int result = getHigherIndex(timestamp);

        if (result == -1) {
            return null;
        } else {
            return list.get(result);
        }
    }

    @Override
    public Observation<T> lower(long timestamp) {
        if (list.isEmpty()) throw new TSRuntimeException("cannot get first observation of empty collection",new NoSuchElementException());

        enforceSorting();

        int result = getLowerIndex(timestamp);

        if (result == -1) {
            return null;
        } else {
            return list.get(result);
        }
    }

    @Override
    public TimeSeries<T> toTimeSeriesStream() {
        return TimeSeries.fromObservations(new ImmutableObservationCollection<>(this),this.trs);
    }

    @Override
    public TimeSeries<T> toTimeSeriesStream(TRS trs) {
        return TimeSeries.fromObservations(new ImmutableObservationCollection<>(this), trs);
    }

    @Override
    public Collection<Observation<T>> toCollection() {
        enforceSorting();
        return list;
    }

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public TRS getTRS() {
        return trs;
    }

//    @Override
//    public boolean isPeriodic() {
//        return (maxIAT != null && minIAT != null) && maxIAT.equals(minIAT);
//    }

    @Override
    public String toString() {
        enforceSorting();

        return list.stream().map(obs -> {
            String valString = (obs.getValue() != null) ? obs.getValue().toString() : "null";
            String timeTickString = (trs != null) ? obs.getTimestamp(trs).toString() : String.valueOf(obs.getTimeTick());
            return "(" + timeTickString + "," + valString + ")";
        }).collect(Collectors.joining(",", "[", "]"));
    }

    private void enforceSorting() {
        if (minIAT != null && minIAT < 0) {
            if (unsortedMinTimeTick == Long.MAX_VALUE) {
                Collections.sort(list);
            } else {
                // if unsorted and we are doing a sort, use the first instance of an unsorted being added index as
                // the top end of sublist
                int h = getHigherIndexTilUnsorted(unsortedMinTimeTick);
                Collections.sort(list.subList(h,list.size()));
            }

            // reset our values
            unsortedUntilIndex = -1;
            unsortedMinTimeTick = Long.MAX_VALUE;

            // recalculate minIAT and maxIAT
            recalculateInterArrivalTimes();
        }
    }

    private void recalculateInterArrivalTimes() {
        minIAT = Long.MAX_VALUE;
        maxIAT = Long.MIN_VALUE;
        for (int i = 0;i < list.size()-1;i++) {
            long curIat = list.get(i + 1).getTimeTick() - list.get(i).getTimeTick();
            if (curIat < minIAT) minIAT = curIat;
            if (curIat > maxIAT) maxIAT = curIat;
        }
    }

    /*
     * Assumes that offset is in [0, lastTimeTick - firstTimeTick]
     */
    private int getMinIndex(long offset) {
        int minIndex = 0;
        /*
         * if maxIAT is not initialized or it is equal to zero then minIndex is 0
         */
        if (maxIAT != null && maxIAT > 0) {
            minIndex = (int) (offset / maxIAT);
        }
        return minIndex;
    }
    /*
     * Assumes that offset is in [0, lastTimeTick - firstTimeTick]
     */
    private int getMaxIndex(long offset) {
        int maxIndex = list.size() - 1;
        /*
         * if minIAT is not initialized or it is equal to zero then maxIndex =
         * list.size()-1
         */
        if (minIAT != null && minIAT > 0) {
            maxIndex = (int) (offset / minIAT);
            if (offset % minIAT != 0) {
                maxIndex++;
            }
        }
        return maxIndex;
    }
    /**
     * Given a target time-tick, find the index into the list which is the floor
     * time-tick of target. 0 1 2 3 4 For example: [1, 2, 3, 5, 6]
     *
     * getFloorIndex(3) => 2 getFooorIndex(0) => -1 getFloorIndex(7) => 4
     * getFloorIndex(4) => 2
     *
     * @param target the target time-tick to find the floor index for
     * @return the floor index
     */
    private int getFloorIndex(long target) {
        if (list.isEmpty()) {
            return -1;
        }
        // list size >= 1, hence first and last exist
        long first = minTimeTick;
        if (target < first) {
            return -1;
        }
        long last = maxTimeTick;
        if (target > last) {
            return list.size() - 1;
        }
        // at this stage first <= target <= last
        long offset = target - first;
        int l = getMinIndex(offset);
        int r = getMaxIndex(offset);
        // must cap l and r in case they are below 0 or greater than list size - 1
        l = Math.max(l, 0);
        r = Math.min(r, list.size()-1);
        int result = -1;
        while (l <= r) {
            int m = (l + r) / 2;
            if (list.get(m).getTimeTick() == target) {
                do {
                    result = m;
                    m--;
                } while (m >= 0 && list.get(m).getTimeTick() == target);
                break;
            } else if (list.get(m).getTimeTick() > target) {
                r = m - 1;
            } else {
                result = m;
                l = m + 1;
            }
        }
        return result;
    }
    /**
     * Given a target time-tick, find the index into the list which is the lower
     * time-tick of target. 0 1 2 3 4 For example: [1, 2, 3, 5, 6]
     *
     * getLowerIndex(3) => 1 getLowerIndex(0) => -1 getLowerIndex(7) => 4
     * getLowerIndex(4) => 2
     *
     * @param target the target time-tick to find the lower index for
     * @return the lower index
     */
    private int getLowerIndex(long target) {
        if (list.isEmpty()) {
            return -1;
        }
        // list size >= 1, hence first and last exist
        long first = minTimeTick;
        if (target <= first) {
            return -1;
        }
        long last = maxTimeTick;
        if (target > last) {
            return list.size() - 1;
        }
        // at this stage first < target <= last
        long offset = target - first;
        int l = getMinIndex(offset);
        int r = getMaxIndex(offset);
        // must cap l and r in case they are below 0 or greater than list size - 1
        l = Math.max(l - 1, 0);
        r = Math.min(r, list.size()-1);
        int result = -1;
        while (l <= r) {
            int m = (l + r) / 2;
            if (list.get(m).getTimeTick() < target) {
                result = m;
                l = m + 1;
            } else {
                r = m - 1;
            }
        }
        return result;
    }
    /**
     * Given a target time-tick, find the index into the list which is the ceiling
     * time-tick of target. 0 1 2 3 4 For example: [1, 2, 3, 5, 6]
     *
     * getCeilingIndex(3) => 2 getCeilingIndex(0) => 0 getCeilingIndex(7) => -1
     * getCeilingIndex(4) => 3
     *
     * @param target the target time-tick to find the ceiling index for
     * @return the ceiling index
     */
    private int getCeilingIndex(long target) {
        if (list.isEmpty()) {
            return -1;
        }
        // list size >= 1, hence first and last exist
        long first = minTimeTick;
        if (target < first) {
            return 0;
        }
        long last = maxTimeTick;
        if (target > last) {
            return -1;
        }
        // at this stage first <= target <= last
        long offset = target - first;
        // must cap l and r in case they are below 0 or greater than list size - 1
        int l = getMinIndex(offset);
        int r = getMaxIndex(offset);
        l = Math.max(l, 0);
        r = Math.min(r, list.size() - 1);
        int result = -1;
        while (l <= r) {
            int m = (l + r) / 2;
            if (list.get(m).getTimeTick() == target) {
                do {
                    result = m;
                    m++;
                } while (m < list.size() && list.get(m).getTimeTick() == target);
                break;
            } else if (list.get(m).getTimeTick() < target) {
                l = m + 1;
            } else {
                result = m;
                r = m - 1;
            }
        }
        return result;
    }

    /**
     * Given a target time-tick, find the index into the list which is the higher
     * time-tick of target. 0 1 2 3 4 For example: [1, 2, 3, 5, 6]
     *
     * getHigherIndex(3) => 3 getHigherIndex(0) => 0 getHigherIndex(7) => -1
     * getHigherIndex(4) => 3
     *
     * @param target the target time-tick to find the higher index for
     * @return the higher index
     */
    private int getHigherIndex(long target) {
        if (list.isEmpty()) {
            return -1;
        }
        // list size >= 1, hence first and last exist
        long first = minTimeTick;
        if (target < first) {
            return 0;
        }
        long last = maxTimeTick;
        if (target >= last) {
            return -1;
        }
        // at this stage first <= target < last
        long offset = target - first;
        int l = getMinIndex(offset);
        int r = getMaxIndex(offset);
        // must cap l and r in case they are below 0 or greater than list size - 1
        l = Math.max(l, 0);
        r = Math.min(r + 1, list.size() - 1);
        if (r >= list.size()) {
            return -1;
        }
        int result = -1;
        while (l <= r) {
            int m = (l + r) / 2;
            if (list.get(m).getTimeTick() <= target) {
                l = m + 1;
            } else {
                result = m;
                r = m - 1;
            }
        }
        return result;
    }

    /**
     * Given a target time-tick, find the index into the list which is the higher
     * time-tick of target, but only taking into account the sorted part of the list.
     * 0 1 2 3 4 5 6 7 For example: [1, 2, 3, 5, 6, 5, 6, 7] (this method will only look at [1, 2, 3, 5, 6])
     *
     * getHigherIndex(3) => 3 getHigherIndex(0) => 0 getHigherIndex(7) => -1
     * getHigherIndex(4) => 3
     *
     * @param target the target time-tick to find the higher index for
     * @return the higher index
     */
    private int getHigherIndexTilUnsorted(long target) {
        if (list.isEmpty()) {
            return -1;
        }
        // list size >= 1, hence first and last exist
        long first = minTimeTick;
        if (target < first) {
            return 0;
        }
        long last = maxTimeTick;
        if (target >= last) {
            return -1;
        }
        // at this stage first <= target < last
        long offset = target - first;
        int l = getMinIndex(offset);
        int r = getMaxIndex(offset);
        // must cap l and r in case they are below 0 or greater than list size - 1
        l = Math.max(l, 0);
        r = Math.min(r + 1, unsortedUntilIndex);
        if (r >= list.size()) {
            return -1;
        }
        int result = -1;
        while (l <= r) {
            int m = (l + r) / 2;
            if (list.get(m).getTimeTick() <= target) {
                l = m + 1;
            } else {
                result = m;
                r = m - 1;
            }
        }
        return result;
    }
}
