/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.cache.Cache;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ImmutableObservationCollection;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Serializable;
import java.util.*;

/**
 * In memory cache which implements the Cache interface
 * <p>This cache is the default cache used in TimeSeries.
 * MemCache implies that our cache has Observation stored in memory for quick access.
 * The underlying structure of this cache is an ExplicitlySortedObservationCollection</p>
 * <p>Created on 12/3/15.</p>
 *
 * @author Joshua Rosenkranz
 */
class MemCache<T> implements Cache<T>, Serializable {
    private static final long serialVersionUID = 5315549906259039999L;
    private MutableObservationCollection<T> cache;//our cache
    private int maxSize;//max size of cache

    /**
     * Default constructor for MemCache
     * <p>Note: The default maximum cache size is Maximum integer size</p>
     */
    MemCache(){
        cache = new MutableObservationCollection<>();
        maxSize = 0;
    }

    /**
     * Constructor for MemCache that takes in a max cache size
     * @param maxSize max size to set the cache to
     */
    public MemCache(int maxSize){
        this.maxSize = maxSize;
    }

    /**
     * add a Observation to our cache storage
     * @param tss the Observation to add
     */
    @Override
    public void add(Observation<T> tss) {
        if (getMaxCacheSize() > 0 && cache.size() >= getMaxCacheSize()) {
             if (tss.getTimeTick() > cache.first().getTimeTick()) {
                 cache.remove(cache.first().getTimeTick());
                 cache.add(tss);
             }
        } else if (getMaxCacheSize() > 0) {
            cache.add(tss);
        }
    }

    /**
     * gets the first Observation in our cache storage
     * @return first Observation in cache storage
     */
    @Override
    public Observation<T> first() {
        return cache.first();
    }

    /**
     * gets the last Observation in our cache storage
     * @return last Observation in cache storage
     */
    @Override
    public Observation<T> last() {
        return cache.last();
    }

    /**
     * gets the current number of TimeStampSensors in our cache storage
     * @return number of TimeStampSensors in our cache storage
     */
    @Override
    public int size() {
        return cache.size();
    }

    /**
     * @return true if cache storage is empty, false if items are in the cache storage
     */
    @Override
    public boolean isEmpty(){
        return cache.isEmpty();
    }

    /**
     * returns our entire cache storage as a SortedSet
     * @return SortedSet with our cache storage
     */
    @Override
    public ObservationCollection<T> getCache(){
        return cache;
    }

    /**
     * returns a subset of our cache from given floor to given ceiling
     * @param t1 timestamp start, the given floor
     * @param t2 timestamp end, the given ceiling
     * @return SortedSet subset of cache storage with our TimeStampSensors from the cache
     */
    @Override
    public ObservationCollection<T> getCacheInRange(long t1, long t2,boolean inclusiveIfNotOnBoundary){

        //cache is empty, just return in, no need to get any subset
        if (cache.isEmpty()) {
            return new ImmutableObservationCollection<>(cache);
        }

        if (!inclusiveIfNotOnBoundary) {
            return new ImmutableObservationCollection<>(cache.subSet(t1,true,t2,true));
        }

        long floor;
        long ceiling;
        //since getCacheInRange by default uses non-strict boundaries, we must stretch the bounds
        //if t1 and t2 are not found in our cache

        //if cache contains our dummy lower bound observation, we can set the floor to this dummy
        //observation since we know the subset floor of our cache will contain this observation's
        //timestamp
        if(cache.contains(t1)){
            floor = t1;
        }else{
            Observation<T> floorHolder = cache.floor(t1);
            //cache doesn't contain our dummy observation or the given observation doesn't have a
            //floor in our cache so return the ceiling
            if(floorHolder == null){
                floor = cache.ceiling(t1).getTimeTick();
            }else{
                floor = floorHolder.getTimeTick();
            }
        }

        //if cache contains our dummy upper bound observation, we can set the ceiling to this dummy
        //observation since we know the subset ceiling of our cache will contain this observation's
        //timestamp
        if(cache.contains(t2)){
            ceiling = t2;
        }else{
            Observation<T> ceilingHolder = cache.ceiling(t2);
            //cache doesn't contain our dummy observation or the given observation doesn't have a
            //ceiling in our cache so return the floor
            if(ceilingHolder == null){
                ceiling = cache.floor(t2).getTimeTick();
            }else{
                ceiling = ceilingHolder.getTimeTick();
            }
        }

        return cache.subSet(floor,true,ceiling,true);
    }

    /**
     * @return iterator to beginning of our cache storage
     */
    @Override
    public Iterator<Observation<T>> iterator(){
        return cache.iterator();
    }

    /**
     * sets the maximum size of our cache storage.
     * @param maxSize the maximum size to set our cache storage too
     */
    @Override
    public void setMaxCacheSize(int maxSize) {
        this.maxSize = maxSize;
    }

    /**
     * get the maximum size of our cache
     * @return the maximum size of our cache
     */
    @Override
    public int getMaxCacheSize(){
        return maxSize;
    }

    /**
     * clear the cache
     */
    @Override
    public void clear() {
        cache.clear();
    }
}
