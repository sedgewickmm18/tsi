/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.forecasting;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Prediction;

import java.io.Serializable;

/**
 * Interface for a forecasting model to be used in the TimeSeries framework if forecasting is enabled.
 * <p>Created on 2/1/16.</p>
 *
 * @param <T> the type of sensor readings
 * @author Joshua Rosenkranz
 * @author David Wood
 */
public interface ObservationForecastingModel<T> extends Serializable {

    /**
     * reset the model to its initial state
     */
    void resetModel();

    /**
     * Train / Initialize a forecasting model
     * @param observations the observations to train with
     * @return true, if the model is fully initialized, otherwise return false
     */
    boolean trainModel(ObservationCollection<T> observations);

    /**
     * Get the next numPredictions predictions given a confidence for bounds
     * @param numPredictions number of predictions
     * @param confidence confidence to be used in calculation of bounds
     * @return a collection of {@link Prediction}
     */
    ObservationCollection<Prediction<T>> predict(int numPredictions, double confidence);
}
