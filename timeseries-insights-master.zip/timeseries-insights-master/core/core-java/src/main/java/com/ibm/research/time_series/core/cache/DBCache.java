/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache;

import com.esotericsoftware.kryo.Kryo;
import com.ibm.research.time_series.core.observation.Observation;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * This is the abstract class that implements a Database version of Cache
 * <p>This class will handle all general Database cache items such as size, first/last row, etc.</p>
 * <p>Created on 1/18/16.</p>
 *
 * @author Joshua Rosenkranz
 * @author Mudhakar Srivatsa
 */
public abstract class DBCache<T> implements Cache<T> {
    private static final Logger logger = Logger.getLogger(DBCache.class);

    private Kryo kryo = new Kryo();

    private int maxSize;//max size of the cache as specified at construction time
    private int cacheSize = 0;//current cache size

    protected long firstRow = -1;//first row of cache timestamp
    protected long lastRow = -1;//last row of cache timestamp
    private double factor;//factor to allow past max size

    private long resizedFirstRow = -1;//in the event that we go 2 times over our cache size, this will be the new firstRow


    /**
     * create a DBCache with a maxSize and factor
     *
     * @param maxSize overall max size of cache to shrink to
     * @param factor how many times the max cache to force a shrink
     */
    public DBCache(int maxSize,double factor) {
        this.maxSize = maxSize;
        this.factor = factor;
    }
    /**
     * add a row to the table
     * @param obs {@link Observation} to add
     */
    public abstract void addRow(Observation<T> obs);

    /**
     * @param obs Observation to check for timestamp
     * @return true if the table contains the given observation timestamp
     */
    protected abstract boolean contains(Observation<T> obs);

    @Override
    public void add(Observation<T> obs) {
        logger.debug("adding Observation object to our db cache");
        if (!this.contains(obs)) {
            if (cacheSize >= maxSize * factor) {
                if (obs.getTimeTick() > firstRow) {
                    addRow(obs);
                    cacheSize++;
                    shrinkCache();
                    cacheSize = maxSize;
                }
            } else {
                addRow(obs);
                cacheSize++;
            }
        }

        //check if firstRow has been set or the new timestamp is less than first row, if this is the case we have a new first row
        if(firstRow == -1 || firstRow > obs.getTimeTick()){
            logger.debug("found our new first row of cache with timestamp: " + obs.getTimeTick());
            firstRow = obs.getTimeTick();
        }

        //check if lastRow has been set or the new timestamp is less than last row, if this is the case we have a new last row
        if(lastRow == -1 || lastRow < obs.getTimeTick()){
            logger.debug("found our new last row of cache with timestamp: " + obs.getTimeTick());
            lastRow = obs.getTimeTick();
        }

    }

    @Override
    public int size() {
        return cacheSize;
    }

    @Override
    public boolean isEmpty() {
        return cacheSize == 0;
    }

    @Override
    public Iterator<Observation<T>> iterator() {
        return getCache().iterator();
    }

    @Override
    public void setMaxCacheSize(int max_size){
        this.maxSize = max_size;
    }

    @Override
    public int getMaxCacheSize(){
        return maxSize;
    }

    /**
     * shrink the cache to max cache size
     */
    protected abstract void shrinkCache();
}
