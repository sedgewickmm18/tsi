/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.core_transforms.general.GeneralReducers;
import com.ibm.research.time_series.core.core_transforms.general.Stats;
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.SegmentTimestampRemappingFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.*;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.List;
import java.util.stream.Collectors;

/**
 * A special form of {@link TimeSeries} that consists of {@link Segment}s as its observation values
 *
 * <p>Created on 5/23/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class SegmentTimeSeries<T> extends UDerivedTimeSeries<Segment<T>> {

    /**
     * create a SegmentTimeSeries from an input unary segmentation transform
     * @param segmentUnaryTransform unary segmentation transform
     */
    public SegmentTimeSeries(UnaryTransform<?, Segment<T>> segmentUnaryTransform) {
        super(segmentUnaryTransform);
    }

    /**
     * Describe each {@link Segment} of the entire {@link TimeSeries} by giving back a {@link Stats} object
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return a {@link  Stats} object per {@link Segment} for this {@link TimeSeries}
     */
    public TimeSeries<Stats<T>> describeSegments() {
        return transform(GeneralReducers.describe());
    }

    /**
     * transform a given segment into another segment
     *
     * @param transform unary transform
     * @param <T2> new segment type
     * @return a new {@link SegmentTimeSeries}
     */
    public <T2> SegmentTimeSeries<T2> transformSegments(UnaryTransform<T,T2> transform) {
        UnaryTransform<Segment<T>,Segment<T2>> segmentMapper = MapTransformers.unaryMap(
                (segment) -> {
                    return Segment.fromSeries(TimeSeries.fromObservations(segment)
                            .transform(transform)
                            .collect());
                }
        );
        segmentMapper.setOperationOn(this);
        return new SegmentTimeSeries<>(segmentMapper);
    }

    @Override
    public SegmentTimeSeries<T> filter(FilterFunction<Segment<T>> filterFunction) {
        final UnaryTransform<Segment<T>, Segment<T>> filter = MapTransformers.filter(filterFunction);
        UnaryTransform<Segment<T>,Segment<T>> newTransform = null;
        try {
            newTransform = (UnaryTransform<Segment<T>, Segment<T>>)filter.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this);
        SegmentTimeSeries<T> result = new SegmentTimeSeries<>(newTransform);
        result.trs = trs;
        return result;
    }

    /**
     * map the values in a segment to a new segment
     *
     * @param f value map function
     * @param <T2> new segment type
     * @return a new {@link SegmentTimeSeries}
     */
    public <T2> SegmentTimeSeries<T2> mapSegments(UnaryMapFunction<T,T2> f) {
        return transformSegments(MapTransformers.unaryMap(f));
    }

    /**
     * reduce a segment using the segment values to a single value
     *
     * @param f iterable value map function
     * @param <T2> new Time Series type
     * @return a new {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> reduceSegments(UnaryMapFunction<Iterable<T>,T2> f) {
        UnaryTransform<Segment<T>,T2> transform = MapTransformers.unaryMap(segment -> {
            return f.evaluate(new ObservationValueIterable<>(segment.observations));
        });
        transform.setOperationOn(this);
        return new UDerivedTimeSeries<>(transform);
    }

    /**
     * transform this {@link SegmentTimeSeries} and remap timestamps
     *
     * @param reducer the {@link UnaryReducer} to perform against each {@link Segment}
     * @param timestampOp Operation to perform to re-map a timestamp
     * @param <T2> new Time Series type
     * @return a new {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> transform(UnaryReducer<T,T2> reducer, SegmentTimestampRemappingFunction timestampOp) {
        return mapObservation(o -> {
            long oTS = o.getTimeTick();
            long start = o.getValue().start;
            long end = o.getValue().end;
            long realStart = -1;
            long realEnd = -1;
            if (!o.getValue().isEmpty()) {
                realStart = o.getValue().first().getTimeTick();
                realEnd = o.getValue().last().getTimeTick();
            }
            return new Observation<>(
                    timestampOp.evaluate(oTS,start,end,realStart,realEnd),
                    reducer.reduceSegment(o.getValue())
            );
        });
    }

    /**
     * perform a binary reducer over two {@link SegmentTimeSeries}
     *
     * @param other other {@link SegmentTimeSeries}
     * @param reducer binary reducer
     * @param <T2> other time series observation type
     * @param <T3> output time series observation type
     * @return a new {@link TimeSeries}
     */
    public <T2,T3> TimeSeries<T3> transform(TimeSeries<Segment<T2>> other, BinaryReducer<T,T2,T3> reducer) {
        BinaryTransform<Segment<T>,Segment<T2>,T3> newTransform = null;
        try {
            newTransform = (BinaryTransform<Segment<T>,Segment<T2>,T3>)reducer.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this,other);
        return new BDerivedTimeSeries<>(newTransform);
    }

    /**
     * perform a n-ary reducer over a list of {@link SegmentTimeSeries}
     *
     * @param tsList list of {@link SegmentTimeSeries}
     * @param reducer n-ary reducer
     * @param <T2> new Time Series type
     * @return a new {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> transform(List<TimeSeries<Segment<T>>> tsList, NaryReducer<T,T2> reducer) {
        NaryTransform<Segment<T>,T2> newTransform = null;
        try {
            newTransform = (NaryTransform<Segment<T>,T2>)reducer.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this,tsList);
        return new NDerivedTimeSeries<>(newTransform);
    }

    /**
     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     *
     * @param keyOp operation where given a {@link Segment}, produce a key
     * @param inclusive inclusive flag
     * @param <K> segment key type
     * @return a new {@link MultiTimeSeries}
     */
    public <K> MultiTimeSeries<K,T> flatten(UnaryMapFunction<Segment<T>, K> keyOp, boolean inclusive) {
        return new MultiTimeSeries<>(
                this.collect(inclusive).stream().map(obs -> {
                    return new Pair<>(keyOp.evaluate(obs.getValue()), obs.getValue().toTimeSeriesStream(this.getTRS()));
                }).collect(Collectors.toMap(x -> x.left, x -> x.right))
        );
    }

    /**
     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     *
     * @param keyOp operation where given a {@link Segment}, produce a key
     * @param <K> segment key type
     * @return a new {@link MultiTimeSeries}
     */
    public <K> MultiTimeSeries<K,T> flatten(UnaryMapFunction<Segment<T>, K> keyOp) {
        return flatten(keyOp,false);
    }

    /**
     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @param inclusive inclusive flag
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Long,T> flatten(boolean inclusive) {
        return flatten(seg -> seg.start, inclusive);
    }

    /**
     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Long,T> flatten() {
        return flatten(false);
    }
}
