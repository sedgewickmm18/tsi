package com.ibm.research.time_series.core.utils;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;

public class PythonRecord implements Record, Serializable {

    private static final long serialVersionUID = -7993933222824262927L;
    private Map<String, Object> state;

    public PythonRecord(Map<String, Object> in) {
        this.state = in;
    }

    @Override
    public Object get(String key) {
        return state.get(key);
    }

    @Override
    public void set(String key, Object value) {
        state.put(key, value);
    }

    @Override
    public Iterator<String> keys() {
        return state.keySet().iterator();
    }

    @Override
    public boolean contains(String key) {
        return state.containsKey(key);
    }

    @Override
    public String toString() {
        return state.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof PythonRecord)) return false;

        PythonRecord other = (PythonRecord)o;

        return this.state.equals(other.state);
    }
}
