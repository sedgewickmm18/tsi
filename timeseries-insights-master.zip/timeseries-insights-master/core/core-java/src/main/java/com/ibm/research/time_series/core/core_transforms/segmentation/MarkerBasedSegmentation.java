package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

class MarkerBasedSegmentation<T> extends UnaryTransform<T, Segment<T>> {
    private static final long serialVersionUID = -6638044068159152529L;
    private FilterFunction<T> anchorF;

    private boolean prevInclusive;
    private boolean nextInclusive;

    MarkerBasedSegmentation(FilterFunction<T> anchorF, boolean prevInclusive, boolean nextInclusive) {
        this.anchorF = anchorF;
        this.prevInclusive = prevInclusive;
        this.nextInclusive = nextInclusive;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        TSBuilder<Segment<T>> resultBuilder = Observations.newBuilder();

        TSBuilder<T> currentBuilder = Observations.newBuilder();
        for(Observation<T> obs: timeSeries.getValues(t1,t2,inclusive)) {
            if (anchorF.evaluate(obs.getValue())) {
                if (prevInclusive) {
                    currentBuilder.add(obs);
                }
                ObservationCollection<T> currentResult = currentBuilder.result();

                if (!currentBuilder.isEmpty()) {
                    resultBuilder.add(new Observation<>(currentResult.first().getTimeTick(), Segment.fromSeries(currentResult)));
                    currentBuilder.clear();
                }

                if (nextInclusive) {
                    currentBuilder.add(obs);
                }
            } else {
                currentBuilder.add(obs);
            }
        }

        if (!currentBuilder.isEmpty()) {
            ObservationCollection<T> currentResult = currentBuilder.result();
            resultBuilder.add(new Observation<>(currentResult.first().getTimeTick(),Segment.fromSeries(currentResult)));
        }
        return resultBuilder.result();
    }

    @Override
    public Object clone() {
        return new MarkerBasedSegmentation<>(anchorF,prevInclusive,nextInclusive);
    }
}
