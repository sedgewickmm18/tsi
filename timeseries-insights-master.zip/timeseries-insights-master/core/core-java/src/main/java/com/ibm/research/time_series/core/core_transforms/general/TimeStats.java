package com.ibm.research.time_series.core.core_transforms.general;

import java.io.Serializable;

/**
 * Immutable Time Stats class container that contains:
 *
 * <p>min inter arrival time: minimum time between observations</p>
 * <p>max inter arrival time: maximum time between observations</p>
 * <p>mean inter arrival time: mean time between observations</p>
 */
public class TimeStats implements Serializable{
    private static final long serialVersionUID = -7210307043172306700L;
    /**
     * minimum time between observations
     */
    public final long minInterArrivalTime;

    /**
     * maximum time between observations
     */
    public final long maxInterArrivalTime;

    /**
     * mean time between observations
     */
    public final double meanInterArrivalTime;

    /**
     * Construct a new TimeStats object
     *
     * @param minInterArrivalTime minimum time between observations
     * @param maxInterArrivalTime maximum time between observations
     * @param meanInterArrivalTime mean time between observations
     */
    public TimeStats(long minInterArrivalTime,long maxInterArrivalTime,double meanInterArrivalTime) {
        this.minInterArrivalTime = minInterArrivalTime;
        this.maxInterArrivalTime = maxInterArrivalTime;
        this.meanInterArrivalTime = meanInterArrivalTime;
    }

    /**
     * @return mean time between observations
     */
    public double meanInterArrivalTime() {
        return meanInterArrivalTime;
    }

    /**
     * @return maximum time between observations
     */
    public long maxInterArrivalTime() {
        return maxInterArrivalTime;
    }

    /**
     * @return minimum time between observations
     */
    public long minInterArrivalTime() {
        return minInterArrivalTime;
    }

    /**
     * @return a human readable representation of this object
     */
    @Override
    public String toString() {
        return "min inter-arrival-time: " + minInterArrivalTime + "\n" +
                "max inter-arrival-time: " + maxInterArrivalTime + "\n" +
                "mean inter-arrival-time: " + meanInterArrivalTime;
    }
}
