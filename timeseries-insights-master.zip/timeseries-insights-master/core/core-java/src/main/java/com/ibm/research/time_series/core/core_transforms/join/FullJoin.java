/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * <p>Created on 7/19/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class FullJoin<LEFT,RIGHT,OUTPUT> extends BinaryTransform<LEFT,RIGHT,OUTPUT> {
    private BinaryTransform<LEFT,RIGHT,OUTPUT> transform;
    private Interpolator<LEFT> interpolatorLeft;
    private Interpolator<RIGHT> interpolatorRight;

    private static final long serialVersionUID = -6276759692062751233L;

    FullJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform){
        this.transform = transform;
        this.interpolatorLeft = GenericInterpolators.nullify();
        this.interpolatorRight = GenericInterpolators.nullify();
    }

    FullJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform, Interpolator<LEFT> interpolatorLeft, Interpolator<RIGHT> interpolatorRight) {
        this.transform = transform;
        this.interpolatorLeft = interpolatorLeft;
        this.interpolatorRight = interpolatorRight;
    }

    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2, boolean inclusive) {
        ObservationCollection<OUTPUT> result = Observations.empty();

        TSBuilder<LEFT> leftBuilder = Observations.newBuilder();
        TSBuilder<RIGHT> rightBuilder = Observations.newBuilder();


        ObservationCollection<LEFT> left = this.getTimeSeriesLeft().getValues(t1,t2,inclusive);
        ObservationCollection<RIGHT> right = this.getTimeSeriesRight().getValues(t1,t2,inclusive);

        if(left.isEmpty() || right.isEmpty()) return result;

        Iterator<Observation<LEFT>> leftIter = left.iterator();
        Iterator<Observation<RIGHT>> rightIter = right.iterator();

        Observation<LEFT> leftTSS = leftIter.next();
        Observation<RIGHT> rightTSS = rightIter.next();

        while(leftTSS != null || rightTSS != null){
            if(leftTSS == null || rightTSS == null){//if either is null, we must just add the rest interpolated
                if(leftTSS != null){
                    leftBuilder.add(new Observation<>(leftTSS.getTimeTick(),leftTSS.getValue()));
                    rightBuilder.add(new Observation<>(leftTSS.getTimeTick(),interpolatorRight.interpolate(JoinUtils.getHistory(interpolatorRight.getHistorySize(),leftTSS.getTimeTick(),right),JoinUtils.getFuture(interpolatorRight.getFutureSize(),leftTSS.getTimeTick(),right),leftTSS.getTimeTick())));
                    leftTSS = (leftIter.hasNext()) ? leftIter.next() : null;
                }else{
                    leftBuilder.add(new Observation<>(rightTSS.getTimeTick(),interpolatorLeft.interpolate(JoinUtils.getHistory(interpolatorLeft.getHistorySize(),rightTSS.getTimeTick(),left),JoinUtils.getFuture(interpolatorLeft.getFutureSize(),rightTSS.getTimeTick(),left),rightTSS.getTimeTick())));
                    rightBuilder.add(new Observation<>(rightTSS.getTimeTick(),rightTSS.getValue()));
                    rightTSS = (rightIter.hasNext()) ? rightIter.next() : null;
                }
            }else if(leftTSS.getTimeTick() == rightTSS.getTimeTick()){//if both are equal, just add both as is with no interpolation
                leftBuilder.add(new Observation<>(leftTSS.getTimeTick(),leftTSS.getValue()));
                rightBuilder.add(new Observation<>(rightTSS.getTimeTick(),rightTSS.getValue()));
                leftTSS = (leftIter.hasNext()) ? leftIter.next() : null;
                rightTSS = (rightIter.hasNext()) ? rightIter.next() : null;
            }else{//we must check which way we want to join
                if(leftTSS.getTimeTick() < rightTSS.getTimeTick()){
                    leftBuilder.add(new Observation<>(leftTSS.getTimeTick(),leftTSS.getValue()));
                    rightBuilder.add(new Observation<>(leftTSS.getTimeTick(),interpolatorRight.interpolate(JoinUtils.getHistory(interpolatorRight.getHistorySize(),leftTSS.getTimeTick(),right),JoinUtils.getFuture(interpolatorRight.getFutureSize(),leftTSS.getTimeTick(),right),leftTSS.getTimeTick())));
                    leftTSS = (leftIter.hasNext()) ? leftIter.next() : null;
                }else{
                    leftBuilder.add(new Observation<>(rightTSS.getTimeTick(),interpolatorLeft.interpolate(JoinUtils.getHistory(interpolatorLeft.getHistorySize(),rightTSS.getTimeTick(),left),JoinUtils.getFuture(interpolatorLeft.getFutureSize(),rightTSS.getTimeTick(),left),rightTSS.getTimeTick())));
                    rightBuilder.add(new Observation<>(rightTSS.getTimeTick(),rightTSS.getValue()));
                    rightTSS = (rightIter.hasNext()) ? rightIter.next() : null;
                }
            }
        }

        TimeSeries<LEFT> leftSI = TimeSeries.fromObservations(leftBuilder.result());
        TimeSeries<RIGHT> rightSI = TimeSeries.fromObservations(rightBuilder.result());
        return leftSI.transform(rightSI, transform)
                .getValues(t1,t2,inclusive);
    }

    @Override
    public Object clone(){
        return new FullJoin<>(transform,interpolatorLeft,interpolatorRight);
    }


}
