/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;

/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class FlatMapObservation<IN,OUT> extends FlatMapTransform<IN,OUT> {

    private static final long serialVersionUID = 817848606482673528L;
    private UnaryMapFunction<Observation<IN>,Iterable<Observation<OUT>>> flatMap;

    FlatMapObservation(UnaryMapFunction<Observation<IN>,Iterable<Observation<OUT>>> flatMap) {
        this.flatMap = flatMap;
    }

    @Override
    protected Iterable<Observation<OUT>> performFlatMap(Observation<IN> o) {
        return flatMap.evaluate(o);
    }

    @Override
    public Object clone() {
        return new FlatMapObservation<>(flatMap);
    }
}
