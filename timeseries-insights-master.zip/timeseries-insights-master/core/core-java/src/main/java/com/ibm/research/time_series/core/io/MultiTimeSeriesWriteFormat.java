package com.ibm.research.time_series.core.io;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.Map;

/**
 * Format which denotes how to write to a datasource
 *
 * @param <T> {@link com.ibm.research.time_series.core.observation.Observation} value type
 */
public interface MultiTimeSeriesWriteFormat<K,T> {
    /**
     * Given a collection of observations, a value encoder and options created from {@link TimeSeriesWriter},
     * write to an outside datasource
     *
     * @param observationsMap the in-memory map of observations
     * @param encodeKey a key encoder
     * @param encodeValue a value encoder
     * @param options options to use when writing
     */
    void write(
            Map<K,ObservationCollection<T>> observationsMap,
            UnaryMapFunction<K, String> encodeKey,
            UnaryMapFunction<T, String> encodeValue,
            Map<String, Object> options
    );
}
