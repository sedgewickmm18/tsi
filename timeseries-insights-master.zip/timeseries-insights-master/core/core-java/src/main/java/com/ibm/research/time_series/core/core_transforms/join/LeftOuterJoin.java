/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * <p>Created on 7/21/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class LeftOuterJoin<LEFT,RIGHT,OUTPUT> extends BinaryTransform<LEFT,RIGHT,OUTPUT> {
    private static final long serialVersionUID = -2707397358587976014L;

    private BinaryTransform<LEFT,RIGHT,OUTPUT> transform;
    private Interpolator<RIGHT> interpolator;

    LeftOuterJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform){
        this.transform = transform;
        this.interpolator = GenericInterpolators.nullify();
    }

    LeftOuterJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform,Interpolator<RIGHT> interpolator) {
        this.transform = transform;
        this.interpolator = interpolator;
    }

    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<LEFT> left = this.getTimeSeriesLeft().getValues(t1,t2,inclusive);
        ObservationCollection<RIGHT> right = this.getTimeSeriesRight().getValues(t1,t2,inclusive);

        TSBuilder<LEFT> leftBuilder = Observations.newBuilder();
        TSBuilder<RIGHT> rightBuilder = Observations.newBuilder();

        left.forEach(tss -> {
            if(!right.contains(tss.getTimeTick())) {
                leftBuilder.add(tss);
                rightBuilder.add(new Observation<>(
                        tss.getTimeTick(),
                        interpolator.interpolate(
                                JoinUtils.getHistory(interpolator.getHistorySize(),tss.getTimeTick(),right),
                                JoinUtils.getFuture(interpolator.getFutureSize(),tss.getTimeTick(),right),
                                tss.getTimeTick()
                        )
                ));
            }
        });

        ObservationCollection<LEFT> leftResult = leftBuilder.result();
        ObservationCollection<RIGHT> rightResult = rightBuilder.result();
        TimeSeries<LEFT> leftSI = TimeSeries.fromObservations(leftResult);
        TimeSeries<RIGHT> rightSI = TimeSeries.fromObservations(rightResult);
        return leftSI.transform(rightSI, transform)
                .getValues(leftResult.first().getTimeTick(),leftResult.last().getTimeTick(),inclusive);
    }

    @Override
    public Object clone(){
        return new LeftOuterJoin<>(transform,interpolator);
    }
}
