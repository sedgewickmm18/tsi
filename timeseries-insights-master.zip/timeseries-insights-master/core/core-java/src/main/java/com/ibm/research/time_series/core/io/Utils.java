package com.ibm.research.time_series.core.io;

import java.io.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipFile;

/**
 * IO utility used in various Time-Series data-sources
 */
public class Utils {
    /**
     * Logic courtesy of https://stackoverflow.com/questions/30507653/how-to-check-whether-file-is-gzip-or-not-in-java
     * but with using string as path
     * @param path string path to file
     * @return automatic input stream extraction of text file
     */
    public static InputStream inferInputStream(String path) {
        InputStream result = null;
        try {

            switch (getTextFileType(path)) {
                case 1:
                    result = new GZIPInputStream(new FileInputStream(path));
                    break;
                case 2:
                    ZipFile zf = new ZipFile(path);
                    result = zf.getInputStream(zf.entries().nextElement());
                    break;
                default:
                    result = new FileInputStream(path);
            }
        } catch (Throwable e) {
            e.printStackTrace(System.err);
        }
        return result;
    }

    /**
     * extract the text file type (regular, gzip, zip)
     * @param path input text file path
     * @return 0 for regular file, 1 for gzip, 2 for zip
     */
    public static int getTextFileType(String path) {
        try {
            //check for gzip
            RandomAccessFile raf = new RandomAccessFile(new File(path), "r");
            int magic = raf.read() & 0xff | ((raf.read() << 8) & 0xff00);
            raf.close();
            if (magic == GZIPInputStream.GZIP_MAGIC) return 1;
            //check for zip
            raf = new RandomAccessFile(new File(path), "r");
            int fileSignature = raf.readInt();
            if (fileSignature == 0x504B0304 || fileSignature == 0x504B0506 || fileSignature == 0x504B0708) {
                return 2;
            }
        } catch (Throwable e) {
            e.printStackTrace(System.err);
        }
        return 0;
    }


}
