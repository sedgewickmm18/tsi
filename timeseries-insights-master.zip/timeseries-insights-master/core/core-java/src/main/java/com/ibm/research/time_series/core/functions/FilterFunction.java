/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.functions;

import java.io.Serializable;

/**
 * An interface to handle filtering values from time seriess
 *
 * <p>Created on 12/2/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public interface FilterFunction<T> extends Serializable{
    /**
     * given a value, if true, keep the value, otherwise the value should be filtered out
     * @param value the value to check against
     * @return true if the value passes the filter, otherwise return false
     */
    boolean evaluate(T value);
}
