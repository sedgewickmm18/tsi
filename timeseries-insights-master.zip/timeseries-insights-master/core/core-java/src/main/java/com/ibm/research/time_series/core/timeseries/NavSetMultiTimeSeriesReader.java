/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * <p>Created on 8/2/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class NavSetMultiTimeSeriesReader<T> extends MultiTimeSeriesReader<Integer,T> {

    private List<ObservationCollection<T>> allSeries;

    NavSetMultiTimeSeriesReader(List<ObservationCollection<T>> allSeries){
        this.allSeries = allSeries;
    }

    @Override
    protected Map<Integer,TimeSeriesReader<T>> populateMap() {
        Map<Integer,TimeSeriesReader<T>> result = new HashMap<>();
        AtomicInteger i = new AtomicInteger(0);
        allSeries.forEach(x -> {
            TSBuilder<T> tsBuilder = Observations.newBuilder();
            x.forEach(tsBuilder::add);
            result.put(i.getAndAdd(1),new ObservationCollectionReader<>(tsBuilder.result()));
        });
        return result;
    }

    @Override
    public void close() {

    }
}
