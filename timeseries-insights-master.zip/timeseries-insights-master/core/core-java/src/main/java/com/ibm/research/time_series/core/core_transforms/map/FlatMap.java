/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class FlatMap<IN,OUT> extends FlatMapTransform<IN,OUT> {

    private static final long serialVersionUID = 3498319002092467595L;
    private UnaryMapFunction<IN,Iterable<OUT>> flatMap;

    FlatMap(UnaryMapFunction<IN,Iterable<OUT>> flatMap) {
        this.flatMap = flatMap;
    }

    @Override
    protected Iterable<Observation<OUT>> performFlatMap(Observation<IN> o) {
        TSBuilder<OUT> tsBuilder = Observations.newBuilder();
        Iterable<OUT> evaluated = flatMap.evaluate(o.getValue());
        evaluated.forEach(val -> tsBuilder.add(o.getTimeTick(),val));
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new FlatMap<>(flatMap);
    }
}
