package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

class SingleMarkerBasedSegmentation<T> extends UnaryTransform<T, Segment<T>> {

    private static final long serialVersionUID = -4434540979021171572L;
    private boolean startInclusive;
    private boolean endInclusive;
    private FilterFunction<T> markerOp;

    public SingleMarkerBasedSegmentation(FilterFunction<T> markerOp, boolean startInclusive, boolean endInclusive) {
        this.markerOp = markerOp;
        this.startInclusive = startInclusive;
        this.endInclusive = endInclusive;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();

        boolean foundStart = false;
        TSBuilder<T> currentBuilder = Observations.newBuilder();

        for (Observation<T> obs : timeSeries.getValues(t1,t2,inclusive)) {

            boolean isMarker = markerOp.evaluate(obs.getValue());

            if (foundStart) {
                if (isMarker) {
                    if (endInclusive) currentBuilder.add(obs);
                    Segment<T> segment = Segment.fromSeries(currentBuilder.result());
                    tsBuilder.add(new Observation<>(segment.start, segment));
                    currentBuilder.clear();

                    if (startInclusive) currentBuilder.add(obs);
                } else {
                    currentBuilder.add(obs);
                }
            } else {
                if (isMarker) {
                    if (startInclusive) currentBuilder.add(obs);
                    foundStart = true;
                }
            }


        }

        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new SingleMarkerBasedSegmentation<>(markerOp, startInclusive, endInclusive);
    }
}
