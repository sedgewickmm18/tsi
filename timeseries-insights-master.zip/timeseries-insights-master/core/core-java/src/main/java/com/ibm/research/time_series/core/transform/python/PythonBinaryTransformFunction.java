package com.ibm.research.time_series.core.transform.python;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

public interface PythonBinaryTransformFunction<T,T2,T3> {
    ObservationCollection<T3> call(TimeSeries<T> timeSeries1, TimeSeries<T2> timeSeries2, long start, long end, boolean inclusive);
}
