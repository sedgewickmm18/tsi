package com.ibm.research.time_series.core.io.partitioner;

import com.ibm.research.time_series.core.observation.Observation;

import java.util.OptionalLong;
import java.util.function.Function;

/**
 * Utility class used for partitioning a large Time-Series based on a {@link Histogram}
 */
public class HistogramTimeSeriesPartitioner extends AbstractTimeSeriesPartitioner {
    private Histogram histogram;

    /**
     * Create a Histogram Time-Series partitioner
     *
     * @param histogram the {@link Histogram}
     * @param parser function given a line, optionally extract a time-tick
     */
    public HistogramTimeSeriesPartitioner(Histogram histogram, Function<String, OptionalLong> parser) {
        super(histogram.getNumBins(), parser, histogram.getStartTs(), histogram.getEndTs());
        this.histogram = histogram;
    }

    @Override
    public int getBin(long ts) {
        final int histBin = histogram.getHistBin(ts);
        return histBin;
    }
}
