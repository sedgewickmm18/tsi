//package com.ibm.research.time_series.core.timeseries;
//
//import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
//import com.ibm.research.time_series.core.functions.FilterFunction;
//import com.ibm.research.time_series.core.functions.UnaryMapFunction;
//import com.ibm.research.time_series.core.transform.UnaryReducer;
//import com.ibm.research.time_series.core.transform.UnaryTransform;
//import com.ibm.research.time_series.core.utils.ImmutableObservationCollection;
//import com.ibm.research.time_series.core.utils.ObservationCollection;
//import com.ibm.research.time_series.core.utils.Pair;
//import com.ibm.research.time_series.core.utils.Segment;
//
//import java.io.Serializable;
//import java.util.AbstractMap;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//public class BoundSegmentTimeSeries<T> extends BoundTimeSeries<Segment<T>> {
//
//    public BoundSegmentTimeSeries(ObservationCollection<Segment<T>> observations) {
//        super(observations);
//    }
//
//    public BoundSegmentTimeSeries(TimeSeries<Segment<T>> timeSeries, long lowerBound, long upperBound, Map<String, Serializable> annotationMap) {
//        super(timeSeries, lowerBound, upperBound, annotationMap);
//    }
//
//    public BoundSegmentTimeSeries(ObservationCollection<Segment<T>> observations, long lowerBound, long upperBound) {
//        super(observations, lowerBound, upperBound);
//    }
//
//    public BoundSegmentTimeSeries(ObservationCollection<Segment<T>> observations, long lowerBound, long upperBound, Map<String, Serializable> annotationMap) {
//        super(observations, lowerBound, upperBound, annotationMap);
//    }
//
//    public <T2 extends Serializable> BoundSegmentTimeSeries<T> addSegmentAnnotations(Map<String,UnaryReducer<T,T2>> annotationReducerMap) {
//        BoundTimeSeries<Segment<T>> bts = this.map(segment -> {
//            Map<String,Serializable> computedAnnotations = new HashMap<>();
//            if (segment.annotationsExist()) {
//                for (String annotationKey : segment.getAnnotationKeys()) {
//                    computedAnnotations.put(annotationKey, segment.getAnnotation(annotationKey));
//                }
//            }
//            for (Map.Entry<String, UnaryReducer<T, T2>> e : annotationReducerMap.entrySet()) {
//                computedAnnotations.put(e.getKey(),e.getValue().reduceSegment(segment));
//            }
//            // todo maybe should make something better than this, toTimeSeriesStream collect just makes a copy
//            return new Segment<>(segment.getLowerBound(),segment.getUpperBound(), segment.map(x -> x),computedAnnotations);
//        });
//        return new BoundSegmentTimeSeries<>(bts,getLowerBound(),getUpperBound(),getAnnotations());
//    }
//
//    public <T2 extends Serializable> BoundSegmentTimeSeries<T> addSegmentAnnotation(String key, UnaryReducer<T, T2> annotationReducer) {
//        Map<String,UnaryReducer<T,T2>> annotationReducerMap = new HashMap<>(1);
//        annotationReducerMap.put(key,annotationReducer);
//        return addSegmentAnnotations(annotationReducerMap);
//    }
//
//    public <T2 extends Serializable> BoundSegmentTimeSeries<T> addSegmentAnnotation(String key, UnaryMapFunction<Segment<T>,T2> annotationReducer) {
//        final UnaryReducer<T, T2> unaryReducer = new UnaryReducer<T, T2>() {
//            @Override
//            public T2 reduceSegment(Segment<T> segment) {
//                return annotationReducer.evaluate(segment);
//            }
//        };
//        return addSegmentAnnotation(key,unaryReducer);
//    }
//
//
//        /**
//         * transform a given segment into another segment
//         *
//         * @param unaryTransform unary transform
//         * @param <T2> new segment type
//         * @return a new {@link SegmentTimeSeries}
//         */
//    public <T2> BoundSegmentTimeSeries<T2> transformSegments(UnaryTransform<T,T2> unaryTransform) {
//        BoundTimeSeries<Segment<T2>> bts = this.map(segment -> Segment.fromSeries(segment.transform(unaryTransform),segment.getAnnotations()));
//        return new BoundSegmentTimeSeries<>(bts, getLowerBound(), getUpperBound(), getAnnotations());
//    }
//
//    public <T2> BoundSegmentTimeSeries<T2> transformSegments(UnaryTransform<T,T2> unaryTransform,Map<String, String> annotationMapper) {
//        BoundTimeSeries<Segment<T2>> bts = this.map(segment -> {
//            Map<String, Serializable> annotations = annotationMapper.entrySet().stream().map(e -> {
//                return new AbstractMap.SimpleEntry<>(e.getValue(), segment.getAnnotation(e.getKey()));
//            }).collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
//            UnaryTransform<T,T2> uTransformCloned = null;
//            try {
//                uTransformCloned = (UnaryTransform<T, T2>) unaryTransform.clone();
//            } catch (CloneNotSupportedException e) {
//                e.printStackTrace();
//            }
//            uTransformCloned.setOperationOn(segment.toTimeSeriesStream());
//            uTransformCloned.setAnnotations(annotations);
//            return Segment.fromSeries(uTransformCloned.evaluate(getLowerBound(),getUpperBound(),false),segment.getAnnotations());
//        });
//        return new BoundSegmentTimeSeries<T2>(bts,this.getLowerBound(),this.getUpperBound(),this.getAnnotations());
//    }
//
//    public BoundSegmentTimeSeries<T> filter(FilterFunction<Segment<T>> filterFunction) {
//        return new BoundSegmentTimeSeries<>(this.filter(filterFunction),this.getLowerBound(),this.getUpperBound(),this.getAnnotations());
//    }
//
//    public <T2> BoundSegmentTimeSeries<T2> mapSegments(UnaryMapFunction<T,T2> f) {
//        return transformSegments(MapTransformers.unaryMap(f));
//    }
//
//    /**
//     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
//     * will be the result of a single {@link Segment}.
//     *
//     * <p>Note: this method will bring all observations into memory</p>
//     *
//     * @param keyOp operation where given a {@link Segment}, produce a key
//     * @param <K> segment key type
//     * @return a new {@link MultiTimeSeries}
//     */
//    public <K> MultiTimeSeries<K,T> flatten(UnaryMapFunction<Segment<T>,K> keyOp) {
//        return new MultiTimeSeries<>(
//                this.stream().map(obs -> {
//                    return new Pair<>(keyOp.evaluate(obs.getValue()), obs.getValue().toTimeSeriesStream(getTRS()));
//                }).collect(Collectors.toMap(x -> x.left, x -> x.right))
//        );
//    }
//
//    /**
//     * Converts this {@link SegmentTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
//     * will be the result of a single {@link Segment}.
//     *
//     * <p>Note: this method will bring all observations into memory</p>
//     * <p>Note: the Segment key will be created based on the start of the segment</p>
//     *
//     * @return a new {@link MultiTimeSeries}
//     */
//    public MultiTimeSeries<Long,T> flatten() {
//        return flatten(BoundTimeSeries::getLowerBound);
//    }
//}
