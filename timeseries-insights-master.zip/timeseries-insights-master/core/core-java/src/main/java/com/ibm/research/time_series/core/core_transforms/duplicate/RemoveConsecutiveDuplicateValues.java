/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.duplicate;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * This is a duplicate removal transform. It can be applied on a timeseries, which will remove consecutive duplicates.
 * The oldest timestamp is preserved and the newer ones are dropped.
 *
 * For example, a timeseries {(a,t0),(a,t1),(b,t2),(c,t3),(a,t4),(d,t5)}
 *             will be converted to {(a,t0),(b,t2),(c,t3),(a,t4),(d,t5)}.
 *
 * @param <T> Value type
 */
class RemoveConsecutiveDuplicateValues<T> extends UnaryTransform<T, T> {
    private static final long serialVersionUID = -2200202719315176039L;

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<T> observations = this.getTimeSeries().getValues(t1, t2, inclusive);

        //return value
        TSBuilder<T> tsBuilder = Observations.newBuilder();

        //remove duplicates that are consecutive
        T prevValue = null;
        for (Observation<T> observation : observations) {
            T currObservationValue = observation.getValue();
            if (!currObservationValue.equals(prevValue)) {
                //not equal, hence add it to the return value and update the previous value
                tsBuilder.add(observation);
                prevValue = currObservationValue;
            }
        }

        return tsBuilder.result();
    }
}
