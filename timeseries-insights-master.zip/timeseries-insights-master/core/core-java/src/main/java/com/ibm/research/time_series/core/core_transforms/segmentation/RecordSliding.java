/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * <p>Created on 5/23/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class RecordSliding<T> extends UnaryTransform<T,Segment<T>> {

    private static final long serialVersionUID = 1899506409252951799L;
    private long window;//window size
    private long step;//step size
    private boolean enforceSize;

    RecordSliding(long window,long step, boolean enforceSize) {
        this.window = window;
        this.step = step;
        this.enforceSize = enforceSize;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<T> input = this.getTimeSeries().getValues(t1,t2,inclusive);

        if (input.isEmpty())
            return Observations.empty();

        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();

        Iterator<Observation<T>> inputIter = input.iterator();
        Observation<T> firstInWindow = inputIter.next();

        while(firstInWindow != null){
            ObservationCollection<T> recordWindow = produceWindow(input,firstInWindow.getTimeTick());
            //only get this window back if we have all values needed
            if (!enforceSize || recordWindow.size() == window)
                tsBuilder.add(new Observation<>(
                        recordWindow.first().getTimeTick(),
                        Segment.fromSeries(recordWindow)
                ));

            for(int i = 0;i < step;i++){
                if (inputIter.hasNext())
                    firstInWindow = inputIter.next();
                else {
                    firstInWindow = null;
                }
            }
        }

        return tsBuilder.result();
    }

    /**
     * gets the window size
     * @return the window size
     */
    @Override
    public long getWindow() {
        return window;
    }

    /**
     * get sht step size
     * @return the step size
     */
    @Override
    public long getStep() {
        return step;
    }

    @Override
    public Object clone() {
        return new RecordSliding<T>(window,step,enforceSize);
    }

    private ObservationCollection<T> produceWindow(
            ObservationCollection<T> navigableCollection,
            long timestamp){
        TSBuilder<T> tsBuilder = Observations.newBuilder();

        ObservationCollection<T> collectedWindow = navigableCollection
                .tailSet(timestamp,true);

        for (Observation<T> obs : collectedWindow) {
            if (tsBuilder.size() >= window) break;
            tsBuilder.add(obs);
        }

        return tsBuilder.result();
    }
}
