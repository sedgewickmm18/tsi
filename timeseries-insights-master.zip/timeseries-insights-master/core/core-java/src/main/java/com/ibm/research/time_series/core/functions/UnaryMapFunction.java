/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.functions;


import java.io.IOException;
import java.io.Serializable;

/**
 * An interface to handle an unary mapping functions where a single input maps to one output.
 *
 * <p>Created on 4/12/16.</p>
 *
 * @param <INPUT> initial TimeSeries Observation value type
 * @param <OUTPUT> resulting Observation value type
 *
 * @author Joshua Rosenkranz
 */
public interface UnaryMapFunction<INPUT,OUTPUT> extends Serializable{
    /**
     * evaluate an expression that takes one input and returns a single output
     * @param x - the input
     * @return a single output represented from the result of the mapping logic on the input
     */
    OUTPUT evaluate(INPUT x);
}
