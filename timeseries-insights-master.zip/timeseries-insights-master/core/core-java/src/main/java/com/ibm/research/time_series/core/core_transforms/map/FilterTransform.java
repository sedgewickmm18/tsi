/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.io.Serializable;

/**
 * <p>Created on 7/21/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class FilterTransform<T> extends UnaryTransform<T,T> implements Serializable{
    private static final long serialVersionUID = 1115852798857272396L;
    private FilterFunction<T> filterFunction;

    FilterTransform(FilterFunction<T> filterFunction){
        this.filterFunction = filterFunction;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<T> tsBuilder = Observations.newBuilder();

        this.getTimeSeries().getValues(t1,t2,inclusive).forEach(tss -> {
            if(filterFunction.evaluate(tss.getValue())) tsBuilder.add(tss);
        });

        return tsBuilder.result();
    }

    @Override
    public Object clone(){
        return new FilterTransform<>(filterFunction);
    }
}
