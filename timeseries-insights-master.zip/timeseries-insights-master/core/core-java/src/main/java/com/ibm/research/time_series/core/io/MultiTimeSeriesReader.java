/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.io;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * This is the abstract class to handle generation of multiple {@link TimeSeriesReader}s from a single source
 * <p>Created on 5/5/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class MultiTimeSeriesReader<PRIMARY_TYPE, T> implements Serializable {

    /**
     * a HashMap to hold all of our readers that we have generated from populateMap. Each key gives you access to a new reader
     */
    private Map<PRIMARY_TYPE,TimeSeriesReader<T>> readerMap = null;

    /**
     * @return a map of keys to source {@link TimeSeriesReader}
     */
    protected abstract Map<PRIMARY_TYPE, TimeSeriesReader<T>> populateMap();

    /**
     * close the {@link TimeSeriesReader}s
     */
    public abstract void close();

    /**
     * @return the generated map of {@link TimeSeriesReader}
     */
    public Map<PRIMARY_TYPE, TimeSeriesReader<T>> getReaderMap(){
        if (readerMap == null) {
            readerMap = populateMap();
        }
        return readerMap;
    }

    /**
     * get a specific reader given a key
     * @param key key to reader from HashMap
     * @return a {@link TimeSeriesReader} given a key
     */
    public TimeSeriesReader<T> getReader(PRIMARY_TYPE key){
        if (readerMap == null) {
            readerMap = populateMap();
        }
        return readerMap.get(key);
    }
}
