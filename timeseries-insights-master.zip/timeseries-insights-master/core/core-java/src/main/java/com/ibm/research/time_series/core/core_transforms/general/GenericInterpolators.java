/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * This is the entry point for all built-in generic type {@link Interpolator}
 *
 * <p>Created on 7/27/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class GenericInterpolators {

    /**
     * This is the prev observation interpolator which applied during interpolation finds the previous observation to the
     * timestamp within the interpolation function
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.prev(-1))}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,0),Observation(6:00,5)]</p>
     *
     * @param fillValue default fill value if history size not met
     * @param <T> observation value type
     * @return a single instance of the prev observation interpolation function
     */
    public static <T> Interpolator<T> prev(T fillValue) {
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                if (history.size() != getHistorySize() || future.size() != getFutureSize()) return fillValue;
                return history.last().getValue();
            }

            @Override
            public int getHistorySize() {
                return 1;
            }

            @Override
            public int getFutureSize() {
                return 0;
            }
        };
    }

    /**
     * This is the prev observation interpolator which applied during interpolation finds the previous observation to the
     * timestamp within the interpolation function. By default, the fill value is null if history size is not met.
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.prev(-1))}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,0),Observation(6:00,5)]</p>
     *
     * @param <T> observation value type
     * @return a single instance of the prev observation interpolation function
     */
    public static <T> Interpolator<T> prev() {
        return prev(null);
    }

    /**
     * This is the next observation interpolator which applied during interpolation finds the next observation to the
     * timestamp within the interpolation function
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.next(-1))}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,4),Observation(6:00,-1)]</p>
     *
     * @param fillValue default fill value if future size not met
     * @param <T> observation value type
     * @return a single instance of the next observation interpolation function
     */
    public static <T> Interpolator<T> next(T fillValue) {
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                if (history.size() != getHistorySize() || future.size() != getFutureSize()) return fillValue;
                return future.first().getValue();
            }

            @Override
            public int getHistorySize() {
                return 0;
            }

            @Override
            public int getFutureSize() {
                return 1;
            }
        };
    }

    /**
     * This is the next observation interpolator which applied during interpolation finds the next observation to the
     * timestamp within the interpolation function. By default, the fill value is null if future size is not met.
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.next(-1))}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,4),Observation(6:00,-1)]</p>
     *
     * @param <T> observation value type
     * @return a single instance of the next observation interpolation function
     */
    public static <T> Interpolator<T> next() {
        return next(null);
    }

    /**
     * This is the nearest observation interpolator which applied during interpolation finds the nearest observation
     * to the timestamp within the resample function
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.nearest())}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,4),Observation(6:00,5)]</p>
     *
     * @param fillValue default fill value if history and future size not met
     * @param <T> observation value type
     * @return a single instance of the nearest observation interpolation function
     */
    public static <T> Interpolator<T> nearest(T fillValue) {
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                if (history.size() != getHistorySize() || future.size() != getFutureSize()) return fillValue;
                Observation<T> leftOfTimestamp = history.last();
                Observation<T> rightOfTimestamp = future.first();
                return (timestamp - leftOfTimestamp.getTimeTick() > rightOfTimestamp.getTimeTick() - timestamp)
                        ? rightOfTimestamp.getValue()
                        : leftOfTimestamp.getValue();
            }

            @Override
            public int getHistorySize() {
                return 1;
            }

            @Override
            public int getFutureSize() {
                return 1;
            }

            @Override
            public T getFillValue() {
                return fillValue;
            }
        };
    }

    /**
     * This is the nearest observation interpolator which applied during interpolation finds the nearest observation
     * to the timestamp within the resample function. By default, the fill value is null if history and future size is
     * not met.
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.nearest())}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,4),Observation(6:00,5)]</p>
     *
     * @param <T> observation value type
     * @return a single instance of the nearest observation interpolation function
     */
    public static <T> Interpolator<T> nearest() {
        return nearest(null);
    }

    /**
     * This is the nullify observation interpolator which applied during interpolation sets the observation to resample
     * to null
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.nullify())}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,null),Observation(6:00,null)]</p>
     *
     * @param <T> observation value type
     * @return a single instance of the null observation interpolation function
     */
    public static <T> Interpolator<T> nullify(){
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                return null;
            }

            @Override
            public int getHistorySize() {
                return 0;
            }

            @Override
            public int getFutureSize() {
                return 0;
            }

            @Override
            public T getFillValue() {
                return null;
            }
        };
    }

    /**
     * This is the fill observation interpolator which applied during interpolation which sets the value of the observation
     * to resample to the given fillValue
     *
     * <p>Example:</p>
     * <p>input: [Observation(12:00,0),Observation(4:00,4),Observation(5:00,5)]</p>
     * <pre>{@code resample(3 hours,1,1,GenericInterpolators.fill(100))}</pre>
     * <p>result: [Observation(12:00,0),Observation(3:00,100),Observation(6:00,100)]</p>
     *
     * @param fillValue fill value
     * @param <T> observation value type
     * @return a single instance of the fill observation interpolation function
     */
    public static <T> Interpolator<T> fill(T fillValue) {
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                return fillValue;
            }

            @Override
            public int getHistorySize() {
                return 0;
            }

            @Override
            public int getFutureSize() {
                return 0;
            }

            @Override
            public T getFillValue() {
                return fillValue;
            }
        };
    }

    /**
     * Creates an {@link Interpolator} with a given history size and future size
     *
     * @param interpolator the interpolator function
     * @param fillValue default fill value if history and future size not met
     * @param historySize number of history observations to get prior to missing value
     * @param futureSize number of future observations to get prior to missing value
     * @param <T> observation value type
     * @return a single instance of an interpolation function
     */
    public static <T> Interpolator<T> create(Interpolator<T> interpolator, T fillValue, int historySize, int futureSize) {
        return new Interpolator<T>() {
            @Override
            public T interpolate(ObservationCollection<T> history, ObservationCollection<T> future, long timestamp) {
                if (history.size() != getHistorySize() || future.size() != getFutureSize()) return fillValue;
                return interpolator.interpolate(history,future,timestamp);
            }

            @Override
            public int getHistorySize() {
                return historySize;
            }

            @Override
            public int getFutureSize() {
                return futureSize;
            }

            @Override
            public T getFillValue() {
                return fillValue;
            }
        };
    }
}
