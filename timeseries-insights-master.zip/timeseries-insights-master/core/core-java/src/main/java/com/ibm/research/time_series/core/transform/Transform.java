/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;

import java.io.Serializable;
import java.util.*;

import com.ibm.research.time_series.core.observation.Observation;

/**
 * Abstract class Transform which Unary, Binary and NaryTransform Extend.
 *
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 */
abstract class Transform implements Serializable{

    /**
     * get window size
     * @return the window size
     */
    public long getWindow() {
        return 0;
    }

    /**
     * get step size
     * @return the step size
     */
    public long getStep() {
        return 0;
    }
}
