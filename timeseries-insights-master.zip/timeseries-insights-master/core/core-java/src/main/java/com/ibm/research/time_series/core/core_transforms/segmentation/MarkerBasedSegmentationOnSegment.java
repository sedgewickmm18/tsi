package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.*;

class MarkerBasedSegmentationOnSegment<T> extends UnaryTransform<T, Segment<T>> {

    private UnaryTransform<T,Segment<T>> initialSegmentTransform;
    private boolean prevInclusive;
    private boolean nextInclusive;
    private FilterFunction<Segment<T>> isMarker;

    public MarkerBasedSegmentationOnSegment(UnaryTransform<T,Segment<T>> initialSegmentTransform, FilterFunction<Segment<T>> isMarker, boolean prevInclusive, boolean nextInclusive) {
        this.initialSegmentTransform = initialSegmentTransform;
        this.isMarker = isMarker;
        this.prevInclusive = prevInclusive;
        this.nextInclusive = nextInclusive;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        final ObservationCollection<Segment<T>> values = timeSeries.toSegments(initialSegmentTransform)
                .getValues(t1, t2, inclusive);

        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();
        Segment<T> prev = null;
        for (Observation<Segment<T>> oSegment : values) {
            if (isMarker.evaluate(oSegment.getValue())) {
                if (prev == null) {
                    prev = oSegment.getValue();
                } else {
                    Segment<T> current = oSegment.getValue();
                    if (prev.end < current.start) {
                        long start = (prevInclusive) ? prev.start : prev.end + 1;
                        long end = (nextInclusive) ? current.end : current.start - 1;
                        tsBuilder.add(start, Segment.fromSeries(start,end,timeSeries.getValues(start,end))); //no inclusive as its covered by the above
                    }
                    prev = current;
                }
            }
        }
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new MarkerBasedSegmentationOnSegment<>(initialSegmentTransform,isMarker,prevInclusive,nextInclusive);
    }
}
