package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;

import java.util.Optional;

class TextFileSequentialTimeSeriesReader<T> extends SequentialFileTimeSeriesReader<T> {
    private UnaryMapFunction<String, Optional<Observation<T>>> observationOp;

    public TextFileSequentialTimeSeriesReader(String path, UnaryMapFunction<String, Optional<Observation<T>>> observationOp, int skipNumLines) {
        super(path, Integer.MAX_VALUE, true, skipNumLines);
        this.observationOp = observationOp;
    }

    @Override
    protected Optional<Observation<T>> parseLine(String line) {
        return observationOp.evaluate(line);
    }
}
