package com.ibm.research.time_series.core.utils;

import java.io.Serializable;

public class Prediction<T> implements Serializable {

    private static final long serialVersionUID = 7851106570893831986L;
    private T value;
    private T lowerBound;
    private T upperBound;
    private double error;

    public Prediction(T value, T lowerBound, T upperBound, double error) {
        this.value = value;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.error = error;
    }

    public T getValue() {
        return value;
    }

    public T getLowerBound() {
        return lowerBound;
    }

    public T getUpperBound() {
        return upperBound;
    }

    public double getError() {
        return error;
    }

    @Override
    public String toString() {
        return "Prediction(value=" + value + ", lower_bound=" + lowerBound + ", upper_bound=" + upperBound + ", error=" + error + ")";
    }
}
