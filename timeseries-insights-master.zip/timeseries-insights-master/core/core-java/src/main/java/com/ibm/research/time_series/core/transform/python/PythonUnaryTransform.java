package com.ibm.research.time_series.core.transform.python;

import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;

public class PythonUnaryTransform<T,T2> extends UnaryTransform<T,T2> {

    private PythonUnaryTransformFunction<T,T2> func;

    public PythonUnaryTransform(PythonUnaryTransformFunction<T,T2> func) {
        this.func = func;
    }

    @Override
    public ObservationCollection<T2> evaluate(long t1, long t2, boolean inclusive) {
        return this.func.call(this.timeSeries, t1, t2, inclusive);
    }

    @Override
    public Object clone() {
        return new PythonUnaryTransform<>(func);
    }
}
