package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import org.apache.log4j.Logger;

class Concat<T> extends BinaryTransform<T,T,T> {
    private static final Logger logger = Logger.getLogger(Concat.class);


    @Override
    public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {
        if (timeSeriesLeft.getTRS() != null && timeSeriesRight.getTRS() != null && !timeSeriesLeft.getTRS().equals(timeSeriesRight.getTRS())) {
            logger.info("concatenating 2 time series that have different time-reference-systems");
        } else if (timeSeriesLeft.getTRS() != null && timeSeriesRight.getTRS() == null) {
            logger.info("concatenating 2 time series that have different time-reference-systems");
        } else if (timeSeriesLeft.getTRS() == null && timeSeriesRight.getTRS() != null) {
            logger.warn("concatenating 2 time series that have different time-reference-systems");
        }

        TSBuilder<T> tsBuilder = Observations.newBuilder();

        ObservationCollection<T> firstSeries = this.timeSeriesLeft.getValues(t1,t2,inclusive);
        tsBuilder.addAll(firstSeries);

        long firstTimestampSecondSeries = (firstSeries.isEmpty()) ? t1 : firstSeries.last().getTimeTick();

        if (firstTimestampSecondSeries <= t2) {
            ObservationCollection<T> secondSeries = timeSeriesRight.getValues(firstTimestampSecondSeries, t2, inclusive);
            tsBuilder.addAll(secondSeries);
        }
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new Concat<>();
    }

}
