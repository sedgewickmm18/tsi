/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Serializable;
import java.util.Iterator;

/**
 * ~~~~~~DEVELOPER API~~~~~~
 * An Abstraction for an iterable of Observation values
 * <p>Created on 3/27/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class ObservationValueIterable<T> implements Iterable<T>, Serializable {

    private static final long serialVersionUID = 3682675196041448615L;
    /**
     * this classes data is backed by an ObservationCollection
     */
    private ObservationCollection<T> series;

    /**
     * Constructs an ObservationValueIterable from and ObservationCollection
     * @param series the series of observations
     */
    public ObservationValueIterable(ObservationCollection<T> series) {
        this.series = series;
    }

    /**
     * @return an iterator of observation values
     */
    @Override
    public Iterator<T> iterator() {
        return new ObservationValueIterator<>(series.iterator());
    }
}
