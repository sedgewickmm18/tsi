/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
abstract class FlatMapTransform<IN,OUT> extends UnaryTransform<IN,OUT>{

    @Override
    public ObservationCollection<OUT> evaluate(long t1, long t2,boolean inclusive) {

        ObservationCollection<IN> input = this.getTimeSeries().getValues(t1,t2,inclusive);

        TSBuilder<OUT> tsBuilder = Observations.newBuilder();
        input.forEach(obs -> {
            Iterable<Observation<OUT>> flattened = performFlatMap(obs);
            tsBuilder.addAll(flattened);
        });

        return tsBuilder.result();
    }

    protected abstract Iterable<Observation<OUT>> performFlatMap(Observation<IN> o);
}
