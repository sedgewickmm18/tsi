/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.observation;

import com.ibm.research.time_series.core.utils.TRS;

import java.io.Serializable;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * Basic storage unit for a single Time series observation
 *
 * <p>
 *     Each Observation consists of a timestamp(long), value(templated type), and annotations(Map)
 * </p>
 * @param <T> type for the value
 *
 * @author Joshua Rosenkranz
 * @author Ramya Raghavendra
 * @author Mudhakar Srivatsa
 */
public class Observation<T> implements Comparable<Observation<T>>,Serializable{

    /**
     * an observation's timestamp, when the observation occurred in time
     */
	final private long timestamp;

    /**
     * an observation's annotations
     */
	private Map<String,Object> annotationMap;
    /**
     * an observation's value, the value associated with this observation
     */
	final private T value;

    /**
     * Default constructor for Observation. Constructs an empty Observation.
     *
     * Note: the timestamp defaults to -1 and the value defaults to null
     */
    public Observation(){
        timestamp = -1;
        annotationMap = null;
//        metadata = new Properties();
        value = null;
    }

	/**
	 * Constructs an Observation with a given timestamp, value and metadata
     * @param timestamp the observation's timestamp
     * @param value the observation's value
     * @param annotationMap the observation's annotations
     */
	public Observation(long timestamp, T value, Map<String,Object> annotationMap){
		this.annotationMap = (annotationMap == null) ? null : new HashMap<>(annotationMap);//make a copy
		this.timestamp = timestamp;
		this.value = value;
	}

    /**
     * Constructs an Observation with a given timestamp and value
     * @param timestamp the observation's timestamp
     * @param value the observation's value
     */
    public Observation(long timestamp, T value){
        this.annotationMap = null;
        this.timestamp = timestamp;
        this.value = value;
    }

	/**
	 * Constructs an Observation, given another observation (Copy Constructor)
	 * simply copies a Observation given an Observation object
	 * @param observation the Observation to copy
	 */
	public Observation(Observation<T> observation){
	    this.annotationMap = (observation.annotationMap == null) ? null : new HashMap<>(observation.annotationMap);
		this.timestamp = observation.timestamp;
		this.value = observation.value;
	}

    /**
     * Constructs an Observation from a ZonedDateTime (observation occurrence time) and
     * value
     *
     * @param zonedDateTime the occurrence of this observation
     * @param value the observation's value
     */
    public Observation(ZonedDateTime zonedDateTime,T value) {
        this.annotationMap = null;
        this.timestamp = zonedDateTime.toInstant().toEpochMilli();
        this.value = value;
    }

	public Set<String> getAnnotationKeys() {
        return (annotationMap == null) ? new HashSet<>() : annotationMap.keySet();
    }

    public <OUT> OUT getAnnotation(String key) {
        return (OUT) annotationMap.get(key);
    }

    public void addAnnotation(String key, Object annotation) {
        if (annotationMap == null) annotationMap = new HashMap<>();
        annotationMap.putIfAbsent(key,annotation);
    }

	/**
	 * @return the value associated with this observation
	 */
	public T getValue(){
		return value;
	}

	/**
	 * @return the timestamp associated with this observation
	 */
	public long getTimeTick(){
		return timestamp;
	}

	public ZonedDateTime getTimestamp(TRS trs) {
        long offset = trs.getStartTime().toInstant().toEpochMilli();
        long tt = trs.getGranularity().toMillis();
        long newTS = (tt * timestamp) + offset;
        return ZonedDateTime.ofInstant(Instant.ofEpochMilli(newTS), trs.getStartTime().getZone());
    }

	/**
	 * @return a human readable representation of this observation
	 */
	@Override
	public String toString() {
	    String friendlyTs = String.valueOf(timestamp);
	    String metadata = (this.annotationMap == null || this.annotationMap.isEmpty()) ? "" : "     Annotation: " + this.annotationMap.toString();
        return "TimeStamp: " + friendlyTs + "     Value: " + this.getValue() + metadata;
    }

    /**
     * @param trs {@link TRS} used in aiding in human readability of string
     * @return a human readable representation of this observation. If trs is null, will default to default toString
     * method
     */
    public String toString(TRS trs) {
	    if (trs != null) {
            long offset = trs.getStartTime().toInstant().toEpochMilli();
            long tt = trs.getGranularity().toMillis();
            long newTS = (tt * timestamp) + offset;
	        String friendlyTs = ZonedDateTime.ofInstant(Instant.ofEpochMilli(newTS), trs.getStartTime().getZone()).toString();
            String metadata = (this.annotationMap == null || this.annotationMap.isEmpty()) ? "" : "     Metadata: " + this.annotationMap.toString();
            return "TimeStamp: " + friendlyTs + "     Value: " + this.getValue() + metadata;
        } else {
	        return toString();
        }
    }

    /**
     * overriding hashcode for Observation
     * @return the integer hashcode for this observation
     */
    @Override
    public int hashCode(){
        int result;

        int long_ts_hashcode = (int) (timestamp ^ (timestamp >>> 32));
        int value_ts_hashcode = (value != null) ? value.hashCode() : 0;

        int metadata_hashcode = 0;
        if (annotationMap != null) {
            for (Map.Entry<String, Object> entry : annotationMap.entrySet()) {
                metadata_hashcode += entry.getKey().hashCode() + entry.getValue().hashCode();
            }
        }

        result = long_ts_hashcode + value_ts_hashcode + metadata_hashcode;
        return result;
    }

    /**
     * overriding the equals method for Observation
     *
     * Observation equality is based on 3 factors, an observation's timestamp, an observation's
     * value, and an observation's metadata. If these 3 factors are equivalent between 2 observation's
     * the observation's are deemed equivalent.
     *
     * @param other the other Observation to compare this too
     * @return true if other has equivalent timestamp, value, and metadata
     */
    @Override
    public boolean equals(Object other){
        //make sure other isn't null
        if(other ==  null){
            return false;
        }

        //if other's reference is this, they are definitely equal
        if(other == this){
            return true;
        }

        //make sure that others type is of this class
        if(!(other instanceof Observation)){
            return false;
        }

        //we are checking correctness above with instanceof
        Observation<T> other_tss = (Observation<T>)other;

        //check if timestamps are equal
        if(this.getTimeTick() != other_tss.getTimeTick()){
            return false;
        }

        //check if values are equal
        if(!this.getValue().equals(other_tss.getValue())){
            return false;
        }

        //check if metadata is equal

        if (this.annotationMap != null && other_tss.annotationMap != null) {
            if (this.annotationMap.size() != other_tss.annotationMap.size()) {
                return false;
            } else {
                for (Map.Entry<String, Object> entry : annotationMap.entrySet()) {
                    if (!entry.getValue().equals(other_tss.annotationMap.get(entry.getKey()))) {
                        return false;
                    }
                }
            }
        } else {
            return this.annotationMap == other_tss.annotationMap;
        }

        return true;
    }

    /**
     * Overriding the compareTo method of Observation
     *
     * Observation compareTo is dependant on 2 main factors, the observation's timestamp and the
     * observation's version, it does not follow the semantics of this classes equals method. We have
     * chosen this for the following reasons, we wanted to allow multiple observations with the same timestamps
     * and values in a set and multiple observations ordering should not be dependant in any way on that observation's
     * value or metadata.
     *
     * Primarily, an observation is sorted by it's timestamp, but if however, 2 observation's contain
     * the same timestamp, the version will then be what determines an observation's ordering.
     *
     * The semantics are as followed:
     *
     * 1. If this observation's timestamp is less than incoming observation's timestamp OR
     * If this observation's timestamp equals the incoming observation's timestamp AND this
     * observation's version is less than the other observation's version
     *
     * RETURN -1
     *
     * 2. If this observation's timestamp is equal to the incoming observation's timestamp AND
     * if this observation's version is equal to the incoming observation's version
     *
     * RETURN 0
     *
     * 3. Otherwise
     *
     * RETURN 1
     *
     * @param o the specified object to compare this too
     * @return a positive integer, if this object is greater than the specified object, 0 if this
     * object is equal to the specified object, or -1 if this object is less than the specified object
     */
    @Override
    public int compareTo(Observation<T> o) {
        return Long.compare(this.getTimeTick(), o.getTimeTick());
    }
}
