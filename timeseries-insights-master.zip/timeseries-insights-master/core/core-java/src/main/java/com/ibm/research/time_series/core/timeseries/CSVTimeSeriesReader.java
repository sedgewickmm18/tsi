package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

//did all in one class as not too much logic required
class CSVTimeSeriesReader implements TimeSeriesReader<Map<String,String>> {
    private TimeSeriesReader<Map<String,String>> textFileReader;
    private Map<String,Integer> headerMapping;
    private String delimiter;
    private String timestampColumn;
    private DateTimeFormatter dateTimeFormatter;

    public CSVTimeSeriesReader(String path, String timestampColumn, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter,boolean sort) {
        this.delimiter = delimiter;
        this.timestampColumn = timestampColumn;
        this.dateTimeFormatter = dateTimeFormatter;
        this.headerMapping = new HashMap<>();
        int skipNumLines = (header) ? 1 : 0;
        try {
            String firstLine = Files.lines(Paths.get(path)).findFirst().get(); //todo throw exception here maybe if empty (will add these checks later)
            String[] split = firstLine.split(delimiter);
            for (int i = 0;i < split.length;i++) {
                this.headerMapping.put((header) ? split[i] : "_" + i,i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        textFileReader = (sort)
                ? new TextFileUnsortedTimeSeriesReader<>(path,this::parseObservation,skipNumLines)
                : new TextFileSequentialTimeSeriesReader<>(path,this::parseObservation,skipNumLines);
    }

    private Optional<Observation<Map<String,String>>> parseObservation(String line) {
        final String[] split = line.split(delimiter);
        final Map<String, String> value = headerMapping.entrySet().stream()
                .map(e -> new AbstractMap.SimpleEntry<>(e.getKey(), split[e.getValue()]))
                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
        final long timestamp = (dateTimeFormatter == null) ? Long.parseLong(value.get(timestampColumn)) : ZonedDateTime.from(dateTimeFormatter.parse(value.get(timestampColumn))).toInstant().toEpochMilli();
        value.remove(timestampColumn);
        return Optional.of(new Observation<>(timestamp,value));
    }

    @Override
    public Iterator<Observation<Map<String, String>>> read(long t1, long t2, boolean inclusiveIfBoundsNotExist) {
        return textFileReader.read(t1,t2,inclusiveIfBoundsNotExist);
    }

    @Override
    public long start() {
        return textFileReader.start();
    }

    @Override
    public long end() {
        return textFileReader.end();
    }

    @Override
    public void close() {
        textFileReader.close();
    }
}
