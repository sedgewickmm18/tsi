/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.io.Serializable;

/**
 * <p>Generic Unary Transform that transforms one value</p>
 * <p>Given a time series with values of type INPUT, return a time series of values of type OUTPUT</p>
 * <pre>{@code (x) -> x'}</pre>
 * <p>Created on 4/12/16.</p>
 *
 * @param <INPUT> initial TimeSeries Observation value type
 * @param <OUTPUT> resulting Observation value type
 *
 * @author Joshua Rosenkranz
 */
class UnaryMap<INPUT,OUTPUT> extends UnaryTransform<INPUT,OUTPUT> implements Serializable {

    private static final long serialVersionUID = -6073551441218211288L;
    private UnaryMapFunction<INPUT,OUTPUT> expression;//the expression to evaluate

    /**
     * constructor for UnaryMap
     * @param expression expression to evaluate on a window
     */
    UnaryMap(UnaryMapFunction<INPUT,OUTPUT> expression){
        this.expression = expression;
    }

    /**
     * evaluates the given expression on a window of INPUT values and returns OUTPUT
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return a transformed TreeSet of Observation values
     */
    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<INPUT> input = this.getTimeSeries().getValues(t1,t2,inclusive);

        if (input.isEmpty()) return Observations.empty();

        TSBuilder<OUTPUT> tsBuilder = Observations.newBuilder(input.size());

        input.forEach(x -> tsBuilder.add(new Observation<>(x.getTimeTick(),expression.evaluate(x.getValue()))));
        return tsBuilder.result();
    }

    /**
     * creates a clone of this class
     * @return the clone of this
     */
    @Override
    public Object clone() {
        return new UnaryMap<>(expression);
    }


}
