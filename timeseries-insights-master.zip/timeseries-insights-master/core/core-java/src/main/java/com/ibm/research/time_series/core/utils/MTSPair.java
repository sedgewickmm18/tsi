package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;

/**
 * An immutable container that is used to represent a pair of strongly typed {@link MultiTimeSeries} objects, similar to that
 * of a scala Tuple2
 *
 * <p>Created on 8/28/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class MTSPair<KEY, LEFT, RIGHT> extends Pair<MultiTimeSeries<KEY, LEFT>,MultiTimeSeries<KEY, RIGHT>> {

    /**
     * construct a MTSPair from 2 objects (first being left {@link MultiTimeSeries}, second being right {@link MultiTimeSeries})
     * @param left left object
     * @param right right object
     */
    public MTSPair(MultiTimeSeries<KEY, LEFT> left, MultiTimeSeries<KEY, RIGHT> right) {
        super(left,right);
    }
}
