/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.functions;

import java.io.Serializable;
import java.util.List;

/**
 * An interface to handle an Nary mapping functions where a list of inputs map to one output.
 *
 * <p>Created on 4/13/16.</p>
 *
 * @param <INPUT> initial TimeSeries Observation value type
 * @param <OUTPUT> resulting Observation value type
 *
 * @author Joshua Rosenkranz
 */
public interface NaryMapFunction<INPUT,OUTPUT> extends Serializable {

    /**
     * evaluate an expression that takes a list of input(all of same type) and maps to a single output
     * @param x the list of input values
     * @return a single output represented from the mapping logic on the list of inputs
     */
    OUTPUT evaluate(List<INPUT> x);
}
