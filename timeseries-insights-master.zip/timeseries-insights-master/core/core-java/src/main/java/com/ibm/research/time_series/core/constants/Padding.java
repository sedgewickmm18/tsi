/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.constants;

/**
 * Denotes on which side time windows will extend during sliding operations if the sliding window
 * does not start or end directly on the range boundaries
 *
 * <p>Created on 3/6/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public enum Padding {
    /**
     * Window will extend to the right of the time series range
     *
     * <p>example: [1,2,3,4,5] - window = 3, step = 2</p>
     * <p>result: [(1,2,3),(3,4,5),(5,-,-)]</p>
     */
    RIGHT,
    /**
     * Window will extend to the left of the time series range
     *
     * <p>example: [1,2,3,4,5] - window = 3, step = 2</p>
     * <p>result: [(-,-,1),(1,2,3),(3,4,5)]</p>
     */
    LEFT,
    /**
     * Window will extend on both the left and the right of the time series range
     *
     * <p>example: [1,2,3,4,5] - window = 3, step = 2</p>
     * <p>result: [(-,-,1),(1,2,3),(3,4,5),(5,-,-)]</p>
     */
    LEFT_AND_RIGHT,
    /**
     * Window will never extend over the time series range
     *
     * <p>example: [1,2,3,4,5] - window = 3, step = 2</p>
     * <p>result: [(1,2,3),(3,4,5)]</p>
     */
    NONE
}
