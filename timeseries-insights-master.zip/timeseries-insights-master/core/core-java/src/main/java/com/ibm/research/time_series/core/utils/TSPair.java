/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.timeseries.TimeSeries;

/**
 * An immutable container that is used to represent a pair of strongly typed {@link TimeSeries} objects, similar to that
 * of a scala Tuple2
 *
 * <p>Created on 8/28/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public final class TSPair<LEFT, RIGHT> extends Pair<TimeSeries<LEFT>,TimeSeries<RIGHT>> {

    /**
     * construct a TSPair from 2 objects (first being left {@link TimeSeries}, second being right {@link TimeSeries})
     * @param left left TimeSeries object
     * @param right right TimeSeries object
     */
    public TSPair(TimeSeries<LEFT> left, TimeSeries<RIGHT> right) {
        super(left,right);
    }
}
