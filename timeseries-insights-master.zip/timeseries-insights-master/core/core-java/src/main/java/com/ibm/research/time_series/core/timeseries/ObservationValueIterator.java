/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * ~~~~~~DEVELOPER API~~~~~~
 * An Abstraction for an iterator of Observation values
 * <p>Created on 5/25/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class ObservationValueIterator<T> implements Iterator<T> {
    /**
     * this class is backed by an iterator of Observations
     */
    private Iterator<Observation<T>> iterator;

    /**
     * Constructs an ObservationValueIterator from an iterator of Observations
     * @param observationIterator an iterator of Observations
     */
    public ObservationValueIterator(Iterator<Observation<T>> observationIterator){
        this.iterator = observationIterator;
    }

    /**
     * @return true if we have a next value
     */
    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    /**
     * give the next value from Observation,
     * if a Observation doesn't exist throw a NoSuchElementException
     * @return next value from Observation
     */
    @Override
    public T next() {
        if(iterator.hasNext())
            return iterator.next().getValue();
        else
            throw new TSRuntimeException("No Next Observation Exists",new NoSuchElementException("No Next Element Exists"));
    }
}
