package com.ibm.research.time_series.core.transform.python;

import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;

public class PythonBinaryTransform<T,T2,T3> extends BinaryTransform<T,T2,T3> {
    private PythonBinaryTransformFunction<T,T2,T3> func;

    public PythonBinaryTransform(PythonBinaryTransformFunction<T,T2,T3> func) {
        this.func = func;
    }

    @Override
    public ObservationCollection<T3> evaluate(long t1, long t2, boolean inclusive) {
        return this.func.call(this.timeSeriesLeft, this.timeSeriesRight, t1, t2, inclusive);
    }

    @Override
    public Object clone() {
        return new PythonBinaryTransform<>(func);
    }
}
