package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.io.Serializable;
import java.util.Iterator;

class Shift<T> extends UnaryTransform<T,T> implements Serializable{
    private static final long serialVersionUID = -2943969016588918902L;

    private T defaultValue;
    private int shift;

    Shift(int shift,T defaultValue) {
        this.shift = shift;
        this.defaultValue = defaultValue;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<T> collected = timeSeries.getValues(t1,t2,inclusive);
        int length = collected.size();

        if (shift > length) {
            throw new TSRuntimeException("shift cannot be greater than time series length");
        }

        Iterator<Long> timestampIter = collected.stream().map(Observation::getTimeTick).iterator();
        Iterator<T> valueIter = collected.stream().map(Observation::getValue).iterator();

        TSBuilder<T> builder = Observations.newBuilder();

        if (shift >= 0) {
            for (int i = 0;i < length;i++) {
                long currentTimestamp = timestampIter.next();
                if (i < shift) {
                    builder.add(currentTimestamp,defaultValue);
                } else {
                    builder.add(currentTimestamp,valueIter.next());
                }
            }
        } else {
            for (int i = 0;i < Math.abs(shift);i++) valueIter.next();

            for (int i = 0;i < length;i++) {
                long currentTimestamp = timestampIter.next();
                if (i >= length + shift) {
                    builder.add(currentTimestamp,defaultValue);
                } else {
                    builder.add(currentTimestamp,valueIter.next());
                }
            }
        }
        return builder.result();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return new Shift<>(shift,defaultValue);
    }
}
