/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Serializable;

/**
 * interface for resample function
 *
 * given a set of history observations and future observations, compute a observation's value at a
 * given timestamp
 *
 * <p>Created on 7/19/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public interface Interpolator<T> extends Serializable{
    /**
     * interpolate a value for a given time-tick.
     *
     * @param history closest observations which have a time-tick less than the given time-tick
     * @param future closest observations which have a time-tick greater than the given time-tick
     * @param timetick time-tick to compute value at
     * @return a value signifying the result of interpolation at a given time-tick
     */
    T interpolate(
            ObservationCollection<T> history,
            ObservationCollection<T> future,
            long timetick);

    /**
     * @return the number of history values required for interpolation
     */
    default int getHistorySize() {
        return 1;//1 since many can be implemented with this
    }

    /**
     * @return the number of future values required for interpolation
     */
    default int getFutureSize() {
        return 1;//1 since many can be implemented with this
    }

    /**
     * @return the default fill value if future size or history size is not met
     */
    default T getFillValue() {
        return null;
    }
}
