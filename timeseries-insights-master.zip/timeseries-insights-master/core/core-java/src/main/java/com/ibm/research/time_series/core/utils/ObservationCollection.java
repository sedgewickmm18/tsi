package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.stream.Stream;

/**
 * A Special form of sorted collection which always has values of type {@link Observation}.
 *
 * <p>An Observation-Collection has the following properties:</p>
 * <ul>
 *     <li>Sorted by {@link Observation} time-tick</li>
 *     <li>Observations with duplicate time-ticks are supported</li>
 *     <li>Duplicate time-ticks will keep ordering based on insertion order</li>
 * </ul>
 *
 * <p>Created on 8/28/17.</p>
 * @param <T> {@link Observation} value type
 * @author Joshua Rosenkranz
 */
public interface ObservationCollection<T> extends Iterable<Observation<T>>, Serializable {

    /**
     * Checks for containment of a time-tick within the collection
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code contains(2)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>true</p>
     *     </li>
     * </ul>
     * <pre>{@code contains(3)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>false</p>
     *     </li>
     * </ul>
     *
     * @param timeTick the time-tick to find in the given collection
     * @return true if time-tick exists in collection, otherwise false
     */
    boolean contains(long timeTick);

    /**
     * Checks for containment of all time-ticks within the collection
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code containsAll(Arrays.asList(1,2))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>true</p>
     *     </li>
     * </ul>
     * <pre>{@code containsAll(Arrays.asList(1,3))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>false</p>
     *     </li>
     * </ul>
     *
     * @param c collection of time-ticks to find in the given collection
     * @return true if all time-ticks exist in collection, otherwise false
     */
    boolean containsAll(Collection<? extends Long> c);

    /**
     * @return an iterator of the {@link Observation} in this {@link ObservationCollection}
     */
    Iterator<Observation<T>> iterator();

    /**
     * @return a parallel stream of the {@link Observation} in this {@link ObservationCollection}
     */
    Stream<Observation<T>> parallelStream();

    /**
     * @return a spliterator of the {@link Observation} in this {@link ObservationCollection}
     */
    Spliterator<Observation<T>> spliterator();

    /**
     * @return a stream of the {@link Observation} in this {@link ObservationCollection}
     */
    Stream<Observation<T>> stream();

    /**
     * @return an object array of the {@link Observation} in this {@link ObservationCollection}
     */
    Object[] toArray();

    /**
     * @param a array initialization
     * @return an array of the {@link Observation} in this {@link ObservationCollection}
     */
    Observation<T>[] toArray(Observation<T>[] a);

    /**
     * Given a time-tick, get the ceiling for that time-tick.
     *
     * The ceiling is defined as the the observation which bares the same time-tick as the
     * incoming observation, or if one does not exist, the next higher observation. If no such
     * Observation exists that satisfies these arguments, in the collection, null will be returned.
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code ceiling(2)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(2,2)</p>
     *     </li>
     * </ul>
     * <pre>{@code ceiling(3)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(4,4)</p>
     *     </li>
     * </ul>
     * <pre>{@code ceiling(5)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>null</p>
     *     </li>
     * </ul>
     *
     * @param timeTick the time-tick to find the ceiling of in the given collection
     * @return the ceiling {@link Observation} of the given time-tick
     */
    Observation<T> ceiling(long timeTick);

    /**
     * Given an time-tick, get the floor for that time-tick.
     *
     * The floor is defined as the the observation which bares the same time-tick as the
     * incoming observation, or if one does not exist, the next lower observation.  If no such
     * Observation exists that satisfies these arguments, in the collection, null will be returned.
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code floor(2)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(2,2)</p>
     *     </li>
     * </ul>
     * <pre>{@code floor(3)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(2,2)</p>
     *     </li>
     * </ul>
     * <pre>{@code floor(0)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>null</p>
     *     </li>
     * </ul>
     *
     * @param timeTick the time-tick to find the floor of in the given collection
     * @return the floor observation of the given observation
     */
    Observation<T> floor(long timeTick);

    /**
     * Get the head-set snap-shot {@link ObservationCollection} ending with the given "to" Observation.
     *
     * The head-set is defined as all observations
     * (less than for non-inclusive) / (less than or equal to for inclusive) to the given "to"
     * observation.
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code headSet(2,false}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1)]</p>
     *     </li>
     * </ul>
     * <pre>{@code headSet(2,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2)]</p>
     *     </li>
     * </ul>
     * <pre>{@code headSet(1,false))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[]</p>
     *     </li>
     * </ul>
     * <pre>{@code headSet(3,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2)]</p>
     *     </li>
     * </ul>
     *
     * @param to the ending observation of the head-set
     * @param toInclusive denotes whether to include the "to" observation if one exists
     * @return the head-set of the given to time-tick
     */
    ObservationCollection<T> headSet(long to, boolean toInclusive);

    /**
     * Get the tail-set snap-shot ObservationCollection starting with the given "from" Observation.
     *
     * The tail-set is defined as all observations
     * (greater than for non-inclusive) / (greater than or equal to for inclusive) to the given
     * "from" observation.
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code tailSet(2,false))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code tailSet(2,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code tailSet(4,false))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[]</p>
     *     </li>
     * </ul>
     * <pre>{@code tailSet(3,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(4,4)]</p>
     *     </li>
     * </ul>
     *
     * @param from the starting time-tick of the headset
     * @param fromInclusive denotes whether to include the "from" observation if one exists
     * @return the tail-set of the given from time-tick
     */
    ObservationCollection<T> tailSet(long from, boolean fromInclusive);

    /**
     * @return this collection as an iterator in descending order sorted by Observation timestamp
     */
    Iterator<Observation<T>> descendingIterator();

    /**
     * Get the sub-set snap-shot ObservationCollection starting with the given "from" Observation
     * and ending with the given "to" Observation
     *
     * The sub-set is defined as all observations
     * (less than for non-inclusive) / (less than or equal to for inclusive) to the given "to"
     * observation and (greater than for non-inclusive) / (greater than or equal to for inclusive)
     * to the given "from" observation.
     *
     * todo we should probably throw an exception if "from" greater than "to"
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code subset(2,false,3,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[]</p>
     *     </li>
     * </ul>
     * <pre>{@code subset(2,false,4,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code subset(2,true,4,false))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2)]</p>
     *     </li>
     * </ul>
     * <pre>{@code subset(2,true,4,true))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code subset(2,true,5,false))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(4,4)]</p>
     *     </li>
     * </ul>
     *
     * @param from the starting time-tick of the headset
     * @param fromInclusive denotes whether to include the "from" observation if one exists
     * @param to the ending time-tick of the head-set
     * @param toInclusive denotes whether to include the "to" observation if one exists
     * @return the sub-set of the given from/to time-ticks, if no Observations exist, an exception will be thrown
     */
    ObservationCollection<T> subSet(long from, boolean fromInclusive, long to, boolean toInclusive);

    /**
     * get the first observation in this collection
     *
     * The first observation is that observation which has the lowest timestamp in the collection.
     * If 2 observations have the same timestamp, the first observation that was in the collection
     * will be the one returned.
     *
     * @return the first observation in this collection
     */
    Observation<T> first();

    /**
     * get the last observation in this collection
     *
     * The last observation is that observation which has the highest timestamp in the collection.
     * If 2 observations have the same timestamp, the last observation that was in the collection
     * will be the one returned
     *
     * @return the last observation in this collection
     */
    Observation<T> last();

    /**
     * given an observation, get the observation which is higher than the given observation
     *
     * The higher observation is that observation which has a timestamp greater than the given
     * observation. If none such observation exists with a higher timestamp, higher return null
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2L,3.0),Observation(2L,2.0),Observation(5L,1.0),Observation(7L,2.0)]</p>
     *     </li>
     * </ul>
     * <pre>{@code higher(Observation(5L,3.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(7L,2.0)</p>
     *     </li>
     * </ul>
     * <pre>{@code higher(Observation(6L,1.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(7L,2.0)</p>
     *     </li>
     * </ul>
     * <pre>{@code higher(Observation(7L,1.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>null</p>
     *     </li>
     * </ul>
     *
     * @param timeTick given time-tick to check higher against
     * @return the higher observation in this collection of a given time-tick
     */
    Observation<T> higher(long timeTick);

    /**
     * given an observation, get the observation which is lower than the given observation
     *
     * The lower observation is that observation which has a timestamp less than the given
     * observation. If none such observation exists with a lower timestamp, lower will return null
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2L,3.0),Observation(2L,2.0),Observation(5L,1.0),Observation(7L,2.0)]</p>
     *     </li>
     * </ul>
     * <pre>{@code lower(Observation(5L,3.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(2L,2.0)</p>
     *     </li>
     * </ul>
     * <pre>{@code lower(Observation(6L,1.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>Observation(5L,1.0)</p>
     *     </li>
     * </ul>
     * <pre>{@code lower(Observation(2L,4.0))}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>null</p>
     *     </li>
     * </ul>
     *
     * @param timeTick given time-tick to check lower against
     * @return the lower observation in this collection of a given time-tick
     */
    Observation<T> lower(long timeTick);

    /**
     * @return a lazily evaluated time series object of the current in memory collection
     */
    TimeSeries<T> toTimeSeriesStream();

    /**
     * @param trs the source {@link TRS}
     * @return a lazily evaluated time series object of the current in memory collection
     */
    TimeSeries<T> toTimeSeriesStream(TRS trs);

    /**
     * @return a collection of the {@link Observation} in this {@link ObservationCollection}
     */
    Collection<Observation<T>> toCollection();

    /**
     * @return the number of {@link Observation} in this collection
     */
    int size();

    /**
     * @return true if no {@link Observation}s exist in this collection, otherwise return false
     */
    boolean isEmpty();

    /**
     * @return the {@link TRS} associated with this collection
     */
    TRS getTRS();

//    /**
//     * @return true if this collection of {@link Observation}s is periodic, otherwise false
//     */
//    boolean isPeriodic();
}
