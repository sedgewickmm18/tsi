package com.ibm.research.time_series.core.utils;

import java.util.function.Supplier;

public interface State<STATE,VALUE> {
    void update(VALUE value);
    STATE get();
}
