package com.ibm.research.time_series.core.exceptions;

/**
 * A simple TimeSeries framework extension of {@link RuntimeException} to identify
 * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} specific run-time exceptions
 */
public class TSRuntimeException extends RuntimeException {
    private static final long serialVersionUID = -4942234241320881087L;

    /**
     * Create a {@link com.ibm.research.time_series.core.timeseries.TimeSeries} run-time exception given a simple
     * message
     * @param msg the simple message describing the exception
     */
    public TSRuntimeException(String msg) {
        super(msg);
    }

    /**
     * Create a {@link com.ibm.research.time_series.core.timeseries.TimeSeries} run-time exception given a simple
     * message and another {@link Throwable}
     * @param msg the simple message describing the exception
     * @param t a {@link Throwable} further describing the exception
     */
    public TSRuntimeException(String msg, Throwable t) {
        super(msg, t);
    }
}
