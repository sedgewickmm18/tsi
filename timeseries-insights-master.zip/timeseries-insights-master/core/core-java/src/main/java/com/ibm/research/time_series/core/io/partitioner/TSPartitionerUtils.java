package com.ibm.research.time_series.core.io.partitioner;

import com.ibm.research.time_series.core.io.Utils;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.TSBuilder;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalLong;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Internal Utility class for use in Time-Series partitioning
 */
public class TSPartitionerUtils {

    /**
     * @param fileName time-series data file name
     * @param parser function given a line, optionally extract a time-tick
     * @return an array containing the min and max time-tick
     * @throws IOException if file not exist
     */
    public static long [] getStartEndTs(String fileName, Function<String, OptionalLong> parser) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(Utils.inferInputStream(fileName)));

        String readLine;
        long[] result = {Long.MAX_VALUE, Long.MIN_VALUE};
        while ((readLine = br.readLine()) != null) {
            OptionalLong l = parser.apply(readLine);
            if (l.isPresent()) {
                result[0] = Math.min(l.getAsLong(), result[0]);
                result[1] = Math.max(l.getAsLong(), result[1]);
            }
        }

        return result;
    }

    static int getBin(long ts, long startTs, long endTs, int numBins) {
        int bin = (int) Math.floor(numBins * 1.0 * (ts - startTs) / (endTs - startTs));
        bin = Math.max(bin, 0);
        bin = Math.min(bin, numBins - 1);

        return bin;
    }

    static int getUpperBoundCount(int binId, int totalCount, int numBins) {
        double upperBoundCountVal = 1.0 * (binId + 1) * totalCount / numBins;
        return (int) Math.floor(upperBoundCountVal);
    }

    static long getUpperBoundTs(int binId, long startTs, long endTs, int numHistBins) {
        long upperBoundTs = (long) (startTs + (binId + 1) * ( 1.0 * (endTs - startTs) / numHistBins));

        return upperBoundTs;
    }

    /**
     * sort an unsorted partitioned file
     * @param fileName unsorted partitioned file name
     * @param outFileName output file name
     * @return the output file name once sorted
     * @throws IOException if file does not exist
     */
    public static String sort(String fileName, String outFileName) throws IOException {
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFileName)));

        Files.lines(Paths.get(fileName)).sorted(Comparator.comparing(x -> Long.parseLong(x.substring(0,x.indexOf(","))))).forEach(s -> {
            try {
                final int index = s.indexOf(",");
                bw.write(s,index+1,s.length() - index - 1);
                bw.write("\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        bw.close();
        return outFileName;
    }
}
