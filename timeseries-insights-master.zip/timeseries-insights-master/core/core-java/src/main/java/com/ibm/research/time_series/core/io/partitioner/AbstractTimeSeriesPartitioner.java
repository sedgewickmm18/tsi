package com.ibm.research.time_series.core.io.partitioner;

import com.ibm.research.time_series.core.io.Utils;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.OptionalLong;
import java.util.function.Function;
import java.util.zip.GZIPInputStream;

/**
 * Abstract representation of a Time-Series Partitioner
 */
abstract class AbstractTimeSeriesPartitioner {
    protected int numBins;
    protected Function<String, OptionalLong> parser;
    protected long startTs;
    protected long endTs;

    /**
     * @param ts time-tick
     * @return bin associated with given time-tick
     */
    public abstract int getBin(long ts);

    protected AbstractTimeSeriesPartitioner(int numBins, Function<String, OptionalLong> parser, long startTs, long endTs) {
        this.numBins = numBins;
        this.parser = parser;
        this.startTs = startTs;
        this.endTs = endTs;
    }

    /**
     * partition the data into a list of files
     *
     * @param inputFileNames input data file names
     * @param outputFileNamePrefix output file prefix
     * @param outputFileNameSuffix output file suffix
     * @return a list of partitioned file names
     * @throws IOException if file does not exist
     */
    public List<String> partition(List<String> inputFileNames, String outputFileNamePrefix, String outputFileNameSuffix) throws IOException {

        List<BufferedWriter> binWriters = new ArrayList<>(numBins);

        List<String> outFileNames = new ArrayList<>();
        for (int i = 0; i < numBins; i++) {
            String fileName = outputFileNamePrefix + "_" + i + outputFileNameSuffix;
            outFileNames.add(fileName);
            binWriters.add(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName))));
        }

        for (String inputFileName : inputFileNames) {
            InputStream inputStream = Utils.inferInputStream(inputFileName);

            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));

            String readLine;

            while ((readLine = br.readLine()) != null) {
                OptionalLong optionalLong = parser.apply(readLine);

                if (optionalLong.isPresent()) {
                    final long asLong = optionalLong.getAsLong();
                    int bin = getBin(asLong);
                    BufferedWriter bw = binWriters.get(bin);
                    bw.write(asLong + "," + readLine);
                    bw.write("\n");
                }
            }

            for (BufferedWriter binWriter : binWriters) {
                binWriter.flush();
            }

        }

        for (BufferedWriter binWriter : binWriters) {
            binWriter.close();
        }
        return outFileNames;
    }

    /**
     * partition the data into a list of files
     *
     * @param inputFileName single input file name
     * @param outputFileNamePrefix output file prefix
     * @param outputFileNameSuffix output file suffix
     * @return a list of partitioned file names
     * @throws IOException if file does not exist
     */
    public List<String> partition(String inputFileName, String outputFileNamePrefix, String outputFileNameSuffix) throws IOException {
        return partition(Collections.singletonList(inputFileName),outputFileNamePrefix,outputFileNameSuffix);
    }
}
