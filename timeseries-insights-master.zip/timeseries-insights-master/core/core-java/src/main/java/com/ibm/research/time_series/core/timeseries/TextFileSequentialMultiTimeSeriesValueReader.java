package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.utils.Pair;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class TextFileSequentialMultiTimeSeriesValueReader<K,T> extends MultiTimeSeriesReader<K,T> {
    private String path;
    private UnaryMapFunction<String, Optional<Pair<K, T>>> parseLine;
    private int skipNumLines;

    public TextFileSequentialMultiTimeSeriesValueReader(
            String path,
            UnaryMapFunction<String, Optional<Pair<K, T>>> parseLine,
            int skipNumLines) {
        this.path = path;
        this.parseLine = parseLine;
        this.skipNumLines = skipNumLines;
    }

    @Override
    protected Map<K, TimeSeriesReader<T>> populateMap() {
        Map<K,TimeSeriesReader<T>> result = null;
        try(Stream<String> stream = Files.lines(Paths.get(path))) {
            result = stream
                    .map(l -> parseLine.evaluate(l))
                    .filter(Optional::isPresent)
                    .map(x -> x.get().left)
                    .distinct()
                    .map(k -> {
                        return new Pair<>(k,new TextFileSequentialTimeSeriesValueReader<>(
                                path,
                                s -> {
                                    final Optional<Pair<K, T>> optPair = parseLine.evaluate(s);

                                    return (optPair.isPresent() && optPair.get().left.equals(k))
                                            ? optPair.map(p -> p.right)
                                            : Optional.<T>empty();
                                },
                                skipNumLines
                        ));
                    })
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void close() {

    }
}
