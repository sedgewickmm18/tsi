package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;
import java.util.List;

class IndexNaryJoin<IN,OUT> extends NaryTransform<IN,OUT> {

    private static final long serialVersionUID = -8247596813585627407L;
    private BinaryMapFunction<OUT,IN,OUT> combineOp;
    private OUT zeroValue;

    IndexNaryJoin(OUT zeroValue, BinaryMapFunction<OUT,IN,OUT> combineOp) {
        this.zeroValue = zeroValue;
        this.combineOp = combineOp;
    }

    @Override
    public ObservationCollection<OUT> evaluate(long start, long end,boolean inclusive) {

        TimeSeries<OUT> aggregateTS = this.timeSeriesRoot.map(x -> combineOp.evaluate(zeroValue,x));
        List<TimeSeries<IN>> tail = this.timeSeriesTail;
        for (TimeSeries<IN> currentTailTs : tail) {
            aggregateTS = join(aggregateTS,currentTailTs,start,end,inclusive);
        }

        return aggregateTS.getValues(start,end,inclusive);
    }

    private TimeSeries<OUT> join(TimeSeries<OUT> aggregateTS, TimeSeries<IN> currentTS, long start, long end, boolean inclusive) {
        ObservationCollection<IN> curObservations = currentTS.getValues(start,end,inclusive);
        ObservationCollection<OUT> aggObservations = aggregateTS.getValues(start,end,inclusive);

        TSBuilder<OUT> tsBuilder = Observations.newBuilder();

        Iterator<Observation<IN>> curIter = curObservations.iterator();
        Iterator<Observation<OUT>> aggIter = aggObservations.iterator();

        while (curIter.hasNext() && aggIter.hasNext()) {
            Observation<IN> curObs = curIter.next();
            Observation<OUT> aggObs = aggIter.next();
            tsBuilder.add(new Observation<>(aggObs.getTimeTick(),combineOp.evaluate(aggObs.getValue(),curObs.getValue())));
        }
        return TimeSeries.fromObservations(tsBuilder.result());
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return new IndexNaryJoin<>(zeroValue,combineOp);
    }
}
