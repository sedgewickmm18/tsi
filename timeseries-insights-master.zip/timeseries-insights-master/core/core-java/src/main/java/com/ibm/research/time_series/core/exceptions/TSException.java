package com.ibm.research.time_series.core.exceptions;

/**
 * A simple TimeSeries framework extension of {@link Exception} to identify
 * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} specific exceptions
 */
public class TSException extends Exception {

    private static final long serialVersionUID = 3460554339065811500L;

    /**
     * Create a {@link com.ibm.research.time_series.core.timeseries.TimeSeries} exception given a simple message
     * @param msg the simple message describing the exception
     */
    public TSException(String msg) {
        super(msg);
    }

    /**
     * Create a {@link com.ibm.research.time_series.core.timeseries.TimeSeries} exception given a simple message and
     * another {@link Throwable}
     * @param msg the simple message describing the exception
     * @param t a {@link Throwable} further describing the exception
     */
    public TSException(String msg, Throwable t) {
        super(msg, t);
    }
}
