package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.stream.DoubleStream;

class DescribeTimeReducer<T> extends UnaryReducer<T,TimeStats>{

    private static final long serialVersionUID = 8969742481873967089L;

    @Override
    public TimeStats reduceSegment(Segment<T> segment) {
        TimeSeries<T> ts = segment.toTimeSeriesStream();

        double[] iatList = ts
                .segment(2)
                .map(s -> ((double) s.last().getTimeTick() - (double) s.first().getTimeTick()))
                .collect()
                .stream()
                .mapToDouble(Observation::getValue)
                .toArray();

        long iatMax = (long) DoubleStream.of(iatList).max().orElse(Double.NaN);
        long iatMin = (long)DoubleStream.of(iatList).min().orElse(Double.NaN);
        double iatAvg = DoubleStream.of(iatList).average().orElse(Double.NaN);
        return new TimeStats(iatMin,iatMax,iatAvg);
    }
}
