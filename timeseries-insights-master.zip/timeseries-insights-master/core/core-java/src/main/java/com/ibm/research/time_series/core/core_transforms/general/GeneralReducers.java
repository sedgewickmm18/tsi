package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.transform.UnaryReducer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Entry point for a general set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries} reducers
 */
public class GeneralReducers {

    /**
     * describe time reducer will take a segment of any time and give back the {@link TimeStats}
     *
     * @param <T> type of {@link com.ibm.research.time_series.core.observation.Observation} value
     * @return a new describe time {@link UnaryReducer}
     */
    public static <T> UnaryReducer<T,TimeStats> describeTime() {
        return new DescribeTimeReducer<>();
    }

    /**
     * describe object reducer will take a segment of objects of generic type and give back a {@link Stats}
     *
     * @param <T> type of {@link com.ibm.research.time_series.core.observation.Observation} value
     * @return a new describe {@link UnaryReducer}
     */
    public static <T> UnaryReducer<T,Stats<T>> describe() {
        return new DescribeObjectReducer<>();
    }

    /**
     * aggregate a {@link com.ibm.research.time_series.core.utils.Segment} or
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to a single value
     *
     * @param zero the zero value
     * @param updateFunc update function for aggregate value
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @param <OUTPUT> output type
     * @return a new aggregate {@link UnaryReducer}
     */
    public static <T,OUTPUT> UnaryReducer<T,OUTPUT> aggregate(Supplier<OUTPUT> zero, BinaryMapFunction<OUTPUT,T,OUTPUT> updateFunc) {
        return new Aggregate<>(zero, updateFunc);
    }

    /**
     * reducer which, for each unique {@link com.ibm.research.time_series.core.observation.Observation} value in a
     * {@link com.ibm.research.time_series.core.utils.Segment} or
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, count the number of occurrences
     *
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return a new count-by-value {@link UnaryReducer}
     */
    public static <T> UnaryReducer<T, Map<T,Integer>> countByValue() {
        return aggregate(
                HashMap::new,
                (agg,cur) -> {
                    agg.putIfAbsent(cur, 0);
                    agg.computeIfPresent(cur,(key,value) -> value + 1);
                    return agg;
                }
        );
    }
}
