/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.*;

/**
 * <p>This is the interface to a Cache which holds {@link Observation}</p>
 * <p>Cache is used for all types of caching as part of the pipeline of TimeSeries chains.
 * By default in-memory cache will be used, which uses an {@link ObservationCollection} as its underlying structure.</p>
 * <p>Created on 12/2/15.</p>
 *
 * @author Joshua Rosenkranz
 * @author Mudhakar Srivatsa
 */
public interface Cache<T>{

    /**
     * add an {@link Observation} to our cache storage
     * @param observation the Observation to add
     */
    void add(Observation<T> observation);

    /**
     * @return first {@link Observation} in cache storage
     */
    Observation<T> first();

    /**
     * @return last {@link Observation} in cache storage
     */
    Observation<T> last();

    /**
     * @return the amount of Observation in our cache storage
     */
    int size();

    /**
     * @return true if cache storage is empty, false if items are in the cache storage
     */
    boolean isEmpty();

    /**
     * returns our entire cache storage as a SortedSet
     * @return SortedSet with our cache storage TimeStampSensors
     */
    ObservationCollection<T> getCache();

    /**
     * returns a subset of our cache from given floor to given ceiling
     * @param t1 timestamp start, the given floor
     * @param t2 timestamp end, the given ceiling
     * @param inclusiveIfNotOnBoundary if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return SortedSet subset of cache storage with our TimeStampSensors from the cache
     */
    ObservationCollection<T> getCacheInRange(long t1, long t2, boolean inclusiveIfNotOnBoundary);

    /**
     * @return iterator to beginning of our cache storage
     */
    Iterator<Observation<T>> iterator();

    /**
     * sets the maximum size of our cache storage.
     * <p>Note: Maximum cache size can be flexible depending on the shrink cache removal scheme of the given cache</p>
     * @param size the maximum size to set our cache storage too
     */
    void setMaxCacheSize(int size);

    /**
     * @return the maximum size of our cache
     */
    int getMaxCacheSize();

    /**
     * clear the cache
     */
    void clear();

}
