package com.ibm.research.time_series.core.io.writers;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesWriteFormat;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

public class ObjectFileTimeSeriesWriterFormat<T> implements TimeSeriesWriteFormat<T> {

    private String path;

    public ObjectFileTimeSeriesWriterFormat(String path) {
        this.path = path;
    }

    @Override
    public void write(ObservationCollection<T> observations, UnaryMapFunction<T, String> encodeValue, Map<String, Object> options) {
        ByteArrayOutputStream baStreamTS = new ByteArrayOutputStream();
        ObjectOutputStream ooStreamTS = null;
        try {
            FileOutputStream fos = new FileOutputStream(path);
            ooStreamTS = new ObjectOutputStream(baStreamTS);
            ooStreamTS.writeObject(observations);
            ooStreamTS.close();
            baStreamTS.writeTo(fos);
            baStreamTS.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
