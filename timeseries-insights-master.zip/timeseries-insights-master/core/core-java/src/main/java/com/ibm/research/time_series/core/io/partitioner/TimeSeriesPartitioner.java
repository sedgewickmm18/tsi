package com.ibm.research.time_series.core.io.partitioner;

import com.ibm.research.time_series.core.observation.Observation;

import java.util.OptionalLong;
import java.util.function.Function;

/**
 * Utility class used for partitioning a large Time-Series based on time-ticks start and end
 */
public class TimeSeriesPartitioner extends AbstractTimeSeriesPartitioner {

    /**
     * Create a TimeSeries partitioner
     *
     * @param numBins number of bins to partition
     * @param parser function given a line, optionally extract a time-tick
     * @param startTs first time-tick in data
     * @param endTs last time-tick in data
     */
    public TimeSeriesPartitioner(int numBins, Function<String, OptionalLong> parser, long startTs, long endTs) {
        super(numBins, parser, startTs, endTs);
    }

    @Override
    public int getBin(long ts) {
        return TSPartitionerUtils.getBin(ts, startTs, endTs, numBins);
    }
}
