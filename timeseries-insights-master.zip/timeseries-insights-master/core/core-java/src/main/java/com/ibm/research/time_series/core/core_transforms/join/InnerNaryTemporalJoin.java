package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.List;

class InnerNaryTemporalJoin<IN,OUT> extends NaryTransform<IN,OUT> {

    private static final long serialVersionUID = 5529531043130209533L;
    private BinaryMapFunction<OUT,IN,OUT> combineOp;
    private OUT zeroValue;

    InnerNaryTemporalJoin(OUT zeroValue, BinaryMapFunction<OUT,IN,OUT> combineOp) {
        this.zeroValue = zeroValue;
        this.combineOp = combineOp;
    }

    @Override
    public ObservationCollection<OUT> evaluate(long start, long end,boolean inclusive) {
        TimeSeries<OUT> aggregateTS = this.timeSeriesRoot.map(x -> combineOp.evaluate(zeroValue,x));
        List<TimeSeries<IN>> tail = this.timeSeriesTail;
        for (TimeSeries<IN> currentTailTs : tail) {
            aggregateTS = aggregateTS.innerJoin(currentTailTs,combineOp);
        }

        return aggregateTS.getValues(start,end,inclusive);
    }

    @Override
    public Object clone() {
        return new InnerNaryTemporalJoin<>(zeroValue,combineOp);
    }
}
