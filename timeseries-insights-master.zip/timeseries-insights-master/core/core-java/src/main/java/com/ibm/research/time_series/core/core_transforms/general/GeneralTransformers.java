package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.TRS;

/**
 * This is the entry point for all core built-in general {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
 * transforms
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class GeneralTransformers {

    /**
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return a new {@link BinaryTransform} which will concatenate two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     */
    public static <T> BinaryTransform<T,T,T> concat() {
        return new Concat<>();
    }

    /**
     * @param interpolator the interpolator method to be used when a value is null
     * @param nullValue denotes a null value, for instance if nullValue = Double.NaN, Double.NaN would be filled
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return an {@link UnaryTransform} which will fill all null values in the {@link TimeSeries}
     */
    public static <T> UnaryTransform<T,T> fillNA(Interpolator<T> interpolator, T nullValue) {
        return new FillNA<>(interpolator, nullValue);
    }

    /**
     * @param interpolator the interpolator method to be used when a value is null
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return an {@link UnaryTransform} which will fill all nulls in the {@link TimeSeries}
     */
    public static <T> UnaryTransform<T,T> fillNA(Interpolator<T> interpolator) {
        return fillNA(interpolator, null);
    }

    /**
     * @param trs the given {@link TRS}
     * @param <T> input {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return an {@link UnaryTransform} which will re-map a {@link TimeSeries} time ticks based on a start time and a
     * granularity.
     */
    public static <T> UnaryTransform<T,T> withTRS(TRS trs) {
        return new WithTRS<>(trs);
    }

    /**
     * This is the interpolation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will resample the given time series.
     *
     * <p>
     *     Interpolation is done through a function that given sequence of future/history values and a timestamp,
     *     returns a value for the given timestamp. View {@link Interpolator} for more details
     * </p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code resample(1,1,1,GenericInterpolators.prev())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,2),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code resample(1,1,1,GenericInterpolators.next())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,4),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param period periodicity
     * @param interpolator resample function
     * @param startOnBounds if true, uses given range start for start computation, otherwise usese first time-tick for
     *                      start computation
     * @param <T> {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return a single instance of an interpolation transform
     */
    public static <T> UnaryTransform<T,T> interpolate(long period, Interpolator<T> interpolator, boolean startOnBounds) {
        return new InterpolationTransform<>(interpolator,period,startOnBounds);
    }

    /**
     * This is the lag transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will lag the given time series by the
     * given amount.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code lag(2)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param amount amount to lag series by
     * @param <T> {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return a single instance of a lag transform
     */
    public static <T> UnaryTransform<T,T> lag(long amount) {
        return new LagTransform<>(amount);
    }

    /**
     * This is the shift transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will shift the given time series values by the
     * given shift amount, padding extra observations with a default value.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code shift(2,0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,0),Observation(2,0),Observation(3,1),Observation(4,2),Observation(5,3)]</p>
     *     </li>
     * </ul>
     *
     * @param shift amount to shift series values by
     * @param defaultValue default padding value
     * @param <T> {@link com.ibm.research.time_series.core.observation.Observation} value type
     * @return a single instance of a shift transform
     */
    public static <T> UnaryTransform<T,T> shift(int shift,T defaultValue) {
        return new Shift<>(shift,defaultValue);
    }
}
