/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.transform.BinaryReducer;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.AbstractMap;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * A special form of {@link MultiTimeSeries} that consists of {@link Segment}s as its observation values
 *
 * <p>Created on 6/15/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class SegmentMultiTimeSeries<KEY,VALUE> extends MultiTimeSeries<KEY,Segment<VALUE>> {
    private Map<KEY,SegmentTimeSeries<VALUE>> stsMap;

    /**
     * Construct a {@link SegmentMultiTimeSeries} given a Map of {@link SegmentTimeSeries}
     * @param stsMap {@link SegmentTimeSeries} map
     */
    public SegmentMultiTimeSeries(Map<KEY,SegmentTimeSeries<VALUE>> stsMap) {
        super(
                stsMap.entrySet().stream()
                    .map(x -> new AbstractMap.SimpleEntry<>(x.getKey(),(TimeSeries<Segment<VALUE>>)x.getValue()))
                    .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue))
        );
        this.stsMap = stsMap;
    }

    /**
     * transform a given segment into another segment
     *
     * @param transform unary transform
     * @param <VALUE2> new segment type
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public <VALUE2> SegmentMultiTimeSeries<KEY,VALUE2> transformSegments(UnaryTransform<VALUE,VALUE2> transform) {
        Map<KEY,SegmentTimeSeries<VALUE2>> result = Collections.synchronizedMap(new HashMap<>());
        stsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(),ts.getValue().transformSegments(transform));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * map the values in a segment to a new segment
     *
     * @param f value map function
     * @param <VALUE2> new segment type
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public <VALUE2> SegmentMultiTimeSeries<KEY,VALUE2> mapSegments(UnaryMapFunction<VALUE,VALUE2> f) {
        Map<KEY,SegmentTimeSeries<VALUE2>> result = Collections.synchronizedMap(new HashMap<>());
        stsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(),ts.getValue().mapSegments(f));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * perform a binary reducer over two {@link SegmentMultiTimeSeries}
     *
     * @param other other {@link SegmentTimeSeries}
     * @param reducer binary reducer
     * @param <VALUE2> other time series observation type
     * @param <VALUEOUT> output time series observation type
     * @return a new {@link MultiTimeSeries}
     */
    public <VALUE2,VALUEOUT> MultiTimeSeries<KEY,VALUEOUT> transform(
            SegmentMultiTimeSeries<KEY,VALUE2> other,
            BinaryReducer<VALUE,VALUE2,VALUEOUT> reducer) {
        Map<KEY,TimeSeries<VALUEOUT>> result = Collections.synchronizedMap(new HashMap<>());

        stsMap.entrySet().stream().parallel().forEach(ts -> {
            SegmentTimeSeries<VALUE2> ts2 = other.stsMap.get(ts.getKey());
            result.put(ts.getKey(),ts.getValue().transform(ts2,reducer));
        });

        return new MultiTimeSeries<>(result);
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations in range into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @param start start timetick of range
     * @param end end timetick of range
     * @param inclusive inclusive flag
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Pair<KEY, Long>, VALUE> flatten(long start, long end, boolean inclusive) {
        return new MultiTimeSeries<>(
                stsMap.entrySet().parallelStream().flatMap(entry ->
                    entry.getValue().getValues(start, end, inclusive).stream().map(obs ->
                        new Pair<>(new Pair<>(entry.getKey(), obs.getTimeTick()), obs.getValue())
                    )
                ).collect(Collectors.toMap(x -> x.left, x -> x.right.toTimeSeriesStream()))
        );
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations in range into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @param start start timetick of range
     * @param end end timetick of range
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Pair<KEY, Long>, VALUE> flatten(long start, long end) {
        return flatten(start, end, false);
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @param inclusive inclusive flag
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Pair<KEY, Long>, VALUE> flatten(boolean inclusive) {
        return new MultiTimeSeries<>(
                stsMap.entrySet().parallelStream().flatMap(entry ->
                        entry.getValue().collect(inclusive).stream().map(obs ->
                                new Pair<>(new Pair<>(entry.getKey(), obs.getTimeTick()), obs.getValue())
                        )
                ).collect(Collectors.toMap(x -> x.left, x -> x.right.toTimeSeriesStream()))
        );
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     * <p>Note: the Segment key will be created based on the start of the segment</p>
     *
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<Pair<KEY, Long>, VALUE> flatten() {
        return flatten(false);
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     *
     * @param secondaryKeyOp operation where given a {@link Segment}, produce a key
     * @param inclusive inclusive flag
     * @param <KEY2> segment key type
     * @return a new {@link MultiTimeSeries}
     */
    public <KEY2> MultiTimeSeries<Pair<KEY, KEY2>, VALUE> flatten(UnaryMapFunction<Segment<VALUE>, KEY2> secondaryKeyOp, boolean inclusive) {
        return new MultiTimeSeries<>(
                stsMap.entrySet().parallelStream().flatMap(entry ->
                        entry.getValue().collect(inclusive).stream().map(obs ->
                                new Pair<>(new Pair<>(entry.getKey(), secondaryKeyOp.evaluate(obs.getValue())), obs.getValue())
                        )
                ).collect(Collectors.toMap(x -> x.left, x -> x.right.toTimeSeriesStream()))
        );
    }

    /**
     * Converts this {@link SegmentMultiTimeSeries} into a {@link MultiTimeSeries} where each {@link TimeSeries}
     * will be the result of a single {@link Segment}.
     *
     * <p>Note: this method will bring all observations into memory</p>
     *
     * @param secondaryKeyOp operation where given a {@link Segment}, produce a key
     * @param <KEY2> segment key type
     * @return a new {@link MultiTimeSeries}
     */
    public <KEY2> MultiTimeSeries<Pair<KEY, KEY2>, VALUE> flatten(UnaryMapFunction<Segment<VALUE>, KEY2> secondaryKeyOp) {
        return flatten(secondaryKeyOp, false);
    }

    @Override
    public SegmentMultiTimeSeries<KEY, VALUE> filter(FilterFunction<Segment<VALUE>> filterFunction) {
        Map<KEY,SegmentTimeSeries<VALUE>> result = Collections.synchronizedMap(new HashMap<>());
        stsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(),ts.getValue().filter(filterFunction));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    @Override
    public SegmentMultiTimeSeries<KEY,VALUE> filterSeries(FilterFunction<TimeSeries<Segment<VALUE>>> filterFunction) {
        return new SegmentMultiTimeSeries<>(
                stsMap.entrySet().stream().parallel()
                        .filter(x -> filterFunction.evaluate(x.getValue()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
        );
    }
}
