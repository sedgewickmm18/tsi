package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TRS;
import com.ibm.research.time_series.core.utils.TSBuilder;

class WithTRS<T> extends UnaryTransform<T,T> {

    private TRS trs;

    WithTRS(TRS trs) {
        this.trs = trs;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {

        if (this.timeSeries.getTRS() == null) {
            throw new TSRuntimeException("withTRS requires that your TimeSeries have a TRS. You can add a TRS to your TimeSeries by collected the TimeSeries and re-initializing a TimeSeries Stream with a TRS",new UnsupportedOperationException());
        } else {
            long t1Fixed = this.timeSeries.getTRS().toIndex(trs.toLongLower(t1));
            long t2Fixed = this.timeSeries.getTRS().toIndex(trs.toLongUpper(t2));// + ((trs.getGranularity().toMillis() / this.timeSeries.getSourceTRS().getGranularity().toMillis()) - 1);
            ObservationCollection<T> input = this.timeSeries.getValues(t1Fixed, t2Fixed, inclusive);
            TSBuilder<T> tsBuilder = Observations.newBuilder();
            for (Observation<T> obs : input) {
                tsBuilder.add(new Observation<>(trs.toIndex(this.timeSeries.getTRS().toLongLower(obs.getTimeTick())), obs.getValue()));
            }
            return tsBuilder.result();
        }
    }

    @Override
    public Object clone() {
        return new WithTRS<>(trs);
    }
}
