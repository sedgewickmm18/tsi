package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.*;

class ChangeBasedSegmentation<T> extends UnaryTransform<T, Segment<T>> {

    private BinaryMapFunction<T,T,Boolean> isChangeOp;

    ChangeBasedSegmentation(BinaryMapFunction<T,T,Boolean> isChangeOp) {
        this.isChangeOp = isChangeOp;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {

        final ObservationCollection<T> values = timeSeries.getValues(t1, t2, inclusive);

        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();
        MutableObservationCollection<T> currentSegment = new MutableObservationCollection<>();

        Observation<T> prev = null;
        for (Observation<T> current : values) {
            if (prev == null) {
                currentSegment.add(current);
            } else {
                if (isChangeOp.evaluate(prev.getValue(),current.getValue())) {
                    tsBuilder.add(currentSegment.first().getTimeTick(), Segment.fromSeries(currentSegment));
                    currentSegment = new MutableObservationCollection<>();
                }
                currentSegment.add(current);
            }
            prev = current;
        }
        tsBuilder.add(currentSegment.first().getTimeTick(), Segment.fromSeries(currentSegment));

        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new ChangeBasedSegmentation<>(isChangeOp);
    }
}
