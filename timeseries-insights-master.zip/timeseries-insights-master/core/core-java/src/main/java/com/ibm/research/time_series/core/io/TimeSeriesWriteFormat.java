package com.ibm.research.time_series.core.io;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Writer;
import java.util.Map;

/**
 * Format which denotes how to write to a datasource
 *
 * @param <T> {@link com.ibm.research.time_series.core.observation.Observation} value type
 */
public interface TimeSeriesWriteFormat<T> {

    /**
     * Given a collection of observations, a value encoder and options created from {@link TimeSeriesWriter},
     * write to an outside datasource
     *
     * @param observations the in-memory collection of observations
     * @param encodeValue a value encoder
     * @param options options to use when writing
     */
    void write(ObservationCollection<T> observations, UnaryMapFunction<T, String> encodeValue, Map<String, Object> options);
}
