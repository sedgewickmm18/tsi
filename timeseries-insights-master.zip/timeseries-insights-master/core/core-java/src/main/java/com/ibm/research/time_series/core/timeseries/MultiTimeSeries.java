/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.constants.Padding;
import com.ibm.research.time_series.core.constants.ResultingTimeStamp;
import com.ibm.research.time_series.core.core_transforms.general.GeneralReducers;
import com.ibm.research.time_series.core.core_transforms.general.GeneralTransformers;
import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.core_transforms.general.Stats;
import com.ibm.research.time_series.core.core_transforms.join.*;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.NaryMapFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.MultiTimeSeriesWriter;
import com.ibm.research.time_series.core.io.TimeSeriesWriter;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.cache.Cache;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.*;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.util.DefaultPrettyPrinter;
import com.ibm.research.time_series.core.io.TimeSeriesReader;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQueries;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * A collection of {@link TimeSeries} where each {@link TimeSeries} is identified by some key.
 *
 * <p>All transforms against a MultiTimeSeries will be run in parallel on a single jvm</p>
 *
 */
public class MultiTimeSeries<KEY,T> {

    /**
     * the map of identifiers to time series
     */
    private Map<KEY, TimeSeries<T>> tsMap;

    /**
     * create a {@link MultiTimeSeries} from a {@link MultiTimeSeriesReader}
     *
     * @param multiTimeSeriesReader multi time series reader
     * @param trs the given {@link TRS}
     */
    public MultiTimeSeries(MultiTimeSeriesReader<KEY, T> multiTimeSeriesReader, TRS trs) {
        tsMap = new HashMap<>();
        multiTimeSeriesReader.getReaderMap().forEach((key, value) -> tsMap.put(key, (trs == null) ? TimeSeries.reader(value) : TimeSeries.reader(value, trs)));
    }

    /**
     * create a {@link MultiTimeSeries} from a map of {@link TimeSeries}
     *
     * @param timeSeriesMap the {@link TimeSeries} map
     */
    public MultiTimeSeries(Map<KEY, TimeSeries<T>> timeSeriesMap) {
        tsMap = timeSeriesMap;
    }

    /**
     * Get the {@link TRS} of a given key {@link TimeSeries}
     *
     * @param key the {@link TimeSeries} key
     * @return the {@link TRS} associated with the given keys {@link TimeSeries}
     */
    public TRS getTRS(KEY key) {
        return tsMap.get(key).getTRS();
    }

    /**
     * create an {@link MultiTimeSeriesWriter} given a range
     *
     * @param t1 start range
     * @param t2 end range
     * @param inclusive inclusive flag
     * @return a new {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<KEY,T> write(long t1, long t2, boolean inclusive) {
        return new MultiTimeSeriesWriter<>(getValues(t1,t2,inclusive));
    }

    /**
     * create an {@link MultiTimeSeriesWriter} given a range
     *
     * @param t1 start range
     * @param t2 end range
     * @return a new {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<KEY,T> write(long t1, long t2) {
        return write(t1,t2,false);
    }

    /**
     * create an {@link MultiTimeSeriesWriter} over the whole {@link MultiTimeSeries}
     *
     * <p>Note: This will infer the bounds based on each {@link TimeSeriesReader} start and end time</p>
     *
     * @param inclusive inclusive flag
     * @return a new {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<KEY,T> write(boolean inclusive) {
        return new MultiTimeSeriesWriter<>(collect(inclusive));
    }

    /**
     * create an {@link MultiTimeSeriesWriter} over the whole {@link MultiTimeSeries}
     *
     * <p>Note: This will infer the bounds based on each {@link TimeSeriesReader} start and end time</p>
     *
     * @return a new {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<KEY,T> write() {
        return write(false);
    }

    /**
     * Add an annotation to each {@link Observation} of the current {@link MultiTimeSeries}
     * @param annotationKey the annotation key
     * @param annotation the annotation value
     * @return this {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY,T> addAnnotation(String annotationKey, Object annotation) {
        return addAnnotation(annotationKey, o -> Optional.of(annotation));
    }

    /**
     * Add an annotation to each {@link Observation} of the current {@link MultiTimeSeries} where the annotation value is the
     * result of applying a function over each {@link Observation}.
     *
     * @param annotationKey the annotation key
     * @param extractAnnotation the extract annotation function
     * @return this {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY,T> addAnnotation(String annotationKey, UnaryMapFunction<Observation<T>, Optional<Object>> extractAnnotation) {
        tsMap.forEach((k,v) -> v.addAnnotation(annotationKey, extractAnnotation));
        return this;
    }

    /**
     * Collect this entire {@link MultiTimeSeries} and produce a String
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     * <p>
     *     Note: This method will provide human readable Timestamp if a {@link TRS} exists for a {@link TimeSeries}
     * </p>
     * @return A String representation of this {@link MultiTimeSeries}
     */
    @Override
    public String toString() {
        return tsMap.entrySet().stream()
                .map(entry -> entry.getKey().toString() + " time series\n------------------------------\n" +
                        entry.getValue().toString())
                .collect(Collectors.joining("\n"));
    }

    /**
     * Describe this entire {@link MultiTimeSeries} by given back a {@link Stats} object
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return a map of {@link  Stats} for this {@link MultiTimeSeries}
     */
    public Map<KEY, Stats<T>> describe() {
        return reduce(GeneralReducers.describe());
    }

    /**
     * @return the internal map of {@link TimeSeries}
     */
    public Map<KEY, TimeSeries<T>> getTimeSeriesMap() {
        return tsMap;
    }

    public TimeSeries<T> getTimeSeries(KEY k) {
        return tsMap.get(k);
    }

    public Set<KEY> getKeys() {
        return tsMap.keySet();
    }

    /**
     * collect and materialize this entire {@link MultiTimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return a map of {@link ObservationCollection} containing all observations from each {@link TimeSeries}
     */
    public Map<KEY, ObservationCollection<T>> collect() {
        return collect(false);
    }

    /**
     * collect and materialize this entire {@link MultiTimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return a map of {@link ObservationCollection} containing all observations from each {@link TimeSeries}
     */
    public Map<KEY, ObservationCollection<T>> collect(boolean inclusive) {
        return tsMap.entrySet().stream().parallel()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().collect(inclusive)));
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range for each {@link TimeSeries} in this
     * {@link MultiTimeSeries}
     *
     * @param t1 time tick start
     * @param t2 time tick end
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return a map from {@link TimeSeries} key to immutable {@link ObservationCollection} containing all
     * {@link Observation} in the key's {@link TimeSeries}
     */
    public Map<KEY, ObservationCollection<T>> getValues(long t1, long t2, boolean inclusive) {
        return tsMap.entrySet().stream().parallel().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getValues(t1, t2, inclusive)));
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range for each {@link TimeSeries} in this
     * {@link MultiTimeSeries}
     *
     * @param t1 time tick start
     * @param t2 time tick end
     * @return a map from {@link TimeSeries} key to immutable {@link ObservationCollection} containing all
     * {@link Observation} in the key's {@link TimeSeries}
     */
    public Map<KEY, ObservationCollection<T>> getValues(long t1, long t2) {
        return getValues(t1, t2, false);
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range for each {@link TimeSeries} in this
     * {@link MultiTimeSeries}
     *
     * @param start start time
     * @param end end time
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return a map from {@link TimeSeries} key to immutable {@link ObservationCollection} containing all
     * {@link Observation} in the key's {@link TimeSeries}
     */
    public Map<KEY, ObservationCollection<T>> getValues(ZonedDateTime start, ZonedDateTime end, boolean inclusive) {
        return tsMap.entrySet().stream().parallel().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getValues(start, end, inclusive)));
    }

    /**
     * Print this entire {@link MultiTimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     * <p>
     *     Note: This method will provide human readable Timestamp if a {@link TRS} exists for a given {@link TimeSeries}
     * </p>
     */
    public void print() {
        tsMap.entrySet().forEach(ts -> {
            System.out.println("Printing result for TimeSeries with key: " + ts.getKey());
            ts.getValue().print();
        });
    }

    /**
     * Print this entire {@link MultiTimeSeries} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     */
    public void print(long t1, long t2, boolean inclusive) {
        tsMap.entrySet().forEach(si -> {
            System.out.println("Printing result for TimeSeries with key: " + si.getKey());
            si.getValue().print(t1, t2, inclusive);
        });
    }

    /**
     * Print this entire {@link MultiTimeSeries} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     */
    public void print(long t1, long t2) {
        print(t1, t2, false);
    }

    /**
     * Print this entire {@link MultiTimeSeries} between a given time range
     *
     * @param start starting time
     * @param end ending time
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     */
    public void print(ZonedDateTime start, ZonedDateTime end, boolean inclusive) {
        tsMap.entrySet().forEach(si -> {
            System.out.println("Printing result for TimeSeries with key: " + si.getKey());
            si.getValue().print(start, end, inclusive);
        });
    }

    /**
     * Print this entire {@link MultiTimeSeries} between a given time range
     *
     * @param start starting time
     * @param end ending time
     */
    public void print(ZonedDateTime start, ZonedDateTime end) {
        print(start, end, false);
    }

    /**
     * Create a new {@link MultiTimeSeries} that is the product of performing a {@link UnaryTransform} over each
     * {@link TimeSeries} in this {@link MultiTimeSeries}
     *
     * @param unaryTransform the {@link UnaryTransform}
     * @param <T2> output {@link Observation} value type
     * @return a newly transformed {@link MultiTimeSeries}
     */
    public <T2> MultiTimeSeries<KEY, T2> transform(UnaryTransform<T, T2> unaryTransform) {
        Map<KEY, TimeSeries<T2>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(si -> {
            result.put(si.getKey(), si.getValue().transform(unaryTransform));
        });
        return new MultiTimeSeries<>(result);
    }

    /**
     * Create a new {@link MultiTimeSeries} that is the product of performing a {@link BinaryTransform} over each
     * {@link TimeSeries} in this {@link MultiTimeSeries}
     *
     * @param otherTimeSeries the other {@link TimeSeries}
     * @param binaryTransform the {@link BinaryTransform}
     * @param <T2> other time series observation value type
     * @param <T3> output {@link Observation} value type
     * @return a newly transformed {@link MultiTimeSeries}
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> transform(
            TimeSeries<T2> otherTimeSeries,
            BinaryTransform<T, T2, T3> binaryTransform) {
        Map<KEY, TimeSeries<T3>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(si -> {
            result.put(si.getKey(), si.getValue().transform(otherTimeSeries, binaryTransform));
        });
        return new MultiTimeSeries<>(result);
    }

    /**
     * Create a new {@link MultiTimeSeries} that is the product of performing a {@link NaryTransform} over each
     * {@link TimeSeries} and another list of {@link TimeSeries}
     *
     * @param timeSeriesList the other list of {@link TimeSeries}
     * @param naryTransform the {@link NaryTransform}
     * @param <T2> output {@link Observation} value type
     * @return a newly transformed {@link MultiTimeSeries}
     */
    public <T2> MultiTimeSeries<KEY, T2> transform(
            List<TimeSeries<T>> timeSeriesList,
            NaryTransform<T, T2> naryTransform) {
        Map<KEY, TimeSeries<T2>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(si -> {
            result.put(si.getKey(), si.getValue().transform(timeSeriesList, naryTransform));
        });
        return new MultiTimeSeries<>(result);
    }

    /**
     * Create a new {@link MultiTimeSeries} where each {@link TimeSeries} has its time ticks mapped based on a start
     * time and a granularity. In the scope of this method, start time refers to the zone-date-time in which to start
     * your {@link TimeSeries} data when calling getValues and granularity refers to the lowest granularity of time
     * tick.
     *
     * <p>Time ticks will be mapped as follows - (currentTimeTick - startTime) / granularity</p>
     *
     * @param trs the given {@link TRS}
     * @return a new {@link MultiTimeSeries} where each {@link TimeSeries} has its timestamps mapped based on the given
     * {@link TRS}
     */
    public MultiTimeSeries<KEY, T> withTRS(TRS trs) {
        return new MultiTimeSeries<>(
                tsMap.entrySet().stream().parallel()
                        .map(x -> new AbstractMap.SimpleEntry<>(x.getKey(), x.getValue().withTRS(trs)))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
        );
    }

    /**
     * Create a new {@link MultiTimeSeries} which is the product of performing a pair-wise transform against all
     * combination of keys
     *
     * <p>Note: Keys will be based on a {@link Pair} of keys for which the transform took place</p>
     *
     * @param binaryTransform a {@link BinaryTransform}
     * @param <T2> output {@link Observation} value type
     * @return a newly transformed {@link MultiTimeSeries}
     */
    public <T2> MultiTimeSeries<Pair<KEY, KEY>, T2> pairWiseTransform(BinaryTransform<T, T, T2> binaryTransform) {
        Map<Pair<KEY, KEY>, TimeSeries<T2>> result = new HashMap<>();
        tsMap.keySet().forEach(key -> {
            TimeSeries<T> i = tsMap.get(key);

            tsMap.entrySet().parallelStream().forEach(tsEntry -> {
                Pair<KEY, KEY> keyPair = new Pair<>(key, tsEntry.getKey());
                TimeSeries<T> j = tsEntry.getValue();
                result.put(keyPair, i.transform(j, binaryTransform));
            });
        });
        return new MultiTimeSeries<>(result);
    }

    /**
     * fill null values in the {@link TimeSeries}
     *
     *
     * @param interpolator the interpolator method to be used when a value is null
     * @param nullValue denotes a null value, for instance if nullValue = Double.NaN, Double.NaN would be filled
     * @return a new {@link MultiTimeSeries} with null values filled
     */
    public MultiTimeSeries<KEY,T> fillna(Interpolator<T> interpolator, T nullValue) {
        return transform(GeneralTransformers.fillNA(interpolator,nullValue));
    }

    /**
     * fill null values in the {@link MultiTimeSeries} where nullValue is default to null
     *
     * @param interpolator the interpolator method to be used when a value is null
     * @return a new {@link MultiTimeSeries} with null values filled
     */
    public MultiTimeSeries<KEY,T> fillna(Interpolator<T> interpolator) {
        return fillna(interpolator, null);
    }

    /**
     * fill null values in the {@link MultiTimeSeries} where nullValue is default to null and a generic value fill method is
     * always used
     *
     * @param value value to be filled when a value is null
     * @return a new {@link MultiTimeSeries} with null values filled
     */
    public MultiTimeSeries<KEY,T> fillna(T value) {
        return transform(GeneralTransformers.fillNA(GenericInterpolators.fill(value)));
    }

    /**
     * resample the {@link MultiTimeSeries} to a given periodicity
     *
     * Refer to {@link TimeSeries#resample(long, Interpolator)} for more information
     *
     * @param periodicity the time tick periodicity to resample at
     * @param interpolator the interpolation method to be used when a value does not exist for a given time tick
     * @return a new periodic {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY, T> resample(
            long periodicity,
            Interpolator<T> interpolator) {
        return transform(
                GeneralTransformers.interpolate(periodicity, interpolator, true)
        );
    }

    /**
     * resample the {@link MultiTimeSeries} to a given periodicity
     *
     * <p>Refer to {@link TimeSeries#resample(long, Object)} for more information</p>
     *
     * @param periodicity the time tick periodicity to resample at
     * @param fillValue the value to fill when a value does not exist at a given time tick
     * @return a new periodic {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY, T> resample(
            long periodicity,
            T fillValue) {
        return resample(periodicity, GenericInterpolators.fill(fillValue));
    }

    /**
     * filter the {@link MultiTimeSeries} by each {@link Observation}'s value
     *
     * <p>Refer to {@link TimeSeries#filter(FilterFunction)} for more information</p>
     *
     * @param filterFunction the filter function to be used
     * @return a filtered on value MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> filter(FilterFunction<T> filterFunction) {
        return transform(MapTransformers.filter(filterFunction));
    }

    /**
     * filter the {@link ObservationCollection} in a {@link MultiTimeSeries} that match a filter function on the key
     *
     * @param filterFunction the filter function to be used
     * @return a new {@link MultiTimeSeries} with keys that match the filter function
     */
    public MultiTimeSeries<KEY, T> filterSeriesKey(FilterFunction<KEY> filterFunction) {
        return new MultiTimeSeries<>(
                tsMap.entrySet().stream().parallel()
                        .filter(x -> filterFunction.evaluate(x.getKey()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
        );
    }

    /**
     * map each series key to another key
     *
     * @param keyOp key mapping function
     * @param <KEY2> the other key type
     * @return a new {@link MultiTimeSeries} with its keys remapped
     */
    public <KEY2> MultiTimeSeries<KEY2, T> mapSeriesKey(UnaryMapFunction<KEY, KEY2> keyOp) {
        return new MultiTimeSeries<>(
                tsMap.entrySet().stream().parallel()
                        .map(x -> new Pair<>(keyOp.evaluate(x.getKey()),x.getValue()))
                        .collect(Collectors.toMap(x -> x.left(), x -> x.right()))
        );
    }

    /**
     * filter the {@link ObservationCollection} in a {@link MultiTimeSeries} that match a filter function on the
     * {@link TimeSeries}
     *
     * @param filterFunction the filter function to be used
     * @return a new {@link MultiTimeSeries} with {@link TimeSeries} that match the filter function
     */
    public MultiTimeSeries<KEY, T> filterSeries(FilterFunction<TimeSeries<T>> filterFunction) {
        return new MultiTimeSeries<>(
                tsMap.entrySet().stream().parallel()
                        .filter(x -> filterFunction.evaluate(x.getValue()))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
        );
    }

    /**
     * create a {@link SegmentMultiTimeSeries} from a segmentation transform ({@link UnaryTransform} that is of type
     * {@code T -> {@link Segment}<T>})
     *
     * @param segmenter unary transform that results in time series of segments
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> toSegments(UnaryTransform<T, Segment<T>> segmenter) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().toSegments(segmenter));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#segment(long, long, boolean)} for more details</p>
     *
     * @param window window size
     * @param step step size
     * @param enforceSize enforce that size is always of size window
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segment(long window, long step, boolean enforceSize) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segment(window, step, enforceSize));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#segment(long, long)} for more details</p>
     *
     * @param window window size
     * @param step step size
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segment(long window, long step) {
        return segment(window, step, true);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#segment(long)} for more details</p>
     *
     * @param window window size
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segment(long window) {
        return segment(window, window, true);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on a sliding time window over the {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#segmentByTime(long, long, Padding, ResultingTimeStamp)} for more details</p>
     *
     * @param window window size in time ticks
     * @param step step size in time ticks
     * @param padding padding type {@link Padding}
     * @param resultingTimeStamp resulting timestamp {@link ResultingTimeStamp}
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segmentByTime(
            long window,
            long step,
            Padding padding,
            ResultingTimeStamp resultingTimeStamp) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segmentByTime(window, step, padding, resultingTimeStamp));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on a sliding time window over the {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#segmentByTime(long, long)} for more details</p>
     *
     * @param window window size in time ticks
     * @param step step size in time ticks
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segmentByTime(
            long window,
            long step) {
        return segmentByTime(window, step, Padding.RIGHT, ResultingTimeStamp.START_OF_WINDOW);
    }

    /**
     * segment each {@link TimeSeries} in the {@link MultiTimeSeries} based on building segments around anchor points.
     * An anchor point is defined as any value that satisfies the isAnchorF filter function. When an anchor point is
     * determined the {@link Segment} is built based on leftDelta time ticks to the left of the point and rightDelta
     * time ticks to the right of the point.
     *
     * <p>view {@link TimeSeries#segmentByAnchor(FilterFunction, long, long)} for more details</p>
     *
     * @param isAnchorF anchor function
     * @param leftDelta left delta time ticks to the left of the anchor point
     * @param rightDelta right delta time ticks to the right of the anchor point
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segmentByAnchor(
            FilterFunction<T> isAnchorF,
            long leftDelta,
            long rightDelta) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segmentByAnchor(isAnchorF, leftDelta, rightDelta));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in this {@link MultiTimeSeries} based on a group by operation. A group by
     * operation works by taking each observation and producing a single key. Each segment will be generated for each
     * unique key
     *
     * @param groupByOp group by operation
     * @param <K> the key-by type
     * @return a new {@link SegmentMultiTimeSeries}
     */
    public <K> SegmentMultiTimeSeries<KEY, T> segmentBy(UnaryMapFunction<Observation<T>, K> groupByOp) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segmentBy(groupByOp));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in this {@link MultiTimeSeries} based on a change-point. A change-point can be
     * defined as any change in 2 values that results in a true statement.
     *
     * @param isChangeOp a function given a prev/next value to determine if a change exists
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segmentByChangePoint(BinaryMapFunction<T,T,Boolean> isChangeOp) {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segmentByChangePoint(isChangeOp));
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * segment each {@link TimeSeries} in this {@link MultiTimeSeries} on an equality based change-point
     *
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentMultiTimeSeries<KEY, T> segmentByChangePoint() {
        Map<KEY, SegmentTimeSeries<T>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(ts -> {
            result.put(ts.getKey(), ts.getValue().segmentByChangePoint());
        });
        return new SegmentMultiTimeSeries<>(result);
    }

    /**
     * May want to rename!!!
     * flat map each series in this MultiTimeSeries where each observation in this TimeSeries is map to 0 to N new
     * Observations
     *
     * <p>view {@link TimeSeries#flatMapObservation(UnaryMapFunction)} for more details</p>
     *
     * @param f flat mapping function
     * @param <T2> output {@link Observation} value type
     * @return a new flat mapped MultiTimeSeries
     */
    public <T2> MultiTimeSeries<KEY, T2> flatMapObservation(
            UnaryMapFunction<Observation<T>, Iterable<Observation<T2>>> f) {
        return transform(MapTransformers.flatMapObservation(f));
    }

    /**
     * perform a unary mapping function over each observation in each series in this MultiTimeSeries.
     *
     * <p>view {@link TimeSeries#mapObservation(UnaryMapFunction)} for more details</p>
     *
     * @param f unary observation mapping function
     * @param <T2> output type of observation values in MultiTimeSeries
     * @return a newly mapped MultiTimeSeries
     */
    public <T2> MultiTimeSeries<KEY, T2> mapObservation(
            UnaryMapFunction<Observation<T>, Observation<T2>> f) {
        return transform(MapTransformers.unaryMapObservation(f));
    }

    /**
     * Perform a unary mapping function over each value in each series in this {@link MultiTimeSeries}
     *
     * @param f unary mapping function
     * @param <T2> output type of observation values in {@link MultiTimeSeries}
     * @return a newly mapped MultiTimeSeries
     */
    public <T2> MultiTimeSeries<KEY, T2> map(UnaryMapFunction<T, T2> f) {
        return transform(MapTransformers.unaryMap(f));
    }

    /**
     * Create a new {@link MultiTimeSeries} which is the product of mapping each key's series to a new series
     *
     * @param f unary mapping function from a pair of key and series to series
     * @param <T2> output type of observation values in {@link MultiTimeSeries}
     * @return a newly mapped {@link MultiTimeSeries}
     */
    public <T2> MultiTimeSeries<KEY, T2> mapSeries(UnaryMapFunction<ObservationCollection<T>, ObservationCollection<T2>> f) {
        UnaryTransform<T, T2> transform = new UnaryTransform<T, T2>() {
            @Override
            public ObservationCollection<T2> evaluate(long t1, long t2, boolean inclusive) {
                return f.evaluate(timeSeries.getValues(t1, t2, inclusive));
            }
        };
        return transform(transform);
    }

    /**
     * Create a new {@link MultiTimeSeries} which is the product of mapping each key's series (with key provided) to a
     * new series
     *
     * @param f unary mapping function from a pair of key and series to series
     * @param <T2> output type of observation values in {@link MultiTimeSeries}
     * @return a newly mapped {@link MultiTimeSeries}
     */
    public <T2> MultiTimeSeries<KEY, T2> mapSeriesWithKey(UnaryMapFunction<Pair<KEY, ObservationCollection<T>>, ObservationCollection<T2>> f) {
        return new MultiTimeSeries<>(
                tsMap.entrySet().parallelStream().map(entry -> {
                    final KEY key = entry.getKey();
                    TimeSeries<T> ts = entry.getValue();
                    UnaryTransform<T, T2> transform = new UnaryTransform<T, T2>() {
                        @Override
                        public ObservationCollection<T2> evaluate(long t1, long t2, boolean inclusive) {
                            return f.evaluate(new Pair<>(key, timeSeries.getValues(t1, t2, inclusive)));
                        }
                    };
                    return new Pair<>(
                            key,
                            ts.transform(transform)
                    );
                }).collect(Collectors.toMap(x -> x.left, x -> x.right))
        );
    }

    /**
     * @return current number of time series in this MultiTimeSeries
     */
    public int size() {
        return tsMap.size();
    }

    /**
     * Perform a binary transform over this MultiTimeSeries and another MultiTimeSeries
     * joined on series key.
     *
     * @param multiTimeSeries the other MultiTimeSeries
     * @param binaryTransform binary transform to perform over each series
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a newly transformed {@link MultiTimeSeries}
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> transform(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryTransform<T, T2, T3> binaryTransform) {
        Map<KEY, TimeSeries<T3>> result = Collections.synchronizedMap(new HashMap<>());

        this.tsMap.entrySet().stream().parallel().forEach(entry -> {
            TimeSeries<T> thisTs = entry.getValue();
            TimeSeries<T2> otherTs = multiTimeSeries.tsMap.get(entry.getKey());
            result.put(entry.getKey(), thisTs.transform(otherTs, binaryTransform));
        });
        return new MultiTimeSeries<>(result);
    }

    /**
     * align 2 {@link MultiTimeSeries} based on an inner temporal join strategy
     *
     * <p>view {@link TimeSeries#innerAlign(TimeSeries)} for more details</p>
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @return a {@link MTSPair} of aligned {@link MultiTimeSeries}
     */
    public <T2> MTSPair<KEY, T, T2> innerAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {

        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.innerJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally inner joining this {@link MultiTimeSeries} with another
     * {@link MultiTimeSeries}
     *
     * <p>view {@link TimeSeries#innerJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries the right {@link MultiTimeSeries}
     * @param f binary mapper to join values
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of an inner join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> innerJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.innerJoin(f)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally inner joining this {@link MultiTimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>view {@link TimeSeries#innerJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param f binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of an inner join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> innerJoin(TimeSeries<T2> timeSeries, BinaryMapFunction<T, T2, T3> f) {
        return transform(timeSeries, JoinTransformers.innerJoin(f));
    }

    /**
     * align 2 {@link MultiTimeSeries} based on an full temporal join strategy
     *
     * <p>view {@link TimeSeries#fullAlign(TimeSeries)} for more details</p>
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @return a {@link MTSPair} of aligned {@link MultiTimeSeries}
     */
    public <T2> MTSPair<KEY, T, T2> fullAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.fullJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * align 2 {@link MultiTimeSeries} based on an full temporal join strategy and interpolate missing values
     *
     * <p>view {@link TimeSeries#fullAlign(TimeSeries,Interpolator,Interpolator)} for more details</p>
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param leftInterpolator left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @return a {@link MTSPair} of aligned {@link MultiTimeSeries}
     */
    public <T2> MTSPair<KEY, T, T2> fullAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            Interpolator<T> leftInterpolator,
            Interpolator<T2> rightInterpolator) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.fullJoin(Pair::new, leftInterpolator, rightInterpolator)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally full joining this {@link MultiTimeSeries} with another
     * {@link MultiTimeSeries}
     *
     * <p>view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries the right {@link MultiTimeSeries}
     * @param f binary mapper to join values
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a full join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> fullJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.fullJoin(f)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally full joining this {@link MultiTimeSeries} with another
     * {@link MultiTimeSeries} and interpolate missing values
     *
     * <p>
     *     view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction, Interpolator, Interpolator)} for more details
     * </p>
     *
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries the right {@link MultiTimeSeries}
     * @param f binary mapper to join values
     * @param leftInterpolator left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a full join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> fullJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> leftInterpolator,
            Interpolator<T2> rightInterpolator) {
        return transform(
                multiTimeSeries,
                JoinTransformers.fullJoin(f, leftInterpolator, rightInterpolator)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally full joining this {@link MultiTimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>
     *     view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction, Interpolator, Interpolator)} for more details
     * </p>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param f binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a full join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> fullJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                timeSeries,
                JoinTransformers.fullJoin(f)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally full joining this {@link MultiTimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>
     *     view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction, Interpolator, Interpolator)} for more details
     * </p>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param f binary mapper to join values
     * @param leftInterpolator left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param rightInterpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a full join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> fullJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> leftInterpolator,
            Interpolator<T2> rightInterpolator) {
        return transform(
                timeSeries,
                JoinTransformers.fullJoin(f, leftInterpolator, rightInterpolator)
        );
    }


    ///////////////

    /**
     * align 2 {@link MultiTimeSeries} based on an left temporal join strategy
     *
     * <p>view {@link TimeSeries#leftAlign(TimeSeries)} for more details</p>
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @return a {@link MTSPair} of aligned {@link MultiTimeSeries}
     */
    public <T2> MTSPair<KEY, T, T2> leftAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.leftJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * align 2 {@link MultiTimeSeries} based on an left temporal join strategy and interpolate missing values
     *
     * <p>view {@link TimeSeries#leftAlign(TimeSeries,Interpolator)} for more details</p>
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param interpolator right time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @return a {@link MTSPair} of aligned {@link MultiTimeSeries}
     */
    public <T2> MTSPair<KEY, T, T2> leftAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            Interpolator<T2> interpolator) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.leftJoin(Pair::new, interpolator)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally left joining this {@link MultiTimeSeries} with another
     * {@link MultiTimeSeries}
     *
     * <p>view {@link TimeSeries#leftJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * <p>Note: This method will join {@link TimeSeries} on like keys</p>
     *
     * @param multiTimeSeries the right {@link MultiTimeSeries}
     * @param f binary mapper to join values
     * @param <T2> other {@link MultiTimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a left join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> leftJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.leftJoin(f)
        );
    }

    /**
     * create a new {@link MultiTimeSeries} by temporally left joining this {@link MultiTimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>
     *     view {@link TimeSeries#leftJoin(TimeSeries, BinaryMapFunction, Interpolator)} for more details
     * </p>
     *
     * @param multiTimeSeries the right {@link MultiTimeSeries}
     * @param f binary mapper to join values
     * @param interpolator right time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries} which is the product of a left join
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> leftJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T2> interpolator) {
        return transform(
                multiTimeSeries,
                JoinTransformers.leftJoin(f, interpolator)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> leftJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                timeSeries,
                JoinTransformers.leftJoin(f)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> leftJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T2> interpolator) {
        return transform(
                timeSeries,
                JoinTransformers.leftJoin(f, interpolator)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a right temporal join strategy
     *
     * <p>view {@link TimeSeries#rightAlign(TimeSeries)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> rightAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.rightJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a right temporal join strategy and optionally resample
     * missing values
     *
     * <p>view {@link TimeSeries#rightAlign(TimeSeries, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param interpolator    left time series interpolator
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> rightAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            Interpolator<T> interpolator) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.rightJoin(Pair::new, interpolator)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * perform a temporal right join and optionally resample missing values
     *
     * <p>view {@link TimeSeries#rightJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> rightJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.rightJoin(f)
        );
    }

    /**
     * perform a temporal right join and optionally resample missing values
     *
     * <p>view {@link TimeSeries#rightJoin(TimeSeries, BinaryMapFunction, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param interpolator    left time series interpolator
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> rightJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> interpolator) {
        return transform(
                multiTimeSeries,
                JoinTransformers.rightJoin(f, interpolator)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> rightJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                timeSeries,
                JoinTransformers.rightJoin(f)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> rightJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> interpolator) {
        return transform(
                timeSeries,
                JoinTransformers.rightJoin(f, interpolator)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a left outer temporal join strategy
     *
     * <p>view {@link TimeSeries#leftOuterAlign(TimeSeries)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> leftOuterAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.leftOuterJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a left outer temporal join strategy and optionally resample
     * missing values
     *
     * <p>view {@link TimeSeries#leftOuterAlign(TimeSeries, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param interpolator    right time series interpolator
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> leftOuterAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            Interpolator<T2> interpolator) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.leftOuterJoin(Pair::new, interpolator)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * perform a temporal left outer join
     *
     * <p>view {@link TimeSeries#leftOuterJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> leftOuterJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.leftOuterJoin(f)
        );
    }

    /**
     * perform a temporal left outer join and optionally resample missing values
     *
     * <p>view {@link TimeSeries#leftOuterJoin(TimeSeries, BinaryMapFunction, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param interpolator    right time series interpolator
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> leftOuterJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T2> interpolator) {
        return transform(
                multiTimeSeries,
                JoinTransformers.leftOuterJoin(f, interpolator)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> leftOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                timeSeries,
                JoinTransformers.leftOuterJoin(f)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> leftOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T2> interpolator) {
        return transform(
                timeSeries,
                JoinTransformers.leftOuterJoin(f, interpolator)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a right outer temporal join strategy
     *
     * <p>view {@link TimeSeries#rightOuterAlign(TimeSeries)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> rightOuterAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.rightOuterJoin(Pair::new)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * align 2 MultiTimeSeries based on a right outer temporal join strategy and optionally resample
     * missing values
     *
     * <p>view {@link TimeSeries#rightOuterAlign(TimeSeries, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param interpolator    left time series interpolator
     * @param <T2>            other time series observation type
     * @return a MultiTimeSeries pair of aligned MultiTimeSeries
     */
    public <T2> MTSPair<KEY, T, T2> rightOuterAlign(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            Interpolator<T> interpolator) {
        MultiTimeSeries<KEY, Pair<T, T2>> transformed = transform(
                multiTimeSeries,
                JoinTransformers.rightOuterJoin(Pair::new, interpolator)
        );

        return new MTSPair<>(
                transformed.map(x -> x.left),
                transformed.map(x -> x.right)
        );
    }

    /**
     * perform a temporal right outer join
     *
     * <p>view {@link TimeSeries#rightOuterJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> rightOuterJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                multiTimeSeries,
                JoinTransformers.rightOuterJoin(f)
        );
    }

    /**
     * perform a temporal right outer join and optionally resample missing values
     *
     * <p>view {@link TimeSeries#rightOuterJoin(TimeSeries, BinaryMapFunction, Interpolator)} for more details</p>
     *
     * @param multiTimeSeries other MultiTimeSeries
     * @param f               combine function
     * @param interpolator    left time series interpolator
     * @param <T2>            other time series observation type
     * @param <T3>            output time series observation type
     * @return a new MultiTimeSeries
     */
    public <T2, T3> MultiTimeSeries<KEY, T3> rightOuterJoin(
            MultiTimeSeries<KEY, T2> multiTimeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> interpolator) {
        return transform(
                multiTimeSeries,
                JoinTransformers.rightOuterJoin(f, interpolator)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> rightOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f) {
        return transform(
                timeSeries,
                JoinTransformers.rightOuterJoin(f)
        );
    }

    public <T2, T3> MultiTimeSeries<KEY, T3> rightOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T, T2, T3> f,
            Interpolator<T> interpolator) {
        return transform(
                timeSeries,
                JoinTransformers.rightOuterJoin(f, interpolator)
        );
    }

    /**
     * Align all {@link TimeSeries} in this {@link MultiTimeSeries} with the time-series denoted by the given key
     *
     * @param key key that denotes time-series to align with
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY, T> align(KEY key) {
        return align(key, GenericInterpolators.nullify());
    }

    /**
     * Align all {@link TimeSeries} in this {@link MultiTimeSeries} with the time-series denoted by the given key
     *
     * @param key key that denotes time-series to align with
     * @param interpolator time series interpolator
     * @return a new {@link MultiTimeSeries}
     */
    public MultiTimeSeries<KEY, T> align(KEY key, Interpolator<T> interpolator) {
        final TimeSeries<T> leftTs = tsMap.get(key);

        return new MultiTimeSeries<>(
                this.tsMap.entrySet().parallelStream().map(entry -> {
                    if (key.equals(entry.getKey())) {
                        return entry;
                    } else {
                        return new AbstractMap.SimpleEntry<>(entry.getKey(), leftTs.leftAlign(entry.getValue(), interpolator).right);
                    }
                }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
        );
    }

    /**
     * aggregate all series in this MultiTimeSeries to produce a single value
     *
     * @param zero   zero value for aggregation
     * @param seqOp  operation to perform against each time series to reduce a time series to a single value
     * @param combOp operation to perform against each reduced time series values to combine those values
     * @param <T2>   output type
     * @return a single output value representing the aggregate of all TimeSeries in the MultiTimeSeries
     */
    public <T2> T2 aggregate(T2 zero, BinaryMapFunction<T2, TimeSeries<T>, T2> seqOp, BinaryMapFunction<T2, T2, T2> combOp) {
        final T2 combined = zero;
        //combine our time series
        List<T2> combinedValues = new ArrayList<>();
        for (TimeSeries<T> ts : tsMap.values()) {
            combinedValues.add(seqOp.evaluate(combined, ts));
        }
        if (combinedValues.size() == 0) {
            return zero;
        } else {
            T2 result = combinedValues.get(0);
            for (int i = 1; i < combinedValues.size(); i++) {
                result = combOp.evaluate(result, combinedValues.get(i));
            }
            return result;
        }
    }

    public <T2> TimeSeries<T2> aggregateSeriesWithKey(UnaryMapFunction<List<Pair<KEY, T>>, T2> expression) {
        if (tsMap.isEmpty()) return Observations.<T2>empty().toTimeSeriesStream();
        final List<TimeSeries<Pair<KEY, T>>> collected = this
                .mapSeriesWithKey(s ->
                        s.right.toTimeSeriesStream().map(x -> new Pair<>(s.left, x)).collect()
                ).tsMap.entrySet().stream()
                .map(x -> x.getValue())
                .collect(Collectors.toList());
        return collected.get(0).transform(collected.subList(1, collected.size()), MapTransformers.naryMap(expression::evaluate));
    }

    /**
     * aggregate all TimeSeries in the MultiTimeSeries using an {@link NaryTransform} to produce a single TimeSeries
     *
     * @param transform n-ary transfor to perform against all TimeSeries
     * @param <T2>      output TimeSeries observation type
     * @return a new TimeSeries
     */
    public <T2> TimeSeries<T2> aggregateSeries(NaryTransform<T, T2> transform) {
        if (tsMap.isEmpty()) return Observations.<T2>empty().toTimeSeriesStream();
        List<TimeSeries<T>> collected = tsMap.entrySet().stream().parallel()
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());
        return collected.get(0).transform(collected.subList(1, collected.size()), transform);
    }

    /**
     * aggregate all TimeSeries in the MultiTimeSeries using an {@link NaryMapFunction} to produce a single TimeSeries
     *
     * @param expression n-ary map function to perform against all TimeSeries
     * @param <T2>       output TimeSeries observation type
     * @return a new TimeSeries
     */
    public <T2> TimeSeries<T2> aggregateSeries(NaryMapFunction<T, T2> expression) {
        return aggregateSeries(MapTransformers.naryMap(expression));
    }

    /**
     * Reduces each series in this MultiTimeSeries to a single value using a {@link UnaryReducer}
     *
     * @param reducer unary reducer
     * @param <T2>    output value type
     * @return a map of keys to reduced values
     */
    public <T2> Map<KEY, T2> reduce(UnaryReducer<T, T2> reducer) {
        return tsMap.entrySet().stream().parallel()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> reducer.reduceSegment(Segment.fromSeries(e.getValue().collect()))
                ));
    }

    public <T2> Map<KEY, T2> reduceRange(UnaryReducer<T, T2> reducer, long start, long end, boolean inclusive) {
        return tsMap.entrySet().stream().parallel()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> reducer.reduceSegment(Segment.fromSeries(e.getValue().getValues(start,end,inclusive)))
                ));
    }

    public <T2> Map<KEY, T2> reduceRange(UnaryReducer<T, T2> reducer, long start, long end) {
        return reduceRange(reducer,start,end,false);
    }

    /**
     * Reduces each series in this MultiTimeSeries to a single value
     *
     * @param reduceF function to reduce a series to a value
     * @param <T2>    output value type
     * @return a map of keys to reduced values
     */
    public <T2> Map<KEY, T2> reduce(UnaryMapFunction<ObservationCollection<T>, T2> reduceF) {
        return tsMap.entrySet().stream().parallel()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> reduceF.evaluate(e.getValue().collect())
                ));
    }

    public <T2> Map<KEY, T2> reduceRange(UnaryMapFunction<ObservationCollection<T>, T2> reduceF, long t1, long t2, boolean inclusive) {
        return tsMap.entrySet().stream().parallel()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> reduceF.evaluate(e.getValue().getValues(t1,t2,inclusive))
                ));
    }

    public <T2> Map<KEY, T2> reduceRange(UnaryMapFunction<ObservationCollection<T>, T2> reduceF, long t1, long t2) {
        return reduceRange(reduceF,t1,t2,false);
    }

    /**
     * Cache each {@link TimeSeries} in this {@link MultiTimeSeries} with max cache size
     *
     * @return the current MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> cache() {
        return cache(Integer.MAX_VALUE);
    }

    /**
     * Cache each {@link TimeSeries} in this {@link MultiTimeSeries} with given cache size
     *
     * @param maxSize max number of {@link Observation} in cache
     * @return the current MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> cache(int maxSize) {
        tsMap.entrySet().stream().parallel().forEach(si -> si.getValue().cache(maxSize));
        return this;
    }

    /**
     * Cache each {@link TimeSeries} in this {@link MultiTimeSeries} with a new user defined {@link Cache} for each key
     *
     * <p>Note: Each TimeSeries will have a cache of maximum integer size</p>
     *
     * @param cacheMap map of user defined caches
     * @return the current MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> userDefinedCache(Map<KEY, Cache<T>> cacheMap) {
        return userDefinedCache(cacheMap, Integer.MAX_VALUE);
    }

    /**
     * Cache each {@link TimeSeries} in this {@link MultiTimeSeries} with a new user defined {@link Cache} with a given
     * maximum cache size for each key
     *
     * @param cacheMap map of user defined caches
     * @param maxSize  maximum cache size
     * @return the current MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> userDefinedCache(Map<KEY, Cache<T>> cacheMap, int maxSize) {
        tsMap.entrySet().stream().parallel().forEach(si -> si.getValue().userDefinedCache(cacheMap.get(si.getKey()), maxSize));
        return this;
    }

    /**
     * uncache each {@link TimeSeries} in this {@link MultiTimeSeries}
     *
     * @return the current MultiTimeSeries
     */
    public MultiTimeSeries<KEY, T> uncache() {
        tsMap.entrySet().stream().parallel().forEach(si -> si.getValue().uncache());
        return this;
    }

    /**
     * @return a map of cache sizes keyed by TimeSeries key
     */
    public Map<KEY, Integer> getMaximumCacheSizes() {
        Map<KEY, Integer> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(si -> result.put(si.getKey(), si.getValue().getMaximumCacheSize()));
        return result;
    }

    /**
     * @return a map of caches keyed by TimeSeries key
     */
    public Map<KEY, Iterator<Observation<T>>> getCaches() {
        Map<KEY, Iterator<Observation<T>>> result = Collections.synchronizedMap(new HashMap<>());
        tsMap.entrySet().stream().parallel().forEach(si -> result.put(si.getKey(), si.getValue().getCache()));
        return result;
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTimeTick the time tick where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model, long trainingStartTimeTick) {
        return forecast(numForecasts, model, trainingStartTimeTick, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTimeTick the time tick where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model, long trainingStartTimeTick, double confidence) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(bos);
            out.writeObject(model);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {

            }
        }
        final byte[] bytesObject = bos.toByteArray();
        return tsMap.entrySet().parallelStream().map(entry -> {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytesObject);
            ObjectInput in = null;
            ObservationForecastingModel<T> m = null;
            try {
                in = new ObjectInputStream(bis);
                m = (ObservationForecastingModel<T>) in.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException ex) {
                    // ignore close exception
                }
            }
            return new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, m, trainingStartTimeTick, confidence));
        }).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model, ZonedDateTime trainingStartTime) {
        return forecast(numForecasts, model, trainingStartTime, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model, ZonedDateTime trainingStartTime, double confidence) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(bos);
            out.writeObject(model);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {

            }
        }
        final byte[] bytesObject = bos.toByteArray();
        return tsMap.entrySet().parallelStream().map(entry -> {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytesObject);
            ObjectInput in = null;
            ObservationForecastingModel<T> m = null;
            try {
                in = new ObjectInputStream(bis);
                m = (ObservationForecastingModel<T>) in.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException ex) {
                    // ignore close exception
                }
            }
            return new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, m, trainingStartTime, confidence));
        }).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model) {
        return forecast(numForecasts, model, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, ObservationForecastingModel<T> model, double confidence) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(bos);
            out.writeObject(model);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException ignored) {

            }
        }
        final byte[] bytesObject = bos.toByteArray();
        return tsMap.entrySet().parallelStream().map(entry -> {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytesObject);
            ObjectInput in = null;
            ObservationForecastingModel<T> m = null;
            try {
                in = new ObjectInputStream(bis);
                m = (ObservationForecastingModel<T>) in.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException ex) {
                    // ignore close exception
                }
            }
            return new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, m, confidence));
        }).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    /**
     * Get the next numForecast {@link Observation} using a different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @param startTrainingTime the time where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap, long startTrainingTime) {
        return forecast(numForecasts, modelMap, startTrainingTime, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @param trainingStartTimeTick the time tick where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap, long trainingStartTimeTick, double confidence) {
        return tsMap.entrySet().parallelStream().map(entry ->
                new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, modelMap.get(entry.getKey()), trainingStartTimeTick, confidence))
        ).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    /**
     * Get the next numForecast {@link Observation} using different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap, ZonedDateTime trainingStartTime) {
        return forecast(numForecasts, modelMap, trainingStartTime, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap, ZonedDateTime trainingStartTime, double confidence) {
        return tsMap.entrySet().parallelStream().map(entry ->
                new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, modelMap.get(entry.getKey()), trainingStartTime, confidence))
        ).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    /**
     * Get the next numForecast {@link Observation} using different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap) {
        return forecast(numForecasts, modelMap, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using different {@link ObservationForecastingModel} for each
     * {@link TimeSeries}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     * <p>
     *     Note: The {@link ObservationForecastingModel} will be chosen from the map based on like keys with the
     *     {@link TimeSeries} in this {@link MultiTimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param modelMap the {@link Map} of {@link ObservationForecastingModel} to be used in forecasting
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction} for each key
     */
    public Map<KEY, ObservationCollection<Prediction<T>>> forecast(int numForecasts, Map<KEY,ObservationForecastingModel<T>> modelMap, double confidence) {
        return tsMap.entrySet().parallelStream().map(entry ->
                new Pair<>(entry.getKey(), entry.getValue().forecast(numForecasts, modelMap.get(entry.getKey()), confidence))
        ).collect(Collectors.toMap(x -> x.left, x -> x.right));
    }

    //todo make csv instants its own reader, for now this method...
    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csv(fileName,groupByKeyColumns,timestampColumn,sort,header,delimiter,dateTimeFormatter,trs)
                .flatMapObservation(o -> {
                    if (valueColumns == null || valueColumns.isEmpty()) {
                        return o.getValue().entrySet().stream()
                                .map(e -> new Observation<>(o.getTimeTick(), new Pair<>(e.getKey(), e.getValue())))
                                .collect(Collectors.toList());
                    } else {
                        return valueColumns.stream()
                                .map(s -> new Observation<>(o.getTimeTick(),new Pair<>(s,o.getValue().get(s))))
                                .collect(Collectors.toList());
                    }
                })
                .segmentBy(x -> x.getValue().left)
                .flatten(s -> s.first().getValue().left)
                .map(p -> p.right);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,valueColumns,sort,header,delimiter,dateTimeFormatter,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, boolean sort) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,valueColumns,sort,true,",",null,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, TRS trs) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,valueColumns,false,true,",",null,trs);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,valueColumns,false,true,",",null,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, Set<String> valueColumns, boolean sort, TRS trs) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,valueColumns,sort,true,",",null,trs);
    }

    /////
    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,sort,header,delimiter,dateTimeFormatter,null);

    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,sort,header,delimiter,dateTimeFormatter,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, boolean sort) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,sort,true,",",null,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, TRS trs) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,false,true,",",null,trs);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,false,true,",",null,null);
    }

    public static <T> MultiTimeSeries<Pair<Map<String,String>,String>,String> csvInstants(String fileName, Set<String> groupByKeyColumns, String timestampColumn, boolean sort, TRS trs) {
        return csvInstants(fileName,groupByKeyColumns,timestampColumn,null,sort,true,",",null,trs);
    }

    ////

    public static <T> MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter, TRS trs) {
        return TimeSeries.csv(fileName,timestampColumn,sort,header,delimiter,dateTimeFormatter,trs)
                .flatMapObservation(o -> {
                    if (valueColumns == null || valueColumns.isEmpty()) {
                        return o.getValue().entrySet().stream()
                                .map(e -> new Observation<>(o.getTimeTick(), new Pair<>(e.getKey(), e.getValue())))
                                .collect(Collectors.toList());
                    } else {
                        return valueColumns.stream()
                                .map(s -> new Observation<>(o.getTimeTick(), new Pair<>(s, o.getValue().get(s))))
                                .collect(Collectors.toList());
                    }
                })
                .segmentBy(x -> x.getValue().left)
                .flatten(s -> s.first().getValue().left)
                .map(p -> p.right);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter) {
        return csvInstants(fileName,timestampColumn,valueColumns,sort,header,delimiter,dateTimeFormatter,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns, boolean sort) {
        return csvInstants(fileName,timestampColumn,valueColumns,sort,true,",",null,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns, TRS trs) {
        return csvInstants(fileName,timestampColumn,valueColumns,false,true,",",null,trs);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns) {
        return csvInstants(fileName,timestampColumn,valueColumns,false,true,",",null,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, Set<String> valueColumns, boolean sort, TRS trs) {
        return csvInstants(fileName,timestampColumn,valueColumns,sort,true,",",null,trs);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csvInstants(fileName,timestampColumn,null,sort,header,delimiter,dateTimeFormatter,trs);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, boolean sort,boolean header,String delimiter,DateTimeFormatter dateTimeFormatter) {
        return csvInstants(fileName,timestampColumn,null,sort,header,delimiter,dateTimeFormatter,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, boolean sort) {
        return csvInstants(fileName,timestampColumn,null,sort,true,",",null,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, TRS trs) {
        return csvInstants(fileName,timestampColumn,null,false,true,",",null,trs);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn) {
        return csvInstants(fileName,timestampColumn,null,false,true,",",null,null);
    }

    public static MultiTimeSeries<String,String> csvInstants(String fileName, String timestampColumn, boolean sort, TRS trs) {
        return csvInstants(fileName,timestampColumn,null,sort,true,",",null,trs);
    }

    private static long convertToLongTimestamp(String tsString, DateTimeFormatter dtf) {

        try {
            return Long.parseLong(tsString);
        } catch (Exception e) {
            TemporalAccessor temporalAccessor = dtf.parseBest(
                    tsString,
                    t -> ZonedDateTime.from(t),
                    t -> LocalDateTime.from(t),
                    t -> LocalDate.from(t),
                    t -> LocalTime.from(t)
            );

            LocalDate localDate = temporalAccessor.query(TemporalQueries.localDate());
            localDate = (localDate == null) ? LocalDate.MIN : localDate;
            LocalTime localTime = temporalAccessor.query(TemporalQueries.localTime());
            localTime = (localTime == null) ? LocalTime.MIN : localTime;
            ZoneId zoneId = temporalAccessor.query(TemporalQueries.zoneId());
            zoneId = (zoneId == null) ? ZoneId.of("UTC") : zoneId;
            return ZonedDateTime.of(localDate, localTime, zoneId).toInstant().toEpochMilli();
        }
    }

    private static Object getValueFromType(String rawValue) {
        try {
            return Integer.valueOf(rawValue);
        } catch (Exception integerException) {
            try {
                return Long.valueOf(rawValue);
            } catch (Exception longException) {
                try {
                    return Double.valueOf(rawValue);
                } catch (Exception doubleException) {
                    return rawValue;
                }
            }
        }
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns,boolean header, String delimiter, TRS trs) {
        return reader(new CSVMultiTimeSeriesValueReader(path,keyColumns,header,delimiter),trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns,boolean header, String delimiter) {
        return csv(path,keyColumns,header,delimiter,null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns,TRS trs) {
        return csv(path,keyColumns,true,",",trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns) {
        return csv(path,keyColumns,true,",",null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns, String timestampColumn, boolean sort, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return reader(new CSVMultiTimeSeriesReader(path,keyColumns,timestampColumn,header,delimiter,dateTimeFormatter,sort),trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns, String timestampColumn, boolean sort, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter) {
        return csv(path,keyColumns,timestampColumn,sort,header,delimiter,dateTimeFormatter,null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns, String timestampColumn, boolean sort, boolean header, String delimiter) {
        return csv(path,keyColumns,timestampColumn,sort,header,delimiter,null,null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path, Set<String> keyColumns, String timestampColumn, boolean sort, TRS trs) {
        return csv(path, keyColumns,timestampColumn, sort, true, ",", null, trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns,String timestampColumn, TRS trs) {
        return csv(path, keyColumns,timestampColumn, false, trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn, boolean sort) {
        return csv(path,keyColumns, timestampColumn, sort, true, ",", null, null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn) {
        return csv(path,keyColumns, timestampColumn, false);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csv(path,keyColumns, timestampColumn, false,true,",",dateTimeFormatter,trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn, DateTimeFormatter dateTimeFormatter) {
        return csv(path,keyColumns, timestampColumn, dateTimeFormatter,null);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn, boolean sort, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csv(path,keyColumns, timestampColumn, sort,true,",",dateTimeFormatter,trs);
    }

    /**
     * Create a {@link MultiTimeSeries} from a csv where each line denotes a single {@link Observation} and key. Each
     * observation will be a map where each key is based on the header key, and value is the corresponding column. Each
     * key will be a map where the map key is based on the header key, and the value is the corresponding column. Each
     * unique key will denote a new time-series.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param keyColumns key columns
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link MultiTimeSeries}
     */
    public static MultiTimeSeries<Map<String,String>,Map<String,String>> csv(String path,Set<String> keyColumns, String timestampColumn, boolean sort, DateTimeFormatter dateTimeFormatter) {
        return csv(path,keyColumns, timestampColumn, sort, dateTimeFormatter,null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, value) pair
     * @param skipNumLines number of lines to skip
     * @param trs the source {@link TRS}
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,VALUE>>> parseLine,
            int skipNumLines,
            TRS trs
    ) {
        return reader(new TextFileSequentialMultiTimeSeriesValueReader<>(path,parseLine,skipNumLines),trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, value) pair
     * @param skipNumLines number of lines to skip
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,VALUE>>> parseLine,
            int skipNumLines
    ) {
        return textFile(path,parseLine,skipNumLines,null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, value) pair
     * @param trs the source {@link TRS}
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,VALUE>>> parseLine,
            TRS trs
    ) {
        return textFile(path,parseLine,0,trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, value) pair
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,VALUE>>> parseLine
    ) {
        return textFile(path,parseLine,0,null);
    }

    /////////////

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, observation) pair
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param skipNumLines number of lines to skip
     * @param trs the source {@link TRS}
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,Observation<VALUE>>>> parseLine,
            boolean sort,
            int skipNumLines,
            TRS trs) {
        return (sort)
                ? reader(new TextFileUnsortedMultiTimeSeriesReader<>(path,parseLine,skipNumLines), trs)
                : reader(new TextFileSequentialMultiTimeSeriesReader<>(path,parseLine,skipNumLines), trs).cache();
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, observation) pair
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param skipNumLines number of lines to skip
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,Observation<VALUE>>>> parseLine,
            boolean sort,
            int skipNumLines) {
        return textFile(path,parseLine, sort, skipNumLines, null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, observation) pair
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param trs the source {@link TRS}
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,Observation<VALUE>>>> parseLine,
            boolean sort,
            TRS trs) {
        return textFile(path,parseLine, sort, 0, trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} and time-series key is
     * extracted from a single line. Time-Series will be grouped by their unique key
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a (key, observation) pair
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param <KEY> output key type
     * @param <VALUE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUE> MultiTimeSeries<KEY, VALUE> textFile(
            String path,
            UnaryMapFunction<String,Optional<Pair<KEY,Observation<VALUE>>>> parseLine,
            boolean sort) {
        return textFile(path,parseLine, sort, 0, null);
    }

    /**
     * create a {@link MultiTimeSeries} from an object file
     *
     * <p>Note: This brings the time series in to memory</p>
     *
     * @param inputStream {@link InputStream} containing the {@link TimeSeries} object
     * @param <KEY> output key type
     * @param <VALUETYPE> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <KEY, VALUETYPE> MultiTimeSeries<KEY, VALUETYPE> objectFile(InputStream inputStream) {
        MultiTimeSeries<KEY, VALUETYPE> result = null;
        try {
            ObjectInputStream ois = new ObjectInputStream(inputStream);
            Map<KEY, ObservationCollection<VALUETYPE>> obsMap = (Map<KEY, ObservationCollection<VALUETYPE>>) ois.readObject();
            result = new MultiTimeSeries<>(
                    obsMap.entrySet().parallelStream().map(x -> new Pair<>(x.getKey(), x.getValue().toTimeSeriesStream())).collect(Collectors.toMap(x -> x.left, x -> x.right))
            );
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * create a {@link MultiTimeSeries} from a list of pairs of (KEY,Observation). A Time-series will be created for
     * each unique key.
     *
     * @param observations pairs of Observations
     * @param <KEY> output key type
     * @param <VALUETYPE> output {@link Observation} value type
     * @param trs the source {@link TRS}
     * @return a new {@link MultiTimeSeries}
     */
    public static <KEY, VALUETYPE> MultiTimeSeries<KEY, VALUETYPE> fromObservations(List<Pair<KEY, Observation<VALUETYPE>>> observations, TRS trs) {

        final Map<KEY, List<Pair<KEY, Observation<VALUETYPE>>>> collect = observations.stream()
                .map(x -> new Pair<>(x.left, x.right))
                .collect(Collectors.groupingBy(x -> x.left));

        Map<KEY, TimeSeries<VALUETYPE>> map = collect.entrySet().parallelStream().map(entry -> {
            TSBuilder<VALUETYPE> tsBuilder = Observations.newBuilder();
            entry.getValue().forEach(pair -> tsBuilder.add(pair.right));
            return new Pair<>(entry.getKey(), TimeSeries.fromObservations(tsBuilder.result(), trs));
        }).collect(Collectors.toMap(x -> x.left, x -> x.right));

        return new MultiTimeSeries<>(map);
    }

    /**
     * create a {@link MultiTimeSeries} from a list of pairs of (KEY,Observation). A Time-series will be created for
     * each unique key.
     *
     * @param observations pairs of Observations
     * @param <KEY> output key type
     * @param <VALUETYPE> output {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <KEY, VALUETYPE> MultiTimeSeries<KEY, VALUETYPE> fromObservations(List<Pair<KEY, Observation<VALUETYPE>>> observations) {
        return fromObservations(observations, null);
    }

    /**
     * create a {@link MultiTimeSeries} from an in memory List of {@link ObservationCollection}s
     *
     * @param listTimeSeries list of ObservationCollections
     * @param trs the source {@link TRS}
     * @param <VALUETYPE>    {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <VALUETYPE> MultiTimeSeries<Integer, VALUETYPE> fromObservationCollectionList(List<ObservationCollection<VALUETYPE>> listTimeSeries, TRS trs) {
        MultiTimeSeriesReader<Integer, VALUETYPE> multiTimeSeriesReader = new NavSetMultiTimeSeriesReader<>(listTimeSeries);
        return new MultiTimeSeries<>(multiTimeSeriesReader, trs);
    }

    /**
     * create a {@link MultiTimeSeries} from an in memory List of {@link ObservationCollection}s
     *
     * @param listTimeSeries list of ObservationCollections
     * @param <VALUETYPE> {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <VALUETYPE> MultiTimeSeries<Integer, VALUETYPE> fromObservationCollectionList(List<ObservationCollection<VALUETYPE>> listTimeSeries) {
        return fromObservationCollectionList(listTimeSeries, null);
    }

    /**
     * create a {@link MultiTimeSeries} from a List of List of values. The inner list will denote each TimeSeries whereas the
     * outer list container denotes the key to a given TimeSeries based on the index of the TimeSeries into the list.
     *
     * <p>Note: Timestamps will be value indexes into each TimeSeries</p>
     *
     * @param listValues  list of list of values
     * @param trs the source {@link TRS}
     * @param <VALUETYPE> {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <VALUETYPE> MultiTimeSeries<Integer, VALUETYPE> list(List<List<VALUETYPE>> listValues, TRS trs) {
        MultiTimeSeriesReader<Integer, VALUETYPE> multiTimeSeriesReader = new ValueListMultiTimeSeriesReader<>(listValues);
        return new MultiTimeSeries<>(multiTimeSeriesReader, trs);
    }

    /**
     * create a {@link MultiTimeSeries} from a List of List of values. The inner list will denote each TimeSeries whereas the
     * outer list container denotes the key to a given TimeSeries based on the index of the TimeSeries into the list.
     *
     * <p>Note: Timestamps will be value indexes into each TimeSeries</p>
     *
     * @param listValues  list of list of values
     * @param <VALUETYPE> {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <VALUETYPE> MultiTimeSeries<Integer, VALUETYPE> list(List<List<VALUETYPE>> listValues) {
        return list(listValues, null);
    }

    /**
     * create a {@link MultiTimeSeries} from a {@link MultiTimeSeriesReader}
     *
     * @param multiTimeSeriesReader the {@link MultiTimeSeriesReader}
     * @param trs the source {@link TRS}
     * @param <KEYTYPE>             key type to map to a {@link TimeSeries}
     * @param <VALUETYPE>           value type for each {@link Observation}
     * @return a new {@link MultiTimeSeries}
     */
    public static <KEYTYPE, VALUETYPE> MultiTimeSeries<KEYTYPE, VALUETYPE> reader(MultiTimeSeriesReader<KEYTYPE, VALUETYPE> multiTimeSeriesReader, TRS trs) {
        return new MultiTimeSeries<>(multiTimeSeriesReader, trs);
    }

    /**
     * create a {@link MultiTimeSeries} from a {@link MultiTimeSeriesReader}
     *
     * @param multiTimeSeriesReader the {@link MultiTimeSeriesReader}
     * @param <KEYTYPE>             key type to map to a {@link TimeSeries}
     * @param <VALUETYPE>           value type for each {@link Observation}
     * @return a new {@link MultiTimeSeries}
     */
    public static <KEYTYPE, VALUETYPE> MultiTimeSeries<KEYTYPE, VALUETYPE> reader(MultiTimeSeriesReader<KEYTYPE, VALUETYPE> multiTimeSeriesReader) {
        return reader(multiTimeSeriesReader, null);
    }

    /**
     * create a {@link MultiTimeSeries} from a list of {@link TimeSeries}
     *
     * @param timeSeriesList TimeSeries list
     * @param <VALUETYPE>    {@link Observation} value type
     * @return a new {@link MultiTimeSeries}
     */
    public static <VALUETYPE> MultiTimeSeries<Integer, VALUETYPE> fromTimeSeriesList(
            List<TimeSeries<VALUETYPE>> timeSeriesList) {
        Map<Integer, TimeSeries<VALUETYPE>> siMap = new HashMap<>();
        AtomicInteger i = new AtomicInteger(0);
        timeSeriesList.forEach(si -> siMap.put(i.getAndAdd(1), si));
        return new MultiTimeSeries<>(siMap);
    }
}
