package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

class DescribeObjectReducer<T> extends UnaryReducer<T,Stats<T>>{
    private static final long serialVersionUID = -5754398376794096377L;

    @Override
    public Stats<T> reduceSegment(Segment<T> segment) {

        if (segment.isEmpty()) {
            throw new TSRuntimeException("cannot describe an empty TimeSeries");
        }

        TimeStats timeStats = segment.toTimeSeriesStream().reduce(GeneralReducers.describeTime());

        Observation<T> first = segment.first();
        Observation<T> last = segment.last();

        long unique = segment.stream().map(Observation::getValue).distinct().count();

        final Optional<Pair<T, Integer>> max = segment.stream().map(Observation::getValue).collect(Collectors.groupingBy(x -> x))
                .entrySet().stream()
                .map(x -> new Pair<>(x.getKey(), x.getValue().size()))
                .max(Comparator.comparing(x -> x.right));

        Pair<T,Integer> topFreq = max.orElse(null);

        T top;
        int freq;

        if (topFreq == null) {
            top = null;
            freq = 0;
        } else {
            freq = topFreq.right;
            if (topFreq.right == 1 && unique > 1)
                top = null;
            else
                top = topFreq.left;
        }

        return new Stats<>(timeStats,top,unique,freq,first,last,segment.size());
    }
}
