package com.ibm.research.time_series.core.core_transforms.general.python;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.List;

public class PythonFilterKey {
    public static <T> FilterFunction<T> filterContains(List<T> values, boolean contains) {
        return (value) -> (values.contains(value)) && contains;
    }
}
