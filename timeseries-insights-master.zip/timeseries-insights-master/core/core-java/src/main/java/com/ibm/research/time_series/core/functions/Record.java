package com.ibm.research.time_series.core.functions;

/**
 * Interface used for python Records similar to a map getter
 */
public interface Record {
    /**
     * @param attributeName attribute in record to get
     * @return the object associated with this attribute name
     */
    Object get(String attributeName);
}
