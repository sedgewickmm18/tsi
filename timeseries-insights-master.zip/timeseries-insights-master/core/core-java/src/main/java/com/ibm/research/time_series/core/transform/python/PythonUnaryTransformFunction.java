package com.ibm.research.time_series.core.transform.python;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

public interface PythonUnaryTransformFunction<T,T2> {
    ObservationCollection<T2> call(TimeSeries<T> timeSeries, long start, long end, boolean inclusive);
}
