package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.ArrayList;
import java.util.List;

class FullNaryTemporalJoin<IN,OUT> extends NaryTransform<IN,OUT> {

    private static final long serialVersionUID = -2306676537888388070L;
    private final Interpolator<IN> interpolatorForInType;
    private BinaryMapFunction<OUT,IN,OUT> combineOp;
    private final OUT zeroValue;

    FullNaryTemporalJoin(OUT zeroValue, BinaryMapFunction<OUT, IN, OUT> combineOp) {
        this(zeroValue,combineOp, GenericInterpolators.nullify());
    }

    FullNaryTemporalJoin(
            OUT zeroValue,
            BinaryMapFunction<OUT, IN, OUT> combineOp,
            Interpolator<IN> interpolatorForInType) {
        this.zeroValue = zeroValue;
        this.combineOp = combineOp;
        this.interpolatorForInType = interpolatorForInType;
    }

    private TimeSeries<OUT> join(TimeSeries<OUT> aggregateTS, TimeSeries<IN> currentTS) {
        //perform a left join here since in NaryTemporalJoinTransform we handle operations from both sides
        if (interpolatorForInType == null) {
            return aggregateTS.leftJoin(currentTS,combineOp);
        } else {
            return aggregateTS.leftJoin(
                    currentTS,
                    combineOp,
                    interpolatorForInType);
        }
    }

    @Override
    public ObservationCollection<OUT> evaluate(long t1, long t2,boolean inclusive) {
        List<TimeSeries<IN>> tsList = new ArrayList<>(this.timeSeriesTail);
        tsList.add(this.timeSeriesRoot);

        List<TimeSeries<OUT>> aggregates = new ArrayList<>();

        //perform a join on all possible combinations
        for (int i = 0;i < tsList.size();i++) {
            TimeSeries<OUT> aggregate = tsList.get(i).map(x -> combineOp.evaluate(zeroValue,x));
            for (int j = 0;j < tsList.size();j++) {
                if (i == j) continue;
                aggregate = join(aggregate,tsList.get(j));
            }
            aggregates.add(aggregate);
        }

        //only keep unique timestamps from the final aggregates
        TSBuilder<OUT> resultBuilder = Observations.newBuilder();
        aggregates.forEach(ts -> {
            ObservationCollection<OUT> currentOC = ts.getValues(t1,t2,inclusive);
            currentOC.forEach(resultBuilder::add);
        });
        return resultBuilder.result(x -> x.get(0));
    }

    @Override
    public Object clone() {
        return new FullNaryTemporalJoin<>(
                zeroValue,combineOp,interpolatorForInType);
    }
}
