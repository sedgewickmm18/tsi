/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import org.apache.log4j.Logger;

/**
 * Abstract class to handle DerivedTimeSeries, TimeSeries object that was derived from the result of
 * a transform on TimeSeries(no physical source)
 * <p>This class can be either extended by Unary, Binary or Nary DerivedTimeSeries.</p>
 *
 * @param <T> the type of the sensor reading values
 *
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 * @author Mudhakar Srivatsa
 */
abstract class DerivedTimeSeries<T> extends TimeSeries<T> {
    private static Logger logger = Logger.getLogger(DerivedTimeSeries.class);

    DerivedTimeSeries() {
        cache = new MemCache<>();
    }

    /**
     * perform evaluation from timestamps t1 to t2 on a
     * DerivedTimeSeries(Unary, Binary or Nary) and return result
     * @param t1 time start
     * @param t2 time end
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return the result of the evaluation
     */
    protected abstract ObservationCollection<T> performEvaluation(
            long t1,
            long t2,
            boolean inclusive
    );

    protected boolean sourceInMemory() {
        return false;
    }

    /**
     * build our values from a derived source
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return a NavigableSet produced from our evaluate from derived source
     */
    @Override
    protected ObservationCollection<T> buildValuesFromSource(
            long t1,
            long t2,
            boolean inclusive){
        return performEvaluation(t1,t2,inclusive);
    }

}
