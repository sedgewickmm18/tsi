package com.ibm.research.time_series.core.io.writers;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesWriteFormat;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.*;
import java.util.Map;

public class CSVMultiTimeSeriesWriterFormat<K,T> implements MultiTimeSeriesWriteFormat<K,T> {
    private BufferedWriter bufferedWriter;
    public CSVMultiTimeSeriesWriterFormat(String path) {
        File f = new File(path);
        try {
            FileOutputStream fos = new FileOutputStream(f);
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(fos));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void write(
            Map<K,ObservationCollection<T>> observationsMap,
            UnaryMapFunction<K, String> encodeKey,
            UnaryMapFunction<T, String> encodeValue,
            Map<String, Object> options) {
        String delimiter = (String) options.getOrDefault("delimiter",",");
        boolean header = (boolean) options.getOrDefault("header", true);

        try {
            if (header) {
                bufferedWriter.write("key" + delimiter + "timetick" + delimiter + "value");
                bufferedWriter.newLine();
            }

            observationsMap.forEach((k,observations) -> {
                final String key = encodeKey.evaluate(k);
                for (Observation<T> observation : observations) {
                    try {
                        bufferedWriter.write(key + delimiter + observation.getTimeTick() + delimiter + encodeValue.evaluate(observation.getValue()));
                        bufferedWriter.newLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
