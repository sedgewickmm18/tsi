package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.*;

import java.util.List;
import java.util.stream.Collectors;

class GroupBySegmentation<T,K> extends UnaryTransform<T,Segment<T>>{

    private static final long serialVersionUID = -5920069221499006893L;
    private UnaryMapFunction<Observation<T>,K> groupByOp;

    GroupBySegmentation(UnaryMapFunction<Observation<T>,K> groupByOp) {
        this.groupByOp = groupByOp;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        ObservationCollection<T> values = timeSeries.getValues(t1, t2, inclusive);

        List<Segment<T>> collect = values.stream()
                .map(x -> new Pair<>(groupByOp.evaluate(x), x)).collect(Collectors.groupingBy(a -> a.left))
                .entrySet()
                .stream()
                .map(x -> {
                    TSBuilder<T> tsBuilder = Observations.newBuilder();
                    x.getValue().forEach(pair -> {
                        tsBuilder.add(pair.right);
                    });
                    return Segment.fromSeries(tsBuilder.result());
                }).collect(Collectors.toList());

        TSBuilder<Segment<T>> result = Observations.newBuilder();

        for (Segment<T> segment : collect) {
            result.add(new Observation<>(segment.start,segment));
        }

        return result.result();
    }

    @Override
    public Object clone() {
        return new GroupBySegmentation<>(groupByOp);
    }
}
