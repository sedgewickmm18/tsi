/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;

import java.io.Serializable;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * Abstract class to represent a BinaryTransform.
 *
 * A BinaryTransform is a transform that takes 2 time series and produces a single time series
 *
 * <p>A BinaryTransform has no dependence on a time series, it can be created without a time series.
 * 	the purpose of time series in this class is to hold the time series reference when chaining
 * 	transforms.</p>
 *
 * <p>Any class that extends this class will require:</p>
 * <p>implementation of evaluate - algorithm to perform to go from TimeSeries RIGHT,LEFT to TimeSeries
 * OUT.</p>
 * <p>Optional - implementation of clone if stateful - this method will require the class to make a
 * copy of itself and return(must be used as to not compromise a transformation chain).</p>
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 *
 * @param <LEFT> time series type in first
 * @param <RIGHT> time series type in second
 * @param <OUT> time series type out
 */
public abstract class BinaryTransform<LEFT, RIGHT, OUT> extends Transform implements Serializable,Cloneable {

    private static final long serialVersionUID = 176398519987725145L;
    /**
     * the current state of our left time series at any given time in a transform chain
     */
    protected TimeSeries<LEFT> timeSeriesLeft;

    /**
     * the current state of our right time series at any given time in a transform chain
     */
    protected TimeSeries<RIGHT> timeSeriesRight;

	/**
	 * this is the simple evaluate method.
     * Use this method to write your own implementation of your transform.
     *
     * Within this method, use this classes timeSeriesLeft, timeSeriesRight and the given parameters
     * to evaluate and transform your time series.
     *
	 * @param t1 timestamp start
	 * @param t2 timestamp end
	 * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
	 * @return the resulting time series after the transform you wish to implement
	 */
	public abstract ObservationCollection<OUT> evaluate(long t1, long t2, boolean inclusive);

    /**
     * this method is used to save the state of a transform at any given time in the chain of transforms.
     * To implement this method, you must create a new (x)BinaryTransform with the properties of the current
     * transform and return this new transform.
     */
	public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    /**
     * ~~~~~~DEVELOPER API~~~~~~
     * this method is used to set an operation on time series(left and right) of an already existing transform.
     * @param tsLeft the first(left) TimeSeries to operate on
     * @param tsRight the second(right) TimeSeries to operate on
     */
	public void setOperationOn(TimeSeries<LEFT> tsLeft, TimeSeries<RIGHT> tsRight){
		timeSeriesLeft = tsLeft;
		timeSeriesRight = tsRight;
	}

    /**
     * @return the current state of our left time series at any given time in a transform chain
     */
	public TimeSeries<LEFT> getTimeSeriesLeft(){
		return timeSeriesLeft;
	}

    /**
     * @return the current state of our right time series at any given time in a transform chain
     */
	public TimeSeries<RIGHT> getTimeSeriesRight(){
		return timeSeriesRight;
	}

}
