package com.ibm.research.time_series.core.io.writers;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesWriteFormat;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

public class ObjectFileMultiTimeSeriesWriterFormat<K,T> implements MultiTimeSeriesWriteFormat<K,T> {

    private String path;

    public ObjectFileMultiTimeSeriesWriterFormat(String path) {
        this.path = path;
    }

    @Override
    public void write(Map<K, ObservationCollection<T>> observationsMap, UnaryMapFunction<K, String> encodeKey, UnaryMapFunction<T, String> encodeValue, Map<String, Object> options) {
        ByteArrayOutputStream baStreamTS = new ByteArrayOutputStream();
        ObjectOutputStream ooStreamTS = null;
        try {
            FileOutputStream fos = new FileOutputStream(path);
            ooStreamTS = new ObjectOutputStream(baStreamTS);
            ooStreamTS.writeObject(observationsMap);
            ooStreamTS.close();
            baStreamTS.writeTo(fos);
            baStreamTS.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
