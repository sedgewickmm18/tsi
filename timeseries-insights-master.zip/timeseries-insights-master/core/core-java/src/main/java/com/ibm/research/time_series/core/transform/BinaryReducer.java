/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * A special form of {@link BinaryTransform} that works over two
 * {@link com.ibm.research.time_series.core.timeseries.SegmentTimeSeries} using the transform method or
 * two {@link com.ibm.research.time_series.core.timeseries.TimeSeries} using the reduce method.
 *
 * <p>
 *     In the case of two {@link com.ibm.research.time_series.core.timeseries.SegmentTimeSeries}, the output will be a
 *     single {@link com.ibm.research.time_series.core.timeseries.TimeSeries}.
 * </p>
 * <p>
 *     In the case of two {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, the output will be a single
 *     value
 * </p>
 *
 * To extend a BinaryReducer, one must implement the single method reduceSegment which given two
 * segments as a parameter, produces a single value
 *
 * <p>Created on 6/13/17.</p>
 * @param <LEFT> left {@link Observation} value type
 * @param <RIGHT> right {@link Observation} value type
 * @param <OUT> output value type
 * @author Joshua Rosenkranz
 */
public abstract class BinaryReducer<LEFT,RIGHT,OUT>
        extends BinaryTransform<Segment<LEFT>,Segment<RIGHT>,OUT> {

    /**
     * implementation of evaluate for a BinaryReducer where each segment in the left and right time series is reduced
     * to a single value. Segments will be paired by like index into their corresponding time series.
     *
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @param inclusive inclusive bound
     * @return a new observation collection of type OUT
     */
    @Override
    public ObservationCollection<OUT> evaluate(long t1, long t2,boolean inclusive) {
        ObservationCollection<Segment<LEFT>> left = this.getTimeSeriesLeft().getValues(t1,t2,inclusive);
        ObservationCollection<Segment<RIGHT>> right = this.getTimeSeriesRight().getValues(t1,t2,inclusive);

        Iterator<Observation<Segment<LEFT>>> leftIter = left.iterator();
        Iterator<Observation<Segment<RIGHT>>> rightIter = right.iterator();

        //each segment from left and right goes in order by index
        //we then reduce each 2 segments to a single value and return an observation with that value
        TSBuilder<OUT> tsBuilder = Observations.newBuilder();
        while(leftIter.hasNext() && rightIter.hasNext()) {
            Observation<Segment<LEFT>> leftObs = leftIter.next();
            Observation<Segment<RIGHT>> rightObs = rightIter.next();
            tsBuilder.add(
                    new Observation<>(
                            leftObs.getValue().start,
                            reduceSegment(leftObs.getValue(),rightObs.getValue())
                    )
            );
        }
        return tsBuilder.result();
    }

    /**
     * reduce two segments to a single value
     *
     * @param leftSegment left time series segment {@link Segment}
     * @param rightSegment right time series segment {@link Segment}
     * @return a single value
     */
    public abstract OUT reduceSegment(Segment<LEFT> leftSegment,Segment<RIGHT> rightSegment);
}
