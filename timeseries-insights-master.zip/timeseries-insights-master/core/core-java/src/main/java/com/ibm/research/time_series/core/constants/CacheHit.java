/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.constants;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

/**
 * Class which denotes the most recent type of cache hit in a given {@link TimeSeries}.
 *
 * <p>When referring to cache hits, a value is deemed to be in the cache if both:</p>
 * <ul>
 *      <li>its timestamp is greater than or equal to the lowest timestamp in the cache</li>
 *      <li>its timestamp is less than or equal to the greatest timestamp in the cache</li>
 * </ul>
 *
 * <p>Created on 8/21/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public enum CacheHit {
    /**
     * There was no cache hit in the last query
     *
     * <p>Cache = (3,4,5)</p>
     * <p>query = getValues(7,10)</p>
     *
     * <p>result: all values will be retrieved from source</p>
     */
    NONE,
    /**
     * All values queried for were in the cache
     *
     * <p>Cache = (3,4,5)</p>
     * <p>query = getValues(3,4)</p>
     *
     * <p>result: all values will be retrieved from cache</p>
     */
    FULL,
    /**
     * There existed values queried that were not in the cache from both before and after the cache
     *
     * <p>Cache = (3,4,5)</p>
     * <p>query = getValues(2,7)</p>
     *
     * <p>result: [2,3) will be retrieved from source</p>
     * <p>result: [3,5] will be retrieved from cache</p>
     * <p>result: (5,7] will be retrieved from source</p>
     */
    MIDDLE,
    /**
     * There existed values queried that were not in the cache from before the cache
     *
     * <p>Cache = (3,4,5)</p>
     * <p>query = getValues(2,4)</p>
     *
     * <p>result: [2,3) will be retrieved from source</p>
     * <p>result: [3,4] will be retrieved from cache</p>
     */
    BEFORE,
    /**
     * There existed values queried that were not in the cache from after the cache
     *
     * <p>Cache = (3,4,5)</p>
     * <p>query = getValues(4,7)</p>
     *
     * <p>result: [4,5] will be retrieved from cache</p>
     * <p>result: (5,7] will be retrieved from source</p>
     */
    AFTER
}
