package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.constants.Padding;
import com.ibm.research.time_series.core.constants.ResultingTimeStamp;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.Segment;

/**
 * This is the entry point for all core built-in transforms for segmenting time series
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class GenericSegmentationTransformers {
    /**
     * This is the unary record based segmentation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will segment the time series based on a
     * sliding window
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(3,3),Observation(6,6),Observation(7,7)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3,2,false)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(Observation(1,1),Observation(3,3),Observation(6,6)),
     *             Segment(Observation(6,6),Observation(7,7))]
     *         </p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3,2,true)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Segment(Observation(1,1),Observation(3,3),Observation(6,6))]</p>
     *     </li>
     * </ul>
     *
     * @param window window size
     * @param step step size
     * @param enforceSize enforce that size is always of size window
     * @param <T> observation value type
     * @return a single instance of a segment transform
     */
    public static <T> UnaryTransform<T,Segment<T>> segment(long window, long step, boolean enforceSize) {
        return new RecordSliding<>(window,step,enforceSize);
    }

    /**
     * This is the unary time based segmentation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will segment the time series based on a
     * sliding time window
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByTime(1 hour,1 hour)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=12:00,end=12:59,Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)),
     *             Segment(start=1:00,end=1:59,Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)),
     *             Segment(start=2:00,end=2:59,Observation(2:00,5))]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param window window size (time)
     * @param step step size (time)
     * @param padding the {@link Padding} to be used
     * @param resultingTimeStamp the {@link ResultingTimeStamp} to be used
     * @param <T> observation value type
     * @return a single instance of a time based segment transform
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByTime(long window, long step, Padding padding, ResultingTimeStamp resultingTimeStamp) {
        return new TimeSliding<>(
                window,
                step,
                padding,
                resultingTimeStamp
        );
    }

    /**
     * This is the unary anchor based segmentation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will segment the time series around a series
     * of anchor points.
     *
     * <p>An anchor point is defined as any value that satisfies the isAnchorF filter function. When an anchor point is
     * determined the segment is built based on leftDelta time to the left of the point and rightDelta time to the
     * right of the point.</p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByAnchor(x -> x % 2 == 0,1 hour, 30 minutes)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param f anchor function
     * @param leftDelta left delta time
     * @param rightDelta right delta time
     * @param <T> observation value type
     * @return a single instance of an anchor based segment transform
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByAnchor(FilterFunction<T> f,long leftDelta,long rightDelta) {
        return new AnchorSliding<>(f,leftDelta,rightDelta);
    }

    /**
     * This is the unary anchor based segmentation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will segment the time series around a series
     * of anchor points.
     *
     * <p>An anchor point is defined as any value that satisfies the isAnchorF filter function. When an anchor point is
     * determined the segment is built based on leftDelta time to the left of the point and rightDelta time to the
     * right of the point.</p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByAnchor(x -> x % 2 == 0,1 hour, 30 minutes)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param f anchor function
     * @param leftDelta left delta time
     * @param rightDelta right delta time
     * @param perc number between 0 and 1.0 denoting how often to accept anchor
     * @param <T> observation value type
     * @return a single instance of an anchor based segment transform
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByAnchor(FilterFunction<T> f,long leftDelta,long rightDelta, double perc) {
        return new AnchorSliding<>(f,leftDelta,rightDelta,perc);
    }

    /**
     * @param f the marker function
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * based on a marker function. A marker is defined as any value that satisfies the isMarkerF function.
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByMarker(FilterFunction<T> f) {
        return new MarkerBasedSegmentation<>(f, false, true);
    }

    /**
     * @param f the marker function
     * @param prevInclusive if true, will include the marker to the previous segment
     * @param nextInclusive if true, will include the marker to the previous segment
     * @param requiresStartAndEnd if true, a segment will only be created if encapsulated by 2 markers (a start and end)
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * based on a marker function. A marker is defined as any value that satisfies the isMarkerF function.
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByMarker(FilterFunction<T> f, boolean prevInclusive, boolean nextInclusive, boolean requiresStartAndEnd) {
        if (requiresStartAndEnd)
            return new SingleMarkerBasedSegmentation<>(f, prevInclusive, nextInclusive);
        else
            return new MarkerBasedSegmentation<>(f, prevInclusive, nextInclusive);
    }

    /**
     * This is the unary segmentation by transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will segment based on the result of a group
     * by operation. A group by operation works by taking each observation and producing a single key. Each segment will
     * be generated for each unique key
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input: (Note: january,february, and march denote timestamps in those months)
     *         <p>[Observation(january1,1),Observation(january5,2),Observation(january10,3),Observation(february1,4),Observation(march3,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentBy(obs -> Instant.ofEpochMilli(obs.timestamp).atZone(ZoneId.systemDefault()).toLocalDate().getMonth().toString()}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=january1,end=january10,[Observation(january1,1),Observation(january5,2),Observation(january10,3)]),
     *             Segment(start=february1,end=february1,[Observation(february1,4)])
     *             Segment(start=march3,end=march3,[Observation(march3,5)]]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param groupByOp group by operation
     * @param <K> output key type
     * @param <T> {@link Observation} value type
     * @return a new Time Series of segments
     */
    public static <T,K> UnaryTransform<T,Segment<T>> segmentBy(UnaryMapFunction<Observation<T>,K> groupByOp) {
        return new GroupBySegmentation<>(groupByOp);
    }

    /**
     * @param startOp the start marker function
     * @param endOp the end marker function
     * @param startInclusive if true, will include the start marker to the segment
     * @param endInclusive if true, will include the end marker to the segment
     * @param startFirst if true, will start the segment on the first instance of the start marker before an end
     *                   marker
     * @param endFirst if true, will end the segment on the first instance of the end marker after a start
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a time-series based on a start and end marker function. A marker
     * is defined as any value that satisfies the isMarkerF function.
     */
    public static <T> UnaryTransform<T, Segment<T>> segmentByMarker(
            FilterFunction<T> startOp,
            FilterFunction<T> endOp,
            boolean startInclusive,
            boolean endInclusive,
            boolean startFirst,
            boolean endFirst
            ) {
        return new BiMarkerBasedSegmentation<>(startOp,endOp,startInclusive,endInclusive,startFirst,endFirst);
    }

    /**
     * @param isChangOp a function given a prev/next value to determine if a change exists
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a time-series based on a change-point.
     */
    public static <T> UnaryTransform<T, Segment<T>> segmentByChangePoint(BinaryMapFunction<T,T,Boolean> isChangOp) {
        return new ChangeBasedSegmentation<>(isChangOp);
    }

    /**
     * @param segmentTransform segmentation transform used to create markers
     * @param isMarkerF the marker function
     * @param prevInclusive if true, will include the marker to the previous segment
     * @param nextInclusive if true, will include the marker to the previous segment
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * based on a marker function on a segment. A marker is defined as any value that satisfies the isMarkerF function.
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> isMarkerF,
            boolean prevInclusive,
            boolean nextInclusive) {
        return new MarkerBasedSegmentationOnSegment<>(segmentTransform,isMarkerF,prevInclusive,nextInclusive);
    }

    /**
     * @param segmentTransform segmentation transform used to create markers
     * @param startMarkerF the start marker function
     * @param endMarkerF the end marker function
     * @param prevInclusive if true, will include the marker to the previous segment
     * @param nextInclusive if true, will include the marker to the next segment
     * @param startFirst if true, will start segment on first instance of start marker
     * @param endFirst if true, will end segment on first instance of end marker
     * @param <T> {@link Observation} value type
     * @return a {@link UnaryTransform} which segments a {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * based on a start and end marker function on a segment. A marker is defined as any value that satisfies the
     * marker function.
     */
    public static <T> UnaryTransform<T,Segment<T>> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> startMarkerF,
            FilterFunction<Segment<T>> endMarkerF,
            boolean prevInclusive,
            boolean nextInclusive,
            boolean startFirst,
            boolean endFirst) {
        return new BiMarkerBasedSegmentationOnSegment<>(
                segmentTransform,startMarkerF,endMarkerF,prevInclusive,nextInclusive,startFirst,endFirst);
    }
}
