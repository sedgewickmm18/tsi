/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.join;

import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

/**
 * <p>Created on 7/21/16.</p>
 *
 * @author Joshua Rosenkranz
 */
class RightOuterJoin<LEFT,RIGHT,OUTPUT> extends BinaryTransform<LEFT,RIGHT,OUTPUT> {

    private static final long serialVersionUID = -3929446215113625139L;

    private BinaryTransform<LEFT,RIGHT,OUTPUT> transform;
    private Interpolator<LEFT> interpolator;

    RightOuterJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform){
        this.transform = transform;
        this.interpolator = GenericInterpolators.nullify();
    }

    RightOuterJoin(BinaryTransform<LEFT,RIGHT,OUTPUT> transform, Interpolator<LEFT> interpolator) {
        this.transform = transform;
        this.interpolator = interpolator;
    }

    @Override
    public ObservationCollection<OUTPUT> evaluate(long t1, long t2, boolean inclusive) {
        ObservationCollection<LEFT> left = this.getTimeSeriesLeft().getValues(t1,t2,inclusive);
        ObservationCollection<RIGHT> right = this.getTimeSeriesRight().getValues(t1,t2,inclusive);

        TSBuilder<LEFT> leftTsBuilder = Observations.newBuilder();
        TSBuilder<RIGHT> rightTsBuilder = Observations.newBuilder();

        right.forEach(tss -> {
            if(!left.contains(tss.getTimeTick())) {
                leftTsBuilder.add(new Observation<>(tss.getTimeTick(),interpolator.interpolate(JoinUtils.getHistory(interpolator.getHistorySize(),tss.getTimeTick(),left),JoinUtils.getFuture(interpolator.getFutureSize(),tss.getTimeTick(),left),tss.getTimeTick())));
                rightTsBuilder.add(tss);
            }
        });

        ObservationCollection<LEFT> leftResult = leftTsBuilder.result();
        ObservationCollection<RIGHT> rightResult = rightTsBuilder.result();

        TimeSeries<LEFT> leftSI = TimeSeries.fromObservations(leftResult);
        TimeSeries<RIGHT> rightSI = TimeSeries.fromObservations(rightResult);
        return leftSI.transform(rightSI, transform)
                .getValues(rightResult.first().getTimeTick(),rightResult.last().getTimeTick(),inclusive);
    }

    @Override
    public Object clone(){
        return new RightOuterJoin<>(transform,interpolator);
    }
}
