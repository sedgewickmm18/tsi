/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.timeseries;


import java.io.*;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.ibm.research.time_series.core.constants.*;
import com.ibm.research.time_series.core.core_transforms.general.*;
import com.ibm.research.time_series.core.core_transforms.join.*;
import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.core_transforms.segmentation.GenericSegmentationTransformers;
import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.cache.Cache;
import com.ibm.research.time_series.core.io.TimeSeriesWriter;
import com.ibm.research.time_series.core.transform.*;
import com.ibm.research.time_series.core.utils.*;
import org.apache.log4j.Logger;

import com.ibm.research.time_series.core.observation.Observation;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.util.DefaultPrettyPrinter;

/**
 * This is the abstract portrayal of lazily evaluated immutable TimeSeries.
 *
 * By lazy, we mean that this time series will only get values when explicitly asked for.
 * By immutable, we mean this time series' observations may never be directly mutated.
 *
 * <p>
 *     A TimeSeries object can either be physical(having a source) or it can be from
 *     some other TimeSeries. One can think of TimeSeries as a series where each value is an
 *     Observation in the series. TimeSeries objects have the property where, values are computed lazily
 *     meaning, execution of a TimeSeries pipeline only continues, when one asks for values
 * </p>
 *
 * <p>
 *     Note: By default, {@link TimeSeries} provides strict bounds. That is, if a range is given, only
 *     {@link Observation} within that range will be provided.
 * </p>
 *
 * @param <T> the {@link Observation} value type
 */
public abstract class TimeSeries<T> implements Serializable{

    private static final Logger logger = Logger.getLogger(TimeSeries.class);
    private static final long serialVersionUID = -4752203697984087389L;

    /**
     * This time series objects cache.
     * By default this cache is an {@link MemCache}
     *
     * This cache has the property that it always keeps highest timestamped values, in other words,
     * if the cache is full, it will first remove values from the front of the cache that have lower
     * timestamps
     */
    protected Cache<T> cache;

    /* ********* TIME SERIES ACTIONS ********* */

    /**
     * create an {@link TimeSeriesWriter} given a range
     *
     * @param t1 start range
     * @param t2 end range
     * @param inclusive inclusive flag
     * @return a new {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> write(long t1, long t2, boolean inclusive) {
        return new TimeSeriesWriter<>(getValues(t1,t2,inclusive));
    }

    /**
     * create an {@link TimeSeriesWriter} given a range
     *
     * @param t1 start range
     * @param t2 end range
     * @return a new {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> write(long t1, long t2) {
        return write(t1,t2,false);
    }

    /**
     * create an {@link TimeSeriesWriter} over the whole {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param inclusive inclusive flag
     * @return a new {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> write(boolean inclusive) {
        return new TimeSeriesWriter<>(collect(inclusive));
    }

    /**
     * create an {@link TimeSeriesWriter} over the whole {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return a new {@link TimeSeriesWriter}
     */
    public TimeSeriesWriter<T> write() {
        return write(false);
    }

    /**
     * Describe this entire {@link TimeSeries} by given back a {@link Stats} object
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return a {@link  Stats} for this {@link TimeSeries}
     */
    public Stats<T> describe() {
        return reduce(GeneralReducers.describe());
    }

    /**
     * Describe this {@link TimeSeries} between a range by given back a {@link Stats} object
     *
     * @param start start time of range
     * @param end end time of range
     * @return a {@link  Stats} for this {@link TimeSeries}
     */
    public Stats<T> describe(long start,long end) {
        return reduceRange(GeneralReducers.describe(),start,end);
    }

    /**
     * a special form of collect that reduces the entire time series to a single value using a
     * mapping function
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param f series mapping function
     * @param <T2> result value type
     * @return the result of reducing the time series to a single value
     */
    public <T2> T2 reduce(UnaryMapFunction<ObservationCollection<T>,T2> f) {
        ObservationCollection<T> collected = collect();
        return f.evaluate(collected);
    }

    /**
     * a special form of collect which reduces the entire time series to a single value using a
     * {@link UnaryReducer}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param reducer unary reducer
     * @param <T2> result value type
     * @return the result of reducing the series to a single value
     */
    public <T2> T2 reduce(UnaryReducer<T,T2> reducer) {
        ObservationCollection<T> collected = collect();

        Segment<T> segment = Segment.fromSeries(collected);
        return reducer.reduceSegment(segment);
    }

    /**
     * a special form of collect which reduces the time series from range between start and end to
     * a single value using a {@link UnaryReducer}
     *
     * @param reducer unary reducer
     * @param start starting timestamp
     * @param end ending timestamp
     * @param <T2> result value type
     * @return the result of reducing the series to a single value
     */
    public <T2> T2 reduceRange(UnaryReducer<T,T2> reducer, long start, long end) {
        return reduceRange(reducer,start,end,false);
    }

    /**
     * a special form of collect which reduces the time series from range between start and end to
     * a single value using a {@link UnaryReducer}
     *
     * @param reducer unary reducer
     * @param start starting timestamp
     * @param end ending timestamp
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @param <T2> result value type
     * @return the result of reducing the series to a single value
     */
    public <T2> T2 reduceRange(UnaryReducer<T,T2> reducer, long start, long end,boolean inclusive) {
        ObservationCollection<T> collected = getValues(start,end,inclusive);

        Segment<T> segment = Segment.fromSeries(collected);

        return reducer.reduceSegment(segment);
    }

    /**
     * a special form of collect which reduces two time series to a single value using a
     * {@link BinaryReducer}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param other other time series
     * @param reducer binary reducer
     * @param <T2> other time series observation value type
     * @param <T3> result value type
     * @return the result of reducing two time series to a single value
     */
    public <T2,T3> T3 reduce(TimeSeries<T2> other, BinaryReducer<T,T2,T3> reducer) {
        Segment<T> segment = Segment.fromSeries(collect());
        Segment<T2> otherSegment = Segment.fromSeries(other.collect());
        return reducer.reduceSegment(segment,otherSegment);
    }

    /**
     * a special form of collect which reduces two time series from ranges between start and end to
     * a single value using a {@link BinaryReducer}
     *
     * @param other other time series
     * @param reducer binary reducer
     * @param start starting timestamp
     * @param end ending timestamp
     * @param <T2> other time series observation value type
     * @param <T3> result value type
     * @return the result of reducing two time series to a single value
     */
    public <T2,T3> T3 reduceRange(TimeSeries<T2> other, BinaryReducer<T,T2,T3> reducer, long start, long end) {
        Segment<T> segment = Segment.fromSeries(getValues(start,end));
        Segment<T2> otherSegment = Segment.fromSeries(other.getValues(start,end));
        return reducer.reduceSegment(segment,otherSegment);
    }

    /**
     * a special form of collect which reduces n time series to a single value using an
     * NaryReducer
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param tsList list of time series
     * @param reducer nary reducer
     * @param <T2> result value type
     * @return the result of reducing n time series to a single value
     */
    public <T2> T2 reduce(List<TimeSeries<T>> tsList,NaryReducer<T,T2> reducer) {
        List<TimeSeries<T>> allTS = new ArrayList<>(tsList);
        allTS.add(this);

        List<Segment<T>> segmentList = allTS.stream()
                .map(ts -> Segment.fromSeries(ts.collect()))
                .collect(Collectors.toList());

        return reducer.reduceSegment(segmentList);
    }

    /**
     * a special form of collect which reduces n time series from ranges between start and end to a
     * single value using an NaryReducer
     *
     * @param tsList list of time series
     * @param reducer nary reducer
     * @param start starting timestamp
     * @param end ending timestamp
     * @param <T2> result value type
     * @return the result of reducing n time series to a single value
     */
    public <T2> T2 reduceRange(List<TimeSeries<T>> tsList,NaryReducer<T,T2> reducer, long start,long end) {
        List<TimeSeries<T>> allTS = new ArrayList<>(tsList);
        allTS.add(this);

        List<Segment<T>> segmentList = allTS.stream()
                .map(ts -> Segment.fromSeries(ts.getValues(start,end)))
                .collect(Collectors.toList());

        return reducer.reduceSegment(segmentList);
    }

    /**
     * Get a count of all {@link Observation} in the entire range of this {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return the count of all {@link Observation}
     */
    public long count() {
        return count(false);
    }

    /**
     * Get a count of all {@link Observation} in the entire range of this {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return the count of all {@link Observation}
     */
    public long count(boolean inclusive) {
        return collect(inclusive).size();
    }

    /**
     * Get a count of all {@link Observation} in the given range of this {@link TimeSeries}
     *
     * @param start start timetick of range
     * @param end end timetick of range
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return the count of all {@link Observation} in the range given
     */
    public long countRange(long start,long end,boolean inclusive) {
        return getValues(start,end,inclusive).size();
    }

    /**
     * Get a count of all {@link Observation} in the given range of this {@link TimeSeries}
     *
     * @param start start timetick of range
     * @param end end timetick of range
     * @return the count of all {@link Observation} in the range given
     */
    public long countRange(long start,long end) {
        return countRange(start,end,false);
    }

    /**
     * Get a count of all {@link Observation} in the given range of this {@link TimeSeries}
     *
     * @param start start time
     * @param end end time
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return the count of all {@link Observation} in the range given
     */
    public long countRange(ZonedDateTime start, ZonedDateTime end, boolean inclusive) {
        return getValues(start,end,inclusive).size();
    }

    /**
     * Get a count of all {@link Observation} in the given range of this {@link TimeSeries}
     *
     * @param start start time
     * @param end end time
     * @return the count of all {@link Observation} in the range given
     */
    public long countRange(ZonedDateTime start, ZonedDateTime end) {
        return countRange(start,end,false);
    }

    /**
     * collect this entire {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @return an immutable {@link ObservationCollection} containing all observations from this Time Series
     */
    public ObservationCollection<T> collect() {
        return collect(false);
    }

    /**
     * collect this entire {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     *
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return an {@link ObservationCollection} containing all observations from this Time Series
     */
    public ObservationCollection<T> collect(boolean inclusive) {
        List<Pair<Pair<Long,Long>, TRS>> list = new ArrayList<>();
        mineForBounds(list);

        long min = list.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongLower(x.left.left)) : x.left.left).min().orElse(Long.MIN_VALUE);
        long max = list.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongUpper(x.left.right)) : x.left.right).max().orElse(Long.MAX_VALUE);

        return getValues(min,max,inclusive);
    }

    //todo experimental
    public abstract void printDAG();

    //experimental

    /**
     * Collect the most recent observations and process them (if no observations exists in a given window, nothing will
     * be executed for that window)
     *
     * @param howOften how often to poll for newest values
     * @param processSeriesOp process the incoming observations
     * @param stopConditionOp condition to stop polling
     */
    @Deprecated
    public void poll(long howOften, Consumer<ObservationCollection<T>> processSeriesOp, Function<ObservationCollection<T>,Boolean> stopConditionOp) {
        pollWithState(
                null,
                howOften,
                (x,y) -> {
                    processSeriesOp.accept(x);
                    return null;
                },
                (x,y) -> stopConditionOp.apply(x)
        );
    }

    /**
     * Collect the most recent observations and process them (if no observations exists in a given window, nothing will
     * be executed for that window)
     *
     * Note: This must be forced to stop
     *
     * @param howOften how often to poll for newest values
     * @param processSeriesOp process the incoming observations
     */
    @Deprecated
    public void poll(long howOften, Consumer<ObservationCollection<T>> processSeriesOp) {
        poll(howOften,processSeriesOp,x -> false);
    }

    /**
     * Collect the most recent observations and process them while also holding a state (if no observations exists in a
     * given window, nothing will be executed for that window)
     *
     * @param zeroState the initial state
     * @param howOften how often to poll for newest values
     * @param processSeriesOp process the incoming observations and return a state
     * @param stopConditionOp condition to stop polling
     * @param <STATE> type of state
     */
    @Deprecated
    public <STATE> void pollWithState(STATE zeroState, long howOften, BiFunction<ObservationCollection<T>,STATE,STATE> processSeriesOp, BiFunction<ObservationCollection<T>,STATE,Boolean> stopConditionOp) {
        Executors.newSingleThreadExecutor().execute(() -> {
            long lastTimestampProcessed = -1;
            STATE currentState = zeroState;
            while (true) {
                try {
                    Thread.sleep(howOften);
                    ObservationCollection<T> current;
                    List<Pair<Pair<Long,Long>, TRS>> bounds = new ArrayList<>();
                    mineForBounds(bounds);
                    OptionalLong optMax = bounds.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongUpper(x.left.right)) : x.left.right).max();
                    if (lastTimestampProcessed == -1) {
                        if (optMax.isPresent() && optMax.getAsLong() == Long.MAX_VALUE) {
                            continue;
                        }
                        current = collect();
                        if (current.isEmpty()) continue;
                        else lastTimestampProcessed = optMax.orElse(-1);
                    } else {
                        if (optMax.isPresent()) {
                            if (optMax.getAsLong() == lastTimestampProcessed) continue;
                            else {
                                current = getValues(lastTimestampProcessed + 1,optMax.getAsLong());
                                lastTimestampProcessed = optMax.getAsLong();
                            }
                        } else {
                            continue;
                        }
                    }
                    if (stopConditionOp.apply(current,currentState)) break;
                    else currentState = processSeriesOp.apply(current,currentState);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private long lastPolledTimestamp = -1;

    /**
     * Collect the latest observations in the time series (based on time)
     *
     * @return the latest observations, if none exist, return an empty {@link ObservationCollection}
     */
    @Deprecated
    public ObservationCollection<T> poll() {
        ObservationCollection<T> current = null;
        List<Pair<Pair<Long,Long>,TRS>> bounds = new ArrayList<>();
        mineForBounds(bounds);
        OptionalLong optMax = bounds.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongUpper(x.left.right)) : x.left.right).max();
        if (lastPolledTimestamp == -1) {
            if (optMax.isPresent() && optMax.getAsLong() == Long.MAX_VALUE) {
                return Observations.empty();
            }
            current = collect();
            if (!current.isEmpty()) {
                lastPolledTimestamp = optMax.orElse(-1);
            }
        } else {
            if (optMax.isPresent()) {
                if (optMax.getAsLong() != lastPolledTimestamp) {
                    current = getValues(lastPolledTimestamp + 1,optMax.getAsLong());
                    lastPolledTimestamp = optMax.getAsLong();
                }
            }
        }
        return (current == null) ? Observations.empty() : current;
    }



    /**
     * Collect the most recent observations and process them while also holding a state (this will not terminate unless
     * explicitly killed)
     *
     * @param zeroState the initial state
     * @param howOften how often to poll for newest values
     * @param processSeriesOp process the incoming observations and return a state
     * @param <STATE> type of state
     */
    @Deprecated
    public <STATE> void pollWithState(STATE zeroState, long howOften, BiFunction<ObservationCollection<T>,STATE,STATE> processSeriesOp) {
        pollWithState(zeroState,howOften,processSeriesOp,(x,y) -> true);
    }

    /**
     * mines for the timetick bounds of this time series
     *
     * <p>This method traverses the DAG to all source time series to find the minimum and maximum
     * timeticks</p>
     *
     * @param bounds mutable reference list of minimum and maximum bounds
     */
    protected abstract void mineForBounds(List<Pair<Pair<Long, Long>, TRS>> bounds);

    /**
     * gets the evaluated series of {@link Observation} between a given time range
     *
     * @param t1 time tick start
     * @param t2 time tick end
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return an immutable {@link ObservationCollection} containing all {@link Observation} in this time series from
     * the given range
     */
    public ObservationCollection<T> getValues(long t1, long t2,boolean inclusive) {
        return computeValues(t1, t2, inclusive);
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @return an immutable {@link ObservationCollection} containing all {@link Observation} in this time series from
     * the given range
     */
    public ObservationCollection<T> getValues(long t1, long t2) {
        return getValues(t1, t2, false);
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range
     *
     * @param start start time
     * @param end end time
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return an immutable {@link ObservationCollection} containing all {@link Observation} in this time series from
     * the given range
     */
    public ObservationCollection<T> getValues(ZonedDateTime start, ZonedDateTime end, boolean inclusive) {
        if (trs == null) {
            return getValues(convertToEpoch(start,TimeUnit.MILLISECONDS),convertToEpoch(end,TimeUnit.MILLISECONDS),inclusive);
        } else {
            return getValues(trs.toIndex(start), trs.toIndex(end), inclusive);
        }
    }

    /**
     * gets the evaluated series of {@link Observation} between a given time range
     *
     * @param start start time
     * @param end end time
     * @return an immutable {@link ObservationCollection} containing all {@link Observation} in this time series from
     * the given range
     */
    public ObservationCollection<T> getValues(ZonedDateTime start, ZonedDateTime end) {
        return getValues(start,end,false);
    }

    /**
     * Print this entire {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     * <p>
     *     Note: This method will provide human readable Timestamp if an {@link TRS} exists for this {@link TimeSeries}
     * </p>
     */
    public void print() {
        print(false, true);
    }

    /**
     * Print this entire {@link TimeSeries}
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     * <p>
     *     Note: This method will provide human readable Timestamp if an {@link TRS} exists for this {@link TimeSeries}
     * </p>
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @param humanReadable if true and a {@link TRS} exists in this {@link TimeSeries}, human readable Timestamps will
     *                      be displayed, otherwise long time ticks will be displayed
     */
    public void print(boolean inclusive, boolean humanReadable) {
        ObservationCollection<T> series = this.collect(inclusive);
        series.forEach(obs -> {
            System.out.println((humanReadable) ? obs.toString(trs) : obs.toString());
        });
    }

    /**
     * Collect this entire {@link TimeSeries} and produce a String
     *
     * <p>Note: This will infer the bounds based on the {@link TimeSeriesReader} start and end time</p>
     * <p>
     *     Note: This method will provide human readable Timestamp if an {@link TRS} exists for this {@link TimeSeries}
     * </p>
     * @return A String representation of this {@link TimeSeries}
     */
    @Override
    public String toString() {
        if (trs == null) {
            return this.collect().stream().map(Observation::toString).collect(Collectors.joining("\n"));
        } else {
            return this.collect().stream().map(x -> x.toString(trs)).collect(Collectors.joining("\n"));
        }
    }


    /**
     * Print this {@link TimeSeries} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     */
    public void print(long t1, long t2){
        print(t1,t2,false);
    }


    /**
     * Print this {@link TimeSeries} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     */
    public void print(long t1, long t2,boolean inclusive){
        print(t1,t2,inclusive,true);
    }

    /**
     * Print this {@link TimeSeries} between a given time range
     *
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @param humanReadable if true and a {@link TRS} exists in this {@link TimeSeries}, human readable Timestamps will
     *                      be displayed, otherwise long time ticks will be displayed
     */
    public void print(long t1, long t2,boolean inclusive, boolean humanReadable){
        //x = (time - offset) / tt
        // tt * x + offset = time
        ObservationCollection<T> ts_values = this.getValues(t1,t2,inclusive);

        ts_values.forEach(obs -> {
            System.out.println((humanReadable) ? obs.toString(trs) : obs.toString());
        });
    }

    /**
     * Print this {@link TimeSeries} between a given time range
     *
     * @param start starting time
     * @param end ending time
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     */
    public void print(
            ZonedDateTime start,
            ZonedDateTime end,
            boolean inclusive){
        if (trs == null) {
            print(convertToEpoch(start, TimeUnit.MILLISECONDS), convertToEpoch(end, TimeUnit.MILLISECONDS), inclusive);
        } else {
            print(trs.toIndex(start), trs.toIndex(end),inclusive);
        }
    }

    /**
     * Print this {@link TimeSeries} between a given time range
     *
     * @param start starting time
     * @param end ending time
     */
    public void print(ZonedDateTime start, ZonedDateTime end){
        print(start,end,false);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model, double confidence) {
        return forecast(collect(),numForecasts,model,confidence);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     * <p>
     *     Note: Training will be started based on the start time tick in the {@link TimeSeriesReader}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model) {
        return forecast(numForecasts,model,1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation} time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTimeTick the time tick where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model, long trainingStartTimeTick, double confidence) {
        model.resetModel();
        List<Pair<Pair<Long,Long>, TRS>> list = new ArrayList<>();
        mineForBounds(list);
        long end = list.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongUpper(x.left.right)) : x.left.right).max().orElse(Long.MAX_VALUE);
        final ObservationCollection<T> trainingData = getValues(trainingStartTimeTick, end);
        return forecast(trainingData, numForecasts, model, confidence);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTimeTick the time tick where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model, long trainingStartTimeTick) {
        return forecast(numForecasts, model, trainingStartTimeTick, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     * <p>
     *     Note: Confidence by default will be set to 1.0
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model, ZonedDateTime trainingStartTime) {
        return forecast(numForecasts, model, trainingStartTime, 1.0);
    }

    /**
     * Get the next numForecast {@link Observation} using a {@link ObservationForecastingModel}
     *
     * <p>
     *     Note: The {@link Observation time ticks produced will be based on the average inter-arrival time of this
     *     {@link TimeSeries}}
     * </p>
     *
     * @param numForecasts the number of {@link Prediction} to produce
     * @param model the {@link ObservationForecastingModel} to be in forecasting
     * @param trainingStartTime the time where the {@link ObservationForecastingModel} should start training
     * @param confidence the confidence to be used in calculating a confidence interval
     * @return an immutable {@link ObservationCollection} of the next numForecast {@link Prediction}
     */
    public ObservationCollection<Prediction<T>> forecast(int numForecasts, ObservationForecastingModel<T> model, ZonedDateTime trainingStartTime, double confidence) {
        long resultStart;
        if (trs == null) {
            resultStart = convertToEpoch(trainingStartTime,TimeUnit.MILLISECONDS);
        } else {
            resultStart = trs.toIndex(trainingStartTime);
        }
        return forecast(numForecasts, model, resultStart, confidence);
    }

    private ObservationCollection<Prediction<T>> forecast(ObservationCollection<T> trainingData, int numForecasts, ObservationForecastingModel<T> model, double confidence) {
        model.resetModel();
        if (!model.trainModel(trainingData)) {
            throw new TSRuntimeException("the model did not have enough data to train and therefore cannot produce predictions");
        } else {
            return model.predict(numForecasts, confidence);
        }
    }

    /* ********* transform ********* */

    /**
     * Create a new {@link TimeSeries} that is the product of performing a {@link UnaryTransform} over the current
     * {@link TimeSeries}
     *
     * @param unaryTransform the {@link UnaryTransform}
     * @param <T2> output {@link Observation} value type
     * @return a newly transformed {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> transform(UnaryTransform<T,T2> unaryTransform) {
        UnaryTransform<T,T2> newTransform = null;
        try {
            newTransform = (UnaryTransform<T,T2>)unaryTransform.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this);
        TimeSeries<T2> result = new UDerivedTimeSeries<>(newTransform);
        result.trs = trs;
        return result;
    }

    /**
     * Create a new {@link TimeSeries} that is the product of performing a {@link BinaryTransform} over the current
     * {@link TimeSeries} and some other {@link TimeSeries}
     *
     * @param otherTimeSeries the other {@link TimeSeries}
     * @param binaryTransform the {@link BinaryTransform}
     * @param <T2> other time series observation value type
     * @param <T3> output {@link Observation} value type
     * @return a newly transformed {@link TimeSeries}
     */
    public <T2,T3> TimeSeries<T3> transform(
            TimeSeries<T2> otherTimeSeries,
            BinaryTransform<T,T2,T3> binaryTransform) {

        BinaryTransform<T,T2,T3> newTransform = null;
        try {
            newTransform = (BinaryTransform<T,T2,T3>)binaryTransform.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this,otherTimeSeries);
        TimeSeries<T3> result = new BDerivedTimeSeries<>(newTransform);
        result.trs = trs;
        return result;
    }

    /**
     * Create a new {@link TimeSeries} that is the product of performing a {@link NaryTransform} on the current
     * {@link TimeSeries} and some list of {@link TimeSeries}
     *
     * @param listTimeSeries list of {@link TimeSeries}
     * @param naryTransform a {@link NaryTransform}
     * @param <T2> output {@link Observation} value type
     * @return a newly transformed {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> transform(
            List<TimeSeries<T>> listTimeSeries,
            NaryTransform<T,T2> naryTransform) {

        NaryTransform<T,T2> newTransform = null;
        try {
            newTransform = (NaryTransform<T,T2>) naryTransform.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this,listTimeSeries);
        TimeSeries<T2> result = new NDerivedTimeSeries<>(newTransform);
        result.trs = trs;
        return result;
    }

    /* ********* general time series operations ********* */

    /**
     * lag the current {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code lag(2)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param lag number of time ticks to lag the {@link TimeSeries}
     * @return a newly lagged {@link TimeSeries}
     */
    public TimeSeries<T> lag(long lag) {
        return transform(GeneralTransformers.lag(lag));
    }

    /**
     * shift the current {@link TimeSeries} values by the given shift amount, padding extra {@link Observation} with a
     * default value.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code shift(2,0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,0),Observation(2,0),Observation(3,1),Observation(4,2),Observation(5,3)]</p>
     *     </li>
     * </ul>
     *
     * @param shift number of time ticks to shift series values by
     * @param defaultValue the default value to set for missing values
     * @return a newly shifted {@link TimeSeries}
     */
    public TimeSeries<T> shift(int shift,T defaultValue) {
        return transform(GeneralTransformers.shift(shift,defaultValue));
    }

    /**
     * fill null values in the {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,Double.NaN),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code fillna(GenericInterpolators.next(), Double.NaN)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,4),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param interpolator the interpolator method to be used when a value is null
     * @param nullValue denotes a null value, for instance if nullValue = Double.NaN, Double.NaN would be filled
     * @return a new {@link TimeSeries} with null values filled
     */
    public TimeSeries<T> fillna(Interpolator<T> interpolator, T nullValue) {
        return transform(GeneralTransformers.fillNA(interpolator,nullValue));
    }

    /**
     * fill null values in the {@link TimeSeries} where nullValue is default to null
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,null),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code fillna(GenericInterpolators.next())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,4),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param interpolator the interpolator method to be used when a value is null
     * @return a new {@link TimeSeries} with null values filled
     */
    public TimeSeries<T> fillna(Interpolator<T> interpolator) {
        return fillna(interpolator, null);
    }

    /**
     * fill null values in the {@link TimeSeries} where nullValue is default to null and a generic value fill method is
     * always used
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,null),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code fillna(0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,0),Observation(4,4),Observation(5,5)]</p>
     *     </li>
     * </ul>
     *
     * @param value value to be filled when a value is null
     * @return a new {@link TimeSeries} with null values filled
     */
    public TimeSeries<T> fillna(T value) {
        return transform(GeneralTransformers.fillNA(GenericInterpolators.fill(value)));
    }

    /**
     * resample the {@link TimeSeries} to a given periodicity
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2,2),Observation(4,4),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code resample(1, 0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(3,0),Observation(4,4),Observation(5,0),Observation(6,6)]</p>
     *     </li>
     * </ul>
     *
     * @param periodicity the time tick periodicity to resample at
     * @param fillValue the value to fill when a value does not exist at a given time tick
     * @return a new periodic {@link TimeSeries}
     */
    public TimeSeries<T> resample(long periodicity, T fillValue) {
        return transform(GeneralTransformers.interpolate(periodicity, GenericInterpolators.fill(fillValue), true));
    }

    /**
     * resample the {@link TimeSeries} to a given periodicity
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2,2),Observation(4,4),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code resample(1, GenericInterpolators.prev())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(3,2),Observation(4,4),Observation(5,4),Observation(6,6)]</p>
     *     </li>
     * </ul>
     *
     * @param periodicity the time tick periodicity to resample at
     * @param interpolator the interpolation method to be used when a value does not exist for a given time tick
     * @return a new periodic {@link TimeSeries}
     */
    public TimeSeries<T> resample(long periodicity, Interpolator<T> interpolator) {
        return transform(GeneralTransformers.interpolate(periodicity, interpolator,true));
    }

    /**
     * filter the {@link TimeSeries} by each {@link Observation}'s value
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code filter(x -> x % 2 == 0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,2),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param filterFunction the filter function to be used
     * @return a new {@link TimeSeries} with {@link Observation}'s filtered based on {@link Observation} value
     */
    public TimeSeries<T> filter(FilterFunction<T> filterFunction){
        return transform(MapTransformers.filter(filterFunction));
    }

    // ***************    Unary Segmentation    ***************

    /**
     * creates a {@link SegmentTimeSeries} from a segmentation transform ({@link UnaryTransform} that is
     * of type {@code T -> {@link Segment}<T>})
     *
     * @param segmenter unary transform that results in time series of segments
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> toSegments(UnaryTransform<T,Segment<T>> segmenter) {
        UnaryTransform<T,Segment<T>> newTransform = null;
        try {
            newTransform = (UnaryTransform<T,Segment<T>>)segmenter.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        newTransform.setOperationOn(this);
        SegmentTimeSeries<T> result = new SegmentTimeSeries<>(newTransform);
        result.trs = trs;
        return result;
    }

    /**
     * segment the {@link TimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(3,3),Observation(6,6),Observation(7,7)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3,2,false)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(Observation(1,1),Observation(3,3),Observation(6,6)),
     *             Segment(Observation(6,6),Observation(7,7))]
     *         </p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3,2,true)}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Segment(Observation(1,1),Observation(3,3),Observation(6,6))]</p>
     *     </li>
     * </ul>
     *
     * @param window window size
     * @param step step size
     * @param enforceSize enforce that size is always of size window
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segment(long window, long step,boolean enforceSize) {
        return toSegments(GenericSegmentationTransformers.segment(window,step,enforceSize));
    }

    /**
     * segment the {@link TimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>Note: each segment will be enforced to be of size window</p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(3,3),Observation(6,6),Observation(7,7)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3,2)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Segment(Observation(1,1),Observation(3,3),Observation(6,6))]</p>
     *     </li>
     * </ul>
     *
     * @param window window size
     * @param step step size
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segment(long window, long step) {
        return toSegments(GenericSegmentationTransformers.segment(window,step,true));
    }

    /**
     * segment the {@link TimeSeries} based on a sliding window over the {@link TimeSeries}
     *
     * <p>Note: each segment will be enforced to be of size window and step will be 1</p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(3,3),Observation(6,6),Observation(7,7)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segment(3)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(Observation(1,1),Observation(3,3),Observation(6,6)),
     *             Segment(Observation(3,3),Observation(6,6),Observation(7,7))]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param window window size
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segment(long window) {
        return segment(window,1);
    }

    /**
     * segment the {@link TimeSeries} based on a sliding time window over the {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByTime(1 hour,1 hour)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=12:00,end=12:59,Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)),
     *             Segment(start=1:00,end=1:59,Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)),
     *             Segment(start=2:00,end=2:59,Observation(2:00,5))]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param window window size in time ticks
     * @param step step size in time ticks
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByTime(long window, long step) {
        return segmentByTime(window,step,Padding.NONE,ResultingTimeStamp.START_OF_WINDOW);
    }

    /**
     * segment the {@link TimeSeries} based on a sliding time window over the {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByTime(1 hour,1 hour,Padding.LEFT,ResultingTimeStamp.END_OF_WINDOW)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(timestamp=12:00,start=11:00:01,end=12:00,[Observation(12:00,1)]),
     *             Segment(timestamp=1:00,start=12:00:01,end=1:00,[Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(timestamp=2:00,start=1:00:01,end=2:00,[Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param window window size in time ticks
     * @param step step size in time ticks
     * @param padding padding type {@link Padding}
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByTime(
            long window,
            long step,
            Padding padding) {
        return toSegments(GenericSegmentationTransformers.segmentByTime(window,step,padding,ResultingTimeStamp.START_OF_WINDOW));
    }


    /**
     * segment the {@link TimeSeries} based on a sliding time window over the {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByTime(1 hour,1 hour,Padding.LEFT,ResultingTimeStamp.END_OF_WINDOW)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(timestamp=12:00,start=11:00:01,end=12:00,[Observation(12:00,1)]),
     *             Segment(timestamp=1:00,start=12:00:01,end=1:00,[Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(timestamp=2:00,start=1:00:01,end=2:00,[Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param window window size in time ticks
     * @param step step size in time ticks
     * @param padding padding type {@link Padding}
     * @param resultingTimeStamp resulting timestamp {@link ResultingTimeStamp}
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByTime(
            long window,
            long step,
            Padding padding,
            ResultingTimeStamp resultingTimeStamp) {
        return toSegments(GenericSegmentationTransformers.segmentByTime(window,step,padding,resultingTimeStamp));
    }

    /**
     * segment the {@link TimeSeries} based on building segments around anchor points. An anchor point is defined
     * as any value that satisfies the isAnchorF filter function. When an anchor point is determined the
     * {@link Segment} is built based on leftDelta time ticks to the left of the point and rightDelta time ticks to the
     * right of the point.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByAnchor(x -> x % 2 == 0,1 hour, 30 minutes)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isAnchorF anchor function
     * @param leftDelta left delta time ticks to the left of the anchor point
     * @param rightDelta right delta time ticks to the right of the anchor point
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByAnchor(
            FilterFunction<T> isAnchorF,
            long leftDelta,
            long rightDelta) {
        return toSegments(GenericSegmentationTransformers.segmentByAnchor(isAnchorF,leftDelta,rightDelta));
    }

    /**
     * segment the {@link TimeSeries} based on building segments around anchor points. An anchor point is defined
     * as any value that satisfies the isAnchorF filter function. When an anchor point is determined the
     * segment is built based on leftDelta time to the left of the point and rightDelta time to the
     * right of the point.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByAnchor(x -> x % 2 == 0,1 hour, 30 minutes)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isAnchorF anchor function
     * @param leftDelta left delta time ticks to the left of the anchor point
     * @param rightDelta right delta time ticks to the right of the anchor point
     * @param perc number between 0 and 1.0 to denote how often to accept the anchor
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByAnchor(
            FilterFunction<T> isAnchorF,
            long leftDelta,
            long rightDelta,
            double perc) {
        return toSegments(GenericSegmentationTransformers.segmentByAnchor(isAnchorF,leftDelta,rightDelta,perc));
    }

    /**
     * segment the {@link TimeSeries} based on a change-point. A change-point can be defined as any change in 2 values
     * that results in a true statement.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,a),Observation(12:30,a),Observation(1:00,b),Observation(1:30,b),Observation(2:00,c)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByChangePoint((x,y) -> !x.equals(y))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isChangeOp a function given a prev/next value to determine if a change exists
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByChangePoint(BinaryMapFunction<T,T,Boolean> isChangeOp) {
        return toSegments(GenericSegmentationTransformers.segmentByChangePoint(isChangeOp));
    }

    /**
     * segment the {@link TimeSeries} on an equality based change-point
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,a),Observation(12:30,a),Observation(1:00,b),Observation(1:30,b),Observation(2:00,c)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByChangePoint()}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=11:30,end=1:00,[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3)]),
     *             Segment(start=12:30,end=2:00,[Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByChangePoint() {
        return segmentByChangePoint((x,y) -> !x.equals(y));
    }

    /**
     * segment the time-series based on a marker function on a segment. A marker is defined as any value that satisfies
     * the isMarkerF function.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByMarker(GenericSegmentationTransformers.segment(2,1,true), s -> s.first().getValue() % 2 == 0, true, false)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=1,end=2,[Observation(1,1),Observation(2,2)]),
     *             Segment(start=3,end=4,[Observation(3,3),Observation(4,4)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param segmentTransform segmentation transform used to create markers
     * @param isMarkerF the marker function
     * @param prevInclusive if true, will include values from starting marker, otherwise values will not be included in
     *                      segment
     * @param nextInclusive if true, will include values from ending marker, otherwise values will not be included in
     *                      segment
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> isMarkerF,
            boolean prevInclusive,
            boolean nextInclusive) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(segmentTransform,isMarkerF,prevInclusive,nextInclusive));
    }

    /**
     * segment the time-series based on a marker function on a segment. A marker is defined as any value that satisfies
     * the isMarkerF function. By default prevInclusive is false and nextInclusive is true.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByMarker(GenericSegmentationTransformers.segment(2,1,true), s -> s.first().getValue() % 2 == 0, true, false)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=1,end=2,[Observation(1,1),Observation(2,2)]),
     *             Segment(start=3,end=4,[Observation(3,3),Observation(4,4)])]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param segmentTransform segmentation transform used to create markers
     * @param isMarkerF the marker function
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> isMarkerF) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(segmentTransform,isMarkerF,false,true));
    }

    /**
     * segment the time-series based on a start and end marker function on a segment. A marker is defined as any value
     * that satisfies the isMarkerF function.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *      segmentByMarker(
     *          GenericSegmentationTransformers.segment(2,1,true),
     *          s -> s.first().getValue() % 2 == 0 && s.first().getValue() != 4,
     *          s -> s.first().getValue() % 5 == 0 && s.first().getValue() != 0,
     *          false,
     *          true,
     *          false,
     *          true
     *      )}
     *  </pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [(4,Segment(start=4,end=6,[Observation(4,4),Observation(5,5),Observation(6,6)]))]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param segmentTransform segmentation transform used to create markers
     * @param isStartMarkerF the start marker function
     * @param isEndMarkerF the end marker function
     * @param startInclusive if true, will include values from starting marker, otherwise values will not be included in
     *                      segment
     * @param endInclusive if true, will include values from ending marker, otherwise values will not be included in
     *                      segment
     * @param startOnFirst if true, will start segment on first instance of start marker
     * @param endOnFirst if true, will end segment on first instance of end marker
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> isStartMarkerF,
            FilterFunction<Segment<T>> isEndMarkerF,
            boolean startInclusive,
            boolean endInclusive,
            boolean startOnFirst,
            boolean endOnFirst) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(segmentTransform,isStartMarkerF,isEndMarkerF,startInclusive,endInclusive,startOnFirst,endOnFirst));
    }

    /**
     * segment the time-series based on a start and end marker function on a segment. A marker is defined as any value
     * that satisfies the isMarkerF function. By default, prevInclusive=false, nextInclusive=true, startFirst=false,
     * endFirst=true.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *      segmentByMarker(
     *          GenericSegmentationTransformers.segment(2,1,true),
     *          s -> s.first().getValue() % 2 == 0 && s.first().getValue() != 4,
     *          s -> s.first().getValue() % 5 == 0 && s.first().getValue() != 0
     *      )}
     *  </pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [(4,Segment(start=4,end=6,[Observation(4,4),Observation(5,5),Observation(6,6)]))]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param segmentTransform segmentation transform used to create markers
     * @param isStartMarkerF the start marker function
     * @param isEndMarkerF the end marker function
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(
            UnaryTransform<T,Segment<T>> segmentTransform,
            FilterFunction<Segment<T>> isStartMarkerF,
            FilterFunction<Segment<T>> isEndMarkerF) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(segmentTransform,isStartMarkerF,isEndMarkerF,false,true,false,true));
    }

    /**
     * segment the time-series based on a marker function. A marker is defined as any value that satisfies
     * the isMarkerF function. By default prevInclusive=false, nextInclusive=true, requiresStartAndEnd=false.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByMarker(s -> s % 2 == 0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 0     Value: original bounds: (0,1) actual bounds: (0,1) observations: [(0,0),(1,1)]
     *             TimeStamp: 2     Value: original bounds: (2,3) actual bounds: (2,3) observations: [(2,2),(3,3)]
     *             TimeStamp: 4     Value: original bounds: (4,5) actual bounds: (4,5) observations: [(4,4),(5,5)]
     *             TimeStamp: 6     Value: original bounds: (6,6) actual bounds: (6,6) observations: [(6,6)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isMarkerF the marker function
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> isMarkerF) {
        return segmentByMarker(isMarkerF, false, true, false);
    }

    /**
     * segment the time-series based on a marker function. A marker is defined as any value that satisfies
     * the isMarkerF function. By default requiresStartAndEnd=false.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByMarker(s -> s % 2 == 0), true, false}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 0     Value: original bounds: (0,0) actual bounds: (0,0) observations: [(0,0)]
     *             TimeStamp: 1     Value: original bounds: (1,2) actual bounds: (1,2) observations: [(1,1),(2,2)]
     *             TimeStamp: 3     Value: original bounds: (3,4) actual bounds: (3,4) observations: [(3,3),(4,4)]
     *             TimeStamp: 5     Value: original bounds: (5,6) actual bounds: (5,6) observations: [(5,5),(6,6)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isMarkerF the marker function
     * @param prevInclusive if true, will include the marker to the previous segment
     * @param nextInclusive if true, will include the marker to the next segment
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> isMarkerF, boolean prevInclusive, boolean nextInclusive) {
        return segmentByMarker(isMarkerF, prevInclusive,nextInclusive,false);
    }

    /**
     * segment the time-series based on a marker function. A marker is defined as any value that satisfies
     * the isMarkerF function.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentByMarker(s -> s % 2 == 0), true, false, true}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 0     Value: original bounds: (0,1) actual bounds: (0,1) observations: [(0,0),(1,1)]
     *             TimeStamp: 2     Value: original bounds: (2,3) actual bounds: (2,3) observations: [(2,2),(3,3)]
     *             TimeStamp: 4     Value: original bounds: (4,5) actual bounds: (4,5) observations: [(4,4),(5,5)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param isMarkerF the marker function
     * @param prevInclusive if true, will include the marker to the previous segment
     * @param nextInclusive if true, will include the marker to the next segment
     * @param requiresStartAndEnd if true, a segment will only be created if encapsulated by 2 markers (a start and end)
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> isMarkerF, boolean prevInclusive, boolean nextInclusive, boolean requiresStartAndEnd) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(isMarkerF, prevInclusive, nextInclusive, requiresStartAndEnd));
    }

    /**
     * segment the time-series based on a start and end marker function. A marker is defined as any value that satisfies
     * the isMarkerF function.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *      segmentByMarker(
     *          x -> x % 2 == 0 && x != 4,
     *          x -> x % 5 == 0 && x != 0,
     *          true,
     *          true,
     *          false,
     *          true
     *      )}
     *  </pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 2     Value: original bounds: (2,5) actual bounds: (2,5) observations: [(2,2),(3,3),(4,4),(5,5)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param startOp the start marker function
     * @param endOp the end marker function
     * @param startInclusive if true, will include the start marker to the segment
     * @param endInclusive if true, will include the end marker to the segment
     * @param startOnFirst if true, will start the segment on the first instance of the start marker before an end
     *                     marker
     * @param endOnFirst if true, will end the segment on the first instance of the end marker after a start
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> startOp, FilterFunction<T> endOp, boolean startInclusive, boolean endInclusive, boolean startOnFirst, boolean endOnFirst) {
        return toSegments(GenericSegmentationTransformers.segmentByMarker(startOp,endOp,startInclusive,endInclusive,startOnFirst,endOnFirst));
    }

    /**
     * segment the time-series based on a start and end marker function. A marker is defined as any value that satisfies
     * the isMarkerF function. By default, startOnFirst=false, endOnFirst=true.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *      segmentByMarker(
     *          x -> x % 2 == 0 && x != 4,
     *          x -> x % 5 == 0 && x != 0,
     *          true,
     *          true
     *      )}
     *  </pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 2     Value: original bounds: (2,5) actual bounds: (2,5) observations: [(2,2),(3,3),(4,4),(5,5)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param startOp the start marker function
     * @param endOp the end marker function
     * @param startInclusive if true, will include the start marker to the segment
     * @param endInclusive if true, will include the end marker to the segment
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> startOp, FilterFunction<T> endOp, boolean startInclusive, boolean endInclusive) {
        return segmentByMarker(startOp, endOp, startInclusive, endInclusive, false, true);
    }

    /**
     * segment the time-series based on a start and end marker function. A marker is defined as any value that satisfies
     * the isMarkerF function. By default, startInclusive=true, endInclusive=true, startOnFirst=false, endOnFirst=true.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(0,0),Observation(1,1),Observation(2,2),Observation(3,3),Observation(4,4),Observation(5,5),Observation(6,6)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *      segmentByMarker(
     *          x -> x % 2 == 0 && x != 4,
     *          x -> x % 5 == 0 && x != 0
     *      )}
     *  </pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             TimeStamp: 2     Value: original bounds: (2,5) actual bounds: (2,5) observations: [(2,2),(3,3),(4,4),(5,5)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param startOp the start marker function
     * @param endOp the end marker function
     * @return a new {@link SegmentTimeSeries}
     */
    public SegmentTimeSeries<T> segmentByMarker(FilterFunction<T> startOp, FilterFunction<T> endOp) {
        return segmentByMarker(startOp, endOp, true, true);
    }

    /**
     * segment the {@link TimeSeries} based on a group by operation. A group by operation works by taking
     * each observation and producing a single key. Each segment will be generated for each unique key
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input: (Note: january,february, and march denote timestamps in those months)
     *         <p>[Observation(january1,1),Observation(january5,2),Observation(january10,3),Observation(february1,4),Observation(march3,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code segmentBy(obs -> Instant.ofEpochMilli(obs.timestamp).atZone(ZoneId.systemDefault()).toLocalDate().getMonth().toString()}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Segment(start=january1,end=january10,[Observation(january1,1),Observation(january5,2),Observation(january10,3)]),
     *             Segment(start=february1,end=february1,[Observation(february1,4)])
     *             Segment(start=march3,end=march3,[Observation(march3,5)]]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param groupByOp group by operation
     * @param <K> the key-by type
     * @return a new {@link SegmentTimeSeries}
     */
    public <K> SegmentTimeSeries<T> segmentBy(UnaryMapFunction<Observation<T>,K> groupByOp) {
        return toSegments(GenericSegmentationTransformers.segmentBy(groupByOp));
    }

    /**
     * Create a {@link MultiTimeSeries} by grouping each observation by the result of a groupBy operation. The resulting
     * {@link MultiTimeSeries} will contain all unique keys resulting by the groupBy operation.
     *
     * @param groupByOp function from a single {@link Observation} to a key
     * @param <K> key type
     * @return a new {@link MultiTimeSeries}
     */
    public <K> MultiTimeSeries<K, T> groupBy(UnaryMapFunction<Observation<T>,K> groupByOp) {
        return segmentBy(groupByOp).flatten(s -> groupByOp.evaluate(s.first()));
    }

    /* ********* map operations ********* */

    /**
     * @return the {@link TimeSeries} {@link TRS}
     */
    public TRS getTRS() {
        return trs;
    }

    /**
     * @return the {@link TRS} for the source {@link TimeSeries}, that is, the {@link TimeSeries} which is connected directly to a
     * {@link TimeSeriesReader}
     */
    public TRS getSourceTRS() {
        List<Pair<Pair<Long,Long>,TRS>> list = new ArrayList<>();
        mineForBounds(list);
        return list.stream()
                .map(x -> x.right)
                .filter(Objects::nonNull)
                .min(Comparator.comparing(x -> x.getGranularity().toMillis()))
                .orElse(null);
    }

    protected TRS trs = null;

    /**
     * Create a new {@link TimeSeries} with its time ticks mapped based on a start time and a granularity. In the
     * scope of this method, start time refers to the zone-date-time in which to start your {@link TimeSeries} data when
     * calling getValues and granularity refers to the lowest granularity of time tick.
     *
     * <p>Time ticks will be mapped as follows - (currentTimeTick - startTime) / granularity</p>
     *
     * @param trs the given {@link TRS}
     * @return a new {@link TimeSeries} with its timestamps mapped based on the given {@link TRS}
     */
    public TimeSeries<T> withTRS(TRS trs) {
        if (this.getTRS() == null) {
            throw new TSRuntimeException("withTRS requires that your TimeSeries have a TRS. You can add a TRS to your TimeSeries by collected the TimeSeries and re-initializing a TimeSeries Stream with a TRS",new UnsupportedOperationException());
        }
        TimeSeries<T> result = transform(GeneralTransformers.withTRS(trs));
        result.trs = trs;
        return result;
    }

    /**
     * Create a new {@link TimeSeries} where each {@link Observation} in this {@link TimeSeries} is mapped to a new
     * {@link Observation}
     *
     * <p>Example:</p>
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code mapObservation(x -> new Observation<>(x.getValue() + 1,x.getTimeStamp + 1))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(3,3),Observation(4,4)]</p>
     *     </li>
     * </ul>
     *
     * @param f {@link Observation} mapping function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} with its {@link Observation}'s mapped to new {@link Observation}
     */
    public <T2> TimeSeries<T2> mapObservation(UnaryMapFunction<Observation<T>,Observation<T2>> f) {
        return transform(MapTransformers.unaryMapObservation(f));
    }

    /**
     * Create a new {@link TimeSeries} where each {@link Observation} in this {@link TimeSeries} is mapped to 0 to N new
     * {@link Observation}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code
     *      flatMapObservation(obs -> {
     *          return Arrays.asList(
     *               new Observation<>(obs.timestamp - 5.minutes,-1),
     *               obs,
     *               new Observation<>(obs.timestamp + 5.minutes,-1)
     *          );
     *      }
     * }</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Observation(11:55,-1),Observation(12:00,1),Observation(12:05,-1),Observation(12:25,-1),
     *             Observation(12:30,2),Observation(12:35,-1),Observation(12:55,-1),Observation(1:00,3),
     *             Observation(1:05,-1),Observation(1:25,-1),Observation(1:30,4),Observation(1:35,-1),
     *             Observation(1:55,-1),Observation(2:00,5),Observation(2:05,-1)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param flatMapFunction {@link Observation} flat mapping function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} with its {@link Observation}'s mapped to 0 to n new {@link Observation}
     */
    public <T2> TimeSeries<T2> flatMapObservation(UnaryMapFunction<Observation<T>,Iterable<Observation<T2>>> flatMapFunction) {
        return transform(MapTransformers.flatMapObservation(flatMapFunction));
    }

    /**
     * create a new {@link TimeSeries} where each {@link Observation} value in this {@link TimeSeries} is mapped to a new
     * {@link Observation} value
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code map(x -> x + 1)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,2),Observation(2,3),Observation(3,4)]</p>
     *     </li>
     * </ul>
     *
     * @param f {@link Observation} value mapping function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} with its {@link Observation} values mapped
     */
    public <T2> TimeSeries<T2> map(UnaryMapFunction<T,T2> f) {
        return transform(MapTransformers.unaryMap(f));
    }

    /**
     * create a new {@link TimeSeries} where each {@link Observation} value and its index in this {@link TimeSeries} is
     * mapped to a new {@link Observation} value
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code map((index,x) -> x + 1)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,2),Observation(2,3),Observation(3,4)]</p>
     *     </li>
     * </ul>
     *
     * @param mapWithIndexFunction {@link Observation} value mapping function with index
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} with its {@link Observation} values mapped
     */
    public <T2> TimeSeries<T2> mapWithIndex(BinaryMapFunction<Integer,T,T2> mapWithIndexFunction) {
        return transform(MapTransformers.unaryMapWithIndex(mapWithIndexFunction));
    }

    /**
     * create a new {@link TimeSeries} where each {@link Observation} value in this {@link TimeSeries} is mapped to 0 to
     * N new values. An {@link Observation}'s time tick will be duplicated if a single value maps to multiple values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code flatMap(x -> Arrays.asList(1,2,3))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Observation(1,1),Observation(1,2),Observation(1,3),Observation(2,1),Observation(2,2),
     *             Observation(2,3),Observation(3,1),Observation(3,2),Observation(3,3)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param flatMapFunction value flat map function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} with its values mapped to 0 to n new values
     */
    public <T2> TimeSeries<T2> flatMap(UnaryMapFunction<T,Iterable<T2>> flatMapFunction) {
        return transform(MapTransformers.flatMap(flatMapFunction));
    }

    /* ********* join operations ********* */

    /**
     * align 2 {@link TimeSeries} based on an temporal inner join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.innerAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(3,2),Observation(4,3)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> innerAlign(TimeSeries<T2> timeSeries) {
        TimeSeries<Pair<T,T2>> joined = innerJoin(timeSeries, Pair::new);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally inner joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.innerAlign(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction combine function
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of an inner join
     */
    public <T2,T3> TimeSeries<T3> innerJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return transform(timeSeries,JoinTransformers.innerJoin(binaryMapFunction));
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal full join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1),Observation(2,null),Observation(3,3),Observation(4,4),Observation(5,null)]</p>
     *         <p>right = [Observation(1,null),Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> fullAlign(TimeSeries<T2> timeSeries) {
        return fullAlign(timeSeries,null,null);
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal full join strategy and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullAlign(right,GenericInterpolators.prev(),GenericInterpolators.next())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1),Observation(2,1),Observation(3,3),Observation(4,4),Observation(5,4)]</p>
     *         <p>right = [Observation(1,1),Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param interpolatorLeft left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param interpolatorRight right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> fullAlign(
            TimeSeries<T2> timeSeries,
            Interpolator<T> interpolatorLeft,
            Interpolator<T2> interpolatorRight) {
        TimeSeries<Pair<T,T2>> joined = fullJoin(
                timeSeries,
                Pair::new,
                interpolatorLeft,
                interpolatorRight);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally full joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null]),Observation(2,[null,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a full join
     */
    public <T2,T3> TimeSeries<T3> fullJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return fullJoin(timeSeries, binaryMapFunction,GenericInterpolators.nullify(), GenericInterpolators.nullify());
    }

    /**
     * create a new {@link TimeSeries} by temporally full joining this {@link TimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.fullJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev,GenericInterpolators.next)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1]),Observation(2,[1,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param interpolatorLeft left time series interpolator
     *                         {@link TimeSeries#resample(long, Interpolator)}
     * @param interpolatorRight right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a full join
     */
    public <T2,T3> TimeSeries<T3> fullJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction,
            Interpolator<T> interpolatorLeft,
            Interpolator<T2> interpolatorRight) {
        BinaryTransform<T,T2,T3> join = (interpolatorLeft == null || interpolatorRight == null) ?
                JoinTransformers.fullJoin(binaryMapFunction) :
                JoinTransformers.fullJoin(
                        binaryMapFunction,
                        interpolatorLeft,
                        interpolatorRight
                );
        return transform(timeSeries, join);
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal left join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(1,null),Observation(3,2),Observation(4,3)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> leftAlign(TimeSeries<T2> timeSeries) {
        TimeSeries<Pair<T,T2>> joined = leftJoin(timeSeries, Pair::new);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal left join strategy and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftAlign(right,1,1,GenericInterpolators.next)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(1,1),Observation(3,2),Observation(4,3)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param interpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> leftAlign(
            TimeSeries<T2> timeSeries,
            Interpolator<T2> interpolator) {
        TimeSeries<Pair<T,T2>> joined = leftJoin(
                timeSeries,
                Pair::new,
                interpolator);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally left joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null]),Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a left join
     */
    public <T2,T3> TimeSeries<T3> leftJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return leftJoin(timeSeries,binaryMapFunction,null);
    }

    /**
     * create a new {@link TimeSeries} by temporally left joining this {@link TimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.next)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1]),Observation(3,[3,2]),Observation(4,[4,3])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param interpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a left join
     */
    public <T2,T3> TimeSeries<T3> leftJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction,
            Interpolator<T2> interpolator) {
        BinaryTransform<T,T2,T3> join = (interpolator == null) ?
                JoinTransformers.leftJoin(binaryMapFunction) :
                JoinTransformers.leftJoin(
                        binaryMapFunction,
                        interpolator
                );
        return transform(timeSeries, join);
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal right join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(2,null),Observation(3,3),Observation(4,4),Observation(5,null)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> rightAlign(TimeSeries<T2> timeSeries) {
        TimeSeries<Pair<T,T2>> joined = rightJoin(timeSeries, Pair::new);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal right join strategy and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightAlign(right,1,1,GenericInterpolators.prev)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(2,1),Observation(3,3),Observation(4,4),Observation(5,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param interpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> rightAlign(
            TimeSeries<T2> timeSeries,
            Interpolator<T> interpolator) {
        TimeSeries<Pair<T,T2>> joined = rightJoin(
                timeSeries,
                Pair::new,
                interpolator);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally right joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[null,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a right join
     */
    public <T2,T3> TimeSeries<T3> rightJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return rightJoin(timeSeries,binaryMapFunction,null);
    }

    /**
     * create a new {@link TimeSeries} by temporally right joining this {@link TimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[1,1]),Observation(3,[3,2]),Observation(4,[4,3]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param interpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a right join
     */
    public <T2,T3> TimeSeries<T3> rightJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction,
            Interpolator<T> interpolator) {
        BinaryTransform<T,T2,T3> join = (interpolator == null) ?
                JoinTransformers.rightJoin(binaryMapFunction) :
                JoinTransformers.rightJoin(
                        binaryMapFunction,
                        interpolator
                );
        return transform(timeSeries, join);
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal left outer join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1)]</p>
     *         <p>right = [Observation(1,null)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> leftOuterAlign(TimeSeries<T2> timeSeries) {
        TimeSeries<Pair<T,T2>> joined = leftOuterJoin(timeSeries, Pair::new);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal left outer join strategy and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterAlign(right,1,1,GenericInterpolators.next())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(1,1)]</p>
     *         <p>right = [Observation(1,1)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param interpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> leftOuterAlign(
            TimeSeries<T2> timeSeries,
            Interpolator<T2> interpolator) {
        TimeSeries<Pair<T,T2>> joined = leftOuterJoin(
                timeSeries,
                Pair::new,
                interpolator);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally left outer joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,null])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a left outer join
     */
    public <T2,T3> TimeSeries<T3> leftOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return leftOuterJoin(timeSeries,binaryMapFunction,null);
    }

    /**
     * create a new {@link TimeSeries} by temporally left outer joining this {@link TimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.leftOuterJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param interpolator right time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a left outer join
     */
    public <T2,T3> TimeSeries<T3> leftOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction,
            Interpolator<T2> interpolator) {
        BinaryTransform<T,T2,T3> join = (interpolator == null) ?
                JoinTransformers.leftOuterJoin(binaryMapFunction) :
                JoinTransformers.leftOuterJoin(
                        binaryMapFunction,
                        interpolator
                );
        return transform(timeSeries, join);
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal right outer join strategy
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterAlign(right)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(2,null),Observation(5,null)]</p>
     *         <p>right = [Observation(2,1),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> rightOuterAlign(TimeSeries<T2> timeSeries) {
        TimeSeries<Pair<T,T2>> joined = rightOuterJoin(timeSeries, Pair::new);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * align 2 {@link TimeSeries} based on an temporal right outer join strategy and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterAlign(right,1,1,GenericInterpolators.prev())}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>left = [Observation(2,1),Observation(5,4)]</p>
     *         <p>right = [Observation(2,1),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param interpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @return a {@link TSPair} of the aligned {@link TimeSeries}
     */
    public <T2> TSPair<T,T2> rightOuterAlign(
            TimeSeries<T2> timeSeries,
            Interpolator<T> interpolator) {
        TimeSeries<Pair<T,T2>> joined = rightOuterJoin(
                timeSeries,
                Pair::new,
                interpolator);
        return new TSPair<>(joined.map(x -> x.left),joined.map(x -> x.right));
    }

    /**
     * create a new {@link TimeSeries} by temporally right outer joining this {@link TimeSeries} with another
     * {@link TimeSeries}
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterJoin(right,(l,r) -> Arrays.asList(l,r))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[null,1]),Observation(5,[null,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a right outer join
     */
    public <T2,T3> TimeSeries<T3> rightOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return rightOuterJoin(timeSeries,binaryMapFunction,null);
    }

    /**
     * create a new {@link TimeSeries} by temporally right outer joining this {@link TimeSeries} with another
     * {@link TimeSeries} and interpolate missing values
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>left = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>right = [Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code left.rightOuterJoin(right,(l,r) -> Arrays.asList(l,r),1,1,GenericInterpolators.prev())}</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,[1,1]),Observation(5,[4,4])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeries the right {@link TimeSeries}
     * @param binaryMapFunction binary mapper to join values
     * @param interpolator left time series interpolator
     *                          {@link TimeSeries#resample(long, Interpolator)}
     * @param <T2> other {@link TimeSeries} {@link Observation} value type
     * @param <T3> output {@link Observation} value type
     * @return a new {@link TimeSeries} which is the product of a right outer join
     */
    public <T2,T3> TimeSeries<T3> rightOuterJoin(
            TimeSeries<T2> timeSeries,
            BinaryMapFunction<T,T2,T3> binaryMapFunction,
            Interpolator<T> interpolator) {
        BinaryTransform<T,T2,T3> join = (interpolator == null) ?
                JoinTransformers.rightOuterJoin(binaryMapFunction) :
                JoinTransformers.rightOuterJoin(
                        binaryMapFunction,
                        interpolator
                );
        return transform(timeSeries, join);
    }

    /**
     * create a new {@link TimeSeries} by performing an N-ary join over a list of {@link TimeSeries} and combine
     * observations from each {@link TimeSeries} based on a temporal inner join strategy.
     *
     * <p>view {@link TimeSeries#innerJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param timeSeriesList list of {@link TimeSeries}
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} that is the product of performing an N-ary inner join over a list of
     * {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> innerJoin(List<TimeSeries<T>> timeSeriesList,T2 zeroValue,BinaryMapFunction<T2,T,T2> combineOp) {
        return transform(timeSeriesList,JoinTransformers.innerJoin(zeroValue,combineOp));
    }

    /**
     * create a new {@link TimeSeries} by performing an N-ary join over a list of {@link TimeSeries} and combine
     * observations from each {@link TimeSeries} based on a temporal full join strategy.
     *
     * <p>view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction)} for more details</p>
     *
     * @param timeSeriesList list of {@link TimeSeries}
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <T2> output {@link Observation} value type
     * @return a new {@link TimeSeries} that is the product of performing an N-ary full join over a list of
     * {@link TimeSeries}
     */
    public <T2> TimeSeries<T2> fullJoin(List<TimeSeries<T>> timeSeriesList,T2 zeroValue,BinaryMapFunction<T2,T,T2> combineOp) {
        return transform(timeSeriesList,JoinTransformers.fullJoin(zeroValue,combineOp));
    }

    /**
     * perform an N-Ary join over a list of TimeSeries and combine observations from each time series based on a temporal
     * full join strategy that interpolates missing values
     *
     * <p>view {@link TimeSeries#fullJoin(TimeSeries, BinaryMapFunction, Interpolator, Interpolator)} for more
     * details</p>
     *
     * @param timeSeriesList list of TimeSeries
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param inTypeInterpolator initial time series type interpolator
     * @param <T2> observation type out
     * @return a newly joined TimeSeries
     */
    public <T2> TimeSeries<T2> fullJoin(
            List<TimeSeries<T>> timeSeriesList,
            T2 zeroValue,BinaryMapFunction<T2,T,T2> combineOp,
            Interpolator<T> inTypeInterpolator) {
        return transform(
                timeSeriesList,
                JoinTransformers.fullJoin(
                        zeroValue,
                        combineOp,
                        inTypeInterpolator
                )
        );
    }

    /**
     * perform an N-Ary join over a list of TimeSeries and combine observations from each time series based on their
     * index in the TimeSeries
     *
     * <p>Note: If the list of TimeSeries are not synchronized by timestamp, answers may be incorrect depending
     * on the usage</p>
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>first = [Observation(1,1),Observation(3,3),Observation(4,4)]</p>
     *         <p>second = [Observation(1,1),Observation(3,2),Observation(4,3)]</p>
     *         <p>third = [Observation(1,3),Observation(3,4),Observation(4,5)]</p>
     *     </li>
     * </ul>
     * <pre>
     *     {@code
     *     first.indexJoin(
     *          Arrays.asList(second,third),
     *          Collections.emptyList(),
     *          (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
     *     )}
     * </pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,[1,1,3]),Observation(3,[3,2,4]),Observation(4,[4,3,5])]</p>
     *     </li>
     * </ul>
     *
     * @param timeSeriesList list of TimeSeries
     * @param zeroValue initial value to start with
     * @param combineOp combine function
     * @param <T2> observation type out
     * @return a newly joined TimeSeries
     */
    public <T2> TimeSeries<T2> indexJoin(List<TimeSeries<T>> timeSeriesList,T2 zeroValue,BinaryMapFunction<T2,T,T2> combineOp) {
        return transform(timeSeriesList,JoinTransformers.indexJoin(zeroValue,combineOp));
    }

    /**
     * create a new {@link TimeSeries} which is the product of this {@link TimeSeries} concatenated with another
     * {@link TimeSeries}
     *
     * @param trailingTimeSeries the trailing {@link TimeSeries}
     * @return a new {@link TimeSeries} which is the product of this {@link TimeSeries} concatenated with another
     * {@link TimeSeries}
     */
    public TimeSeries<T> concat(TimeSeries<T> trailingTimeSeries) {
        return transform(trailingTimeSeries, GeneralTransformers.concat());
    }

    /**
     * denotes whether the source is in memory
     * @return true if the source of this time series is in memory, otherwise false
     */
    protected abstract boolean sourceInMemory();

    List<Pair<String,UnaryMapFunction<Observation<T>,Optional<Object>>>> annotations = null;

    /**
     * Add an annotation to each {@link Observation} of the current {@link TimeSeries}
     * @param annotationKey the annotation key
     * @param annotation the annotation value
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> addAnnotation(String annotationKey, Object annotation) {
        return addAnnotation(annotationKey, o -> Optional.of(annotation));
    }

    /**
     * Add an annotation to each {@link Observation} of the current {@link TimeSeries} where the annotation value is the
     * result of applying a function over each {@link Observation}.
     *
     * @param annotationKey the annotation key
     * @param extractAnnotation the extract annotation function
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> addAnnotation(String annotationKey, UnaryMapFunction<Observation<T>, Optional<Object>> extractAnnotation) {
        if (annotations == null) annotations = new ArrayList<>();
        annotations.add(new Pair<>(annotationKey,extractAnnotation));
        return this;
    }

    /**
     * Estimate the current range of this {@link TimeSeries}.
     *
     * <p>
     *     Note: Because this time-series may not be backed by an in-memory data structure, answers can be subject
     *     to change
     * </p>
     * @return the current min/max range of this {@link TimeSeries}
     */
    public Pair<Long,Long> estimateRange() {
        List<Pair<Pair<Long,Long>, TRS>> list = new ArrayList<>();
        mineForBounds(list);

        long min = list.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongLower(x.left.left)) : x.left.left).min().orElse(Long.MIN_VALUE);
        long max = list.stream().mapToLong(x -> (x.right != null) ? trs.toIndex(x.right.toLongUpper(x.left.right)) : x.left.right).max().orElse(Long.MAX_VALUE);
        return new Pair<>(min,max);
    }

    //ALL LAMBDA TRANSFORM

    //CACHING!!!!!!
    //these values are intended for testing
    private CacheHit cacheHitValue = CacheHit.NONE;
//    private int cacheHitValue = -1;//this is only intended for use in testing
//    private static final int NO_CACHE_HIT = -1;//denotes no cache hit
//    private static final int FULL_CACHE_HIT = 0;//denotes full cache hit
//    private static final int MIDDLE_CACHE_HIT = 1;//denotes t1 < first cache and t2 > last cache
//    private static final int BEFORE_CACHE_HIT = 2;//denotes t1 < first cache
//    private static final int AFTER_CACHE_HIT = 3;//denotes t2 > last cache

    /**
     * enable caching on this {@link TimeSeries} with max cache size
     *
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> cache() {
        return cache(Integer.MAX_VALUE);
    }

    /**
     * enable caching on the current {@link TimeSeries} with the current TimeSeries {@link Cache} having a max cache
     * size of the given maxSize value
     *
     * @param maxSize given max cache size
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> cache(int maxSize) {
        cache.setMaxCacheSize(maxSize);
        return this;
    }

    /**
     * enable caching on the current {@link TimeSeries} with a new self defined cache having a max cache size of the
     * given maxSize value
     *
     * @param newCache new self defined cache
     * @param maxSize given max cache size
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> userDefinedCache(Cache<T> newCache,int maxSize) {
        cache = newCache;
        cache.setMaxCacheSize(maxSize);
        return this;
    }

    /**
     * enable caching on the current {@link TimeSeries} with a new self defined {@link Cache} with maximum cache size
     * @param newCache new self defined cache
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> userDefinedCache(Cache<T> newCache) {
        return userDefinedCache(newCache,Integer.MAX_VALUE);
    }

    /**
     * clear the current {@link Cache} and disable caching
     * @return this {@link TimeSeries}
     */
    public TimeSeries<T> uncache() {
        cache.clear();
        cache.setMaxCacheSize(0);
        return this;
    }

    /**
     * gets the most recent cache hit type
     * @return the integer denoting the cache hit type
     */
    public CacheHit getMostRecentCacheHitType(){
        return cacheHitValue;
    }

    /**
     * gets the maximum cache size
     * @return maximum size of cache
     */
    public int getMaximumCacheSize(){
        return cache.getMaxCacheSize();
    }

    /**
     * gets an iterator to the cache
     * @return the iterator to our cache at this TimeSeries level
     */
    public Iterator<Observation<T>> getCache(){
        return cache.iterator();
    }

    /**
     * reads values from source, whether it be physical or derived
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return the values in our range t1 to t2
     */
    private synchronized ObservationCollection<T> readValuesFromSource(
            long t1,
            long t2,
            boolean inclusive){
        logger.debug("readValuesFromSource got control from " + this.getClass().getSimpleName());
        ObservationCollection<T> res = buildValuesFromSource(t1,t2,inclusive);
        //todo this is not being cached for in mem so performance could be hit, we will save this for later
        if (annotations != null) {
            res.forEach(o -> {
                annotations.forEach(p -> p.right.evaluate(o).ifPresent(obj -> o.addAnnotation(p.left,obj)));
            });
        }
        return res;
    }

    /**
     * computes our values
     * <p>first checks to see if we can get from cache, if we cannot get from cache, we must now
     * read from our physical source, if we can get from cache, we do so.</p>
     * <p>Note: A deep copy is made since we want to return the actual values and not the cache.</p>
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return result, our computed values
     */
    protected synchronized ObservationCollection<T> computeValues(
            long t1,
            long t2,
            boolean inclusive){
        logger.debug("entered computeValues method");

        if (sourceInMemory()) {
            return readValuesFromSource(t1,t2,inclusive);
        } else {

            //this will eventually be our result that contains all values from cache and source
            TSBuilder<T> tsBuilder = Observations.newBuilder();

            //we must check if we have a cache hit and therefore must look in our cache
            if (isCacheHit(t1, t2)) {

                //holds all observations that come before our cache
                ObservationCollection<T> beforeCache;
                //holds all observations that come after our cache
                ObservationCollection<T> afterCache;
                switch (cacheHitValue) {

                    //all of our timestamps existed in the cache, so nothing to append to out cache
                    //all observations will be returned straight from the cache
                    case FULL:
                        tsBuilder.addAll(cache.getCacheInRange(t1, t2, inclusive));
                        break;

                    //we have observations with timestamps that are less than our caches minimum timestamp
                    case BEFORE:

                        //get our observations from before the cache
                        beforeCache = readValuesFromSource(t1, cache.first().getTimeTick(), inclusive);

                        //remove the last value in beforeCache because it may be already in the cache
                        if (!beforeCache.isEmpty() && beforeCache.last().getTimeTick() == cache.first().getTimeTick()) {
                            beforeCache = beforeCache.headSet(beforeCache.last().getTimeTick() - 1, true);
                        }

                        //add our values to the result, first adding the before cache values, then adding cache values
                        tsBuilder.addAll(beforeCache);
                        tsBuilder.addAll(cache.getCacheInRange(t1, t2, inclusive));

                        //populate our cache
                        //if the cache doesn't have space, this will be handled from within the cache
                        beforeCache.forEach(obs -> cache.add(obs));
                        break;

                    //we have observations with timestamps that are greater tan our caches maximum timestamp
                    case AFTER:

                        //get our observations from after the cache
                        afterCache = readValuesFromSource(cache.last().getTimeTick(), t2, inclusive);

                        //remove the first value in afterCache because it may be already in the cache
                        if (!afterCache.isEmpty() && afterCache.first().getTimeTick() == cache.last().getTimeTick()) {
                            afterCache = afterCache.tailSet(afterCache.first().getTimeTick() + 1, true);
                        }

                        //add our values to the result, first adding the cache values, then adding after cache values
                        tsBuilder.addAll(cache.getCacheInRange(t1, t2, inclusive));
                        tsBuilder.addAll(afterCache);

                        //populate our cache
                        //if the cache doesn't have space, this will be handled from within the cache
                        afterCache.forEach(obs -> cache.add(obs));
                        break;

                    //we have observations with timestamps that are less than our caches minimum timestamp
                    //and observations with timestamps that are greater than our caches maximum timestamp
                    case MIDDLE:

                        //get our observations from before the cache
                        beforeCache = readValuesFromSource(t1, cache.first().getTimeTick(), inclusive);
                        //get our observations from after the cache
                        afterCache = readValuesFromSource(cache.last().getTimeTick(), t2, inclusive);

                        //remove the last value in beforeCache because it may be already in the cache
                        if (!beforeCache.isEmpty() && beforeCache.last().getTimeTick() == cache.first().getTimeTick()) {
                            beforeCache = beforeCache.headSet(beforeCache.last().getTimeTick() - 1, true);
                        }

                        //remove the first value in afterCache because it may be already in the cache
                        if (!afterCache.isEmpty() && afterCache.first().getTimeTick() == cache.last().getTimeTick()) {
                            afterCache = afterCache.tailSet(afterCache.first().getTimeTick() + 1, true);
                        }

                        //add our values to the result
                        //first adding the beforeCache values
                        //then adding cache values
                        //last adding the afterCache values
                        tsBuilder.addAll(beforeCache);
                        tsBuilder.addAll(cache.getCache());
                        tsBuilder.addAll(afterCache);

                        //populate our cache
                        //if the cache doesn't have space, this will be handled from within the cache
                        beforeCache.forEach(obs -> cache.add(obs));
                        afterCache.forEach(obs -> cache.add(obs));
                        break;
                }
            } else { //no cache hit occurred, so we can just get all our values from source
                ObservationCollection<T> sourceValues = readValuesFromSource(t1, t2, inclusive);
                tsBuilder.addAll(sourceValues);
                sourceValues.forEach(obs -> cache.add(obs));
            }

            return tsBuilder.result(this.trs);
        }
    }

    /**
     * checks if we have any type of hit in the cache and...
     * sets the cacheHitValue
     * @param t1 - timestamp start
     * @param t2 - timestamp end
     * @return true if t1 or t2 is within the bounds of our cache, otherwise returns false
     */
    private boolean isCacheHit(long t1,long t2){
        boolean wasHit = false;
        if(cache.isEmpty() ||
                (t1 < cache.first().getTimeTick() && t2 < cache.first().getTimeTick()) ||
                (t1 > cache.last().getTimeTick() && t2 > cache.last().getTimeTick())){
            cacheHitValue = CacheHit.NONE;
        }else{
            if(t1 >= cache.first().getTimeTick() && t2 <= cache.last().getTimeTick()) {
                cacheHitValue = CacheHit.FULL;
            }else if(t1 < cache.first().getTimeTick() && t2 > cache.last().getTimeTick()){
                cacheHitValue = CacheHit.MIDDLE;
            }else if(t1 < cache.first().getTimeTick()){
                cacheHitValue = CacheHit.BEFORE;
            }else if(t2 > cache.last().getTimeTick()){
                cacheHitValue = CacheHit.AFTER;
            }
            wasHit = true;
        }

        return wasHit;


    }

    /**
     * builds our TimeStampSensors from a source given a time range t1 to t2
     * @param t1 starting time tick
     * @param t2 ending time tick
     * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
     * @return a NavigableSet of TimeStampSensors retrieved from our source
     */
    protected abstract ObservationCollection<T> buildValuesFromSource(
            long t1,
            long t2,
            boolean inclusive);

    private long convertToEpoch(ZonedDateTime zonedDateTime, TimeUnit timeUnit){
        long result;
        switch(timeUnit){
            case SECONDS:
                result = zonedDateTime.toInstant().getEpochSecond();
                break;
            case MILLISECONDS:
                result = zonedDateTime.toInstant().toEpochMilli();
                break;
            default:
                result = zonedDateTime.toInstant().toEpochMilli();
                break;
        }
        return result;
    }

    /* CONSTRUCTORS */

    /**
     * create a {@link TimeSeries} from a {@link TimeSeriesReader}
     *
     * @param reader the {@link TimeSeriesReader}
     * @param trs the source {@link TRS}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> reader(TimeSeriesReader<T> reader, TRS trs){
        return new SourceTimeSeries<>(reader, trs);
    }

    /**
     * create a {@link TimeSeries} from a {@link TimeSeriesReader}
     *
     * @param reader the {@link TimeSeriesReader}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> reader(TimeSeriesReader<T> reader){
        return reader(reader, null);
    }

    /**
     * create a {@link TimeSeries} from an object file
     *
     * <p>Note: This brings the time series in to memory</p>
     *
     * @param inputStream {@link InputStream} containing the {@link TimeSeries} object
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> objectFile(InputStream inputStream) {
        TimeSeries<T> result = null;
        try {
            ObjectInputStream ois = new ObjectInputStream(inputStream);
            ObservationCollection<T> observations = (ObservationCollection<T>) ois.readObject();
            result = observations.toTimeSeriesStream();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * create a {@link TimeSeries} from an in-memory {@link ObservationCollection}
     *
     * <p>Note: If the {@link ObservationCollection} contains a {@link TRS}, it will be used</p>
     *
     * @param observationCollection the in-memory {@link ObservationCollection}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> fromObservations(ObservationCollection<T> observationCollection){
        return fromObservations(observationCollection,true, observationCollection.getTRS());
    }

    /**
     * create a {@link TimeSeries} from an in-memory {@link ObservationCollection}
     *
     * @param observationCollection the in-memory {@link ObservationCollection}
     * @param trs the source {@link TRS}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> fromObservations(ObservationCollection<T> observationCollection, TRS trs){
        return fromObservations(observationCollection,true, trs);
    }

    /**
     * create a {@link TimeSeries} from an in-memory {@link ObservationCollection}
     *
     * <p>Note: If the {@link ObservationCollection} contains a {@link TRS}, it will be used</p>
     *
     * @param observationCollection the in-memory {@link ObservationCollection}
     * @param copy if true will create a deep copy of the {@link ObservationCollection}, otherwise will use the
     *             reference
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> fromObservations(
            ObservationCollection<T> observationCollection,Boolean copy) {
        return fromObservations(observationCollection,copy,observationCollection.getTRS());
    }

    /**
     * create a {@link TimeSeries} from an in-memory {@link ObservationCollection}
     *
     * @param observationCollection the in-memory {@link ObservationCollection}
     * @param copy if true will create a deep copy of the {@link ObservationCollection}, otherwise will use the
     *             reference
     * @param trs the source {@link TRS}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> fromObservations(
            ObservationCollection<T> observationCollection,
            Boolean copy,
            TRS trs) {
        if (copy) {
            TSBuilder<T> tsBuilder = Observations.newBuilder();
            tsBuilder.addAll(observationCollection);
            return new SourceTimeSeries<>(new ObservationCollectionReader<>(tsBuilder.result()), trs);
        } else {
            return new SourceTimeSeries<>(new ObservationCollectionReader<>(observationCollection), trs);
        }
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, boolean header, String delimiter, TRS trs) {
        return reader(new CSVTimeSeriesValueReader(path,header,delimiter),trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, boolean header, String delimiter) {
        return csv(path,header,delimiter,null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, TRS trs) {
        return csv(path,true,",",trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path csv path
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path) {
        return csv(path,true,",",null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return reader(new CSVTimeSeriesReader(path,timestampColumn,header,delimiter,dateTimeFormatter,sort),trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, boolean header, String delimiter, DateTimeFormatter dateTimeFormatter) {
        return csv(path,timestampColumn,sort,header,delimiter,dateTimeFormatter,null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param header if true, the first line will be treated as a header
     * @param delimiter csv delimiter
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, boolean header, String delimiter) {
        return csv(path,timestampColumn,sort,header,delimiter,null,null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, TRS trs) {
        return csv(path, timestampColumn, sort, true, ",", null, trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, TRS trs) {
        return csv(path, timestampColumn, false, trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort) {
        return csv(path, timestampColumn, sort, true, ",", null, null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn) {
        return csv(path, timestampColumn, false);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csv(path, timestampColumn, false,true,",",dateTimeFormatter,trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, DateTimeFormatter dateTimeFormatter) {
        return csv(path, timestampColumn, dateTimeFormatter,null);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @param trs the source {@link TRS}
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, DateTimeFormatter dateTimeFormatter, TRS trs) {
        return csv(path, timestampColumn, sort,true,",",dateTimeFormatter,trs);
    }

    /**
     * Create a {@link TimeSeries} from a csv where each line denotes a single {@link Observation}. Each observation
     * will be a map where each key is based on the header key, and value is the corresponding column.
     *
     * <p>Note: if no header, default keys are "_" + i where i is the column index</p>
     *
     * @param path csv path
     * @param timestampColumn column containing timestamp
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param dateTimeFormatter timestamp format for timestampColumn
     * @return a new {@link TimeSeries}
     */
    public static TimeSeries<Map<String,String>> csv(String path, String timestampColumn, boolean sort, DateTimeFormatter dateTimeFormatter) {
        return csv(path, timestampColumn, sort, dateTimeFormatter,null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} is extracted from a
     * single line.
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a value
     * @param skipNumLines number of lines to skip
     * @param trs the source {@link TRS}
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<OUT>> parseLine,
            int skipNumLines,
            TRS trs
    ) {
        return reader(new TextFileSequentialTimeSeriesValueReader<>(path,parseLine,skipNumLines),trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} is extracted from a
     * single line.
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a value
     * @param skipNumLines number of lines to skip
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<OUT>> parseLine,
            int skipNumLines
    ) {
        return textFile(path,parseLine,skipNumLines,null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} is extracted from a
     * single line.
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a value
     * @param trs the source {@link TRS}
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<OUT>> parseLine,
            TRS trs
    ) {
        return textFile(path,parseLine,0,trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each value of an {@link Observation} is extracted from a
     * single line.
     *
     * <p>Note: Time-ticks will be generated based on order of line being read</p>
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns a value
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<OUT>> parseLine
    ) {
        return textFile(path,parseLine,0,null);
    }

    //////////


    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} is extracted from a single line.
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns an {@link Observation}
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param skipNumLines number of lines to skip
     * @param trs the source {@link TRS}
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String, Optional<Observation<OUT>>> parseLine,
            boolean sort,
            int skipNumLines,
            TRS trs) {
        return (sort)
                ? reader(new TextFileUnsortedTimeSeriesReader<>(path,parseLine,skipNumLines), trs)
                : reader(new TextFileSequentialTimeSeriesReader<>(path,parseLine,skipNumLines), trs).cache();
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} is extracted from a single line.
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns an {@link Observation}
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param skipNumLines number of lines to skip
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<Observation<OUT>>> parseLine,
            boolean sort,
            int skipNumLines) {
        return textFile(path,parseLine, sort, skipNumLines, null);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} is extracted from a single line.
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns an {@link Observation}
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param trs the source {@link TRS}
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<Observation<OUT>>> parseLine,
            boolean sort,
            TRS trs) {
        return textFile(path,parseLine, sort, 0, trs);
    }

    /**
     * Create an {@link TimeSeries} from a Text file where each {@link Observation} is extracted from a single line.
     *
     * @param path path to a text file
     * @param parseLine function given a line, optionally returns an {@link Observation}
     * @param sort if true, will assume the data is unsorted and incur a sorting cost, otherwise will assume lines are
     *             sorted in time order
     * @param <OUT> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <OUT> TimeSeries<OUT> textFile(
            String path,
            UnaryMapFunction<String,Optional<Observation<OUT>>> parseLine,
            boolean sort) {
        return textFile(path,parseLine, sort, 0, null);
    }

    /**
     * create a {@link TimeSeries} from an in memory {@link List} of values
     *
     * <p>Note: time-ticks will be based on index in {@link List}</p>
     *
     * @param list the in memory {@link List} of values
     * @param trs the source {@link TRS}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> list(List<T> list, TRS trs){
        TSBuilder<T> tsBuilder = Observations.newBuilder();
        AtomicLong i = new AtomicLong(0);
        list.forEach(value -> tsBuilder.add(new Observation<>(i.getAndAdd(1),value)));
        return new SourceTimeSeries<>(new ObservationCollectionReader<>(tsBuilder.result()), trs);
    }

    /**
     * create a {@link TimeSeries} from an in memory {@link List} of values
     *
     * <p>Note: time-ticks will be based on index in {@link List}</p>
     *
     * @param list the in memory {@link List} of values
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> list(List<T> list) {
        return TimeSeries.list(list, (TRS) null);
    }

    /**
     * create a {@link TimeSeries} from an in memory {@link List} of values
     *
     * @param list the in memory {@link List} of values
     * @param functionToTimeStamp function to extract a time-tick from a value
     * @param trs the source {@link TRS}
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> list(List<T> list,UnaryMapFunction<T,Long> functionToTimeStamp, TRS trs){
        TSBuilder<T> tsBuilder = Observations.newBuilder();
        list.forEach(value -> {
            tsBuilder.add(new Observation<>(functionToTimeStamp.evaluate(value),value));
        });
        return new SourceTimeSeries<>(new ObservationCollectionReader<>(tsBuilder.result()), trs);
    }

    /**
     * create a {@link TimeSeries} from an in memory {@link List} of values
     *
     * @param list the in memory {@link List} of values
     * @param functionToTimeStamp function to extract a time-tick from a value
     * @param <T> output {@link Observation} value type
     * @return a new {@link TimeSeries}
     */
    public static <T> TimeSeries<T> list(List<T> list,UnaryMapFunction<T,Long> functionToTimeStamp){
        return TimeSeries.list(list, functionToTimeStamp, null);
    }

}
