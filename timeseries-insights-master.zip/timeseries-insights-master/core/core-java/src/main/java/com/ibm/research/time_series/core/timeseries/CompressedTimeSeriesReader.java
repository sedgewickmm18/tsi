package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.io.Utils;
import com.ibm.research.time_series.core.io.partitioner.TSPartitionerUtils;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Pair;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.input.ReversedLinesFileReader;

import java.io.*;
import java.util.*;

/**
 * A special form of {@link TimeSeriesReader} that reads a compressed time-series.
 *
 * @param <T> {@link Observation} value type
 */
public class CompressedTimeSeriesReader<T> implements TimeSeriesReader<T> {
    private Iterator<String> lines;
    private MutableObservationCollection<T> buffer;
    private String path;

    private UnaryMapFunction<String, Pair<Long[],T>> parseOp;

    public CompressedTimeSeriesReader(String path, UnaryMapFunction<String, Pair<Long[],T>> parseOp) {
        this.path = path;
        final InputStream inputStream = Utils.inferInputStream(path);
        this.lines =new LineIterator(new InputStreamReader(inputStream));
        this.buffer = new MutableObservationCollection<>();
        this.parseOp = parseOp;
    }

    @Override
    public long start() {
        long start = Long.MIN_VALUE;
        try {
            BufferedReader buffer = new BufferedReader(new FileReader(path));

            final Pair<Long[], T> opt = parseOp.evaluate(buffer.readLine());
            start = opt.left[0];
        } catch (IOException e) {
            e.printStackTrace();
        }
        return start;
    }

    @Override
    public long end() {

        long end = Long.MAX_VALUE;
        if (Utils.getTextFileType(path) > 0) { //if the file is a compressed file, we redd till end...
            try {
                final long[] startEndTs = TSPartitionerUtils.getStartEndTs(path, x -> {
                    final Pair<Long[], T> opt = parseOp.evaluate(x);
                    return OptionalLong.of(opt.left[0]);
                });
                end = startEndTs[1];//todo this is reading through whole file as it
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else { //if the file is a regular text file, use a optimized reverse file reader
            try {
                ReversedLinesFileReader rf = new ReversedLinesFileReader(new File(path));
                final Pair<Long[], T> opt = parseOp.evaluate(rf.readLine());
                end = opt.left[1];
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return end;
    }

    @Override
    public Iterator<Observation<T>> read(long t1, long t2, boolean inclusiveIfBoundsNotExist) {
        ObservationCollection<T> current = Observations.empty();
        //first we must check if we have our values already
        if(!buffer.isEmpty()) {

            if (inclusiveIfBoundsNotExist) {
                //need to create new so not reference
                current = buffer.subSet(TimeSeriesReader.getFloor(buffer, t1), true, TimeSeriesReader.getCeiling(buffer, t2), true);
            } else {
                current = buffer.subSet(t1,true,t2,true);
            }

            if (!current.isEmpty() && current.last().getTimeTick() >= t2){
                return current.iterator();
            }
        }

        Iterator<Observation<T>> currentIter = current.iterator();
        final Iterator<String> finalLines = lines;
        return new Iterator<Observation<T>>() {
            boolean foundFirst;
            boolean foundLast = false;
            Queue<Observation<T>> border = new LinkedList<>();
            Pair<Long[], T> lookAhead = null;

            @Override
            public boolean hasNext() {
                if (currentIter.hasNext()) {
                    foundFirst = true;
                    //no need to check range here as if we had full it would have been covered in the return above
                    return true;
                } else {
                    if (foundLast) return false;
                    //do normal processing of lines
                    if (!foundFirst) {
                        Pair<Long[], T> prevEval = null;
                        while (lines.hasNext() && !foundFirst) {
                            final Pair<Long[], T> evaluate = parseOp.evaluate(lines.next());
                            if (prevEval == null) {
                                prevEval = evaluate;
                                buffer.add(new Observation<>(prevEval.left[0],prevEval.right));

                                if (prevEval.left[1] >= t1) {
                                    border.add(new Observation<>(prevEval.left[0],prevEval.right));
                                    foundFirst = true;
                                    break;//break here so we dont perform another parseLine
                                }
                            } else {
                                if (prevEval.left[1] >= t1) {
                                    border.add(new Observation<>(prevEval.left[0],prevEval.right));
                                    foundFirst = true;
                                    break;
                                } else {
                                    final Observation<T> nextObs = new Observation<>(evaluate.left[0],evaluate.right);
                                    buffer.add(nextObs);
                                    if (evaluate.left[1] > t1) {
                                        //need to use both
                                        border.add(new Observation<>(prevEval.left[0],prevEval.right));
                                        border.add(nextObs);
                                        foundFirst = true;
                                        break;
                                    } else if (evaluate.left[1] == t1) {
                                        border.add(nextObs);
                                        foundFirst = true;
                                        break;
                                    } else {
                                        prevEval = evaluate;
                                    }
                                }
                            }
                        }
                        return border.size() != 0;
                    } else {
                        while (lookAhead == null && lines.hasNext()) {
                            lookAhead = parseOp.evaluate(lines.next());
                        }
                        if (lookAhead != null) {
                            buffer.add(new Observation<>(lookAhead.left[0],lookAhead.right));
                            if (lookAhead.left[1] >= t2 || !lines.hasNext()) {
                                foundLast = true;
                            }
                            return true;
                        } else {
                            return false;
                        }
                    }
                }
            }

            @Override
            public Observation<T> next() {
                if (currentIter.hasNext()) {
                    return currentIter.next();
                } else {
                    if (border.size() > 0) {
                        return border.remove();
                    } else {
                        final Observation<T> toReturn = new Observation<>(lookAhead.left[0],lookAhead.right);
                        lookAhead = null;
                        return toReturn;
                    }
                }
            }
        };
    }

    @Override
    public void close() {

    }
}
