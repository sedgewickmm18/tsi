package com.ibm.research.time_series.core.timeseries;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

class CSVTimeSeriesValueReader implements TimeSeriesReader<Map<String,String>>{
    private TimeSeriesReader<Map<String,String>> textFileReader;
    private Map<String,Integer> headerMapping;
    private String delimiter;

    public CSVTimeSeriesValueReader(String path, boolean header, String delimiter) {
        this.delimiter = delimiter;
        this.headerMapping = new HashMap<>();
        try {
            String firstLine = Files.lines(Paths.get(path)).findFirst().get(); //todo throw exception here maybe if empty (will add these checks later)
            String[] split = firstLine.split(delimiter);
            for (int i = 0;i < split.length;i++) {
                this.headerMapping.put((header) ? split[i] : "_" + i,i);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        int skipNumLines = (header) ? 1 : 0;
        textFileReader = new TextFileSequentialTimeSeriesValueReader<>(path,this::parseValue,skipNumLines);
    }

    private Optional<Map<String,String>> parseValue(String line) {
        final String[] split = line.split(delimiter);
        final Map<String, String> value = headerMapping.entrySet().stream()
                .map(e -> new AbstractMap.SimpleEntry<>(e.getKey(), split[e.getValue()]))
                .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
        return Optional.of(value);
    }

    @Override
    public Iterator<Observation<Map<String, String>>> read(long t1, long t2, boolean inclusiveIfBoundsNotExist) {
        return textFileReader.read(t1,t2,inclusiveIfBoundsNotExist);
    }

    @Override
    public long start() {
        return textFileReader.start();
    }

    @Override
    public long end() {
        return textFileReader.end();
    }

    @Override
    public void close() {
        textFileReader.close();
    }
}
