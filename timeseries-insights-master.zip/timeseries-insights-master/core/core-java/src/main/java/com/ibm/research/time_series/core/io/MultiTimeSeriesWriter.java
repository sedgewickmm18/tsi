package com.ibm.research.time_series.core.io;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.writers.ObjectFileMultiTimeSeriesWriterFormat;
import com.ibm.research.time_series.core.io.writers.ObjectFileTimeSeriesWriterFormat;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Builder pattern used for writing a {@link com.ibm.research.time_series.core.timeseries.MultiTimeSeries} to an outside
 * datasource
 *
 * <p>A {@link MultiTimeSeriesWriter} has a few components:</p>
 *     <ul>
 *          <li>Observations-Map: the in-memory observations map to write to an outside datasource</li>
 *          <li>Options: Key-value String pair in Map of options to be used in writing</li>
 *          <li>Value-Encoder: function to encode a value to a String, by default toString is used</li>
 *          <li>Key-Encoder: function to encode a key to a String, by default toString is used</li>
 *     </ul>
 *
 * <p>This class works in the following way:</p>
 *     <ul>
 *         <li>     1. Builds a blank {@link MultiTimeSeriesWriter} that only contains observations.</li>
 *         <li>     2. Set options, value-encoder, and key-encoder (optional)</li>
 *         <li>     3. Save to datasource (will save using {@link TimeSeriesWriteFormat}) given options and value-encoder </li>
 *     </ul>
 *
 *
 * @param <T> {@link com.ibm.research.time_series.core.timeseries.TimeSeries} value type
 */
public class MultiTimeSeriesWriter<K,T> {

    private Map<String,Object> options;
    private UnaryMapFunction<K,String> encodeKey;
    private UnaryMapFunction<T,String> encodeValue;
    private Map<K,ObservationCollection<T>> observationsMap;

    public MultiTimeSeriesWriter(Map<K, ObservationCollection<T>> observationsMap) {
        this.observationsMap = observationsMap;
        this.options = new HashMap<>();
        this.encodeKey = Objects::toString;
        this.encodeValue = Objects::toString;
    }

    /**
     * set function to encode a value to a String
     *
     * @param valueEncoder function to encode a value to String
     * @return this {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<K,T> encodeValue(UnaryMapFunction<T,String> valueEncoder) {
        this.encodeValue = valueEncoder;
        return this;
    }

    /**
     * set function to encode a key to a String
     *
     * @param keyEncoder function to encode a key to String
     * @return this {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<K,T> encodeKey(UnaryMapFunction<K,String> keyEncoder) {
        this.encodeKey = keyEncoder;
        return this;
    }

    /**
     * set an option on this {@link MultiTimeSeriesWriter}
     *
     * @param optionKey option key
     * @param optionValue option value
     * @return this {@link MultiTimeSeriesWriter}
     */
    public MultiTimeSeriesWriter<K,T> option(String optionKey, Object optionValue) {
        options.put(optionKey,optionValue);
        return this;
    }

    /**
     * save as object file
     * @param path path to save to
     */
    public void objectFile(String path) {
        ObjectFileMultiTimeSeriesWriterFormat<K,T> tsFormat = new ObjectFileMultiTimeSeriesWriterFormat<>(path);
        save(tsFormat);
    }

    /**
     * save to an outside datasource with the given {@link MultiTimeSeriesWriteFormat}
     * @param multiTimeSeriesWriteFormat the {@link MultiTimeSeriesWriteFormat}
     */
    public void save(MultiTimeSeriesWriteFormat<K,T> multiTimeSeriesWriteFormat) {
        multiTimeSeriesWriteFormat.write(observationsMap,encodeKey,encodeValue,options);
    }
}
