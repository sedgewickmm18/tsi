package com.ibm.research.time_series.core.io.writers;

import com.ibm.research.time_series.core.io.TimeSeriesWriteFormat;

public class TimeSeriesWriteFormats {
    public static <T> TimeSeriesWriteFormat<T> objectFile(String path) {
        return new ObjectFileTimeSeriesWriterFormat<>(path);
    }

    public static <T> TimeSeriesWriteFormat<T> csv(String path) {
        return new CSVTimeSeriesWriterFormat<>(path);
    }
}
