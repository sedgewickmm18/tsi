package com.ibm.research.time_series.core.core_transforms.map;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.functions.NaryMapFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.Pair;

/**
 * This is the entry point for all core built-in transforms for mapping values and observations
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class MapTransformers {

    /**
     * This is the unary map transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will map each observation value of the time
     * series to a new value.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code map(x -> x + 1)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,2),Observation(2,3),Observation(3,4)]</p>
     *     </li>
     * </ul>
     *
     * @param unaryMapFunction observation value mapping function
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a unary map transform
     */
    public static <T,T2> UnaryTransform<T,T2> unaryMap(UnaryMapFunction<T,T2> unaryMapFunction) {
        return new UnaryMap<>(unaryMapFunction);
    }

    /**
     * ~~~ DEVELOPER API ~~~
     * This is the binary map transform, applied on any two
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will perform a binary map over two observation
     * values with like index into the time series.
     *
     * @param binaryMapFunction binary observation value mapping function
     * @param <T> left input observation value type
     * @param <T2> right input observation value type
     * @param <T3> output observation value type
     * @return a single instance of a binary map transform
     */
    public static <T,T2,T3> BinaryTransform<T,T2,T3> binaryMap(BinaryMapFunction<T,T2,T3> binaryMapFunction) {
        return new BinaryMap<T, T2, T3>(binaryMapFunction);
    }

    /**
     * ~~~ DEVELOPER API ~~~
     * This is the n-ary map transform, applied on any n
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will perform an nary map over n observation
     * values withi like index into the time series
     *
     * @param naryMapFunction n-ary observation value mapping function
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a n-ary map transform
     */
    public static <T,T2> NaryTransform<T,T2> naryMap(NaryMapFunction<T,T2> naryMapFunction) {
        return new NaryMap<>(naryMapFunction);
    }

    /**
     * This is the unary map observation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will map each observation of the time
     * series to a new observation.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code mapObservation(x -> new Observation<>(x.getValue() + 1,x.getTimeStamp + 1))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(2,2),Observation(3,3),Observation(4,4)]</p>
     *     </li>
     * </ul>
     *
     * @param unaryMapFunction observation value mapping function
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a unary map observation transform
     */
    public static <T,T2> UnaryTransform<T,T2> unaryMapObservation(UnaryMapFunction<Observation<T>,Observation<T2>> unaryMapFunction) {
        return new UnaryMapObservation<>(unaryMapFunction);
    }

    /**
     * This is the flat map transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will map each observation value of the time
     * series to 0 or more values.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code flatMap(x -> Arrays.asList(1,2,3))}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Observation(1,1),Observation(1,2),Observation(1,3),Observation(2,1),Observation(2,2),
     *             Observation(2,3),Observation(3,1),Observation(3,2),Observation(3,3)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param unaryMapFunction value flat map function
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a flat map transform
     */
    public static <T,T2> UnaryTransform<T,T2> flatMap(UnaryMapFunction<T,Iterable<T2>> unaryMapFunction) {
        return new FlatMap<>(unaryMapFunction);
    }

    /**
     * This is the flat map observation transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will map each observation of the time
     * series to 0 or more observations.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(12:00,1),Observation(12:30,2),Observation(1:00,3),Observation(1:30,4),Observation(2:00,5)]</p>
     *     </li>
     * </ul>
     * <pre>{@code
     *      flatMapObservation(obs -> {
     *          return Arrays.asList(
     *               new Observation<>(obs.timestamp - 5.minutes,-1),
     *               obs,
     *               new Observation<>(obs.timestamp + 5.minutes,-1)
     *          );
     *      }
     * }</pre>
     * <ul>
     *     <li>
     *         Result:
     *         <p>
     *             [Observation(11:55,-1),Observation(12:00,1),Observation(12:05,-1),Observation(12:25,-1),
     *             Observation(12:30,2),Observation(12:35,-1),Observation(12:55,-1),Observation(1:00,3),
     *             Observation(1:05,-1),Observation(1:25,-1),Observation(1:30,4),Observation(1:35,-1),
     *             Observation(1:55,-1),Observation(2:00,5),Observation(2:05,-1)]
     *         </p>
     *     </li>
     * </ul>
     *
     * @param unaryMapFunction observation flat map function
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a flat map observation transform
     */
    public static <T,T2> UnaryTransform<T,T2> flatMapObservation(UnaryMapFunction<Observation<T>,Iterable<Observation<T2>>> unaryMapFunction) {
        return new FlatMapObservation<>(unaryMapFunction);
    }

    /**
     * This is the filter transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will filter any observation values that don't
     * match the predicate function.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(2,1),Observation(3,2),Observation(4,3),Observation(5,4)]</p>
     *     </li>
     * </ul>
     * <pre>{@code filter(x -> x % 2 == 0)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(3,2),Observation(5,4)]</p>
     *     </li>
     * </ul>
     *
     * @param filterFunction predicate filter function
     * @param <T> observation value type
     * @return a single instance of a filter transform
     */
    public static <T> UnaryTransform<T,T> filter(FilterFunction<T> filterFunction) {
        return new FilterTransform<>(filterFunction);
    }

    /**
     * This is the unary map with index transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries}, it will map each observation value of the time
     * series to a new value.
     *
     * <p>Example:</p>
     *
     * <ul>
     *     <li>
     *         Input:
     *         <p>[Observation(1,1),Observation(2,2),Observation(3,3)]</p>
     *     </li>
     * </ul>
     * <pre>{@code map((index,x) -> x + 1)}</pre>
     *  <ul>
     *     <li>
     *         Result:
     *         <p>[Observation(1,2),Observation(2,3),Observation(3,4)]</p>
     *     </li>
     * </ul>
     *
     * @param mapFunction observation value mapping function with index
     * @param <T> input observation value type
     * @param <T2> output observation value type
     * @return a single instance of a unary map transform
     */
    public static <T,T2> UnaryTransform<T,T2> unaryMapWithIndex(BinaryMapFunction<Integer,T,T2> mapFunction) {
        return new UnaryMapWithIndex<>(mapFunction);
    }
}
