/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.transform;

import java.io.Serializable;
import java.util.List;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * Abstract class to represent a NaryTransform.
 *
 * An NaryTransform is a transform that takes n time series and produces a single time series
 *
 * <p>An NaryTransform has no dependence on a time series, it can be created without a time series,
 * 	the purpose of the list of time series in this class is to hold the time series reference when
 * 	chaining transforms.</p>
 *
 * <p>Any class that extends this class will require:</p>
 * <p>implementation of evaluate - algorithm to perform to go from TimeSeries IN to TimeSeries OUT</p>
 * <p>Optional - implementation of clone if stateful - this method will require the class to make a
 * copy of itself and return(must be used as to not compromise a transformation chain).</p>
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 *
 * @param <IN> time series type in
 * @param <OUT> time series type out
 */
public abstract class NaryTransform<IN, OUT> extends Transform implements Serializable,Cloneable{

    private static final long serialVersionUID = 878398376835686107L;
    /**
     * the current state of our root time series at any given time in a transform chain
     *
     * The root time series is that which first initiated the Nary Transform
     */
    protected TimeSeries<IN> timeSeriesRoot;

    /**
     * the current state of our list of tail time series at any given time in a transform ahin
     *
     * the tail time series is that list of time series which was used as a parameter as part of the
     * nary transform
     */
    protected List<TimeSeries<IN>> timeSeriesTail;

	/**
	 * this is the simple evaluate method.
     * Use this method to write your own implementation of your transform.
     *
     * Within this method, use this classes timeSeriesRoot, timeSeriesTail and the given parameters
     * to evaluate and transform your time series.
     *
	 * @param t1 timestamp start
	 * @param t2 timestamp end
	 * @param inclusive if true, bounds will be inclusive, otherwise strict boundaries are enforced
	 * @return the resulting time series after the transform you wish to implement
	 */
	public abstract ObservationCollection<OUT> evaluate(long t1, long t2, boolean inclusive);

	/**
	 * this method is used to save the state of a transform at any given time in the chained transform.
	 * to implement this method, you must create a new XTransform with the properties of the current transform and return this new transform.
	 */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    /**
     * ~~~~~~DEVELOPER API~~~~~~
     * this method is used to set an operation on time series(root and tail) of an already existing transform.
     * @param timeSeriesRoot the root TimeSeries to operate on
     * @param timeSeriesTail the list of tail TimeSeries to operate on
     */
	public void setOperationOn(TimeSeries<IN> timeSeriesRoot, List<TimeSeries<IN>> timeSeriesTail){
		this.timeSeriesRoot = timeSeriesRoot;
        this.timeSeriesTail = timeSeriesTail;
	}

    /**
     * @return the current state of our root time series at any given time in a transform chain
     */
	public TimeSeries<IN> getTimeSeriesRoot(){
		return timeSeriesRoot;
	}

    /**
     * @return the current state of our list of tail time series at any given time in a transform
     * chain
     */
	public List<TimeSeries<IN>> getTimeSeriesTail(){
		return timeSeriesTail;
	}

}
