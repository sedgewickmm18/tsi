package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.function.Supplier;

class Aggregate<T,OUTPUT> extends UnaryReducer<T, OUTPUT> {
    private Supplier<OUTPUT> zero;
    private BinaryMapFunction<OUTPUT,T,OUTPUT> updateFunc;
    Aggregate(Supplier<OUTPUT> zero, BinaryMapFunction<OUTPUT,T,OUTPUT> updateFunc) {
        this.zero = zero;
        this.updateFunc = updateFunc;
    }
    @Override
    public OUTPUT reduceSegment(Segment<T> segment) {
        OUTPUT result = zero.get();
        for (Observation<T> o : segment) {
            result = updateFunc.evaluate(result, o.getValue());
        }
        return result;
    }

    @Override
    public Object clone() {
        return new Aggregate<>(zero, updateFunc);
    }
}
