package com.ibm.research.time_series.core.functions;

import java.io.Serializable;

/**
 * An interface to handle the re-mapping of a segments output timestamp
 */
public interface SegmentTimestampRemappingFunction extends Serializable {

    /**
     * re-map the given observation's timestamp to a new timestamp
     * @param observationTimestamp the original {@link com.ibm.research.time_series.core.utils.Segment} timestamp
     * @param segmentStart the start of a {@link com.ibm.research.time_series.core.utils.Segment}
     * @param segmentEnd the end of a {@link com.ibm.research.time_series.core.utils.Segment}
     * @param firstTimestamp the first observation's timestamp in the {@link com.ibm.research.time_series.core.utils.Segment}
     * @param lastTimestamp the last observation's timestamp in the {@link com.ibm.research.time_series.core.utils.Segment}
     * @return a remapped timestamp for a {@link com.ibm.research.time_series.core.utils.Segment}
     */
    long evaluate(long observationTimestamp, long segmentStart, long segmentEnd, long firstTimestamp, long lastTimestamp);
}
