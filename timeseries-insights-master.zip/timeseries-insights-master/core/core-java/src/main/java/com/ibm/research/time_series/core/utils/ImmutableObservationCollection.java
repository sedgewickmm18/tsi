package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

import java.util.Collection;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.stream.Stream;

public class ImmutableObservationCollection<T> implements ObservationCollection<T> {

    private ObservationCollection<T> observations;

    public ImmutableObservationCollection() {
        this.observations = new MutableObservationCollection<>();
    }

    ImmutableObservationCollection(MutableObservationCollection<T> observations, int firstIndex, int lastIndex) {
        this.observations = new MutableObservationCollection<>(observations, firstIndex, lastIndex);
    }

    public ImmutableObservationCollection(ObservationCollection<T> observations) {
        this.observations = observations;
    }

    @Override
    public boolean contains(long timestamp) {
        return observations.contains(timestamp);
    }

    @Override
    public boolean containsAll(Collection<? extends Long> c) {
        return observations.containsAll(c);
    }

    @Override
    public Iterator<Observation<T>> iterator() {
        return observations.iterator();
    }

    @Override
    public Stream<Observation<T>> parallelStream() {
        return observations.parallelStream();
    }

    @Override
    public Spliterator<Observation<T>> spliterator() {
        return observations.spliterator();
    }

    @Override
    public Stream<Observation<T>> stream() {
        return observations.stream();
    }

    @Override
    public Object[] toArray() {
        return observations.toArray();
    }

    @Override
    public Observation<T>[] toArray(Observation<T>[] a) {
        return observations.toArray(a);
    }

    @Override
    public Observation<T> ceiling(long timestamp) {
        return observations.ceiling(timestamp);
    }

    @Override
    public Observation<T> floor(long timestamp) {
        return observations.floor(timestamp);
    }

    @Override
    public ObservationCollection<T> headSet(long to, boolean toInclusive) {
        return observations.headSet(to,toInclusive);
    }

    @Override
    public ObservationCollection<T> tailSet(long from, boolean fromInclusive) {
        return observations.tailSet(from,fromInclusive);
    }

    @Override
    public Iterator<Observation<T>> descendingIterator() {
        return observations.descendingIterator();
    }

    @Override
    public ObservationCollection<T> subSet(long from, boolean fromInclusive, long to, boolean toInclusive) {
        return observations.subSet(from, fromInclusive, to, toInclusive);
    }

    @Override
    public Observation<T> first() {
        return observations.first();
    }

    @Override
    public Observation<T> last() {
        return observations.last();
    }

    @Override
    public Observation<T> higher(long timestamp) {
        return observations.higher(timestamp);
    }

    @Override
    public Observation<T> lower(long timestamp) {
        return observations.lower(timestamp);
    }

    @Override
    public TimeSeries<T> toTimeSeriesStream() {
        return observations.toTimeSeriesStream();
    }

    @Override
    public TimeSeries<T> toTimeSeriesStream(TRS trs) {
        return observations.toTimeSeriesStream(trs);
    }

    @Override
    public Collection<Observation<T>> toCollection() {
        return observations.toCollection();
    }

    @Override
    public int size() {
        return observations.size();
    }

    @Override
    public boolean isEmpty() {
        return observations.isEmpty();
    }

    @Override
    public TRS getTRS() {
        return observations.getTRS();
    }

//    @Override
//    public boolean isPeriodic() {
//        return observations.isPeriodic();
//    }

    @Override
    public String toString() {
        return observations.toString();
    }
}
