/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.duplicate;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.transform.UnaryTransform;

import java.util.List;

/**
 * This is the entry point for all core built-in transforms for handling duplicate timestamps or
 * duplicate values
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DuplicateTransformers {

    /**
     * This is a duplicate consecutive value removal transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} it will remove consecutive duplicates values.
     *
     * <p>Note:The oldest timestamp is preserved and the newer ones are dropped.</p>
     *
     * <p>For example:</p>
     * <ul>
     *     <li>input: [Observation(a,t0),Observation(a,t1),Observation(b,t2),Observation(c,t3),Observation(a,t4),Observation(d,t5)]</li>
     *     <li><pre>{@code transform(DuplicateTransformers.removeConsecutiveDuplicateValues())}</pre></li>
     *     <li>result: [Observation(a,t0),Observation(b,t2),Observation(c,t3),Observation(a,t4),Observation(d,t5)]</li>
     * </ul>
     *
     * @param <T> observation value type
     * @return a single instance of remove consecutive duplicate values transform
     */
    public static <T> UnaryTransform<T,T> removeConsecutiveDuplicateValues() {
        return new RemoveConsecutiveDuplicateValues<>();
    }

    /**
     * This is the combine duplicate timestamps transform, applied on any
     * {@link com.ibm.research.time_series.core.timeseries.TimeSeries} it will combine any observations that have duplicate
     * timestamps.
     *
     * <p>For example:</p>
     * <ul>
     *     <li>input: [Observation(1,1),Observation(1,2),Observation(2,2)]</li>
     *     <li><pre>{@code transform(DuplicateTransformers.combineDuplicateTimeTicks((l) -> l.stream().mapToDouble(x -> x).sum()))}</pre></li>
     *     <li>result: [Observation(1,3),Observation(2,2)]</li>
     * </ul>
     *
     * @param combineOp function to combine duplicate timestamped observations
     * @param <T> observation value type
     * @return a single instance of combine duplicate timestamps transform
     */
    //todo might want to return new time from combine, not always same type...
    public static <T> UnaryTransform<T,T> combineDuplicateTimeTicks(UnaryMapFunction<List<T>,T> combineOp) {
        return new CombineDuplicateTimeTicks<>(combineOp);
    }
}
