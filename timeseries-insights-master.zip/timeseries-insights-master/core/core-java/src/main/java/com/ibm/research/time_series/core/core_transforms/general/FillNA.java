package com.ibm.research.time_series.core.core_transforms.general;

import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

class FillNA<T> extends UnaryTransform<T,T> {
    private static final long serialVersionUID = -4076567038472476830L;

    private Interpolator<T> interpolator;
    private T nullValue;

    FillNA(Interpolator<T> interpolator, T nullValue) {
        this.interpolator = interpolator;
        this.nullValue = nullValue;
    }

    @Override
    public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {

        final ObservationCollection<T> values = timeSeries.getValues(t1, t2, inclusive);

        final ObservationCollection<T> valuesWithoutNulls = timeSeries.filter(x -> x != null && x != nullValue && !(nullValue instanceof Double && Double.isNaN((Double) x)))
                .collect();

        TSBuilder<T> tsBuilder = Observations.newBuilder();
        for (Observation<T> obs : values) {
            if (obs.getValue() == nullValue || (nullValue instanceof Double && Double.isNaN((Double) obs.getValue()))) {
                tsBuilder.add(
                        obs.getTimeTick(),
                        interpolator.interpolate(getHistory(obs.getTimeTick(),valuesWithoutNulls),getFuture(obs.getTimeTick(),valuesWithoutNulls),obs.getTimeTick())
                );
            } else {
                tsBuilder.add(obs.getTimeTick(),obs.getValue());
            }
        }
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new FillNA<>(interpolator,nullValue);
    }

    private ObservationCollection<T> getHistory(long timestamp, ObservationCollection<T> set){

        //we must check if we are in the range, else we will receive an error from headSet
        if (set.isEmpty() || timestamp < set.first().getTimeTick())
            return Observations.empty();

        TSBuilder<T> builder = Observations.newBuilder();

        long timestampToCheck;

        if (timestamp > set.last().getTimeTick())
            timestampToCheck = set.last().getTimeTick();
        else
            timestampToCheck = timestamp;

        Iterator<Observation<T>> headDescending = set.headSet(
                timestampToCheck,
                timestampToCheck != timestamp
        ).descendingIterator();

        while(builder.size() != interpolator.getHistorySize() && headDescending.hasNext()){
            final Observation<T> next = headDescending.next();
            if (next.getValue() != null) builder.add(next);
        }

        return builder.result();
    }

    private ObservationCollection<T> getFuture(long timestamp, ObservationCollection<T> set){

        if (set.isEmpty() || timestamp > set.last().getTimeTick())
            return Observations.empty();

        TSBuilder<T> builder = Observations.newBuilder();

        long timestampToCheck;

        if (timestamp < set.first().getTimeTick())
            timestampToCheck = set.first().getTimeTick();
        else
            timestampToCheck = timestamp;

        Iterator<Observation<T>> tailAscending = set.tailSet(
                timestampToCheck,
                timestampToCheck != timestamp
        ).iterator();

        while(builder.size() != interpolator.getFutureSize() && tailAscending.hasNext()){
            final Observation<T> next = tailAscending.next();
            if (next.getValue() != null) builder.add(next);
        }

        return builder.result();
    }
}
