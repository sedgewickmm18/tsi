package com.ibm.research.time_series.core.core_transforms.general.python;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.List;

public class PythonFilterValues {
    public static <T> UnaryTransform<T,T> filterValue(List<T> value) {
        return new UnaryTransform<T, T>() {
            @Override
            public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {
                return timeSeries.filter(value::contains).getValues(t1,t2,inclusive);
            }
        };
    }

    public static UnaryTransform<Double,Double> filterNumberRange(double min, boolean inclusiveMin, double max, boolean inclusiveMax) {
        return new UnaryTransform<Double, Double>() {
            @Override
            public ObservationCollection<Double> evaluate(long t1, long t2, boolean inclusive) {
                return timeSeries.filter(val -> {
                    if (inclusiveMin && inclusiveMax) {
                        return val >= min && val <= max;
                    } else if (inclusiveMin) {
                        return val >= min && val < max;
                    } else if (inclusiveMax) {
                        return val > min && val <= max;
                    } else {
                        return val > min && val < max;
                    }
                }).getValues(t1,t2,inclusive);
            }
        };
    }

    public static <T> UnaryTransform<T,T> filterBounds(T startValue, boolean inclusiveStart, T endValue, boolean inclusiveEnd) {
        return new UnaryTransform<T, T>() {
            @Override
            public ObservationCollection<T> evaluate(long t1, long t2, boolean inclusive) {
                ObservationCollection<T> collected = timeSeries.getValues(t1, t2, inclusive);
                TSBuilder<T> tsBuilder = Observations.newBuilder();
                boolean foundStart = startValue == null;
                for (Observation<T> obs : collected) {
                    if (!foundStart) {
                        if (obs.getValue().equals(startValue)) {
                            if (inclusiveStart) tsBuilder.add(obs);
                            foundStart = true;
                        }
                    } else {
                        if (obs.getValue().equals(endValue)) {
                            if (inclusiveEnd) tsBuilder.add(obs);
                            break;
                        }
                        tsBuilder.add(obs);
                    }
                }
                return tsBuilder.result();
            }
        };
    }
}
