/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.io;

import java.util.Iterator;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * Interface to represent reading time-series data from a data-source
 *
 * @author Joshua Rosenkranz
 * @author Raghu Ganti
 * @author Mudhakar Srivatsa
 */
public interface TimeSeriesReader<T> {

	/**
	 * Read from a source between time-ticks t1 and t2.
     * Generally, read should be giving back the floor(t1) and the ceiling(t2).
	 *
	 * <p>Example: [Observation(3,3),Observation(5,5),Observation(7,7)]</p>
	 * <pre>{@code read(4,6)}</pre>
	 * <p>Result: [Observation(3,3),Observation(5,5),Observation(7,7)]</p>
	 * <pre>{@code read(5,6)}</pre>
	 * <p>Result: [Observation(5,5),Observation(7,7)]</p>
	 *
     * @param t1 timestamp start
     * @param t2 timestamp end
	 * @param inclusiveIfBoundsNotExist if true, if t1 does not exist in the dataset, get the first observation with
	 *                                  a timetick less than t1 (floor(t1)) and if t2 does not exist in the dataset, get
	 *                                  the first observation with a timetick greater than t2 (ceiling(t2)), otherwise,
	 *                                  strictly keep bounds within the [t1,t2] range
	 * @return an Iterator to a set of {@link Observation} between floor(t1) and ceiling(t2) of our source
	 */
	Iterator<Observation<T>> read(long t1, long t2,boolean inclusiveIfBoundsNotExist);

	/**
	 * close the connection to our source
	 */
	void close();

	/**
	 * signifies the first time-tick in the source
	 * <p>re-implement this method if you would like to accurately use collect()</p>
	 *
	 * @return the starting time-tick of the {@link TimeSeriesReader}
	 */
	default long start() {
	    return Long.MIN_VALUE;
    }

	/**
	 * signifies the last timestamp in the source
	 * <p>re-implement this method if you would like to accurately use collect()</p>
	 *
	 * @return the ending time-tick of the {@link TimeSeriesReader}
	 */
	default long end() {
	    return Long.MAX_VALUE;
    }

	/**
	 * A utility method for getting the floor of a time-tick without returning null. If the floor does not exist,
	 * return the ceiling.
	 * @param observations observation to check against
	 * @param timestamp timestamp to get floor of
	 * @param <T> {@link Observation} value type
	 * @return floor(time-tick) if exists, otherwise ceil(time-tick)
	 */
	static <T> long getFloor(ObservationCollection<T> observations, long timestamp) {
		long result;
		if(observations.contains(timestamp)){
			result = timestamp;
		}else{
			Observation<T> floorHolder = observations.floor(timestamp);
			if (floorHolder == null){
				result = observations.ceiling(timestamp).getTimeTick();
			}else{
				result = floorHolder.getTimeTick();
			}
		}

		return result;
	}

	/**
	 * A utility method for getting the ceiling of a time-tick without returning null. If the ceiling does not exist,
	 * return the floor.
	 * @param observations observation to check against
	 * @param timestamp timestamp to get ceiling of
	 * @param <T> {@link Observation} value type
	 * @return ceil(time-tick) of exists, otherwise floor(time-tick)
	 */
	static <T> long getCeiling(ObservationCollection<T> observations, long timestamp){
		long result;

		if(observations.contains(timestamp)){
			result = timestamp;
		}else{
			Observation<T> ceilingHolder = observations.ceiling(timestamp);
			if(ceilingHolder == null){
				result = observations.floor(timestamp).getTimeTick();
			}else{
				result = ceilingHolder.getTimeTick();
			}
		}

		return result;
	}
}
