package com.ibm.research.time_series.core.utils;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class PythonConnector {

    //todo fix this method (this should really be part of MultiTimeSeries and not just and on-the-fly method like this)
    public static <K,T> String multiTimeSeriesToString(MultiTimeSeries<K,T> mts, Number t1, Number t2, boolean inclusive) {
        TRS ti = mts.getTimeSeriesMap().values().iterator().next().getTRS();
        return mts.getTimeSeriesMap().entrySet().stream()
                .map(entry -> {
                    String result = entry.getKey().toString() + " time series\n------------------------------\n";
                    String tsResult;
                    if (ti == null) {
                        tsResult = entry.getValue().getValues(t1.longValue(),t2.longValue(),inclusive).stream().map(Observation::toString).collect(Collectors.joining("\n"));
                    } else {
                        tsResult = entry.getValue().getValues(ti.toIndex(t1.longValue()),ti.toIndex(t2.longValue()),inclusive).stream().map(x -> x.toString(ti)).collect(Collectors.joining("\n"));
                    }
                    return result + tsResult;
                })
                .collect(Collectors.joining("\n"));
    }

    public static <K,T> String multiTimeSeriesToString(MultiTimeSeries<K,T> mts, ZonedDateTime t1, ZonedDateTime t2, boolean inclusive) {
        TRS ti = mts.getTimeSeriesMap().values().iterator().next().getTRS();
        long t1L = t1.toInstant().toEpochMilli();
        long t2L = t2.toInstant().toEpochMilli();
        return multiTimeSeriesToString(mts, t1L, t2L, inclusive);
    }

    public static <T> TimeSeries<T> resample(TimeSeries<T> ts, long period, Interpolator<T> interpolator) {
        return ts.resample(period, interpolator);
    }

    public static <T> TimeSeries<T> resample(TimeSeries<T> ts, int period, Interpolator<T> interpolator) {
        return ts.resample(period, interpolator);
    }

    public static <K, T> MultiTimeSeries<K, T> resampleSeries(MultiTimeSeries<K,T> mts, long period, Interpolator<T> interpolator) {
        return mts.resample(period, interpolator);
    }

    public static <K, T> MultiTimeSeries<K, T> resampleSeries(MultiTimeSeries<K,T> mts, int period, Interpolator<T> interpolator) {
        return mts.resample(period, interpolator);
    }

    private static long convertToLongTimestamp(String tsString, DateTimeFormatter dtfb) {
        long ts = -1;
        try {
            //try long
            ts = Long.parseLong(tsString);
        } catch (NumberFormatException e) {
            try {
                //try zoned date time
                ts = ZonedDateTime.parse(tsString,dtfb).toInstant().toEpochMilli();
            } catch (Exception e2){
                try {
                    //try replacing space then zoned date time
                    Pattern pattern = Pattern.compile("[0-9]{2} [0-9]{2}");
                    Matcher matcher = pattern.matcher(tsString);
                    if (matcher.find()) {
                        String rStr = matcher.group(0);
                        ts = ZonedDateTime.parse(
                                tsString.replaceFirst("[0-9]{2} [0-9]{2}", rStr.replace(" ", "T")),
                                dtfb
                        ).toInstant().toEpochMilli();
                    }
                } catch (Exception e3) {
                    try {
                        //try local date time
                        ts = ZonedDateTime.parse(tsString,dtfb.withZone(ZoneId.systemDefault())).toInstant().toEpochMilli();
                    } catch (Exception e4) {
                        try {
                            //try replacing space then zoned date time
                            Pattern pattern = Pattern.compile("[0-9]{2} [0-9]{2}");
                            Matcher matcher = pattern.matcher(tsString);
                            if (matcher.find()) {
                                String rStr = matcher.group(0);
                                ts = ZonedDateTime.parse(
                                        tsString.replaceFirst("[0-9]{2} [0-9]{2}", rStr.replace(" ", "T")),
                                        dtfb.withZone(ZoneId.systemDefault())
                                ).toInstant().toEpochMilli();
                            }
                        } catch (Exception e5) {
                            try {
                                //try local date
                                ts = LocalDate.parse(tsString, dtfb).atTime(0, 0, 0, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                            } catch (Exception e6) {
                                //do nothing
                            }
                        }
                    }
                }
            }
        }
        return ts;
    }

    private static Object getValueFromType(String rawValue, String valueType) {
        Object value;
        switch(valueType) {
            case "int64":
                value = (rawValue.equals("")) ? null : Integer.valueOf(rawValue);
                break;
            case "float64":
                value = (rawValue.equals("") || rawValue.equals("NaN")) ? null : Double.valueOf(rawValue);
                break;
            case "object":
                value = rawValue;
                break;
            case "bool":
                value = (rawValue.equals("")) ? null : Boolean.valueOf(rawValue);
                break;
            default:
                throw new TSRuntimeException("currently values supported are String, Boolean, Double, Integer, Long");
        }
        return value;
    }

    private static Function<String,Long> parseTimestamp(Function<String, ?> parseTimestampUnknownType) {
        return (l) -> {
            Object answer = parseTimestampUnknownType.apply(l);
            if (answer instanceof Long) {
                return (Long) answer;
            } else if (answer instanceof Integer) {
                return new Long((Integer) answer);
            } else if (answer instanceof String) {
                try {
                    return Long.valueOf((String) answer);
                } catch (Exception e){
                    return ZonedDateTime.of(LocalDateTime.parse((String) answer, DateTimeFormatter.ISO_OFFSET_DATE_TIME), ZoneId.systemDefault()).toInstant().toEpochMilli();
                }
            }
            return null;
        };
    }







    //////////////////////////////////

    public static TimeSeries<Object> readDataFrameJsonString(String jsonString, Pair<String,String> timestampToType, Pair<String,String> valueToType, TRS trs) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(jsonString);
            final Iterator<JsonNode> nodes = jsonNode.getElements();
            TSBuilder<Object> tsBuilder = Observations.newBuilder();
            if (timestampToType == null) {
                long i = 0;
                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object value = getValueFromType(node, valueToType);
                    tsBuilder.add(i, value);
                    i++;
                }
            } else {
                final DateTimeFormatter dtfb = getDateTimeFormatter();
                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object value = getValueFromType(node, valueToType);
                    tsBuilder.add(getTimestampFromType(node, timestampToType,dtfb), value);
                }
            }
            return tsBuilder.result(trs).toTimeSeriesStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static TimeSeries<PythonRecord> readDataFrameJsonString(String jsonString,Pair<String,String> timestampToType, Map<String,String> valueToType, TRS trs) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(jsonString);
            final Iterator<JsonNode> nodes = jsonNode.getElements();
            TSBuilder<PythonRecord> tsBuilder = Observations.newBuilder();

            if (timestampToType == null) {
                long i = 0;
                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    PythonRecord pythonRecord = new PythonRecord(valueToType.entrySet().stream().map(e -> {
                        return new Pair<>(e.getKey(), getValueFromType(node, new Pair<>(e.getKey(), e.getValue())));
                    }).collect(Collectors.toMap(x -> x.left, x -> x.right)));
                    tsBuilder.add(i, pythonRecord);
                    i++;
                }
            } else {
                final DateTimeFormatter dtfb = getDateTimeFormatter();

                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    PythonRecord pythonRecord = new PythonRecord(valueToType.entrySet().stream().map(e -> {
                        return new Pair<>(e.getKey(), getValueFromType(node, new Pair<>(e.getKey(), e.getValue())));
                    }).collect(Collectors.toMap(x -> x.left, x -> x.right)));
                    tsBuilder.add(getTimestampFromType(node, timestampToType, dtfb), pythonRecord);
                }
            }
            return tsBuilder.result(trs).toTimeSeriesStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> String saveTimeSeriesAsJsonString(TimeSeries<T> timeSeries, boolean inclusive) {
        JsonFactory jsonFactory = new JsonFactory();
        String whatType = "";
        try {
            StringWriter writer = new StringWriter();
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(writer);

            final ObservationCollection<T> collect = timeSeries.collect(inclusive);

            jsonGen.writeStartArray();
            if (!collect.isEmpty()) {
                final Observation<T> first = collect.first();
                whatType = first.getClass().toString();

                if (first.getValue() instanceof Record) {
                    Map<String,String> valueToType = new HashMap<>();

                    for (Observation<T> o : collect) {
                        jsonGen.writeStartObject();

                        jsonGen.writeNumberField("timestamp", o.getTimeTick());
                        Record pythonRecord = (Record) o.getValue();

                        Iterator<String> keysIter = pythonRecord.keys();

                        while (keysIter.hasNext()) {
                            final String key = keysIter.next();
                            final Object obj = pythonRecord.get(key);
                            if (!valueToType.containsKey(key)) {
                                if (obj instanceof Long) {
                                    valueToType.put(key,"long");
                                } else if (obj instanceof Integer) {
                                    valueToType.put(key,"int");
                                } else if (obj instanceof Double) {
                                    valueToType.put(key,"double");
                                } else {
                                    valueToType.put(key,"string");
                                }
                            }

                            String newKey = (key.equals("timestamp")) ? "timestamp.1" : key;
                            switch (valueToType.get(key)) {
                                case "long":
                                    jsonGen.writeNumberField(newKey,(Long)obj);
                                    break;
                                case "int":
                                    jsonGen.writeNumberField(newKey,(Integer) obj);
                                    break;
                                case "double":
                                    jsonGen.writeNumberField(newKey,(Double) obj);
                                    break;
                                default:
                                    jsonGen.writeStringField(newKey,(String) obj);
                                    break;
                            }
                        }

                        jsonGen.writeEndObject();
                    }
                } else if (first.getValue() instanceof HashMap){ //todo this is covering the py4j case where there is automatic conversion, will remove once record properly implements a map

                    Map<String,String> valueToType = new HashMap<>();


                    for (Observation<T> o : collect) {
                        jsonGen.writeStartObject();

                        jsonGen.writeNumberField("timestamp", o.getTimeTick());
                        HashMap<String,Object> pythonRecord = (HashMap<String,Object>) o.getValue();

                        Iterator<String> keysIter = pythonRecord.keySet().iterator();

                        while (keysIter.hasNext()) {
                            final String key = keysIter.next();
                            final Object obj = pythonRecord.get(key);
                            if (!valueToType.containsKey(key)) {
                                if (obj instanceof Long) {
                                    valueToType.put(key,"long");
                                } else if (obj instanceof Integer) {
                                    valueToType.put(key,"int");
                                } else if (obj instanceof Double) {
                                    valueToType.put(key,"double");
                                } else {
                                    valueToType.put(key,"string");
                                }
                            }

                            String newKey = (key.equals("timestamp")) ? "timestamp.1" : key;
                            switch (valueToType.get(key)) {
                                case "long":
                                    jsonGen.writeNumberField(newKey,(Long)obj);
                                    break;
                                case "int":
                                    jsonGen.writeNumberField(newKey,(Integer) obj);
                                    break;
                                case "double":
                                    jsonGen.writeNumberField(newKey,(Double) obj);
                                    break;
                                default:
                                    jsonGen.writeStringField(newKey,(String) obj);
                                    break;
                            }
                        }

                        jsonGen.writeEndObject();
                    }

                } else {
                    for (Observation<T> o : collect) {
                        jsonGen.writeStartObject();

                        jsonGen.writeNumberField("timestamp", o.getTimeTick());
                        T value = o.getValue();
                        if (value instanceof Long) {
                            jsonGen.writeNumberField("value",(Long)value);
                        } else if (value instanceof Integer) {
                            jsonGen.writeNumberField("value",(Integer)value);
                        } else if (value instanceof Double) {
                            jsonGen.writeNumberField("value",(Double)value);
                        } else if (value instanceof String) {
                            jsonGen.writeStringField("value",(String)value);
                        } else {
                            List<Object> l = (List<Object>)value;
                            for (int i = 0;i < l.size();i++) {
                                Object valueI = l.get(i);
                                if (valueI instanceof Long) {
                                    jsonGen.writeNumberField("value_" + i,(Long)valueI);
                                } else if (valueI instanceof Integer) {
                                    jsonGen.writeNumberField("value_" + i,(Integer)valueI);
                                } else if (valueI instanceof Double) {
                                    jsonGen.writeNumberField("value_" + i,(Double)valueI);
                                } else {
                                    jsonGen.writeStringField("value_" + i, (String) valueI);
                                }
                            }
                        }
                        jsonGen.writeEndObject();
                    }
                }

            }
            jsonGen.writeEndArray();

            jsonGen.close();
            return writer.toString();
        } catch (Exception e) {
//            return null
//            e.printStackTrace();
//            StringWriter sw = new StringWriter();
//            e.printStackTrace(new PrintWriter(sw));
//            String exceptionAsString = sw.toString();
//            return exceptionAsString;
        }
        return null;
    }

    public static <T> String saveTimeSeriesAsCSVString(TimeSeries<T> timeSeries, boolean inclusive) {
        StringWriter sw = new StringWriter();
        final ObservationCollection<T> collected = timeSeries.collect(inclusive);
        try {
            if (!collected.isEmpty()) {
                Observation<T> first = collected.first();
                if (first.getValue() instanceof Record) {
                    List<String> keys = new ArrayList<>();
                    ((Record) first.getValue()).keys().forEachRemaining(keys::add);
                    sw.write("timestamp" + "\t" + String.join("\t", keys));
                    sw.write("\n");
                    ObservationCollection<Record> observations = (ObservationCollection<Record>) collected;
                    for (Observation<Record> obs : observations) {
                        long timestamp = obs.getTimeTick();
                        String values = keys.stream().map(k -> (obs.getValue().get(k) == null) ? "" : obs.getValue().get(k).toString()).collect(Collectors.joining("\t"));
                        sw.write(timestamp + "\t" + values);
                        sw.write("\n");
                    }
                } else {
                    sw.write("timestamp" + "\t" + "value");
                    sw.write("\n");
                    for (Observation<T> observation : collected) {
                        String value = (observation.getValue() == null) ? "" : observation.getValue().toString();
                        sw.write(observation.getTimeTick() + "\t" + value);
                        sw.write("\n");
                    }
                }
            }
            sw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sw.toString();
    }

    public static <K,T> String saveMultiTimeSeriesAsInstantsCSVString(MultiTimeSeries<K,T> mts, boolean inclusive) {
        final Map<K, List<Observation<T>>> obsMap = mts.filterSeries(ts -> ts.count() != 0).collect(inclusive)
                .entrySet()
                .parallelStream()
                .map(x -> new AbstractMap.SimpleEntry<>(x.getKey(), new ArrayList<>(x.getValue().toCollection())))
                .collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));

        final int seriesSize = obsMap.entrySet().iterator().next().getValue().size();


        StringWriter sw = new StringWriter();
        try {

            final List<K> columns = new ArrayList<>(obsMap.keySet());

            sw.write("timestamp" + "\t" + columns.stream().map(Object::toString).collect(Collectors.joining("\t")));
            sw.write("\n");
            for (int i = 0; i < seriesSize; i++) {
                int finalI = i;
                final String valueColumns = columns.stream()
                        .map(c -> (obsMap.get(c).get(finalI).getValue() == null) ? "" : obsMap.get(c).get(finalI).getValue().toString())
                        .collect(Collectors.joining("\t"));
                final long timestamp = obsMap.get(columns.iterator().next()).get(i).getTimeTick();
                sw.write(timestamp + "\t" + valueColumns);
                sw.write("\n");
            }
            sw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sw.toString();
    }

    public static <K,T> String saveMultiTimeSeriesAsObservationsCSVString(MultiTimeSeries<K,T> mts, boolean inclusive) {
        final Map<K, ObservationCollection<T>> obsMap = mts.filterSeries(ts -> ts.count() != 0).collect(inclusive);
        StringWriter sw = new StringWriter();
        try {

            if (!obsMap.isEmpty()) {
                final Set<K> keys = obsMap.keySet();
                final ObservationCollection<T> randomColl = obsMap.get(keys.iterator().next());
                Observation<T> first = randomColl.first();

                if (first.getValue() instanceof Record) {
                    List<String> columns = new ArrayList<>();
                    ((Record) first.getValue()).keys().forEachRemaining(columns::add);
                    sw.write("key" + "\t" + "timestamp" + "\t" + String.join("\t", columns));
                    sw.write("\n");
                    for (Map.Entry<K, ObservationCollection<T>> rEntry : obsMap.entrySet()) {
                        ObservationCollection<Record> observations = (ObservationCollection<Record>) rEntry.getValue();
                        for (Observation<Record> obs : observations) {
                            long timestamp = obs.getTimeTick();
                            String values = columns.stream().map(k -> (obs.getValue().get(k) == null) ? "" : obs.getValue().get(k).toString()).collect(Collectors.joining("\t"));
                            sw.write(rEntry.getKey().toString() + "\t" + timestamp + "\t" + values);
                            sw.write("\n");
                        }
                    }
                } else {
                    sw.write("key" + "\t" + "timestamp" + "\t" + "value");
                    sw.write("\n");
                    for (Map.Entry<K, ObservationCollection<T>> obsEntry : obsMap.entrySet()) {
                        for (Observation<T> obs : obsEntry.getValue()) {
                            String value = (obs.getValue() == null) ? "" : obs.getValue().toString();

                            sw.write(obsEntry.getKey().toString() + "\t" + obs.getTimeTick() + "\t" + value);
                            sw.write("\n");
                        }
                    }
                }
            }
            sw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sw.toString();
    }

    private static DateTimeFormatter getDateTimeFormatter() {
        return new DateTimeFormatterBuilder()
                .appendOptional(DateTimeFormatter.ISO_DATE_TIME)
                .appendOptional(DateTimeFormatter.ISO_ZONED_DATE_TIME)
                .appendOptional(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
                .appendOptional(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                .appendOptional(DateTimeFormatter.ISO_INSTANT)
                .appendOptional(DateTimeFormatter.ISO_TIME)
                .appendOptional(DateTimeFormatter.ISO_OFFSET_DATE)
                .appendOptional(DateTimeFormatter.ISO_OFFSET_TIME)
                .appendOptional(DateTimeFormatter.ISO_DATE)
                .appendOptional(DateTimeFormatter.ISO_ORDINAL_DATE)
                .appendOptional(DateTimeFormatter.ISO_LOCAL_DATE)
                .appendOptional(DateTimeFormatter.ISO_LOCAL_TIME)
                .appendOptional(DateTimeFormatter.BASIC_ISO_DATE)
                .appendOptional(DateTimeFormatter.ISO_WEEK_DATE)
                .appendOptional(DateTimeFormatter.RFC_1123_DATE_TIME)
                .toFormatter();
    }

    private static long getTimestampFromType(JsonNode json, Pair<String,String> timestampToType, DateTimeFormatter dtfb) {
        long value = -1;
        switch(timestampToType.right) {
            case "datetime64[ns]":
                value = json.get(timestampToType.left).getLongValue();
                break;
            case "int64":
                value = json.get(timestampToType.left).getLongValue();
                break;
            case "float64":
                value = (long) json.get(timestampToType.left).getDoubleValue();
                break;
            case "object":
                String tsString = json.get(timestampToType.left).getTextValue();
                try {
                    //try zoned date time
                    value = ZonedDateTime.parse(tsString,dtfb).toInstant().toEpochMilli();
                } catch (Exception e2) {
                    try {
                        //try replacing space then zoned date time
                        Pattern pattern = Pattern.compile("[0-9]{2} [0-9]{2}");
                        Matcher matcher = pattern.matcher(tsString);
                        if (matcher.find()) {
                            String rStr = matcher.group(0);
                            value = ZonedDateTime.parse(
                                    tsString.replaceFirst("[0-9]{2} [0-9]{2}", rStr.replace(" ", "T")),
                                    dtfb
                            ).toInstant().toEpochMilli();
                        }
                    } catch (Exception e3) {
                        try {
                            //try local date time
                            value = ZonedDateTime.parse(tsString, dtfb.withZone(ZoneId.systemDefault())).toInstant().toEpochMilli();
                        } catch (Exception e4) {
                            try {
                                //try replacing space then zoned date time
                                Pattern pattern = Pattern.compile("[0-9]{2} [0-9]{2}");
                                Matcher matcher = pattern.matcher(tsString);
                                if (matcher.find()) {
                                    String rStr = matcher.group(0);
                                    value = ZonedDateTime.parse(
                                            tsString.replaceFirst("[0-9]{2} [0-9]{2}", rStr.replace(" ", "T")),
                                            dtfb.withZone(ZoneId.systemDefault())
                                    ).toInstant().toEpochMilli();
                                }
                            } catch (Exception e5) {
                                try {
                                    //try local date
                                    value = LocalDate.parse(tsString, dtfb).atTime(0, 0, 0, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                                } catch (Exception e6) {
                                    //do nothing
                                }
                            }
                        }
                    }
                }
                break;
            default:
                throw new TSRuntimeException("currently values supported are String, Boolean, Double, Integer, Long");
        }
        return value;
    }

    private static Object getValueFromType(JsonNode jsonNode, Pair<String,String> valueToType) {
        Object value;
        switch(valueToType.right) {
            case "datetime64[ns]":
                value = jsonNode.get(valueToType.left).getLongValue();
                break;
            case "int64":
                value = jsonNode.get(valueToType.left).getLongValue();
                break;
            case "float64":
                value = jsonNode.get(valueToType.left).getDoubleValue();
                break;
            case "object":
                value = jsonNode.get(valueToType.left).getTextValue();
                break;
            case "category":
                value = jsonNode.get(valueToType.left).getTextValue();
                break;
            case "bool":
                value = jsonNode.get(valueToType.left).getBooleanValue();
                break;
            default:
                throw new TSRuntimeException("currently values supported are String, Boolean, Double, Integer, Long");
        }
        return value;
    }

    /////////////////////////////////////


    public static MultiTimeSeries<Object,Object> readDataFrameInstantsJsonString(String jsonString, Pair<String,String> timestampToType, Map<String,String> valueToType, TRS trs) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(jsonString);
            final DateTimeFormatter dtfb = getDateTimeFormatter();

            int numRows = (timestampToType == null) ? jsonNode.get(valueToType.entrySet().iterator().next().getKey()).size() : jsonNode.get(timestampToType.left).size();

            Map<Object,MutableObservationCollection<Object>> map = new HashMap<>();
            valueToType.forEach((key, value) -> map.put(key, new MutableObservationCollection<>()));

            for (int i = 0;i < numRows;i++) {
                String currentKey = String.valueOf(i);
                long timestamp = (timestampToType == null) ? i : getTimestampFromType(jsonNode.get(timestampToType.left),new Pair<>(currentKey,timestampToType.right),dtfb);
                for (Map.Entry<String, String> e : valueToType.entrySet()) {
                    map.get(e.getKey()).add(new Observation<>(timestamp, getValueFromType(jsonNode.get(e.getKey()),new Pair<>(currentKey,e.getValue()))));
                }
            }
            final Map<Object, TimeSeries<Object>> collect = map.entrySet().parallelStream()
                    .map(e -> new Pair<>(e.getKey(), e.getValue().toTimeSeriesStream(trs)))
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
            return new MultiTimeSeries<>(collect);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static MultiTimeSeries<String,PythonRecord> readDataFrameJsonString(String jsonString, Pair<String,String> keyToType, Pair<String,String> timestampToType, Map<String,String> valueToType, TRS trs) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(jsonString);
            final Iterator<JsonNode> nodes = jsonNode.getElements();
            Map<Object,MutableObservationCollection<PythonRecord>> map = new HashMap<>();

            if (timestampToType == null) {
                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object key = getValueFromType(node, keyToType);
                    PythonRecord pythonRecord = new PythonRecord(valueToType.entrySet().stream().map(e -> {
                        return new Pair<>(e.getKey(), getValueFromType(node, new Pair<>(e.getKey(), e.getValue())));
                    }).collect(Collectors.toMap(x -> x.left, x -> x.right)));

                    if (map.containsKey(key)) {
                        map.get(key).add(new Observation<>(map.get(key).last().getTimeTick() + 1,pythonRecord));
                    } else {
                        map.put(key, new MutableObservationCollection<>());
                        map.get(key).add(new Observation<>(0,pythonRecord));
                    }
                }
            } else {
                final DateTimeFormatter dtfb = getDateTimeFormatter();

                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object key = getValueFromType(node, keyToType);
                    PythonRecord pythonRecord = new PythonRecord(valueToType.entrySet().stream().map(e -> {
                        return new Pair<>(e.getKey(), getValueFromType(node, new Pair<>(e.getKey(), e.getValue())));
                    }).collect(Collectors.toMap(x -> x.left, x -> x.right)));
                    if (map.containsKey(key)) {
                        map.get(key).add(new Observation<>(getTimestampFromType(node, timestampToType, dtfb),pythonRecord));
                    } else {
                        map.put(key, new MutableObservationCollection<>());
                        map.get(key).add(new Observation<>(getTimestampFromType(node, timestampToType, dtfb),pythonRecord));
                    }
                }
            }
            final Map<String, TimeSeries<PythonRecord>> collect = map.entrySet().parallelStream()
                    .map(e -> new Pair<>(e.getKey().toString(), e.getValue().toTimeSeriesStream(trs)))
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
            return new MultiTimeSeries<>(collect);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static MultiTimeSeries<String,Object> readDataFrameJsonString(String jsonString, Pair<String,String> keyToType, Pair<String,String> timestampToType, Pair<String,String> valueToType, TRS trs) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(jsonString);
            final Iterator<JsonNode> nodes = jsonNode.getElements();
            Map<Object,MutableObservationCollection<Object>> map = new HashMap<>();

            if (timestampToType == null) {
                long i = 0;
                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object key = getValueFromType(node, keyToType);
                    Object value = getValueFromType(node, valueToType);

                    if (map.containsKey(key)) {
                        map.get(key).add(new Observation<>(i,value));
                    } else {
                        map.put(key, new MutableObservationCollection<>());
                        map.get(key).add(new Observation<>(i,value));
                    }
                    i++;
                }
            } else {
                final DateTimeFormatter dtfb = getDateTimeFormatter();

                while (nodes.hasNext()) {
                    final JsonNode node = nodes.next();
                    Object key = getValueFromType(node, keyToType);
                    Object value = getValueFromType(node, valueToType);
                    if (map.containsKey(key)) {
                        map.get(key).add(new Observation<>(getTimestampFromType(node, timestampToType, dtfb),value));
                    } else {
                        map.put(key, new MutableObservationCollection<>());
                        map.get(key).add(new Observation<>(getTimestampFromType(node, timestampToType, dtfb),value));
                    }
                }
            }
            final Map<String, TimeSeries<Object>> collect = map.entrySet().parallelStream()
                    .map(e -> new Pair<>(e.getKey().toString(), e.getValue().toTimeSeriesStream(trs)))
                    .collect(Collectors.toMap(x -> x.left, x -> x.right));
            return new MultiTimeSeries<>(collect);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <K,T> String saveMultiTimeSeriesInstantsAsJsonString(MultiTimeSeries<K,T> multiTimeSeries, boolean inclusive) {
        JsonFactory jsonFactory = new JsonFactory();
        try {
            StringWriter writer = new StringWriter();
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(writer);

            String valueType = null;
            boolean first = true;
            jsonGen.writeStartObject();
            for (Map.Entry<K, ObservationCollection<T>> entry : multiTimeSeries.collect(inclusive).entrySet()) {
                if (first) {
                    jsonGen.writeObjectFieldStart("timestamp");
                    int i = 0;
                    for (Observation<T> observation : entry.getValue()) {
                        jsonGen.writeNumberField(String.valueOf(i), observation.getTimeTick());
                        i++;
                    }
                    jsonGen.writeEndObject();
                    first = false;
                }


                jsonGen.writeObjectFieldStart(entry.getKey().toString());
                int i = 0;
                for (Observation<T> o : entry.getValue()) {
                    if (valueType == null) {
                        if (o.getValue() instanceof Long) valueType = "long";
                        else if (o.getValue() instanceof Integer) valueType = "int";
                        else if (o.getValue() instanceof Double) valueType = "double";
                        else valueType = "string";
                    }

                    switch (valueType) {
                        case "long":
                            jsonGen.writeNumberField(String.valueOf(i),(Long) o.getValue());
                            break;
                        case "int":
                            jsonGen.writeNumberField(String.valueOf(i),(Integer) o.getValue());
                            break;
                        case "double":
                            jsonGen.writeNumberField(String.valueOf(i),(Double) o.getValue());
                            break;
                        default:
                            jsonGen.writeStringField(String.valueOf(i),(String) o.getValue());
                            break;
                    }
                    i++;
                }
                jsonGen.writeEndObject();
            }
            jsonGen.writeEndObject();
            jsonGen.close();
            return writer.toString();
        } catch (Exception e) {

        }
        return null;
    }

    public static <K,T> String saveMultiTimeSeriesAsJsonString(MultiTimeSeries<K,T> multiTimeSeries, boolean inclusive) {
        JsonFactory jsonFactory = new JsonFactory();
        try {
            StringWriter writer = new StringWriter();
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(writer);

            final Map<K,ObservationCollection<T>> mapCollected = multiTimeSeries.collect(inclusive);

            jsonGen.writeStartArray();
            for (Map.Entry<K, ObservationCollection<T>> entry : mapCollected.entrySet()) {
                K tsKey = entry.getKey();
                String tsKeyType = "";
                if (tsKey instanceof Long) {
                    tsKeyType = "long";
                } else if (tsKey instanceof Integer) {
                    tsKeyType = "int";
                } else if (tsKey instanceof Double) {
                    tsKeyType = "double";
                } else {
                    tsKeyType = "string";
                }

                ObservationCollection<T> collect = entry.getValue();
                if (!collect.isEmpty()) {
                    final Observation<T> first = collect.first();

                    if (first.getValue() instanceof Record) {
                        Map<String,String> valueToType = new HashMap<>();


                        for (Observation<T> o : collect) {
                            jsonGen.writeStartObject();

                            jsonGen.writeNumberField("timestamp", o.getTimeTick());
                            switch (tsKeyType) {
                                case "long":
                                    jsonGen.writeNumberField("key",(Long)tsKey);
                                    break;
                                case "int":
                                    jsonGen.writeNumberField("key",(Integer) tsKey);
                                    break;
                                case "double":
                                    jsonGen.writeNumberField("key",(Double) tsKey);
                                    break;
                                default:
                                    jsonGen.writeStringField("key",(String) tsKey);
                                    break;
                            }
                            Record pythonRecord = (Record) o.getValue();

                            Iterator<String> keysIter = pythonRecord.keys();

                            while (keysIter.hasNext()) {
                                final String key = keysIter.next();
                                final Object obj = pythonRecord.get(key);
                                if (!valueToType.containsKey(key)) {
                                    if (obj instanceof Long) {
                                        valueToType.put(key,"long");
                                    } else if (obj instanceof Integer) {
                                        valueToType.put(key,"int");
                                    } else if (obj instanceof Double) {
                                        valueToType.put(key,"double");
                                    } else {
                                        valueToType.put(key,"string");
                                    }
                                }

                                switch (valueToType.get(key)) {
                                    case "long":
                                        jsonGen.writeNumberField(key,(Long)obj);
                                        break;
                                    case "int":
                                        jsonGen.writeNumberField(key,(Integer) obj);
                                        break;
                                    case "double":
                                        jsonGen.writeNumberField(key,(Double) obj);
                                        break;
                                    default:
                                        jsonGen.writeStringField(key,(String) obj);
                                        break;
                                }
                            }

                            jsonGen.writeEndObject();
                        }
                    } else if (first.getValue() instanceof HashMap) {
                        Map<String,String> valueToType = new HashMap<>();


                        for (Observation<T> o : collect) {
                            jsonGen.writeStartObject();

                            jsonGen.writeNumberField("timestamp", o.getTimeTick());
                            switch (tsKeyType) {
                                case "long":
                                    jsonGen.writeNumberField("key",(Long)tsKey);
                                    break;
                                case "int":
                                    jsonGen.writeNumberField("key",(Integer) tsKey);
                                    break;
                                case "double":
                                    jsonGen.writeNumberField("key",(Double) tsKey);
                                    break;
                                default:
                                    jsonGen.writeStringField("key",(String) tsKey);
                                    break;
                            }
                            HashMap<String,Object> pythonRecord = (HashMap<String, Object>) o.getValue();

                            Iterator<String> keysIter = pythonRecord.keySet().iterator();

                            while (keysIter.hasNext()) {
                                final String key = keysIter.next();
                                final Object obj = pythonRecord.get(key);
                                if (!valueToType.containsKey(key)) {
                                    if (obj instanceof Long) {
                                        valueToType.put(key,"long");
                                    } else if (obj instanceof Integer) {
                                        valueToType.put(key,"int");
                                    } else if (obj instanceof Double) {
                                        valueToType.put(key,"double");
                                    } else {
                                        valueToType.put(key,"string");
                                    }
                                }

                                switch (valueToType.get(key)) {
                                    case "long":
                                        jsonGen.writeNumberField(key,(Long)obj);
                                        break;
                                    case "int":
                                        jsonGen.writeNumberField(key,(Integer) obj);
                                        break;
                                    case "double":
                                        jsonGen.writeNumberField(key,(Double) obj);
                                        break;
                                    default:
                                        jsonGen.writeStringField(key,(String) obj);
                                        break;
                                }
                            }

                            jsonGen.writeEndObject();
                        }
                    } else {
                        for (Observation<T> o : collect) {
                            jsonGen.writeStartObject();

                            jsonGen.writeNumberField("timestamp", o.getTimeTick());
                            switch (tsKeyType) {
                                case "long":
                                    jsonGen.writeNumberField("key",(Long)tsKey);
                                    break;
                                case "int":
                                    jsonGen.writeNumberField("key",(Integer) tsKey);
                                    break;
                                case "double":
                                    jsonGen.writeNumberField("key",(Double) tsKey);
                                    break;
                                default:
                                    jsonGen.writeStringField("key",(String) tsKey);
                                    break;
                            }
                            T value = o.getValue();
                            if (value instanceof Long) {
                                jsonGen.writeNumberField("value",(Long)value);
                            } else if (value instanceof Integer) {
                                jsonGen.writeNumberField("value",(Integer)value);
                            } else if (value instanceof Double) {
                                jsonGen.writeNumberField("value",(Double)value);
                            } else if (value instanceof String){
                                jsonGen.writeStringField("value",(String)value);
                            } else {
                                List<Object> l = (List<Object>)value;
                                for (int i = 0;i < l.size();i++) {
                                    Object valueI = l.get(i);
                                    if (valueI instanceof Long) {
                                        jsonGen.writeNumberField("value_" + i,(Long)valueI);
                                    } else if (valueI instanceof Integer) {
                                        jsonGen.writeNumberField("value_" + i,(Integer)valueI);
                                    } else if (valueI instanceof Double) {
                                        jsonGen.writeNumberField("value_" + i,(Double)valueI);
                                    } else {
                                        jsonGen.writeStringField("value_" + i, (String) valueI);
                                    }
                                }
                            }
                            jsonGen.writeEndObject();
                        }
                    }

                }
            }
            jsonGen.writeEndArray();

            jsonGen.close();
            return writer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
