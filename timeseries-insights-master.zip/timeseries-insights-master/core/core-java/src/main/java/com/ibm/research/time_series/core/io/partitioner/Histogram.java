package com.ibm.research.time_series.core.io.partitioner;

import com.ibm.research.time_series.core.io.Utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;

/**
 * Class to represent a generic Histogram used in {@link HistogramTimeSeriesPartitioner}
 */
public class Histogram {
    private TreeMap<Long, Integer> bins;
    private long startTs;
    private long endTs;
    private int numBins;
    private int numHistBins;

    /**
     * default hist scaling factor
     */
    public static int HIST_BINS_SCALING_FACTOR = 100;

    public Histogram(int numBins) {
        this(numBins,1,0);
    }

    public Histogram(int numBins, long start, long end) {
        this.numBins = numBins;
        this.numHistBins = HIST_BINS_SCALING_FACTOR * numBins;
        this.bins = new TreeMap<>();
        this.startTs = start;
        this.endTs = end;
    }

    /**
     * initialize this Histogram
     *
     * @param inputFileNames input files containing one observation per line
     * @param parser function given a line, optionally extract a time-tick
     * @throws IOException if file does not exist
     */
    public void init(List<String> inputFileNames, Function<String,OptionalLong> parser) throws IOException {
        int[] histCounts = new int[numHistBins];

        if (startTs > endTs) {
            long locStart = Long.MAX_VALUE;
            long locEnd = Long.MIN_VALUE;
            for (String inputFileName : inputFileNames) {
                final long[] startEndTs = TSPartitionerUtils.getStartEndTs(inputFileName, parser);
                locStart = Math.min(startEndTs[0], locStart);
                locEnd = Math.max(startEndTs[1],locEnd);
            }
            startTs = locStart;
            endTs = locEnd;
        }

        int totalCount = 0;
        for (String inputFileName : inputFileNames) {

            BufferedReader br = new BufferedReader(new InputStreamReader(Utils.inferInputStream(inputFileName)));

            String readLine;

            while ((readLine = br.readLine()) != null) {
                OptionalLong optionalLong = parser.apply(readLine);

                if (optionalLong.isPresent()) {
                    long ts = optionalLong.getAsLong();
                    int bin = TSPartitionerUtils.getBin(ts, startTs, endTs, numHistBins);
                    histCounts[bin]++;
                    totalCount++;
                }
            }
        }

        int runningCount = 0;
        int binId = 0;

        for (int i = 0; i < numHistBins-1; i++) {
            runningCount = runningCount + histCounts[i];
            int upperBoundCount = TSPartitionerUtils.getUpperBoundCount(binId, totalCount, numBins);
            if (runningCount >= upperBoundCount) {
                long insertTs = TSPartitionerUtils.getUpperBoundTs(i, startTs, endTs, numHistBins);
                bins.put(insertTs,binId+1);
                binId++;
            }
        }

    }

    /**
     * initialize this Histogram
     *
     * @param inputFileName single input file
     * @param parser function given a line, optionally extract a time-tick
     * @throws IOException if file does not exist
     */
    public void init(String inputFileName, Function<String, OptionalLong> parser) throws IOException {
        init(Collections.singletonList(inputFileName),parser);
    }

    /**
     * @param ts time-tick to get a bin for
     * @return bin associated with given time-tick
     */
    public int getHistBin(long ts) {
        Map.Entry<Long, Integer> floorEntry = bins.floorEntry(ts);
        int bin = (floorEntry == null) ? 0 : floorEntry.getValue();

        return bin;
    }

    /**
     * @return number of bins
     */
    public int getNumBins() {
        return this.numBins;
    }

    /**
     * @return starting time-tick
     */
    public long getStartTs() {
        return this.startTs;
    }

    /**
     * @return ending time-tick
     */
    public long getEndTs() {
        return this.endTs;
    }
}
