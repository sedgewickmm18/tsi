/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.core_transforms.segmentation;

import com.ibm.research.time_series.core.constants.*;
import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Properties;

/**
 * <p>Created on 3/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
class TimeSliding<T> extends UnaryTransform<T,Segment<T>> {

    private static final long serialVersionUID = 7687667359078780629L;
    private long window;//window size
    private long step;//step size
    private Padding padding;
    private ResultingTimeStamp resultingTimeStamp;

    TimeSliding(
            long window,
            long step,
            Padding padding,
            ResultingTimeStamp resultingTimeStamp) {
        this.window = window;
        this.step = step;
        this.padding = padding;
        this.resultingTimeStamp = resultingTimeStamp;
    }

    @Override
    public ObservationCollection<Segment<T>> evaluate(long t1, long t2, boolean inclusive) {
        TSBuilder<Segment<T>> tsBuilder = Observations.newBuilder();

        long start;
        long end;

        switch (padding) {
            case RIGHT:
                start = t1;
                end = start + (window - 1);
                break;
            case LEFT:
                start = t1 - window + 1;
                end = t1;
                break;
            case LEFT_AND_RIGHT:
                start = t1 - window + 1;
                end = t1;
                break;
            case NONE:
                start = t1;
                end = start + (window - 1);
                break;
            default:
                throw new TSRuntimeException("padding is not specified in a time-based segmentation operation");

        }

        boolean finished = false;

        while (!finished) {

            ObservationCollection<T> window_tss = this.getTimeSeries()
                    .getValues(start, end,inclusive);

            long currentWindowTimeStamp;
            switch (resultingTimeStamp) {
                case START_OF_WINDOW:
                    currentWindowTimeStamp = start;
                    break;
                case END_OF_WINDOW:
                    currentWindowTimeStamp = end;
                    break;
                default:
                    throw new TSRuntimeException("Timestamp location is not specified");
            }

            tsBuilder.add(
                    new Observation<>(
                            currentWindowTimeStamp,
                            Segment.fromSeries(start, end, window_tss)
                    )
            );



            start = start + step;
            end = start + (window - 1);

            switch (padding) {
                case RIGHT:
                    finished = start > t2;
                    break;
                case LEFT:
                    finished = end > t2;
                    break;
                case LEFT_AND_RIGHT:
                    finished = start > t2;
                    break;
                case NONE:
                    finished = end > t2;
                    break;
                default:
                    throw new TSRuntimeException("padding is not specified");

            }

        }
        return tsBuilder.result();
    }

    @Override
    public Object clone() {
        return new TimeSliding<>(window,step,padding,resultingTimeStamp);
    }

    /**
     * gets the window size
     * @return the window size
     */
    @Override
    public long getWindow() {
        return window;
    }

    /**
     * get sht step size
     * @return the step size
     */
    @Override
    public long getStep() {
        return step;
    }
}
