/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.transform;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.AddOneTransform;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

/**
 * <p>Created on 7/22/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class UnaryTransformTest {

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private MutableObservationCollection<Double> input1 = new MutableObservationCollection<>();

    @Before
    public void setUp() {

        input1.add(new Observation<>(1,2.0));
        input1.add(new Observation<>(3,3.0));
        input1.add(new Observation<>(7,5.0));
        input1.add(new Observation<>(8,8.0));
        input1.add(new Observation<>(10,5.0));
        input1.add(new Observation<>(11,9.0));
        input1.add(new Observation<>(12,11.0));
        input1.add(new Observation<>(14,1.0));

    }

    @Test
    public void testUnaryTransform() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,3.0));
        expectedOutput.add(new Observation<>(3,4.0));
        expectedOutput.add(new Observation<>(7,6.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1).transform(new AddOneTransform());
        verifier.verifyOutput(1,7,expectedOutput,si);
    }

    @Test
    public void testUnaryTransformLambda() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(2,3.0));
        expectedOutput.add(new Observation<>(4,4.0));
        expectedOutput.add(new Observation<>(8,6.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .mapObservation(x -> new Observation<>(x.getTimeTick() + 1, x.getValue() + 1));
        verifier.verifyOutput(1,7,expectedOutput,si);
    }

    @Test
    public void testUnaryWindowTransform() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();

        expectedOutput.add(new Observation<>(1,5.0));
        expectedOutput.add(new Observation<>(3,8.0));
        expectedOutput.add(new Observation<>(5,8.0));
        expectedOutput.add(new Observation<>(7,18.0));
        expectedOutput.add(new Observation<>(9,22.0));
        expectedOutput.add(new Observation<>(11,21.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .segmentByTime(3,2)
                .mapObservation(val -> new Observation<>(
                        val.getTimeTick(),
                        val.getValue().stream().mapToDouble(Observation::getValue).sum())
                );

        verifier.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testUnaryWindowRecordsTransform() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,1.0));
        expectedOutput.add(new Observation<>(3,2.0));
        expectedOutput.add(new Observation<>(7,3.0));
        expectedOutput.add(new Observation<>(8,-3.0));
        expectedOutput.add(new Observation<>(10,4.0));
        expectedOutput.add(new Observation<>(11,2.0));
        expectedOutput.add(new Observation<>(12,-10.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .segment(2,1)
                .mapObservation(obs -> {
                    return new Observation<>(obs.getTimeTick(),obs.getValue().last().getValue() - obs.getValue().first().getValue());
                });

        verifier.verifyOutput(1,14,expectedOutput,si);
    }
}
