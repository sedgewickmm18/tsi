/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Properties;

/**
 * Implementation of DifferenceTransform based on the UnaryTransform abstract class
 *
 * @author Joshua Rosenkranz
 * @author Mudhakar Srivatsa
 */
public class DifferenceTransform extends UnaryTransform<Double,Double>{

	/**
	 * this is the basic constructor of the DifferenceTransform.
	 */
	public DifferenceTransform(){

	}

	/**
	 * this constructor is used if we want to create a transform that already contains a TimeSeries object
	 * @param sensorinformation our TimeSeries to evaluate
	 */
	public DifferenceTransform(TimeSeries<Double> sensorinformation){
		timeSeries = sensorinformation;
	}

	/**
	 * This method will take the sensor information values from between time stamps t1 and t2,
	 * compute the difference between this main.java.sensorinformation T_t and main.java.sensorinformation T_t-1,
	 * the result is a set of values that is our new sensor information.
	 *
	 * @param t1 timestamp start
	 * @param t2 timestamp end
	 * @return the resulting TimeSeries of Observation values after evaluation has taken place
	 */
	@Override
	public ObservationCollection<Double> evaluate(long t1, long t2,boolean inclusive) {

        ObservationCollection<Double> values = this.getTimeSeries().getValues(t1-1, t2,inclusive);

		TSBuilder<Double> tsBuilder = Observations.newBuilder();

		Observation<Double> prev_val = null;

		for(Observation<Double> val : values){
			if(prev_val != null){
                Double res = val.getValue() - prev_val.getValue();
				tsBuilder.add(new Observation<>(val.getTimeTick(), res));
			}
			prev_val = val;
		}

		return tsBuilder.result();
	}

    /**
     * get the window size
     * @return the window size
     */
    @Override
    public long getWindow() {
        return 2;
    }

    /**
     * get the step size
     * @return the step size
     */
    @Override
    public long getStep() {
        return 1;
    }
}


