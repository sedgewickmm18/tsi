/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.segmentation;

import com.ibm.research.time_series.core.constants.Padding;
import com.ibm.research.time_series.core.constants.ResultingTimeStamp;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.SegmentTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.SegmentTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.*;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.StreamSupport;

/**
 * <p>Created on 5/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class UnarySegmentationTest {
    private TimeSeriesVerifier<Segment<Integer>> verifier = new SegmentTimeSeriesVerifier<>();
    private TimeSeriesVerifier<Double> dVerifier = new DoubleTimeSeriesVerifier();
    private MutableObservationCollection<Integer> observations;
    private MutableObservationCollection<Integer> observations2;
    private UnaryTransform<Integer,Integer> addOne = new UnaryTransform<Integer, Integer>() {
        @Override
        public ObservationCollection<Integer> evaluate(long t1, long t2,boolean inclusive) {
            return this.getTimeSeries().map(x -> x + 1).getValues(t1,t2,inclusive);
        }
    };
    private TimeSeriesVerifier<Segment<String>> stringVerifier = new SegmentTimeSeriesVerifier<>();

    @Before
    public void setup() {
        observations = new MutableObservationCollection<>();

        observations.add(new Observation<>(1,1));
        observations.add(new Observation<>(2,2));
        observations.add(new Observation<>(3,3));
        observations.add(new Observation<>(4,4));
        observations.add(new Observation<>(5,5));

        observations2 = new MutableObservationCollection<>();
        observations2.add(new Observation<>(1,1));
        observations2.add(new Observation<>(3,3));
        observations2.add(new Observation<>(4,4));
        observations2.add(new Observation<>(6,6));
        observations2.add(new Observation<>(8,8));
    }

    @Test
    public void testSegment() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations).segment(3);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(2,2), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(2,2), new Observation<>(3,3), new Observation<>(4,4));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4), new Observation<>(5,5));



        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(one).result())));
        expected.add(new Observation<>(2,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(two).result())));
        expected.add(new Observation<>(3,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(three).result())));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testSegmentWithStep() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations).segment(3,2);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(2,2), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4), new Observation<>(5,5));



        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(one).result())));
        expected.add(new Observation<>(3,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(two).result())));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testSegmentWithEnforceBoundsFalse() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations).segment(3,2,false);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(2,2), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(5,5));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(5,5));



        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(one).result())));
        expected.add(new Observation<>(3,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(two).result())));
        expected.add(new Observation<>(5,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(three).result())));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testSegmentByTime() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2).segmentByTime(3,2, Padding.RIGHT);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(4,4), new Observation<>(6,6),new Observation<>(8,8));
        List<Observation<Integer>> four = Arrays.asList(new Observation<>(6,6), new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(1,3,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(3,5,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(5,7,Observations.<Integer>newBuilder().addAll(three).result());
        Segment<Integer> segment4 = Segment.fromSeries(7,9,Observations.<Integer>newBuilder().addAll(four).result());


        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,segment1));
        expected.add(new Observation<>(3,segment2));
        expected.add(new Observation<>(5,segment3));
        expected.add(new Observation<>(7,segment4));

        verifier.verifySeries(expected,ts.collect(true));
    }

    @Test
    public void testSegmentByTimeWithNonInclusiveBounds() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2).segmentByTime(3,2, Padding.RIGHT);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(6,6));
        List<Observation<Integer>> four = Arrays.asList(new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(1,3,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(3,5,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(5,7,Observations.<Integer>newBuilder().addAll(three).result());
        Segment<Integer> segment4 = Segment.fromSeries(7,9,Observations.<Integer>newBuilder().addAll(four).result());


        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,segment1));
        expected.add(new Observation<>(3,segment2));
        expected.add(new Observation<>(5,segment3));
        expected.add(new Observation<>(7,segment4));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testSegmentByTimeWithPaddingLeft() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2).segmentByTime(3,2,Padding.LEFT);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(1,1), new Observation<>(3,3));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> four = Arrays.asList(new Observation<>(4,4),new Observation<>(6,6),new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(-1,1,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(1,3,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(3,5,Observations.<Integer>newBuilder().addAll(three).result());
        Segment<Integer> segment4 = Segment.fromSeries(5,7,Observations.<Integer>newBuilder().addAll(four).result());


        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(-1,segment1));
        expected.add(new Observation<>(1,segment2));
        expected.add(new Observation<>(3,segment3));
        expected.add(new Observation<>(5,segment4));

        verifier.verifySeries(expected,ts.collect(true));
    }

    @Test
    public void testSegmentByTimeWithPaddingBoth() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2).segmentByTime(3,2,Padding.LEFT_AND_RIGHT,ResultingTimeStamp.END_OF_WINDOW);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(1,1), new Observation<>(3,3));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> four = Arrays.asList(new Observation<>(4,4),new Observation<>(6,6),new Observation<>(8,8));
        List<Observation<Integer>> five = Arrays.asList(new Observation<>(6,6),new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(-1,1,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(1,3,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(3,5,Observations.<Integer>newBuilder().addAll(three).result());
        Segment<Integer> segment4 = Segment.fromSeries(5,7,Observations.<Integer>newBuilder().addAll(four).result());
        Segment<Integer> segment5 = Segment.fromSeries(7,9,Observations.<Integer>newBuilder().addAll(five).result());


        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,segment1));
        expected.add(new Observation<>(3,segment2));
        expected.add(new Observation<>(5,segment3));
        expected.add(new Observation<>(7,segment4));
        expected.add(new Observation<>(9,segment5));

        verifier.verifySeries(expected,ts.collect(true));
    }

    @Test
    public void testSegmentByTimeWithPaddingNone() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2).segmentByTime(3,2,Padding.NONE,ResultingTimeStamp.END_OF_WINDOW);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,1), new Observation<>(3,3));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(4,4),new Observation<>(6,6),new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(1,3,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(3,5,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(5,7,Observations.<Integer>newBuilder().addAll(three).result());


        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(3,segment1));
        expected.add(new Observation<>(5,segment2));
        expected.add(new Observation<>(7,segment3));

        verifier.verifySeries(expected,ts.collect(true));
    }

    @Test
    public void testSegmentByAnchor() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations2)
                .segmentByAnchor(x -> x % 2 == 0,1,2);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(4,4),new Observation<>(6,6),new Observation<>(8,8));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(6,6),new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(3,6,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(5,8,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(7,10,Observations.<Integer>newBuilder().addAll(three).result());

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(4,segment1));
        expected.add(new Observation<>(6,segment2));
        expected.add(new Observation<>(8,segment3));

        verifier.verifySeries(expected,ts.collect(true));
    }

    @Test
    public void testSegmentByAnchorNonInclusive() {
        ObservationCollection<Integer> original = Observations.<Integer>newBuilder()
                .add(1,1)
                .add(3,3)
                .add(4,4)
                .add(6,6)
                .add(8,8)
                .add(11,11)
                .result();

        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(original)
                .segmentByAnchor(x -> x % 2 == 0,1,2);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(3,3), new Observation<>(4,4),new Observation<>(6,6));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(6,6),new Observation<>(8,8));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(8,8));

        Segment<Integer> segment1 = Segment.fromSeries(3,6,Observations.<Integer>newBuilder().addAll(one).result());
        Segment<Integer> segment2 = Segment.fromSeries(5,8,Observations.<Integer>newBuilder().addAll(two).result());
        Segment<Integer> segment3 = Segment.fromSeries(7,10,Observations.<Integer>newBuilder().addAll(three).result());

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(4,segment1));
        expected.add(new Observation<>(6,segment2));
        expected.add(new Observation<>(8,segment3));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testReduceSegment() {
        TimeSeries<Double> ts = TimeSeries.fromObservations(observations).segment(3).reduceSegments(x -> {
            return StreamSupport.stream(x.spliterator(),false).mapToDouble(d -> d).sum();
        });

        MutableObservationCollection<Double> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,6.0));
        expected.add(new Observation<>(2,9.0));
        expected.add(new Observation<>(3,12.0));

        dVerifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testTransformSegment() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations)
                .segment(3)
                .transformSegments(addOne);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,2), new Observation<>(2,3), new Observation<>(3,4));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(2,3), new Observation<>(3,4), new Observation<>(4,5));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(3,4), new Observation<>(4,5), new Observation<>(5,6));



        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(one).result())));
        expected.add(new Observation<>(2,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(two).result())));
        expected.add(new Observation<>(3,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(three).result())));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testMapSegment() {
        SegmentTimeSeries<Integer> ts = TimeSeries.fromObservations(observations)
                .segment(3)
                .mapSegments(x -> x + 1);

        List<Observation<Integer>> one = Arrays.asList(new Observation<>(1,2), new Observation<>(2,3), new Observation<>(3,4));
        List<Observation<Integer>> two = Arrays.asList(new Observation<>(2,3), new Observation<>(3,4), new Observation<>(4,5));
        List<Observation<Integer>> three = Arrays.asList(new Observation<>(3,4), new Observation<>(4,5), new Observation<>(5,6));



        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(1,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(one).result())));
        expected.add(new Observation<>(2,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(two).result())));
        expected.add(new Observation<>(3,Segment.fromSeries(Observations.<Integer>newBuilder().addAll(three).result())));

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationFirstStartFirstEnd() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(0,0,0,1,1,1,2,2,2,0,0,0,1,1,1))
                .segmentByMarker(x -> x == 0, x -> x == 1, true, true, true, true);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(0, Segment.fromSeries(Observations.<Integer>newBuilder().add(0,0).add(1,0).add(2,0).add(3,1).result())));
        expected.add(new Observation<>(9, Segment.fromSeries(Observations.<Integer>newBuilder().add(9,0).add(10,0).add(11,0).add(12,1).result())));

        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationFirstStartLastEnd() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(0,0,0,1,1,1,2,2,2,0,0,0,1,1,1))
                .segmentByMarker(x -> x == 0, x -> x == 1, true, true, true, false);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(0, Segment.fromSeries(Observations.<Integer>newBuilder().add(0,0).add(1,0).add(2,0).add(3,1).add(4,1).add(5,1).result())));
        expected.add(new Observation<>(9, Segment.fromSeries(Observations.<Integer>newBuilder().add(9,0).add(10,0).add(11,0).add(12,1).add(13,1).add(14,1).result())));

        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartFirstEnd() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(0,0,0,1,1,1,2,2,2,0,0,0,1,1,1))
                .segmentByMarker(x -> x == 0, x -> x == 1, true, true, false, true);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(Observations.<Integer>newBuilder().add(2,0).add(3,1).result())));
        expected.add(new Observation<>(11, Segment.fromSeries(Observations.<Integer>newBuilder().add(11,0).add(12,1).result())));

        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartLastEnd() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(0,0,0,1,1,1,2,2,2,0,0,0,1,1,1))
                .segmentByMarker(x -> x == 0, x -> x == 1, true, true, false, false);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(Observations.<Integer>newBuilder().add(2,0).add(3,1).add(4,1).add(5,1).result())));
        expected.add(new Observation<>(11, Segment.fromSeries(Observations.<Integer>newBuilder().add(11,0).add(12,1).add(13,1).add(14,1).result())));

        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartFirstEndBothTrue() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(2,2,4))
                .segmentByMarker(x -> x % 2 == 0, x -> x % 4 == 0, true, true, false, true);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(Observations.<Integer>newBuilder().add(2,4).result())));
        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartLastEndBothTrue() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(2,2,4))
                .segmentByMarker(x -> x % 2 == 0, x -> x % 4 == 0, true, true, false, false);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(Observations.<Integer>newBuilder().add(2,4).result())));
        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartFirstEndBothTrueStartNonInclusive() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(2,2,4))
                .segmentByMarker(x -> x % 2 == 0, x -> x % 4 == 0, false, true, false, true);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(new MutableObservationCollection<>())));
        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testBiMarkerBasedSegmentationLastStartLastEndBothTrueEndNonInclusive() {
        SegmentTimeSeries<Integer> actual = TimeSeries.list(Arrays.asList(2,2,4))
                .segmentByMarker(x -> x % 2 == 0, x -> x % 4 == 0, true, false, false, false);

        MutableObservationCollection<Segment<Integer>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(2, Segment.fromSeries(new MutableObservationCollection<>())));
        verifier.verifySeries(expected, actual.collect());
    }

    @Test
    public void testSegmentByChangePoint() {
        final SegmentTimeSeries<String> actual = TimeSeries.list(Arrays.asList("a", "a", "a", "a", "b", "b", "c", "c", "c"))
                .segmentByChangePoint((x, y) -> !x.equals(y));

        MutableObservationCollection<Segment<String>> expected = new MutableObservationCollection<>();
        expected.add(new Observation<>(0, Segment.fromSeries(Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"a")
                .add(2,"a")
                .add(3,"a").result()
        )));
        expected.add(new Observation<>(4, Segment.fromSeries(Observations.<String>newBuilder().add(4,"b").add(5,"b").result())));
        expected.add(new Observation<>(6, Segment.fromSeries(Observations.<String>newBuilder().add(6,"c").add(7,"c").add(8,"c").result())));
        stringVerifier.verifySeries(expected,actual.collect());
    }
}
