/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.observation_tests;

import com.ibm.research.time_series.core.observation.Observation;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNull;


/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ObservationTest {


    @Before
    public void setup() {

    }

    @Test
    public void testDefaultConstructor() {
        Observation<String> observation = new Observation<>();
        assertEquals(observation.getTimeTick(),-1);
        assertEquals(observation.getValue(),null);
        assertEquals(observation.getAnnotationKeys(),new HashSet<>());
        try {
            observation.getAnnotation("key");
            TestCase.fail();
        } catch (NullPointerException e) {

        }
    }

    @Test
    public void testTimestampAndValueConstructor() {
        Observation<String> observation = new Observation<>(1,"test");
        assertEquals(observation.getTimeTick(),1);
        assertEquals(observation.getValue(),"test");
        assertEquals(observation.getAnnotationKeys(),new HashSet<>());
        try {
            observation.getAnnotation("key");
            TestCase.fail();
        } catch (NullPointerException e) {

        }
    }

    @Test
    public void testTimestampValueAndMetaDataConstructor() {
        Observation<String> observation = new Observation<>(1,"test");
        observation.addAnnotation("test","testing");
        observation.addAnnotation("test","testing2");
        assertEquals(observation.getTimeTick(),1);
        assertEquals(observation.getValue(),"test");
        assertEquals(observation.getAnnotationKeys(),new HashSet<>(Arrays.asList("test")));
        assertEquals(observation.<String>getAnnotation("test"),"testing");
    }

    @Test
    public void testCopyConstructor() {
        Observation<String> observation = new Observation<>(new Observation<>(1,"test"));
        assertEquals(observation.getTimeTick(),1);
        assertEquals(observation.getValue(),"test");
        assertEquals(observation.getAnnotationKeys(),new HashSet<>());
        try {
            observation.getAnnotation("key");
            TestCase.fail();
        } catch (NullPointerException e) {

        }
    }

    @Test
    public void testEquals() {
        Observation<String> observation1 = new Observation<>(1,"test");
        Observation<String> observation2 = new Observation<>(1,"test");

        assertEquals(observation1.equals(observation2),true);
    }

    @Test
    public void testNotEqualsTimestamp() {
        Observation<String> observation1 = new Observation<>(1,"test");
        Observation<String> observation2 = new Observation<>(2,"test");

        assertEquals(observation1.equals(observation2),false);
    }

    @Test
    public void testNotEqualsValue() {
        Observation<String> observation1 = new Observation<>(1,"test");
        Observation<String> observation2 = new Observation<>(1,"test2");

        assertEquals(observation1.equals(observation2),false);
    }

    @Test
    public void testNotEqualsObject() {
        Observation<String> observation1 = new Observation<>(1,"test");
        String observation2 = "";

        assertEquals(observation1.equals(observation2),false);
    }

    @Test
    public void testNotEqualsMetadataSize() {
        Observation<String> observation1 = new Observation<>(1,"test");
        Observation<String> observation2 = new Observation<>(1,"test");
        observation2.addAnnotation("test","test");

        assertEquals(observation1.equals(observation2),false);
    }

    @Test
    public void testNotEqualsMetadataValues() {
        Observation<String> observation1 = new Observation<>(1,"test");
        observation1.addAnnotation("test","test");
        Observation<String> observation2 = new Observation<>(1,"test");
        observation2.addAnnotation("test","test2");

        assertEquals(observation1.equals(observation2),false);
    }

    @Test
    public void testCompareToLessThan() {
        Observation<String> observation1 = new Observation<>(0,"test2");
        Observation<String> observation2 = new Observation<>(1,"test2");

        assertEquals(observation1.compareTo(observation2),-1);
    }

    @Test
    public void testCompareEqual() {
        Observation<String> observation1 = new Observation<>(0,"test2");
        Observation<String> observation2 = new Observation<>(0,"test");

        assertEquals(observation1.compareTo(observation2),0);
    }

    @Test
    public void testCompareGreaterThan() {
        Observation<String> observation1 = new Observation<>(1,"test");
        Observation<String> observation2 = new Observation<>(0,"test");

        assertEquals(observation1.compareTo(observation2),1);
    }
}
