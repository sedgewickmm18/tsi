/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.general_transforms;

import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;

import java.util.Arrays;


/**
 * <p>Created on 7/22/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class InterpolateTest {

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private MutableObservationCollection<Double> input1 = new MutableObservationCollection<>();
    private Interpolator<Double> interpolator = (history, future, timestamp) -> {
        if(history.isEmpty()) return future.first().getValue();
        if(future.isEmpty()) return history.first().getValue();
        return history.first().getValue() + (future.first().getValue() - history.first().getValue()) * ((timestamp - (double)history.first().getTimeTick()) / ((double)future.first().getTimeTick() - (double)history.first().getTimeTick()));
    };

    @Before
    public void setUp(){
        input1.add(new Observation<>(1,2.0));
        input1.add(new Observation<>(3,3.0));
        input1.add(new Observation<>(7,5.0));
        input1.add(new Observation<>(8,8.0));
        input1.add(new Observation<>(10,5.0));
        input1.add(new Observation<>(11,9.0));
        input1.add(new Observation<>(12,11.0));
        input1.add(new Observation<>(14,1.0));
    }

    @Test
    public void testInterpolate() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(0,2.0));
        expectedOutput.add(new Observation<>(2,2.5));
        expectedOutput.add(new Observation<>(4,3.5));
        expectedOutput.add(new Observation<>(6,4.5));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1).resample(2,interpolator);

        verifier.verifyOutput(1,7,expectedOutput,si);
    }

    @Test
    public void testFillNaNull() throws Exception {
        final TimeSeries<Double> ts = TimeSeries.list(Arrays.asList(0.0, 1.0, null, null, Double.NaN, 2.0, null))
                .fillna(GenericInterpolators.nearest(2.0));
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,0.0)
                .add(1,1.0)
                .add(2,1.0)
                .add(3,Double.NaN)
                .add(4,Double.NaN)
                .add(5,2.0)
                .add(6,2.0)
                .result();
        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testFillNaNaN() throws Exception {
        final TimeSeries<Double> ts = TimeSeries.list(Arrays.asList(Double.NaN, 1.0, Double.NaN, Double.NaN, Double.NaN, 2.0, Double.NaN))
                .fillna(GenericInterpolators.prev(-1.0), Double.NaN);
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,-1.0)
                .add(1,1.0)
                .add(2,1.0)
                .add(3,1.0)
                .add(4,1.0)
                .add(5,2.0)
                .add(6,2.0)
                .result();
        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testFillNaAllNullWithHist() throws Exception {
        final TimeSeries<Double> ts = TimeSeries.list(Arrays.asList((Double)null, (Double)null, (Double)null))
                .fillna(GenericInterpolators.prev(-1.0));
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,-1.0)
                .add(1,-1.0)
                .add(2,-1.0)
                .result();
        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testFillNaAllNullWithFuture() throws Exception {
        final TimeSeries<Double> ts = TimeSeries.list(Arrays.asList((Double)null, (Double)null, (Double)null))
                .fillna(GenericInterpolators.next(-1.0));
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,-1.0)
                .add(1,-1.0)
                .add(2,-1.0)
                .result();
        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testFillNaAllNullWithHistoryAndFuture() throws Exception {
        final TimeSeries<Double> ts = TimeSeries.list(Arrays.asList((Double)null, (Double)null, (Double)null))
                .fillna(GenericInterpolators.fill(-1.0));
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,-1.0)
                .add(1,-1.0)
                .add(2,-1.0)
                .result();
        verifier.verifySeries(expected,ts.collect());
    }
}
