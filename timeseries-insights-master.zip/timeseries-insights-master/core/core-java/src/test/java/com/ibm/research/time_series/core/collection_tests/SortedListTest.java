/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.collection_tests;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import static junit.framework.TestCase.assertEquals;

/**
 * <p>Created on 4/21/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class SortedListTest {

    ObservationCollection<Integer> collection;
    ObservationCollection<Integer> emptyCollection;
    ObservationCollection<Integer> snapshot;

    @Before
    public void setup() {

        collection = Observations.<Integer>newBuilder()
                .add(new Observation<>(1L,1))
                .add(new Observation<>(3L,2))
                .add(new Observation<>(3L,3))
                .add(new Observation<>(6L,4))
                .add(new Observation<>(8L,5))
                .add(new Observation<>(8L,6))
                .add(new Observation<>(3L,7))
                .add(new Observation<>(9L,8))
                .add(new Observation<>(12L,9))
                .result();

        emptyCollection = Observations.empty();

        //using this to do range checks since snapshots can go out of range
        snapshot = collection.subSet(3, true, 8, true);

    }

    @Test
    public void testContent() throws Exception {
        ObservationCollection<Integer> actual = collection;

        //using list since ordering and duplicates are preserved
        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void floor() throws Exception {
        Observation<Integer> expected = new Observation<>(3L,2);
        Observation<Integer> actual = collection.floor(3L);
        assertEquals(expected,actual);
    }

//    @Test
//    public void floorNotEqual() throws Exception {
//        Observation<Integer> expected = new Observation<>(3L,2);//todo check correctness of this, should we get last 3L or first 3L
//        Observation<Integer> actual = collection.floor(new Observation<>(4L,0));
//        assertEquals(expected,actual);
//    }

    @Test
    public void floorNotExist() throws Exception {
        Observation<Integer> expected = null;
        Observation<Integer> actual = collection.floor(0L);
        assertEquals(expected,actual);
    }

    @Test
    public void headSetInclusive() throws Exception {
        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));

        ObservationCollection<Integer> actual = collection.headSet(
                3L,
                true
        );

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void headSetNotInclusive() throws Exception {
        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));

        ObservationCollection<Integer> actual = collection.headSet(
                3L,
                false
        );

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void headSetFromOutOfRangeBelow() throws Exception {
        ObservationCollection<Integer> actual = collection.headSet(Integer.MIN_VALUE, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void headSetFromOutOfRangeAbove() throws Exception {
        ObservationCollection<Integer> actual = collection.headSet(
                Integer.MAX_VALUE,
                true
        );

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void tailSetInclusive() throws Exception {
        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        ObservationCollection<Integer> actual = collection.tailSet(3L, true);

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void tailSetNotInclusive() throws Exception {
        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        ObservationCollection<Integer> actual = collection.tailSet(3L, false);

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void tailSetFromOutOfRangeBelow() throws Exception {
        ObservationCollection<Integer> actual = collection.tailSet(Integer.MIN_VALUE, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void tailSetFromOutOfRangeAbove() throws Exception {
        ObservationCollection<Integer> actual = collection.tailSet(Integer.MAX_VALUE, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }


    @Test
    public void subSetFullyInclusive() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(3L, true, 8L, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void subSetFromInclusive() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(3L, true,8L, false);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void subSetToInclusive() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(3L, false, 8L, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void subSetFullyOutOfRange() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(Integer.MIN_VALUE, true, Integer.MAX_VALUE, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });

    }

    @Test
    public void subSetFromOutOfRange() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(Integer.MIN_VALUE, true, 3, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(1L,1));
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void subSetToOutOfRange() throws Exception {
        ObservationCollection<Integer> actual = collection.subSet(3, true, Integer.MAX_VALUE, true);

        List<Observation<Integer>> expectedList = new ArrayList<>();
        expectedList.add(new Observation<>(3L,2));
        expectedList.add(new Observation<>(3L,3));
        expectedList.add(new Observation<>(3L,7));
        expectedList.add(new Observation<>(6L,4));
        expectedList.add(new Observation<>(8L,5));
        expectedList.add(new Observation<>(8L,6));
        expectedList.add(new Observation<>(9L,8));
        expectedList.add(new Observation<>(12L,9));

        assertEquals(expectedList.size(),actual.size());

        Iterator<Observation<Integer>> expectedIter = expectedList.iterator();

        actual.forEach(obs -> {
            assertEquals(expectedIter.next(),obs);
        });
    }

    @Test
    public void first() throws Exception {
        Observation<Integer> expected = new Observation<>(1L,1);
        Observation<Integer> actual = collection.first();
        assertEquals(expected,actual);
    }

    @Test(expected = TSRuntimeException.class)
    public void firstNotExist() throws Exception {
        emptyCollection.first();
    }

    @Test
    public void last() throws Exception {
        Observation<Integer> expected = new Observation<>(12L,9);
        Observation<Integer> actual = collection.last();
        assertEquals(expected,actual);
    }

    @Test(expected = TSRuntimeException.class)
    public void lastNotExist() throws Exception {
        emptyCollection.last();
    }

    @Test
    public void higher() throws Exception {
        Observation<Integer> expected = new Observation<>(9L,8);
        Observation<Integer> actual = collection.higher(8L);
        assertEquals(expected,actual);
    }

    @Test
    public void higherNotInRangeBelow() throws Exception {
        Observation<Integer> expected = new Observation<>(3L,2);
        Observation<Integer> actual = snapshot.higher(1L);
        assertEquals(expected,actual);
    }

    @Test
    public void higherNotInRangeAbove() throws Exception {
        Observation<Integer> expected = null;
        Observation<Integer> actual = snapshot.higher(9L);
        assertEquals(expected,actual);
    }

    @Test
    public void lower() throws Exception {
        Observation<Integer> expected = new Observation<>(1L,1);
        Observation<Integer> actual = collection.lower(3L);
        assertEquals(expected,actual);
    }

//    @Test
//    public void lowerNotEqual() throws Exception {
//        Observation<Integer> expected = new Observation<>(3L,2);//todo check correctness of this, should we get last 3L or first 3L
//        Observation<Integer> actual = collection.lower(new Observation<>(4L,0));
//        assertEquals(expected,actual);
//    }

    @Test
    public void lowerNotExist() throws Exception {
        Observation<Integer> expected = null;
        Observation<Integer> actual = collection.lower(0);
        assertEquals(expected,actual);
    }

    @Test
    public void lowerNotInRangeBelow() throws Exception {
        Observation<Integer> expected = null;
        Observation<Integer> actual = snapshot.lower(1L);
        assertEquals(expected,actual);
    }

//    @Test
//    public void lowerNotInRangeAbove() throws Exception {
//        Observation<Integer> expected = new Observation<>(8L,5);
//        Observation<Integer> actual = snapshot.lower(new Observation<>(9L,0));
//        assertEquals(expected,actual);
//    }

    @Test
    public void size() throws Exception {
        int expected = 9;
        int actual = collection.size();
        assertEquals(expected,actual);
    }

    @Test
    public void isEmpty() throws Exception {
        assertEquals(true,emptyCollection.isEmpty());
    }

    @Test
    public void isNotEmpty() throws Exception {
        assertEquals(false,collection.isEmpty());
    }

    @Test
    public void contains() throws Exception {
    }

    @Test
    public void iterator() throws Exception {
    }

    @Test
    public void toArray() throws Exception {
    }

    @Test
    public void toArray1() throws Exception {
    }

    @Test
    public void add() throws Exception {
    }

    @Test
    public void remove() throws Exception {
    }

    @Test
    public void containsAll() throws Exception {
    }

    @Test
    public void addAll() throws Exception {
    }

    @Test
    public void removeAll() throws Exception {
    }

    @Test
    public void retainAll() throws Exception {
    }

    @Test
    public void clear() throws Exception {
    }


}
