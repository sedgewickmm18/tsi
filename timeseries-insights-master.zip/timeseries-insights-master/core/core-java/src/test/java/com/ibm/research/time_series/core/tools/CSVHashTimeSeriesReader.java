/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;


import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Created by jmrosenk on 3/1/16.
 */
public class CSVHashTimeSeriesReader implements TimeSeriesReader<Map<String,Object>> {

    String filepath;

    Helper<Double> helper = new HelperGeneral<>();

    public CSVHashTimeSeriesReader(String filepath){
        this.filepath = filepath;
    }


    @Override
    public Iterator<Observation<Map<String,Object>>> read(long t1, long t2,boolean inclusive) {
        String temp_file_string = "";
        try {
            temp_file_string = new Scanner(new File(filepath)).useDelimiter("\\A").next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Queue<Observation<Map<String,Object>>> values_as_queue = new LinkedList<>();

        String lines[] = temp_file_string.split("\n");

        String keys[] = lines[0].split(",");

        for(int i = 1;i < lines.length;i++){
            if(i >= t1 && i <= t2) {
                Map<String, Object> map_row = new HashMap<>();

                Object values[] = lines[i].split(",");
                for (int j = 0; j < values.length; j++) {
                    map_row.put(keys[j].replaceAll("^\"|\"$", ""), values[j]);
                }

                values_as_queue.add(new Observation<>(i, map_row));
            }
        }

        return values_as_queue.iterator();

    }

    @Override
    public void close() {

    }
}
