/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.transform;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.DummyNaryTransform;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

import java.util.*;

/**
 * <p>Created on 7/22/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class NaryTransformTest {

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private MutableObservationCollection<Double> input1 = new MutableObservationCollection<>();
    private List<TimeSeries<Double>> tail = new ArrayList<>();
    private List<TimeSeries<Double>> irregularTail = new ArrayList<>();

    @Before
    public void setUp(){
        input1.add(new Observation<>(1,2.0));
        input1.add(new Observation<>(3,3.0));
        input1.add(new Observation<>(7,5.0));
        input1.add(new Observation<>(8,8.0));
        input1.add(new Observation<>(10,5.0));
        input1.add(new Observation<>(11,9.0));
        input1.add(new Observation<>(12,11.0));
        input1.add(new Observation<>(14,1.0));

        MutableObservationCollection<Double> input2 = new MutableObservationCollection<>();

        input2.add(new Observation<>(1,6.0));
        input2.add(new Observation<>(3,3.0));
        input2.add(new Observation<>(7,8.0));
        input2.add(new Observation<>(8,3.0));
        input2.add(new Observation<>(10,1.0));
        input2.add(new Observation<>(11,14.0));
        input2.add(new Observation<>(12,12.0));
        input2.add(new Observation<>(14,15.0));

        MutableObservationCollection<Double> input3 = new MutableObservationCollection<>();

        input3.add(new Observation<>(1,1.0));
        input3.add(new Observation<>(3,3.0));
        input3.add(new Observation<>(7,7.0));
        input3.add(new Observation<>(8,4.0));
        input3.add(new Observation<>(10,11.0));
        input3.add(new Observation<>(11,12.0));
        input3.add(new Observation<>(12,15.0));
        input3.add(new Observation<>(14,19.0));

        tail.add(TimeSeries.fromObservations(input2));
        tail.add(TimeSeries.fromObservations(input3));

        MutableObservationCollection<Double> input4 = new MutableObservationCollection<>();

        input4.add(new Observation<>(2,3.0));
        input4.add(new Observation<>(3,5.0));
        input4.add(new Observation<>(4,9.0));
        input4.add(new Observation<>(9,6.0));
        input4.add(new Observation<>(10,13.0));
        input4.add(new Observation<>(11,14.0));
        input4.add(new Observation<>(13,17.0));
        input4.add(new Observation<>(14,21.0));

        irregularTail.add(TimeSeries.fromObservations(input2));
        irregularTail.add(TimeSeries.fromObservations(input4));
    }

    @Test
    public void testNaryTransform() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,9.0));
        expectedOutput.add(new Observation<>(3,9.0));
        expectedOutput.add(new Observation<>(7,20.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1).transform(tail, new DummyNaryTransform());

        verifier.verifyOutput(1,7,expectedOutput,si);

    }

}
