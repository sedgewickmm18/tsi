package com.ibm.research.time_series.core.multi_time_series_tests.general;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

public class DataRetrievalTest {
    //this was added for issue_87 since empty time series in memory would result in noSuchElementException
    @Test
    public void testRetrieveFromEmptyTimeSeries() {
        TimeSeries<Integer> ts = TimeSeries.list(Arrays.asList(1,2,3,4));
        TimeSeries<Integer> ts2 = TimeSeries.list(Arrays.asList(5,6,7,8));

        MultiTimeSeries<Integer, Integer> mts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts, ts2))
                .filter(x -> x < 5);
        assertEquals(4,mts.collect().get(0).size());
        assertEquals(0,mts.collect().get(1).size());
    }
}
