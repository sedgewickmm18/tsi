/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache_tests;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.*;

import static org.junit.Assert.assertEquals;


/**
 * General implementation of TestHelper. This will most likely change...
 * <p>Created on 1/15/16.</p>
 * @param <T> the type
 *
 * @author Joshua Rosenkranz
 */
public class TestHelperGeneral<T> implements TestHelper<T>{

    /**
     * tests if two TimeStampSensors are truly equal
     * @param tss_expected the expected Observation
     * @param tss_actual the actual Observation
     */
    @Override
    public void test_tss_equals(Observation<T> tss_expected, Observation<T> tss_actual) {
        //test the timestamp equals
        assertEquals(tss_expected.getTimeTick(),tss_actual.getTimeTick());

        //test the value equals (if the value is a double, we want to check a range cause there's a good chance there's a slight difference)
        if(tss_expected.getValue() instanceof Double){
            Double tss_expected_doub = (Double)tss_expected.getValue();
            Double tss_actual_doub = (Double)tss_actual.getValue();
            assertEquals(tss_expected_doub,tss_actual_doub,.01);
        }else {
            assertEquals(tss_expected.getValue(), tss_actual.getValue());
        }

        //make sure metadata is equal
        assertEquals(tss_expected.getAnnotationKeys(),tss_actual.getAnnotationKeys());

        for (String key : tss_expected.getAnnotationKeys()) {
            assertEquals(tss_expected.<String>getAnnotation(key),tss_actual.<String>getAnnotation(key));
        }
    }

    /**
     * tests if two NavigableCollections of TimeStampSensors are truly equal
     * @param expected_tss_ts the expected NavigableCollection of TimeStampSensors
     * @param actual_tss_ts the actual NavigableCollection of TimeStampSensors
     */
    @Override
    public void test_tss_tm_equals(ObservationCollection<T> expected_tss_ts, ObservationCollection<T> actual_tss_ts) {
        //check they are both the same size
        assertEquals(expected_tss_ts.size(), actual_tss_ts.size());

        //check that the contents of each Observation are equals
        Iterator<Observation<T>> tss_expected_iter = expected_tss_ts.iterator();
        Iterator<Observation<T>> tss_actual_iter = actual_tss_ts.iterator();

        while(tss_expected_iter.hasNext()){
            Observation<T> tss_expected_current = tss_expected_iter.next();
            Observation<T> tss_actual_current = tss_actual_iter.next();
            test_tss_equals(tss_expected_current,tss_actual_current);
        }
    }
}
