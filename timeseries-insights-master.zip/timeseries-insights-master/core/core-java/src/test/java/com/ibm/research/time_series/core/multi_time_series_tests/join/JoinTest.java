/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.multi_time_series_tests.join;


import com.ibm.research.time_series.core.core_transforms.general.GenericInterpolators;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleMultiTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.MultiTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TupleMultiTimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.MTSPair;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.Pair;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>Created on 7/27/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class JoinTest {

    private MultiTimeSeriesVerifier<Double> verifier = new DoubleMultiTimeSeriesVerifier();
    private MultiTimeSeriesVerifier<Pair<Double,Double>> tupleVerifier = new TupleMultiTimeSeriesVerifier();
    private MultiTimeSeries<String,Double> leftMts;
    private MultiTimeSeries<String,Double> rightMts;
    private String pathLeft = new File("").getAbsolutePath() +
            "/src/test/resources/short_timeseries_testfile.txt";
    private String pathRight = new File("").getAbsolutePath() +
            "/src/test/resources/short_timeseries_testfile_2.txt";

//    a,3,3.0
//    a,4,4.0
//    a,6,6.0
//    a,9,9.0
//    a,10,10.0
//    a,12,12.0
//    b,1,1.0
//    b,3,3.0
//    b,4,4.0
//    b,5,5.0
//    b,8,8.0
//    b,10,10.0
    @Before
    public void setUp(){
        Map<String,TimeSeries<Double>> data1 = new HashMap<>();
        data1.put("a",TimeSeries.fromObservations(
                Observations.<Double>newBuilder()
                        .add(2,1.0)
                        .add(3,2.0)
                        .add(8,5.0)
                        .add(10,6.0)
                        .add(11,4.0)
                        .result()
        ));
        data1.put("b",TimeSeries.fromObservations(
                Observations.<Double>newBuilder()
                        .add(2,2.0)
                        .add(3,3.0)
                        .add(8,6.0)
                        .add(10,7.0)
                        .add(11,5.0)
                        .result()
        ));

        Map<String,TimeSeries<Double>> data2 = new HashMap<>();
        data2.put("a",TimeSeries.fromObservations(
                Observations.<Double>newBuilder()
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(6,6.0)
                        .add(9,9.0)
                        .add(10,10.0)
                        .add(12,12.0)
                        .result()
        ));
        data2.put("b",TimeSeries.fromObservations(
                Observations.<Double>newBuilder()
                        .add(1,1.0)
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(5,5.0)
                        .add(8,8.0)
                        .add(10,10.0)
                        .result()
        ));



        leftMts = new MultiTimeSeries<>(data1);
        rightMts = new MultiTimeSeries<>(data2);
    }

    @Test
    public void testalignWithoutInterpolator() {
        final MultiTimeSeries<String, Double> actual = rightMts.align("a");

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put(
                "a",
                Observations.<Double>newBuilder()
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(6,6.0)
                        .add(9,9.0)
                        .add(10,10.0)
                        .add(12,12.0)
                        .result()
        );
        expected.put(
                "b",
                Observations.<Double>newBuilder()
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(6,null)
                        .add(9,null)
                        .add(10,10.0)
                        .add(12,null)
                        .result()
        );
        verifier.verify(expected,actual.collect());
    }

    @Test
    public void testalign() {
        final MultiTimeSeries<String, Double> actual = rightMts.align("a",GenericInterpolators.nearest(-1.0));

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put(
                "a",
                Observations.<Double>newBuilder()
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(6,6.0)
                        .add(9,9.0)
                        .add(10,10.0)
                        .add(12,12.0)
                        .result()
        );
        expected.put(
                "b",
                Observations.<Double>newBuilder()
                        .add(3,3.0)
                        .add(4,4.0)
                        .add(6,5.0)
                        .add(9,8.0)
                        .add(10,10.0)
                        .add(12,-1.0)
                        .result()
        );
        verifier.verify(expected,actual.collect());
    }

    @Test
    public void testInnerAlign() {
        MTSPair<String,Double,Double> actual = leftMts
                .innerAlign(rightMts);

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a", Observations.<Double>newBuilder().add(3L,2.0).add(10L,6.0).result());
        expectedLeft.put("b", Observations.<Double>newBuilder().add(3L,3.0).add(8L,6.0).add(10L,7.0).result());

        verifier.verify(expectedLeft,actual.left.collect());

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a", Observations.<Double>newBuilder().add(3L,3.0).add(10L,10.0).result());
        expectedRight.put("b", Observations.<Double>newBuilder().add(3L,3.0).add(8L,8.0).add(10L,10.0).result());

        verifier.verify(expectedRight,actual.right.collect());
    }

    @Test
    public void testInnerJoin() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.innerJoin(rightMts,Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(3L,new Pair<>(3.0,3.0))
                        .add(8L,new Pair<>(6.0,8.0))
                        .add(10L,new Pair<>(7.0,10.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    @Test
    public void testFullAlignWithoutInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts.fullAlign(rightMts);
        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(3L,2.0)
                        .add(4L,null)
                        .add(6L,null)
                        .add(8L,5.0)
                        .add(9L,null)
                        .add(10L,6.0)
                        .add(11L,4.0)
                        .add(12L,null)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,null)
                        .add(2L,2.0)
                        .add(3L,3.0)
                        .add(4L,null)
                        .add(5L,null)
                        .add(8L,6.0)
                        .add(10L,7.0)
                        .add(11L,5.0)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,null)
                        .add(3L,3.0)
                        .add(4L,4.0)
                        .add(6L,6.0)
                        .add(8L,null)
                        .add(9L,9.0)
                        .add(10L,10.0)
                        .add(11L,null)
                        .add(12L,12.0)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,1.0)
                        .add(2L,null)
                        .add(3L,3.0)
                        .add(4L,4.0)
                        .add(5L,5.0)
                        .add(8L,8.0)
                        .add(10L,10.0)
                        .add(11L,null)
                        .result()
        );

        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());
    }

    @Test
    public void testFullAlignWithInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts.fullAlign(
                rightMts,
                GenericInterpolators.nearest(-1.0),
                GenericInterpolators.nearest(-1.0)
        );

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(3L,2.0)
                        .add(4L,2.0)
                        .add(6L,5.0)
                        .add(8L,5.0)
                        .add(9L,5.0)
                        .add(10L,6.0)
                        .add(11L,4.0)
                        .add(12L,-1.0)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,-1.0)
                        .add(2L,2.0)
                        .add(3L,3.0)
                        .add(4L,3.0)
                        .add(5L,3.0)
                        .add(8L,6.0)
                        .add(10L,7.0)
                        .add(11L,5.0)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,-1.0)
                        .add(3L,3.0)
                        .add(4L,4.0)
                        .add(6L,6.0)
                        .add(8L,9.0)
                        .add(9L,9.0)
                        .add(10L,10.0)
                        .add(11L,10.0)
                        .add(12L,12.0)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,1.0)
                        .add(2L,1.0)
                        .add(3L,3.0)
                        .add(4L,4.0)
                        .add(5L,5.0)
                        .add(8L,8.0)
                        .add(10L,10.0)
                        .add(11L,-1.0)
                        .result()
        );

        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());
    }

    @Test
    public void testFullJoinWithoutInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.fullJoin(rightMts, Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,null))
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(4L,new Pair<>(null,4.0))
                        .add(6L,new Pair<>(null,6.0))
                        .add(8L,new Pair<>(5.0,null))
                        .add(9L,new Pair<>(null,9.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(11L,new Pair<>(4.0,null))
                        .add(12L,new Pair<>(null,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(null,1.0))
                        .add(2L, new Pair<>(2.0,null))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(4L, new Pair<>(null,4.0))
                        .add(5L, new Pair<>(null,5.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L,new Pair<>(7.0,10.0))
                        .add(11L,new Pair<>(5.0,null))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    @Test
    public void testFullJoinWithInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.fullJoin(
                rightMts,
                Pair::new,
                GenericInterpolators.nearest(-1.0),
                GenericInterpolators.nearest(-1.0)
        );

        actual.print();

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,-1.0))
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(4L,new Pair<>(2.0,4.0))
                        .add(6L,new Pair<>(5.0,6.0))
                        .add(8L,new Pair<>(5.0,9.0))
                        .add(9L,new Pair<>(5.0,9.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(11L,new Pair<>(4.0,10.0))
                        .add(12L,new Pair<>(-1.0,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(-1.0,1.0))
                        .add(2L, new Pair<>(2.0,1.0))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(4L, new Pair<>(3.0,4.0))
                        .add(5L, new Pair<>(3.0,5.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L,new Pair<>(7.0,10.0))
                        .add(11L,new Pair<>(5.0,-1.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    @Test
    public void testLeftAlignWithoutInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .leftAlign(rightMts);

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,null)
                        .add(3L,3.0)
                        .add(8L,null)
                        .add(10L,10.0)
                        .add(11L,null)
                        .result()
        );
        expected.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,null)
                        .add(3L,3.0)
                        .add(8L,8.0)
                        .add(10L,10.0)
                        .add(11L,null)
                        .result()
        );

        verifier.verify(leftMts.collect(),actual.left.collect());
        verifier.verify(expected,actual.right.collect());
    }

    @Test
    public void testLeftAlignWithInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .leftAlign(rightMts,GenericInterpolators.nearest(-1.0));

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,-1.0)
                        .add(3L,3.0)
                        .add(8L,9.0)
                        .add(10L,10.0)
                        .add(11L,10.0)
                        .result()
        );
        expected.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(3L,3.0)
                        .add(8L,8.0)
                        .add(10L,10.0)
                        .add(11L,-1.0)
                        .result()
        );

        verifier.verify(leftMts.collect(),actual.left.collect());
        verifier.verify(expected,actual.right.collect());
    }

    @Test
    public void testLeftJoinWithoutInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.leftJoin(rightMts, Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,null))
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(8L,new Pair<>(5.0,null))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(11L,new Pair<>(4.0,null))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L, new Pair<>(2.0,null))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L, new Pair<>(7.0,10.0))
                        .add(11L, new Pair<>(5.0,null))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    @Test
    public void testLeftJoinWithInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.leftJoin(
                rightMts,
                Pair::new,
                GenericInterpolators.nearest(-1.0)
        );

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,-1.0))
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(8L,new Pair<>(5.0,9.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(11L,new Pair<>(4.0,10.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L, new Pair<>(2.0,1.0))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L, new Pair<>(7.0,10.0))
                        .add(11L, new Pair<>(5.0,-1.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }











    /*
    val expected = Map[String,Observations[Option[Double]]](
      "a" -> Observations(
        Obs(3L,Some(2.0)),
        Obs(4L,None),
        Obs(6L,None),
        Obs(9L,None),
        Obs(10L,Some(6.0)),
        Obs(12L,None)
      ),
      "b" -> Observations(
        Obs(1L,None),
        Obs(3L,Some(3.0)),
        Obs(4L,None),
        Obs(5L,None),
        Obs(8L,Some(6.0)),
        Obs(10L,Some(7.0))
      )
    )
     */

    @Test
    public void testRightAlignWithoutInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .rightAlign(rightMts);

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Double>newBuilder()
                        .add(3L,2.0)
                        .add(4L,null)
                        .add(6L,null)
                        .add(9L,null)
                        .add(10L,6.0)
                        .add(12L,null)
                        .result()
        );
        expected.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,null)
                        .add(3L,3.0)
                        .add(4L,null)
                        .add(5L,null)
                        .add(8L,6.0)
                        .add(10L,7.0)
                        .result()
        );

        verifier.verify(expected,actual.left.collect());
        verifier.verify(rightMts.collect(),actual.right.collect());
    }

    /*
    val expected = Map[String,Observations[Option[Double]]](
      "a" -> Observations(
        Obs(3L,Some(2.0)),
        Obs(4L,Some(2.0)),
        Obs(6L,Some(5.0)),
        Obs(9L,Some(5.0)),
        Obs(10L,Some(6.0)),
        Obs(12L,Some(4.0))
      ),
      "b" -> Observations(
        Obs(1L,Some(2.0)),
        Obs(3L,Some(3.0)),
        Obs(4L,Some(3.0)),
        Obs(5L,Some(3.0)),
        Obs(8L,Some(6.0)),
        Obs(10L,Some(7.0))
      )
    )
     */
    @Test
    public void testRightAlignWithInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .rightAlign(rightMts, GenericInterpolators.nearest(-1.0));

        Map<String,ObservationCollection<Double>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Double>newBuilder()
                        .add(3L,2.0)
                        .add(4L,2.0)
                        .add(6L,5.0)
                        .add(9L,5.0)
                        .add(10L,6.0)
                        .add(12L,-1.0)
                        .result()
        );
        expected.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,-1.0)
                        .add(3L,3.0)
                        .add(4L,3.0)
                        .add(5L,3.0)
                        .add(8L,6.0)
                        .add(10L,7.0)
                        .result()
        );

        verifier.verify(expected,actual.left.collect());
        verifier.verify(rightMts.collect(),actual.right.collect());
    }

    /*
    val expected = Map[String,Observations[(Option[Double],Double)]](
      "a" -> Observations(
        Obs(3L,(Some(2.0),3.0)),
        Obs(4L,(None,4.0)),
        Obs(6L,(None,6.0)),
        Obs(9L,(None,9.0)),
        Obs(10L,(Some(6.0),10.0)),
        Obs(12L,(None,12.0))
      ),
      "b" -> Observations(
        Obs(1L,(None,1.0)),
        Obs(3L,(Some(3.0),3.0)),
        Obs(4L,(None,4.0)),
        Obs(5L,(None,5.0)),
        Obs(8L,(Some(6.0),8.0)),
        Obs(10L,(Some(7.0),10.0))
      )
    )
     */
    @Test
    public void testRightJoinWithoutInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.rightJoin(rightMts, Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(4L,new Pair<>(null,4.0))
                        .add(6L,new Pair<>(null,6.0))
                        .add(9L,new Pair<>(null,9.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(12L,new Pair<>(null,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(null,1.0))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(4L, new Pair<>(null,4.0))
                        .add(5L, new Pair<>(null,5.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L, new Pair<>(7.0,10.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    @Test
    public void testRightJoinWithInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.rightJoin(
                rightMts,
                Pair::new,
                GenericInterpolators.nearest(-1.0)
        );

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(3L,new Pair<>(2.0,3.0))
                        .add(4L,new Pair<>(2.0,4.0))
                        .add(6L,new Pair<>(5.0,6.0))
                        .add(9L,new Pair<>(5.0,9.0))
                        .add(10L,new Pair<>(6.0,10.0))
                        .add(12L,new Pair<>(-1.0,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(-1.0,1.0))
                        .add(3L, new Pair<>(3.0,3.0))
                        .add(4L, new Pair<>(3.0,4.0))
                        .add(5L, new Pair<>(3.0,5.0))
                        .add(8L, new Pair<>(6.0,8.0))
                        .add(10L, new Pair<>(7.0,10.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }




    /*
    val expected = Map[String,Observations[(Double,Option[Double])]](
      "a" -> Observations(
        Obs(2L,(1.0,None)),
        Obs(8L,(5.0,None)),
        Obs(11L,(4.0,None))
      ),
      "b" -> Observations(
        Obs(2L,(2.0,None)),
        Obs(11L,(5.0,None))
      )
    )
     */
    @Test
    public void testLeftOuterAlignWithoutInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .leftOuterAlign(rightMts);

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,null)
                        .add(8L,null)
                        .add(11L,null)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,null)
                        .add(11L,null)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(8L,5.0)
                        .add(11L,4.0)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,2.0)
                        .add(11L,5.0)
                        .result()
        );

        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());
    }

    /*
    val expected = Map[String,Observations[(Double,Option[Double])]](
      "a" -> Observations(
        Obs(2L,(1.0,Some(3.0))),
        Obs(8L,(5.0,Some(9.0))),
        Obs(11L,(4.0,Some(10.0)))
      ),
      "b" -> Observations(
        Obs(2L,(2.0,Some(1.0))),
        Obs(11L,(5.0,Some(10.0)))
      )
    )
     */
    @Test
    public void testLeftOuterAlignWithInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .leftOuterAlign(rightMts,GenericInterpolators.nearest(-1.0));

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,-1.0)
                        .add(8L,9.0)
                        .add(11L,10.0)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(11L,-1.0)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(2L,1.0)
                        .add(8L,5.0)
                        .add(11L,4.0)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(2L,2.0)
                        .add(11L,5.0)
                        .result()
        );

        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());
    }

    /*
    val expected = Map[String,Observations[(Double,Option[Double])]](
      "a" -> Observations(
        Obs(2L,(1.0,None)),
        Obs(8L,(5.0,None)),
        Obs(11L,(4.0,None))
      ),
      "b" -> Observations(
        Obs(2L,(2.0,None)),
        Obs(11L,(5.0,None))
      )
    )
     */
    @Test
    public void testLeftOuterJoinWithoutInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.leftOuterJoin(rightMts, Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,null))
                        .add(8L,new Pair<>(5.0,null))
                        .add(11L,new Pair<>(4.0,null))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L, new Pair<>(2.0,null))
                        .add(11L, new Pair<>(5.0,null))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    /*
    val expected = Map[String,Observations[(Double,Option[Double])]](
      "a" -> Observations(
        Obs(2L,(1.0,Some(3.0))),
        Obs(8L,(5.0,Some(9.0))),
        Obs(11L,(4.0,Some(10.0)))
      ),
      "b" -> Observations(
        Obs(2L,(2.0,Some(1.0))),
        Obs(11L,(5.0,Some(10.0)))
      )
    )
     */
    @Test
    public void testLeftOuterJoinWithInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.leftOuterJoin(
                rightMts,
                Pair::new,
                GenericInterpolators.nearest(-1.0)
        );

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L,new Pair<>(1.0,-1.0))
                        .add(8L,new Pair<>(5.0,9.0))
                        .add(11L,new Pair<>(4.0,10.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(2L, new Pair<>(2.0,1.0))
                        .add(11L, new Pair<>(5.0,-1.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());

    }





    /*
    val expected = Map[String,Observations[(Option[Double],Double)]](
      "a" -> Observations(
        Obs(4L,(None,4.0)),
        Obs(6L,(None,6.0)),
        Obs(9L,(None,9.0)),
        Obs(12L,(None,12.0))
      ),
      "b" -> Observations(
        Obs(1L,(None,1.0)),
        Obs(4L,(None,4.0)),
        Obs(5L,(None,5.0))
      )
    )
     */
    @Test
    public void testRightOuterAlignWithoutInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .rightOuterAlign(rightMts);

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(4L,null)
                        .add(6L,null)
                        .add(9L,null)
                        .add(12L,null)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,null)
                        .add(4L,null)
                        .add(5L,null)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(4L,4.0)
                        .add(6L,6.0)
                        .add(9L,9.0)
                        .add(12L,12.0)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,1.0)
                        .add(4L,4.0)
                        .add(5L,5.0)
                        .result()
        );
        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());

    }

    /*
    val expected = Map[String,Observations[(Option[Double],Double)]](
      "a" -> Observations(
        Obs(4L,(Some(2.0),4.0)),
        Obs(6L,(Some(5.0),6.0)),
        Obs(9L,(Some(5.0),9.0)),
        Obs(12L,(Some(4.0),12.0))
      ),
      "b" -> Observations(
        Obs(1L,(Some(2.0),1.0)),
        Obs(4L,(Some(3.0),4.0)),
        Obs(5L,(Some(3.0),5.0))
      )
    )
     */
    @Test
    public void testRightOuterAlignWithInterpolation() {
        MTSPair<String,Double,Double> actual = leftMts
                .rightOuterAlign(rightMts, GenericInterpolators.nearest(-1.0));

        Map<String,ObservationCollection<Double>> expectedLeft = new HashMap<>();
        expectedLeft.put("a",
                Observations.<Double>newBuilder()
                        .add(4L,2.0)
                        .add(6L,5.0)
                        .add(9L,5.0)
                        .add(12L,-1.0)
                        .result()
        );
        expectedLeft.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,-1.0)
                        .add(4L,3.0)
                        .add(5L,3.0)
                        .result()
        );

        Map<String,ObservationCollection<Double>> expectedRight = new HashMap<>();
        expectedRight.put("a",
                Observations.<Double>newBuilder()
                        .add(4L,4.0)
                        .add(6L,6.0)
                        .add(9L,9.0)
                        .add(12L,12.0)
                        .result()
        );
        expectedRight.put("b",
                Observations.<Double>newBuilder()
                        .add(1L,1.0)
                        .add(4L,4.0)
                        .add(5L,5.0)
                        .result()
        );
        verifier.verify(expectedLeft,actual.left.collect());
        verifier.verify(expectedRight,actual.right.collect());
    }

    /*
    val expected = Map[String,Observations[(Option[Double],Double)]](
      "a" -> Observations(
        Obs(4L,(None,4.0)),
        Obs(6L,(None,6.0)),
        Obs(9L,(None,9.0)),
        Obs(12L,(None,12.0))
      ),
      "b" -> Observations(
        Obs(1L,(None,1.0)),
        Obs(4L,(None,4.0)),
        Obs(5L,(None,5.0))
      )
    )
     */
    @Test
    public void testRightOuterJoinWithoutInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.rightOuterJoin(rightMts, Pair::new);

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(4L,new Pair<>(null,4.0))
                        .add(6L,new Pair<>(null,6.0))
                        .add(9L,new Pair<>(null,9.0))
                        .add(12L,new Pair<>(null,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(null,1.0))
                        .add(4L, new Pair<>(null,4.0))
                        .add(5L, new Pair<>(null,5.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());
    }

    /*
    val expected = Map[String,Observations[(Option[Double],Double)]](
      "a" -> Observations(
        Obs(4L,(Some(2.0),4.0)),
        Obs(6L,(Some(5.0),6.0)),
        Obs(9L,(Some(5.0),9.0)),
        Obs(12L,(Some(4.0),12.0))
      ),
      "b" -> Observations(
        Obs(1L,(Some(2.0),1.0)),
        Obs(4L,(Some(3.0),4.0)),
        Obs(5L,(Some(3.0),5.0))
      )
    )
     */
    @Test
    public void testRightOuterJoinWithInterpolation() {
        MultiTimeSeries<String,Pair<Double,Double>> actual = leftMts.rightOuterJoin(
                rightMts,
                Pair::new,
                GenericInterpolators.nearest(-1.0)
        );

        Map<String,ObservationCollection<Pair<Double,Double>>> expected = new HashMap<>();
        expected.put("a",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(4L,new Pair<>(2.0,4.0))
                        .add(6L,new Pair<>(5.0,6.0))
                        .add(9L,new Pair<>(5.0,9.0))
                        .add(12L,new Pair<>(-1.0,12.0))
                        .result()
        );
        expected.put("b",
                Observations.<Pair<Double,Double>>newBuilder()
                        .add(1L, new Pair<>(-1.0,1.0))
                        .add(4L, new Pair<>(3.0,4.0))
                        .add(5L, new Pair<>(3.0,5.0))
                        .result()
        );

        tupleVerifier.verify(expected,actual.collect());

    }
}
