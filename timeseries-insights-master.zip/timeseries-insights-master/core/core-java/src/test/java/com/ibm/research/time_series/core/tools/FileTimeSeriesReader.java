/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Queue;
import java.util.Scanner;


import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import org.apache.log4j.Logger;


/**
 * This is the TimeSeriesReader implementation that will read from files
 * You can give it a file path and read the file based on this filepath you give it
 * @author Joshua Rosenkranz
 *
 */
public class FileTimeSeriesReader implements TimeSeriesReader<Double> {
	private static final Logger logger = Logger.getLogger(FileTimeSeriesReader.class);
	String filepath;//the path to the file

    Helper<Double> helper = new HelperGeneral<>();

	public FileTimeSeriesReader(String filepath){
		this.filepath = filepath;
	}

	/**
	 * the general method to read from a file
	 * @return the file as a string(for now)
	 */
	@Override
	public Iterator<Observation<Double>> read(long t1, long t2, boolean inclusive) {
		String temp_file_string = "";
		try {
			temp_file_string = new Scanner(new File(filepath)).useDelimiter("\\A").next();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		Queue<Observation<Double>> values_as_queue = new LinkedList<Observation<Double>>();
		//assuming simple csv for now
		String ts_readings[] = temp_file_string.split(",");
        for (String ts_reading : ts_readings) {
            String separatedValues[] = ts_reading.split(":");
            Observation<Double> tssToAdd = new Observation<Double>(Long.valueOf(separatedValues[0]), Double.valueOf(separatedValues[1]));
            values_as_queue.add(tssToAdd);
        }
		return helper.getValuesInRange(t1,t2,values_as_queue.iterator()).iterator();
	}

	/**
	 * close the file
	 */
	public void close(){
		//...
	}

}
