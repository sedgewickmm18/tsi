/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;

/**
 * <p>Created on 6/14/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DummyBinaryTransform extends BinaryTransform<Double,Double,Double> {
    @Override
    public ObservationCollection<Double> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<Double> tsBuilder = Observations.newBuilder();

        Iterator<Observation<Double>> xIter = this.getTimeSeriesLeft().getValues(t1,t2,inclusive).iterator();
        Iterator<Observation<Double>> yIter = this.getTimeSeriesRight().getValues(t1,t2,inclusive).iterator();

        while(xIter.hasNext() && yIter.hasNext()){
            Observation<Double> x = xIter.next();
            Observation<Double> y = yIter.next();
            double resultValue = x.getValue() + y.getValue();
            tsBuilder.add(x.getTimeTick(),resultValue);

        }
        return tsBuilder.result();
    }
}
