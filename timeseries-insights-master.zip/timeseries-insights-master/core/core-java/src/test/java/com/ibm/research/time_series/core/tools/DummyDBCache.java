/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.cache.DBCache;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;

/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DummyDBCache<T> extends DBCache<T>{
    private MutableObservationCollection<T> data;

    public DummyDBCache() {
        super(Integer.MAX_VALUE,1.0);
        this.data = new MutableObservationCollection<>();
    }
    @Override
    public void addRow(Observation<T> tss) {
        data.add(tss);
    }

    @Override
    protected boolean contains(Observation<T> tss) {
        return !data.isEmpty()
                && data.first().getTimeTick() <= tss.getTimeTick()
                && data.last().getTimeTick() >= tss.getTimeTick();
    }

    @Override
    public Observation<T> first() {
        return data.first();
    }

    @Override
    public Observation<T> last() {
        return data.last();
    }

    @Override
    public ObservationCollection<T> getCache() {
        return data;
    }

    @Override
    public ObservationCollection<T> getCacheInRange(long t1, long t2, boolean inclusive) {
        return TimeSeries.fromObservations(data).getValues(t1,t2,inclusive);
    }

    @Override
    public void clear() {
        data.clear();
    }

    @Override
    public void shrinkCache() {
        while(data.size() > getMaxCacheSize()) {
            data.remove(data.first().getTimeTick());
        }
    }
}
