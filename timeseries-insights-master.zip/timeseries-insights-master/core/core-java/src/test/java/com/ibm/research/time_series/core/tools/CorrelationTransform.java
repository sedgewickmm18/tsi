/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Iterator;
import java.util.Properties;

/**
 * <p>Implementation of CorrelationTransform based on the BinaryTransform abstract class</p>
 * <p>This transform will take the correlation of two time series over each window at each step value in a given range</p>
 *
 * @author Joshua Rosenkranz
 * @author Supriyo Chakraborty
 * @author Mudhakar Srivatsa
 */
public class CorrelationTransform extends BinaryTransform<Double,Double,Double>{

	private long step;//number of steps we will do
	private long window;//this is the size of the window we will be calculating the correlation coefficient on
    private int lag;//this is the lag factor

	/**
	 * Basic constructor of the CorrelationTransform.
	 * @param window our window size to compute average
	 * @param step step size
	 */
	public CorrelationTransform(long window, long step){
		this.window = window;
		this.step = step;
        this.lag = 0;
	}

    /**
     * Constructor for CorrelationTransform that includes a lag on our second TimeSeries
     * @param window our window size to compute average
     * @param step our step size to computer average
     * @param lag how much lag we want to account for with our second TimeSeries
     */
    public CorrelationTransform(long window, long step, int lag){
        this.window = window;
        this.step = step;
        this.lag = lag;
    }

	/**
	 * this is our implementation of clone.
	 * create a clone of this and return
	 * @return tClone - the clone of this
	 */
	@Override
	public Object clone() {
		return new CorrelationTransform(this.window,this.step,this.lag);
	}

	/**
	 * This method will take the sensor information values from between time stamps t1 and t2 of timeseries_x and timeseries_y,
	 * compute the correlation coefficient on window, incrementing windows by step (moving correlation),
	 * the result is a set of values that is our new time series.
	 *
	 * @param t1 timestamp start
	 * @param t2 timestamp end
	 * @return resultTimeSeries - the resulting TimeSeries - Observation values after evaluation has taken place
	 */
	@Override
	public ObservationCollection<Double> evaluate(long t1, long t2,boolean inclusive) {
        TSBuilder<Double> tsBuilder = Observations.newBuilder();

        long start = t1;
        long end = start + (window - 1);

        //iterate over window till end of window is > (t2 - 1)
        while (end <= t2 + (window - 1)) {

            //get our windows
            ObservationCollection<Double> window_x = this.getTimeSeriesLeft().getValues(start, end,inclusive);
            ObservationCollection<Double> window_y = this.getTimeSeriesRight().getValues(start + lag, end + lag,inclusive);

            //add result to our resulting correlation coefficient for the given window window_x and window_y to our final resultTimeSeries
            if(window_x.size() != 0 && window_y.size() != 0) tsBuilder.add(performOnWindow(window_x, window_y));

            //get our new start and end
            start = start + step;
            end = start + (window - 1);
        }

		return tsBuilder.result();
	}

    private Observation<Double> performOnWindow(ObservationCollection<Double> ts_x, ObservationCollection<Double> ts_y){
        if(ts_x.size() != ts_y.size()) {
            return new Observation<>(ts_x.first().getTimeTick(),Double.NaN);
        }

        Iterator<Observation<Double>> tsi_x = ts_x.iterator();
        Iterator<Observation<Double>> tsi_y = ts_y.iterator();

        //get the mean of each
        double sum_x = 0;//sum_x will be used more than once, using for the basic mean here
        double sum_y = 0;//sum_y will be used more than once, using for the basic mean here
        double sum_xy;//this will be used for the covariance

        //***************************************************************
        //calculating the mean
        while(tsi_x.hasNext()){
            //must check that the timestamps match up
            Observation<Double> xTSS = tsi_x.next();
            Observation<Double> yTSS = tsi_y.next();
            if(xTSS.getTimeTick() + lag != yTSS.getTimeTick())
                throw new IllegalArgumentException("the 2 series must have the same frequency. Please resample data");

            Double xCurr = xTSS.getValue();
            Double yCurr = yTSS.getValue();
            sum_x += xCurr;
            sum_y += yCurr;
        }

        double mean_x = sum_x / ts_x.size();
        double mean_y = sum_y / ts_y.size();
        //***************************************************************


        tsi_x = ts_x.iterator();
        tsi_y = ts_y.iterator();

        sum_x = 0;
        sum_y = 0;
        sum_xy = 0;
        while(tsi_x.hasNext()){

            Observation<Double> timestamp_x = tsi_x.next();
            Observation<Double> timestamp_y = tsi_y.next();

            //***************************************************************
            //this is for calculating standard deviation
            double subtract_step_x;
            double subtract_step_y;

            subtract_step_x = timestamp_x.getValue() - mean_x;
            subtract_step_y = timestamp_y.getValue() - mean_y;

            double square_step_x = subtract_step_x * subtract_step_x;
            double square_step_y = subtract_step_y * subtract_step_y;

            sum_x += square_step_x;
            sum_y += square_step_y;
            //***************************************************************

            //***************************************************************
            //this is for calculating covariance
            double mean_diff_x;
            double mean_diff_y;

            mean_diff_x = timestamp_x.getValue() - mean_x;
            mean_diff_y = timestamp_y.getValue() - mean_y;


            double std_val_xy = mean_diff_x * mean_diff_y;
            sum_xy += std_val_xy;
            //***************************************************************
        }

        double std_dev_x = Math.sqrt(sum_x / ts_x.size());
        double std_dev_y = Math.sqrt(sum_y / ts_y.size());
        double covariance_xy = sum_xy / ts_x.size();
        double correlation_co = covariance_xy / ((std_dev_x) * (std_dev_y));

        return new Observation<>(ts_x.first().getTimeTick(), correlation_co);
    }

    @Override
    public long getWindow() {
        return window;
    }

    @Override
    public long getStep() {
        return step;
    }
}
