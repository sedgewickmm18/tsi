/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.apache.commons.io.input.ReversedLinesFileReader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.function.Function;

/**
 * This is the SequentialFile TimeSeriesReader implementation of TimeSeriesReader.
 * <p>This reader will be used when each Observation will reside on a single line of a file and
 * the file stores all sensor readings in sequential order based on time.</p>
 * <p>In order to extend this class, one must implement the parseLine method and
 * one must create a constructor which calls super(String path,int buffer_size)</p>
 * <p>Note: When reading a file, we never look backwards in the file, so make sure to keep a large enough buffer size to
 * handle your entire series you will be collecting</p>
 * <p>Created on 3/15/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class SequentialFileTimeSeriesReader<T> implements TimeSeriesReader<T> {

    private String path;
    protected RandomAccessFile file;//the file to be reading from
    private int buffer_size;//the buffer size(number of timestamp sensors to backtrack)
    private MutableObservationCollection<T> buffer;//our buffer
    private String key;
    private KeyExtractor extraction;
    private Function<String,Boolean> filter;
    private boolean artificialStamps;

    private Helper<T> helper = new HelperGeneral<>();//helper method

    /**
     * Constructs a SequentialFileSenosrReader that reads from a file and holds a buffer of values which amounts to buffer_size.
     * <p>Note: Defaults key from line to ""</p>
     * @param path path to the file
     * @param buffer_size size of the buffer of TimeStampSensors
     * @throws FileNotFoundException if file is not found given the path
     */
    public SequentialFileTimeSeriesReader(String path, int buffer_size, boolean artificialStamps) throws FileNotFoundException {
        this.path = path;
        this.file = new RandomAccessFile(path,"r");
        this.buffer_size = buffer_size;
        this.buffer = new MutableObservationCollection<>();
        this.key = "";
        this.extraction = x -> "";
        this.filter = (s) -> true;
        this.artificialStamps = artificialStamps;
    }

    /**
     * Constructs a SequentialFileTimeSeriesReader that reads from a file and holds a buffer of values which amounts to buffer_size. This
     * Will also override the key for a given line to what is given in the constructor
     * @param path path to the file
     * @param extraction the extraction schema for extracting a key from a given string
     * @param key the key to extract
     * @param buffer_size size of the buffer of TimeStampSensors
     * @throws FileNotFoundException if file is not found given the path
     */
    public SequentialFileTimeSeriesReader(String path, KeyExtractor extraction, String key, int buffer_size, boolean artificialStamps) throws FileNotFoundException {
        this.path = path;
        this.file = new RandomAccessFile(path,"r");
        this.buffer_size = buffer_size;
        this.buffer = new MutableObservationCollection<>();
        this.key = key;
        this.extraction = extraction;
        this.filter = (s) -> true;
        this.artificialStamps = artificialStamps;
    }

    public SequentialFileTimeSeriesReader(
            String path,
            KeyExtractor extraction,
            String key,
            int buffer_size,
            Function<String,Boolean> filter,
            boolean artificialStamps) throws FileNotFoundException {
        this.path = path;
        this.file = new RandomAccessFile(path,"r");
        this.buffer_size = buffer_size;
        this.buffer = new MutableObservationCollection<>();
        this.key = key;
        this.extraction = extraction;
        this.filter = filter;
        this.artificialStamps = artificialStamps;
    }

    @Override
    public long start() {
        if (artificialStamps)
            return 0;


        long start = Long.MIN_VALUE;
        try {
            BufferedReader buffer = new BufferedReader(new FileReader(path));
            start = parseLine(buffer.readLine()).getTimeTick();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return start;
    }

    @Override
    public long end() {
        if (artificialStamps) {
            try {
                return Files.lines(Paths.get(path)).count();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        long end = Long.MAX_VALUE;
        try {
            ReversedLinesFileReader rf = new ReversedLinesFileReader(new File(path));
            end = parseLine(rf.readLine()).getTimeTick();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return end;
    }


    /**
     * retrieves TimeStampSensors from our file from floor(t1) to ceiling(t2)
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return an iterator to our set of TimeStampSensors
     */
    @Override
    public Iterator<Observation<T>> read(long t1, long t2,boolean inclusive) {

        ObservationCollection<T> current = null;
        //first we must check if we have our values already
        if(!buffer.isEmpty()) {

            //need to create new so not reference
            current = buffer.subSet(TimeSeriesReader.getFloor(buffer, t1), true, TimeSeriesReader.getCeiling(buffer, t2), true);

            if (current.last().getTimeTick() >= t2){
                return current.iterator();
            }

        }

        //if current is null, init
        if(current == null){
            current = Observations.empty();
        }

        Iterator<Observation<T>> cacheIter = current.iterator();

        return new FileIterator(cacheIter,t1,t2);
    }

    private boolean foundEOF = false;//this must be global in this class scope, if we have already found end, FileIterator needs to know
    private class FileIterator implements Iterator<Observation<T>> {

        Iterator<Observation<T>> cacheIter;//these are our cached values from
        LinkedList<Observation<T>> initialSet;//this is our initial set of values, never contains more than 2 values

        //variables to aid in the range
        //boolean foundEOF = false;
        boolean foundLast = false;
        boolean wentPassed = false;
        boolean processedFirst = false;

        //denotes first and last value
        long t1;
        long t2;

        FileIterator(Iterator<Observation<T>> cacheIter, long t1, long t2){
            this.cacheIter = cacheIter;
            this.t1 = t1;
            this.t2 = t2;
            this.initialSet = new LinkedList<>();
            performPreProcessing();
        }

        @Override
        public boolean hasNext() {
            if (!processedFirst && !initialSet.isEmpty()) return true;

            return !foundLast && !foundEOF;
        }

        @Override
        public Observation<T> next() {
            if(!processedFirst){
                if(wentPassed){
                    Observation<T> nextToReturn = initialSet.remove();
                    if(initialSet.isEmpty()) processedFirst = true;
                    return nextToReturn;
                }else{
                    if(initialSet.size() == 2) initialSet.remove();//must remove the first one since it is not needed(we only want one value since we didn't go past)
                    processedFirst = true;
                    return initialSet.remove();
                }
            }

            if(cacheIter.hasNext()){
                return cacheIter.next();
            }else{
                Observation<T> currentValue = getValueFromLine();
                foundLast = currentValue.getTimeTick() >= t2;
                return currentValue;
            }

        }

        private Observation<T> getValueFromLine(){
            String line = "";
            try {
                line = file.readLine();
                if (file.getFilePointer() >= file.length()) foundEOF = true;
                boolean found = false;
                while (!found) {
                    if(filter.apply(line)) {
                        if(extraction.extract(line).equals(key)) {
                            found = true;
                            continue;
                        }
                    }
                    if (file.getFilePointer() >= file.length()) {
                        foundEOF = true;
                        break;
                    }
                    line = file.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            Observation<T> currentValue = (!line.equals("")) ? parseLine(line) : null;
            //add our timestamp sensor to buffer
            buffer.add(currentValue);

            //if we have reached our max buffer, remove the lowest timestamp sensor
            if(buffer.size() > buffer_size){
                buffer.remove(buffer.first().getTimeTick());
            }
            return currentValue;
        }

        private void performPreProcessing(){
            //must perform pre-processing from the cache to get our initial set
            while(cacheIter.hasNext()){
                Observation<T> nextVal = cacheIter.next();
                if(initialSet.size() == 2){
                    initialSet.remove();
                }
                initialSet.add(nextVal);
                if(nextVal.getTimeTick() >= t1){
                    wentPassed = nextVal.getTimeTick() > t1;
                    foundLast = nextVal.getTimeTick() >= t2;
                    break;
                }
            }

            //need to undertake more pre-processing from the file since we haven't found our value yet
            if(!wentPassed || (!initialSet.isEmpty() && initialSet.peekLast().getTimeTick() != t1)){
                while(!foundEOF) {
                    Observation<T> currentValue = getValueFromLine();
                    if(currentValue != null) {
                        if (initialSet.size() == 2) {
                            initialSet.remove();
                        }
                        initialSet.add(currentValue);
                    }
                    if(foundEOF) break;
                    if(initialSet.peekLast().getTimeTick() >= t1){
                        wentPassed = initialSet.peekLast().getTimeTick() > t1;
                        foundLast = initialSet.peekLast().getTimeTick() >= t2;
                        break;
                    }
                }
            }

        }
    }

    /**
     * given a line from a file, build a Observation
     * @param line the line to parse
     * @return a Observation representing the information in a line
     */
    public abstract Observation<T> parseLine(String line);

    /**
     * close the file
     * todo not implemented
     */
    @Override
    public void close() {

    }
}





//now we can check our file
        /*try {

            //make sure our pointer has not passed the end of file
            while(file.getFilePointer() < file.length()){
                String line = file.readLine();
                String extractedKey = extraction.extract(line);
                boolean foundEnd = false;
                while(!extractedKey.equals(key)){
                    if(file.getFilePointer() >= file.length()){
                        foundEnd = true;
                        break;
                    }
                    line = file.readLine();
                    extractedKey = extraction.extract(line);
                }

                if(foundEnd) break;

                //get our timestamp sensor from a parse line
                Observation<T> tss = parseLine(line);

                //add our timestamp sensor to buffer
                buffer.add(tss);
                current.add(tss);

                //if we have reached our max buffer, remove the lowest timestamp sensor
                if(buffer.size() > buffer_size){
                    buffer.remove(buffer.first());
                }

                //we should only keep reading till we are greater than or equal to t2
                if(tss.getTimeTick() >= t2){
                    break;
                }
            }



        } catch (IOException e) {
            e.printStackTrace();
        }

        return current.subSet(helper.getFloor(current, t1), true, helper.getCeiling(current, t2), true).iterator();*/
