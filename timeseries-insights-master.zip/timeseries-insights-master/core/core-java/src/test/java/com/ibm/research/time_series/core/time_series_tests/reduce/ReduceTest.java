/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.reduce;
import com.ibm.research.time_series.core.core_transforms.general.Stats;
import com.ibm.research.time_series.core.core_transforms.general.TimeStats;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DummyBinaryReducer;
import com.ibm.research.time_series.core.tools.DummyNaryReducer;
import com.ibm.research.time_series.core.tools.DummyUnaryReducer;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertEquals;


/**
 * <p>Created on 8/16/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ReduceTest {


    private ObservationCollection<Double> data;
    private ObservationCollection<Double> data2;
    private ObservationCollection<Double> data3;

    @Before
    public void setUp(){
        TSBuilder<Double> tsBuilder = Observations.newBuilder();
        tsBuilder.add(1,2.0);
        tsBuilder.add(2,3.0);
        tsBuilder.add(3,4.0);
        tsBuilder.add(4,5.0);
        tsBuilder.add(5,6.0);
        tsBuilder.add(6,7.0);
        data = tsBuilder.result();

        tsBuilder.clear();
        tsBuilder.add(1,7.0);
        tsBuilder.add(2,6.0);
        tsBuilder.add(3,5.0);
        tsBuilder.add(4,4.0);
        tsBuilder.add(5,3.0);
        data2 = tsBuilder.result();

        tsBuilder.clear();
        tsBuilder.add(2,6.0);
        tsBuilder.add(3,5.0);
        tsBuilder.add(4,4.0);
        tsBuilder.add(5,3.0);
        data3 = tsBuilder.result();
    }

    @Test
    public void testReduceWithLambda() throws Exception {
        int expected = 6;
        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        int actual = ts.reduce(ObservationCollection::size);
        assertEquals(expected,actual);
    }

    @Test
    public void testReduceWithUnaryReducer() throws Exception {
        int expected = 6;
        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        int actual = ts.reduce(new DummyUnaryReducer());
        assertEquals(expected,actual);
    }

    @Test
    public void testReduceRange() throws Exception {
        int expected = 3;
        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        int actual = ts.reduceRange(new DummyUnaryReducer(),3,5);
        assertEquals(expected,actual);
    }

    @Test
    public void testBinaryReduce() throws Exception {
        int expected = 11;

        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        TimeSeries<Double> ts2 = TimeSeries.fromObservations(data2);

        int actual = ts.reduce(ts2,new DummyBinaryReducer());
        assertEquals(expected,actual);
    }

    @Test
    public void testBinaryReduceRange() throws Exception {
        int expected = 5;

        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        TimeSeries<Double> ts2 = TimeSeries.fromObservations(data2);

        int actual = ts.reduceRange(ts2,new DummyBinaryReducer(),4,6);
        assertEquals(expected,actual);
    }

    @Test
    public void testNaryReduce() throws Exception {
        int expected = 15;
        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        TimeSeries<Double> ts2 = TimeSeries.fromObservations(data2);
        TimeSeries<Double> ts3 = TimeSeries.fromObservations(data3);

        int actual = ts.reduce(Arrays.asList(ts2,ts3),new DummyNaryReducer());
        assertEquals(expected,actual);
    }

    @Test
    public void testNaryReduceRange() throws Exception {
        int expected = 8;

        TimeSeries<Double> ts = TimeSeries.fromObservations(data);
        TimeSeries<Double> ts2 = TimeSeries.fromObservations(data2);
        TimeSeries<Double> ts3 = TimeSeries.fromObservations(data3);

        int actual = ts.reduceRange(Arrays.asList(ts2,ts3),new DummyNaryReducer(),1,3);
        assertEquals(expected,actual);
    }

    @Test
    public void testDescribe() throws Exception {
        TSBuilder<Double> tsBuilder = Observations.newBuilder();
        tsBuilder.add(1,2.0);
        tsBuilder.add(2,3.0);
        tsBuilder.add(3,4.0);
        tsBuilder.add(5,4.0);
        tsBuilder.add(8,7.0);
        TimeSeries<Double> ts = tsBuilder.result().toTimeSeriesStream();

        Stats<Double> expected = new Stats<Double>(
                new TimeStats(1,3,1.75),
                4.0,
                4,
                2,
                new Observation<>(1L,2.0),
                new Observation<>(8L,7.0),
                5
        );

        Stats<Double> actual = ts.describe();

        assertEquals(expected.minInterArrivalTime,actual.minInterArrivalTime);
        assertEquals(expected.maxInterArrivalTime,actual.maxInterArrivalTime);
        assertEquals(expected.meanInterArrivalTime,actual.meanInterArrivalTime,.001);
        assertEquals(expected.top,actual.top);
        assertEquals(expected.unique,actual.unique);
        assertEquals(expected.frequency,actual.frequency);
        assertEquals(expected.first,actual.first);
        assertEquals(expected.last,actual.last);

    }
}
