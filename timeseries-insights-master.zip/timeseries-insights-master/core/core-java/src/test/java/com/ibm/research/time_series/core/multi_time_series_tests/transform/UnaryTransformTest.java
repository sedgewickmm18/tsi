/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.multi_time_series_tests.transform;

import com.ibm.research.time_series.core.constants.Padding;
import com.ibm.research.time_series.core.constants.ResultingTimeStamp;
import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.tools.NavSetMultiTimeSeriesReader;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.AddOneTransform;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

import java.util.*;

/**
 * <p>Created on 7/28/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class UnaryTransformTest {
    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private MultiTimeSeriesReader<Integer,Double> allReaders;

    @Before
    public void setUp(){
        List<ObservationCollection<Double>> input = new ArrayList<>();


        MutableObservationCollection<Double> input1 = new MutableObservationCollection<>();
        input1.add(new Observation<>(1,2.0));
        input1.add(new Observation<>(3,3.0));
        input1.add(new Observation<>(7,5.0));

        MutableObservationCollection<Double> input2 = new MutableObservationCollection<>();
        input2.add(new Observation<>(2,2.0));
        input2.add(new Observation<>(3,3.0));
        input2.add(new Observation<>(8,6.0));
        input2.add(new Observation<>(10,7.0));
        input2.add(new Observation<>(11,5.0));

        input.addAll(Arrays.asList(input1,input2));
        allReaders = new NavSetMultiTimeSeriesReader<>(input);
    }

    @Test
    public void testTransform(){
        Map<Integer,ObservationCollection<Double>> expectedOutput = new HashMap<>();
        MutableObservationCollection<Double> expected1 = new MutableObservationCollection<>();
        expected1.add(new Observation<>(1,3.0));
        expected1.add(new Observation<>(3,4.0));
        expected1.add(new Observation<>(7,6.0));

        MutableObservationCollection<Double> expected2 = new MutableObservationCollection<>();
        expected2.add(new Observation<>(2,3.0));
        expected2.add(new Observation<>(3,4.0));
        expected2.add(new Observation<>(8,7.0));
        expected2.add(new Observation<>(10,8.0));

        expectedOutput.put(0,expected1);
        expectedOutput.put(1,expected2);

        MultiTimeSeries<Integer,Double> msi = MultiTimeSeries.reader(allReaders).transform(new AddOneTransform());
        msi.getTimeSeriesMap().entrySet().forEach(si -> verifier.verifyOutput(1,10,expectedOutput.get(si.getKey()),si.getValue()));
    }

    @Test
    public void testTransformLambda(){
        Map<Integer,ObservationCollection<Double>> expectedOutput = new HashMap<>();
        MutableObservationCollection<Double> expected1 = new MutableObservationCollection<>();
        expected1.add(new Observation<>(1,1.0));
        expected1.add(new Observation<>(3,2.0));
        expected1.add(new Observation<>(7,4.0));

        MutableObservationCollection<Double> expected2 = new MutableObservationCollection<>();
        expected2.add(new Observation<>(2,1.0));
        expected2.add(new Observation<>(3,2.0));
        expected2.add(new Observation<>(8,5.0));
        expected2.add(new Observation<>(10,6.0));

        expectedOutput.put(0,expected1);
        expectedOutput.put(1,expected2);

        MultiTimeSeries<Integer,Double> msi = MultiTimeSeries.reader(allReaders).mapObservation(x -> new Observation<>(x.getTimeTick(),x.getValue() - 1));
        msi.getTimeSeriesMap().entrySet().forEach(si -> verifier.verifyOutput(1,10,expectedOutput.get(si.getKey()),si.getValue()));
    }

    @Test
    public void testWindowTransformStrict(){
        Map<Integer,ObservationCollection<Double>> expectedOutput = new HashMap<>();
        MutableObservationCollection<Double> expected1 = new MutableObservationCollection<>();
        expected1.add(new Observation<>(1,5.0));
        expected1.add(new Observation<>(4,5.0));
        expected1.add(new Observation<>(7,5.0));
        expected1.add(new Observation<>(10,0.0));
        expected1.add(new Observation<>(13,0.0));


        MutableObservationCollection<Double> expected2 = new MutableObservationCollection<>();
        expected2.add(new Observation<>(1,5.0));
        expected2.add(new Observation<>(4,0.0));
        expected2.add(new Observation<>(7,13.0));
        expected2.add(new Observation<>(10,12.0));
        expected2.add(new Observation<>(13,0.0));

        expectedOutput.put(0,expected1);
        expectedOutput.put(1,expected2);

        MultiTimeSeries<Integer,Double> msi = MultiTimeSeries.reader(allReaders)
                .segmentByTime(4,3, Padding.RIGHT, ResultingTimeStamp.START_OF_WINDOW)
                .mapObservation(obs -> {
                    return new Observation<>(
                            obs.getTimeTick(),
                            obs.getValue().stream()
                                    .mapToDouble(Observation::getValue).sum()
                    );
                });

        msi.getTimeSeriesMap().forEach((key, value) -> {
            verifier.verifyOutput(1, 15,false, expectedOutput.get(key), value);
        });
    }

    @Test
    public void testWindowRecordsTransform(){
        Map<Integer,ObservationCollection<Double>> expectedOutput = new HashMap<>();
        MutableObservationCollection<Double> expected1 = new MutableObservationCollection<>();
        expected1.add(new Observation<>(1,5.0));
        expected1.add(new Observation<>(7,5.0));

        MutableObservationCollection<Double> expected2 = new MutableObservationCollection<>();
        expected2.add(new Observation<>(2,5.0));
        expected2.add(new Observation<>(8,13.0));
        expected2.add(new Observation<>(11,5.0));

        expectedOutput.put(0,expected1);
        expectedOutput.put(1,expected2);


        MultiTimeSeries<Integer,Double> msi = MultiTimeSeries.reader(allReaders)
                .segment(2,2,false)
                .mapObservation(obs -> {
                    return new Observation<>(
                            obs.getTimeTick(),
                            obs.getValue().stream().mapToDouble(Observation::getValue).sum()
                    );
                });

        msi.getTimeSeriesMap().forEach((key, value) -> {
            verifier.verifyOutput(1, 15, expectedOutput.get(key), value);
        });
    }
}
