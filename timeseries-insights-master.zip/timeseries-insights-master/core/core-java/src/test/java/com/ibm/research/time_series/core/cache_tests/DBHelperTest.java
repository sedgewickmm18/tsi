/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache_tests;

import com.ibm.research.time_series.core.tools.DBHelper;
import org.junit.Test;
import com.ibm.research.time_series.core.observation.Observation;

import java.util.Enumeration;
import java.util.Properties;

import static org.junit.Assert.assertEquals;

/**
 * Created by Joshua Rosenkranz on 1/25/16.
 */
public class DBHelperTest {

    @Test
    public void testSerialization() throws Exception {

        DBHelper helper = new DBHelper();

        Observation<Double> tss_expected = new Observation<>(1, 1.8);
        tss_expected.addAnnotation("name","josh");
        tss_expected.addAnnotation("city","nyc");

        byte bytes_output[] = helper.serialize(tss_expected);

        Observation<Double> tss_actual = (Observation<Double>)helper.deserialize(bytes_output);

        assertEquals(tss_expected.getTimeTick(),tss_actual.getTimeTick());
        assertEquals(tss_expected.getValue(),tss_expected.getValue());
        //make sure metadata is equal
        assertEquals(tss_expected.getAnnotationKeys(),tss_actual.getAnnotationKeys());

        for (String key : tss_expected.getAnnotationKeys()) {
            assertEquals(tss_expected.<String>getAnnotation(key),tss_actual.<String>getAnnotation(key));
        }


    }
}
