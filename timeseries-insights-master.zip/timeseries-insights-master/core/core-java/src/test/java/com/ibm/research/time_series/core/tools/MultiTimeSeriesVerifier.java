/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static junit.framework.TestCase.assertEquals;


/**
 * <p>Created on 8/18/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class MultiTimeSeriesVerifier<T> {

    protected abstract void assertObservationEquals(Observation<T> expected,Observation<T> actual);

    public void verify(
            Map<String,ObservationCollection<T>> expected,
            Map<String,ObservationCollection<T>> actual) {
        assertEquals(expected.size(),actual.size());

        assertEquals(expected.keySet(),actual.keySet());

        Set<String> keys = expected.keySet();

        keys.forEach(key -> {
            ObservationCollection<T> expectedSeries = expected.get(key);
            ObservationCollection<T> actualSeries = actual.get(key);

            assertEquals(expectedSeries.size(),actualSeries.size());

            Iterator<Observation<T>> eIter = expectedSeries.iterator();
            Iterator<Observation<T>> aIter = actualSeries.iterator();

            while (eIter.hasNext()) {
                assertObservationEquals(eIter.next(),aIter.next());
            }
        });
    }
}
