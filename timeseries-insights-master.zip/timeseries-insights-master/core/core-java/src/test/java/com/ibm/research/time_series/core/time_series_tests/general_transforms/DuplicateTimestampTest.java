package com.ibm.research.time_series.core.time_series_tests.general_transforms;

import com.ibm.research.time_series.core.core_transforms.duplicate.DuplicateTransformers;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Test;

public class DuplicateTimestampTest {
    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();

    @Test
    public void testConsecutiveDuplicatesBeginningAndEnd() {
        ObservationCollection<Double> actual = Observations.<Double>newBuilder()
                .add(1,1.0)
                .add(1,10.0)
                .add(2,2.0)
                .add(3,3.0)
                .add(3,4.0)
                .add(3,5.0)
                .result()
                .toTimeSeriesStream()
                .transform(DuplicateTransformers.combineDuplicateTimeTicks(l -> l.stream().mapToDouble(x -> x).sum()))
                .collect();

        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(1, 11.0)
                .add(2, 2.0)
                .add(3, 12.0)
                .result();

        verifier.verifySeries(expected, actual);
    }

    @Test
    public void testConsecutiveDuplicatesBeginning() {
        ObservationCollection<Double> actual = Observations.<Double>newBuilder()
                .add(1,1.0)
                .add(1,10.0)
                .add(2,2.0)
                .add(3,3.0)
                .add(3,4.0)
                .add(3,5.0)
                .add(4, 1.0)
                .result()
                .toTimeSeriesStream()
                .transform(DuplicateTransformers.combineDuplicateTimeTicks(l -> l.stream().mapToDouble(x -> x).sum()))
                .collect();

        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(1, 11.0)
                .add(2, 2.0)
                .add(3, 12.0)
                .add(4, 1.0)
                .result();

        verifier.verifySeries(expected, actual);
    }

    @Test
    public void testConsecutiveDuplicatesEnd() {
        ObservationCollection<Double> actual = Observations.<Double>newBuilder()
                .add(1,10.0)
                .add(2,2.0)
                .add(3,3.0)
                .add(3,4.0)
                .add(3,5.0)
                .result()
                .toTimeSeriesStream()
                .transform(DuplicateTransformers.combineDuplicateTimeTicks(l -> l.stream().mapToDouble(x -> x).sum()))
                .collect();

        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(1, 10.0)
                .add(2, 2.0)
                .add(3, 12.0)
                .result();

        verifier.verifySeries(expected, actual);
    }
}
