package com.ibm.research.time_series.core.time_series_tests.general_transforms;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Test;

public class ConcatTest {
    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();

    @Test
    public void testConcat() {
        TimeSeries<Double> ts1 = Observations.<Double>newBuilder()
                .add(1,1.0)
                .add(2,2.0)
                .add(3,3.0)
                .add(4,4.0)
                .result()
                .toTimeSeriesStream();

        TimeSeries<Double> ts2 = Observations.<Double>newBuilder()
                .add(2,22.0)
                .add(3,33.0)
                .add(4,44.0)
                .add(4,45.0)
                .add(5,55.0)
                .add(6,66.0)
                .add(7,77.0)
                .result()
                .toTimeSeriesStream();

        TimeSeries<Double> actual = ts1.concat(ts2);

        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(1,1.0)
                .add(2,2.0)
                .add(3,3.0)
                .add(4,4.0)
                .add(4,44.0)
                .add(4,45.0)
                .add(5,55.0)
                .add(6,66.0)
                .add(7,77.0)
                .result();

        verifier.verifySeries(expected,actual.collect());
    }
}
