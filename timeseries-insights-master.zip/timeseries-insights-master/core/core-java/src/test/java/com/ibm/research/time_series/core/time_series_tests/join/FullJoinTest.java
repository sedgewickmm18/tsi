/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.join;

import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleListTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

import java.util.Arrays;
import java.util.List;

/**
 * <p>Created on 8/5/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FullJoinTest {
    private TimeSeriesVerifier<List<Double>> verifierList = new DoubleListTimeSeriesVerifier();
    private TimeSeriesVerifier<Double> verifierDouble = new DoubleTimeSeriesVerifier();

    private ObservationCollection<Double> input1 = Observations.empty();
    private ObservationCollection<Double> input2 = Observations.empty();
    private Interpolator<Double> interpolator = (history, future, timestamp) -> {
        if(history.isEmpty()) return future.first().getValue();
        if(future.isEmpty()) return history.first().getValue();
        return history.first().getValue() + (future.first().getValue() - history.first().getValue()) * ((timestamp - (double)history.first().getTimeTick()) / ((double)future.first().getTimeTick() - (double)history.first().getTimeTick()));
    };

    private BinaryTransform<Double,Double,List<Double>> binaryTransform = MapTransformers.binaryMap((x1, x2) -> Arrays.asList(x1,x2));

    @Before
    public void setUp(){
        input1 = Observations.<Double>newBuilder()
                .add(new Observation<>(1,2.0))
                .add(new Observation<>(3,3.0))
                .add(new Observation<>(7,5.0))
                .add(new Observation<>(8,8.0))
                .add(new Observation<>(10,5.0))
                .add(new Observation<>(11,9.0))
                .add(new Observation<>(12,11.0))
                .add(new Observation<>(14,1.0))
                .result();

        input2 = Observations.<Double>newBuilder()
                .add(new Observation<>(2,3.0))
                .add(new Observation<>(3,5.0))
                .add(new Observation<>(4,9.0))
                .add(new Observation<>(9,6.0))
                .add(new Observation<>(10,13.0))
                .add(new Observation<>(11,14.0))
                .add(new Observation<>(13,17.0))
                .add(new Observation<>(14,21.0))
                .result();
    }

    @Test
    public void testFullJoin() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,Arrays.asList(2.0,null)));
        expectedOutput.add(new Observation<>(2,Arrays.asList(null,3.0)));
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(4,Arrays.asList(null,9.0)));

        expectedOutput.add(new Observation<>(7,Arrays.asList(5.0,null)));
        expectedOutput.add(new Observation<>(8,Arrays.asList(8.0,null)));

        expectedOutput.add(new Observation<>(9,Arrays.asList(null,6.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(12,Arrays.asList(11.0,null)));
        expectedOutput.add(new Observation<>(13,Arrays.asList(null,17.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1).fullJoin(TimeSeries.fromObservations(input2),(x1, x2) -> Arrays.asList(x1,x2));
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinInterpolate() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,Arrays.asList(2.0,3.0)));
        expectedOutput.add(new Observation<>(2,Arrays.asList(2.5,3.0)));
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(4,Arrays.asList(3.5,9.0)));
        expectedOutput.add(new Observation<>(7,Arrays.asList(5.0,7.2)));
        expectedOutput.add(new Observation<>(8,Arrays.asList(8.0,6.6)));
        expectedOutput.add(new Observation<>(9,Arrays.asList(6.5,6.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(12,Arrays.asList(11.0,15.5)));
        expectedOutput.add(new Observation<>(13,Arrays.asList(6.0,17.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1).fullJoin(TimeSeries.fromObservations(input2),(x1, x2) -> Arrays.asList(x1,x2),interpolator,interpolator);
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinMap() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,Arrays.asList(2.0,null)));
        expectedOutput.add(new Observation<>(2,Arrays.asList(null,3.0)));
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(4,Arrays.asList(null,9.0)));

        expectedOutput.add(new Observation<>(7,Arrays.asList(5.0,null)));
        expectedOutput.add(new Observation<>(8,Arrays.asList(8.0,null)));

        expectedOutput.add(new Observation<>(9,Arrays.asList(null,6.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(12,Arrays.asList(11.0,null)));
        expectedOutput.add(new Observation<>(13,Arrays.asList(null,17.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1).fullJoin(TimeSeries.fromObservations(input2),(x, y) -> Arrays.asList(x,y));
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinMapInterpolate() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,Arrays.asList(2.0,3.0)));
        expectedOutput.add(new Observation<>(2,Arrays.asList(2.5,3.0)));
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(4,Arrays.asList(3.5,9.0)));
        expectedOutput.add(new Observation<>(7,Arrays.asList(5.0,7.2)));
        expectedOutput.add(new Observation<>(8,Arrays.asList(8.0,6.6)));
        expectedOutput.add(new Observation<>(9,Arrays.asList(6.5,6.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(12,Arrays.asList(11.0,15.5)));
        expectedOutput.add(new Observation<>(13,Arrays.asList(6.0,17.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1).fullJoin(TimeSeries.fromObservations(input2),(x, y) -> Arrays.asList(x,y),interpolator,interpolator);
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinWindowMap() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,13.0));
        expectedOutput.add(new Observation<>(3,22.0));
        expectedOutput.add(new Observation<>(5,14.0));
        expectedOutput.add(new Observation<>(7,19.0));
        expectedOutput.add(new Observation<>(9,47.0));
        expectedOutput.add(new Observation<>(11,51.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .fullJoin(TimeSeries.fromObservations(input2),(x,y) -> {
                    double newX = (x == null) ? 0.0 : x;
                    double newY = (y == null) ? 0.0 : y;
                    return newX + newY;
                })
                .segmentByTime(3,2)
                .map(val -> val.stream().mapToDouble(Observation::getValue).sum());
        verifierDouble.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinWindowMapInterpolate() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,18.5));
        expectedOutput.add(new Observation<>(3,32.7));
        expectedOutput.add(new Observation<>(5,24.7));
        expectedOutput.add(new Observation<>(7,39.3));
        expectedOutput.add(new Observation<>(9,53.5));
        expectedOutput.add(new Observation<>(11,72.5));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .fullJoin(
                        TimeSeries.fromObservations(input2),
                        (x,y) -> x + y,
                        interpolator,
                        interpolator
                )
                .segmentByTime(3,2)
                .map(val -> val.stream().mapToDouble(Observation::getValue).sum());

        verifierDouble.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinWindowRecordsMap() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,35.0));
        expectedOutput.add(new Observation<>(7,71.0));
        expectedOutput.add(new Observation<>(11,73.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .fullJoin(TimeSeries.fromObservations(input2),(x,y) -> {
                    double newX = (x == null) ? 0.0 : x;
                    double newY = (y == null) ? 0.0 : y;
                    return newX + newY;
                })
                .segment(6,4,false)
                .map(val -> val.stream().mapToDouble(Observation::getValue).sum());

        verifierDouble.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testFullJoinWindowRecordsMapInterpolate() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(1,57.8));
        expectedOutput.add(new Observation<>(7,106.8));
        expectedOutput.add(new Observation<>(11,94.5));

        TimeSeries<Double> si = TimeSeries.fromObservations(input1)
                .fullJoin(TimeSeries.fromObservations(input2),(x,y) -> x + y,interpolator,interpolator)
                .segment(6,4,false)
                .map(val -> val.stream().mapToDouble(Observation::getValue).sum());

        verifierDouble.verifyOutput(1,14,expectedOutput,si);
    }
}
