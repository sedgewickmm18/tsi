/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;


import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;

import java.io.Serializable;
import java.util.Iterator;

/**
 * Created by jmrosenk on 3/9/16.
 */
class ObservationCollectionReader<T> implements TimeSeriesReader<T>, Serializable {

    private static final long serialVersionUID = 6954318797290659068L;
    private ObservationCollection<T> observations;

    public ObservationCollectionReader(ObservationCollection<T> tsIn){
        observations = tsIn;
    }

    @Override
    public void close() {
        // TODO Auto-generated method stub

    }

    @Override
    public Iterator<Observation<T>> read(long t1, long t2,boolean inclusiveIfBoundsNotExist) {
        if(observations.isEmpty()) return Observations.<T>empty().iterator();

        long from;
        long to;

        if (inclusiveIfBoundsNotExist) {
            from = TimeSeriesReader.getFloor(observations, t1);
            to = TimeSeriesReader.getCeiling(observations, t2);
        } else {
            from = t1;
            to = t2;
        }
        return observations.subSet(from, true, to, true).iterator();
    }

    @Override
    public long start() {
        //we must do an isEmpty check since if our underlying collection is empty we will get noSuchElementException
        return (observations.isEmpty()) ? Long.MIN_VALUE : observations.first().getTimeTick();
    }

    @Override
    public long end() {
        //we must do an isEmpty check since if our underlying collection is empty we will get noSuchElementException
        return (observations.isEmpty()) ? Long.MAX_VALUE : observations.last().getTimeTick();
    }


}
