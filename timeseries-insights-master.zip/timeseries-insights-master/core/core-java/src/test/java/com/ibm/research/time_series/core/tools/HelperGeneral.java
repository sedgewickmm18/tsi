/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Properties;

/**
 * The general purpose implementation of our Helper class
 * <p>Created on 12/14/15.</p>
 *
 * @author Joshua Rosenkranz
 */
class HelperGeneral<T> implements Helper<T> {

    private static final long serialVersionUID = -2513702784486213881L;

    /**
     * gets the values between timestamps t1 and t2. If t1 is not found, it gets floor(t1). If t2 is not found, it gets ceiling(t2)
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @param tss_iter the iterator to the LinkedList that contains the TimeStampSensors that t1 and t2 will check against
     * @return a LinkedList to the resulting TimeStampSensors
     */
    @Override
    public LinkedList<Observation<T>> getValuesInRange(long t1, long t2, Iterator<Observation<T>> tss_iter) {
        LinkedList<Observation<T>> result = new LinkedList<>();

        Observation<T> previous_tss = null;

        while (tss_iter.hasNext()) {
            Observation<T> current_tss = tss_iter.next();

            if (current_tss.getTimeTick() >= t1 && current_tss.getTimeTick() < t2) {//we are within our bounds

                //we have passed the lower bound without adding to the result, so we must add the previous timestamp sensor to the result
                if (current_tss.getTimeTick() != t1 && previous_tss != null && result.isEmpty()) {
                    result.add(previous_tss);
                }

                result.add(current_tss);

            } else if (current_tss.getTimeTick() >= t2) {//we have passed our upper bound and must append the last element
                result.add(current_tss);
                break;
            }


            previous_tss = current_tss;

        }
        return result;
    }

    /**
     * gets the floor of a Observation in our NavigableCollection given a starting timestamp t1. If the floor does not exist, will return the ceiling.
     * @param set the NavigableCollection to check against
     * @param t1 the starting timestamp
     * @return a Observation that is the floor in our NavigableCollection given some t1
     */
    public Observation<T> getFloor(ObservationCollection<T> set, long t1){
        Observation<T> dummy_floor = new Observation<>(t1,(T)null);
        Observation<T> result;
        if(set.contains(dummy_floor.getTimeTick())){
            result = dummy_floor;
        }else{
            if(set.floor(dummy_floor.getTimeTick()) == null){
                result = set.ceiling(dummy_floor.getTimeTick());
            }else{
                result = set.floor(dummy_floor.getTimeTick());
            }
        }

        return result;
    }

    /**
     * gets the ceiling of a Observation in our NavigableCollection given an ending timestamp t2. If the ceiling does not exist, will return the floor.
     * @param set the NavigableCollection to check against
     * @param t2 the ending timestamp
     * @return a Observation that is the ceiling in our NavigableCollection given some t2
     */
    public Observation<T> getCeiling(ObservationCollection<T> set, long t2){
        Observation<T> dummy_ceiling = new Observation<>(t2,(T)null);
        Observation<T> result;

        Observation<T> possibleLower = set.floor(dummy_ceiling.getTimeTick());

        if(possibleLower != null && possibleLower.getTimeTick() == dummy_ceiling.getTimeTick()){
            result = dummy_ceiling;
        }else{
            if(set.ceiling(dummy_ceiling.getTimeTick()) == null){
                result = set.floor(dummy_ceiling.getTimeTick());
            }else{
                result = set.ceiling(dummy_ceiling.getTimeTick());
            }
        }

        return result;
    }


}
