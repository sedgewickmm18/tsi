/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.general;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.SequentialFileTimeSeriesReader;
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;

/**
 * <p>Created on 7/25/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ConstructorTest {

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private TimeSeriesVerifier<String> sVerifier = new StringTimeSeriesVerifier();
    private static final String GPS_SPEED_FILE = new File("").getAbsolutePath() + "/src/test/resources/gps_speed.txt";
    private static final String UNSORTED_FILE = new File("").getAbsolutePath() + "/src/test/resources/unsorted.txt";
    private static final String TS_OBJECT_FILE = new File("").getAbsolutePath() + "/src/test/resources/ts-object";

    @Before
    public void setup() {

    }

    @Test
    public void testTimeSeriesReaderConstructor() throws Exception {

        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        final Observation<Double> doubleObservation = new Observation<>(1331667629437L, 5.0);
        doubleObservation.addAnnotation("lat","40.08918920453639");
        doubleObservation.addAnnotation("lon","-88.21113291902361");
        expectedOutput.add(doubleObservation);

        TimeSeriesReader<Double> reader = new SequentialFileTimeSeriesReader<Double>(GPS_SPEED_FILE,20,false) {
            @Override
            public Observation<Double> parseLine(String line) {
                String split[] = line.split(",");
                Properties p = new Properties();
                Observation<Double> res = new Observation<>(Long.parseLong(split[0]),Double.valueOf(split[3]));
                res.addAnnotation("lat",split[1]);
                res.addAnnotation("lon",split[2]);
                return res;
            }
        };

        TimeSeries<Double> si = TimeSeries.reader(reader);

        verifier.verifyOutput(1331667629437L,1331667629437L,expectedOutput,si);
    }

    @Test
    public void testFromObservationsConstructor() throws Exception {
        MutableObservationCollection<Double> input = new MutableObservationCollection<>();
        input.add(new Observation<>(3,5.0));
        input.add(new Observation<>(10,6.0));
        input.add(new Observation<>(7,7.0));

        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(3,5.0));
        expectedOutput.add(new Observation<>(7,7.0));
        expectedOutput.add(new Observation<>(10,6.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input);

        verifier.verifyOutput(0,10,expectedOutput,si);
    }

    @Test
    public void testFromObservationsWithoutCopyConstructor() throws Exception {
        MutableObservationCollection<Double> input = new MutableObservationCollection<>();
        input.add(new Observation<>(3,5.0));
        input.add(new Observation<>(10,6.0));
        input.add(new Observation<>(7,7.0));

        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(3,5.0));
        expectedOutput.add(new Observation<>(7,7.0));
        expectedOutput.add(new Observation<>(10,6.0));

        TimeSeries<Double> si = TimeSeries.fromObservations(input,false);
        verifier.verifyOutput(0,10,expectedOutput,si);
    }

    @Test
    public void testListValueConstructor() throws Exception {

        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(0,5.0));
        expectedOutput.add(new Observation<>(1,6.0));
        expectedOutput.add(new Observation<>(2,7.0));

        TimeSeries<Double> si = TimeSeries.list(Arrays.asList(5.0,6.0,7.0));

        verifier.verifyOutput(0,2,expectedOutput,si);
    }

    @Test
    public void testListWithTimeStampConstructor() throws Exception {

        MutableObservationCollection<String> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(3,"3,5.0"));
        expectedOutput.add(new Observation<>(4,"4,6.0"));
        expectedOutput.add(new Observation<>(5,"5,7.0"));

        TimeSeries<String> ts = TimeSeries.list(
                Arrays.asList("3,5.0","4,6.0","5,7.0"),
                val -> Long.valueOf(val.split(",")[0])
        );

        sVerifier.verifySeries(expectedOutput,ts.collect());
    }

//    @Test
//    public void testPrimListValueConstructor() throws Exception {
//        ObservationCollection<Double> expectedOutput = Observations.empty();
//        expectedOutput.add(new Observation<>(0,5.0));
//        expectedOutput.add(new Observation<>(1,6.0));
//        expectedOutput.add(new Observation<>(2,7.0));
//
//        Double doubles[] = {5.0,6.0,7.0};
//
//        TimeSeries<Double> si = TimeSeries.array(doubles);
//
//        verifier.verifyOutput(0,2,expectedOutput,si);
//
//    }
//
//    @Test
//    public void testPrimListWithTimeStampConstructor() throws Exception {
//
//        ObservationCollection<String> expectedOutput = Observations.empty();
//        expectedOutput.add(new Observation<>(3,"3,5.0"));
//        expectedOutput.add(new Observation<>(4,"4,6.0"));
//        expectedOutput.add(new Observation<>(5,"5,7.0"));
//
//        String[] array = {"3,5.0","4,6.0","5,7.0"};
//
//        TimeSeries<String> ts = TimeSeries.array(array, val -> Long.valueOf(val.split(",")[0]));
//
//        sVerifier.verifySeries(expectedOutput,ts.collect());
//    }
//
//    @Test
//    public void testIteratorValueConstructor() throws Exception {
//        ObservationCollection<Double> expectedOutput = Observations.empty();
//        expectedOutput.add(new Observation<>(0,5.0));
//        expectedOutput.add(new Observation<>(1,6.0));
//        expectedOutput.add(new Observation<>(2,7.0));
//
//        TimeSeries<Double> si = TimeSeries.iterator(Arrays.asList(5.0,6.0,7.0).iterator());
//
//        verifier.verifyOutput(0,2,expectedOutput,si);
//    }
//
//    @Test
//    public void testIteratorWithTimeStampConstructor() throws Exception {
//
//        ObservationCollection<String> expectedOutput = Observations.empty();
//        expectedOutput.add(new Observation<>(3,"3,5.0"));
//        expectedOutput.add(new Observation<>(4,"4,6.0"));
//        expectedOutput.add(new Observation<>(5,"5,7.0"));
//
//        Iterator<String> iter = Arrays.asList("3,5.0","4,6.0","5,7.0").iterator();
//
//        TimeSeries<String> ts = TimeSeries.iterator(iter, val -> Long.valueOf(val.split(",")[0]));
//
//        sVerifier.verifySeries(expectedOutput,ts.collect());
//    }

    @Test
    public void testSIFactoryTextFile() throws Exception {
        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(5,1331667611538D));
        expectedOutput.add(new Observation<>(6,1331667612429D));
        expectedOutput.add(new Observation<>(7,1331667613474D));

        TimeSeries<Double> si = TimeSeries.textFile(
                GPS_SPEED_FILE,
                s -> Optional.of(Double.valueOf(s.split(",")[0]))
        );

        verifier.verifyOutput(5,7,expectedOutput,si);
    }

    @Test
    public void testUnsortedTextFile() throws Exception {
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(2,2.0)
                .add(4,2.0)
                .add(15,1.0)
                .add(17,3.0)
                .add(18,5.0)
                .result();

        TimeSeries<Double> ts = TimeSeries.textFile(
                UNSORTED_FILE,
                x -> Optional.of(new Observation<>(Long.parseLong(x.split(",")[0]),Double.parseDouble(x.split(",")[1]))),
                true
        );

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testUnsortedTextFileSkipLines() throws Exception {
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(2,2.0)
                .add(4,2.0)
                .add(17,3.0)
                .add(18,5.0)
                .result();

        TimeSeries<Double> ts = TimeSeries.textFile(
                UNSORTED_FILE,
                x -> Optional.of(new Observation<>(Long.parseLong(x.split(",")[0]),Double.parseDouble(x.split(",")[1]))),
                true,
                1
        );

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testUnsortedTextFileArtificialTimestamps() throws Exception {
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,1.0)
                .add(1,3.0)
                .add(2,2.0)
                .add(3,5.0)
                .add(4,2.0)
                .result();

        TimeSeries<Double> ts = TimeSeries.textFile(
                UNSORTED_FILE,
                s -> Optional.of(Double.valueOf(s.split(",")[1]))
        );

        verifier.verifySeries(expected,ts.collect());
    }

    @Test
    public void testUnsortedTextFileArtificialTimestampsAndSkipLines() throws Exception {
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,5.0)
                .add(1,2.0)
                .result();

        TimeSeries<Double> ts = TimeSeries.textFile(
                UNSORTED_FILE,
                s -> Optional.of(Double.valueOf(s.split(",")[1])),
                3
        );

        final ObservationCollection<Double> collect = ts.collect();

        verifier.verifySeries(expected,collect);
    }

//    @Test
//    public void testCSV() throws Exception {
//        MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
//        expectedOutput.add(new Observation<>(1331667606731L,40.08918737661366));
//        expectedOutput.add(new Observation<>(1331667607486L,40.08918737661366));
//        expectedOutput.add(new Observation<>(1331667608471L,40.08918737661366));
//
//        TimeSeries<Double> ts = TimeSeries.csv(GPS_SPEED_FILE,",",x -> Long.valueOf(x[0]),x -> Double.valueOf(x[1]));
//
//        verifier.verifyOutput(1331667606731L,1331667608471L,expectedOutput,ts);
//    }
//
//    @Test
//    public void testUnsortedCSV() throws Exception {
//        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
//                .add(2,2.0)
//                .add(4,2.0)
//                .add(15,1.0)
//                .add(17,3.0)
//                .add(18,5.0)
//                .result();
//
//        TimeSeries<Double> ts = TimeSeries.csv(
//                UNSORTED_FILE,
//                ",",
//                x -> Long.valueOf(x[0]),
//                x -> Double.valueOf(x[1]),
//                true
//        );
//
//        verifier.verifySeries(expected,ts.collect());
//    }
//
//    @Test
//    public void testUnsortedCSVSkipLines() throws Exception {
//        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
//                .add(2,2.0)
//                .add(4,2.0)
//                .add(17,3.0)
//                .add(18,5.0)
//                .result();
//
//        TimeSeries<Double> ts = TimeSeries.csv(
//                UNSORTED_FILE,
//                ",",
//                x -> Long.valueOf(x[0]),
//                x -> Double.valueOf(x[1]),
//                1,
//                true
//        );
//
//        verifier.verifySeries(expected,ts.collect());
//    }
//
//    @Test
//    public void testUnsortedCSVSkipLinesGetValuesRange() throws Exception {
//        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
//                .add(4,2.0)
//                .add(17,3.0)
//                .result();
//
//        TimeSeries<Double> ts = TimeSeries.csv(
//                UNSORTED_FILE,
//                ",",
//                x -> Long.valueOf(x[0]),
//                x -> Double.valueOf(x[1]),
//                1,
//                true
//        );
//
//        verifier.verifyOutput(5,10,expected,ts);
//    }

    @Test
    public void testObjectFile() throws Exception {
        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(0,1.0)
                .add(1,2.0)
                .add(2,3.0)
                .add(3,4.0)
                .result();

        TimeSeries.fromObservations(expected).write().objectFile(TS_OBJECT_FILE);

        TimeSeries<Double> actual = TimeSeries.objectFile(new FileInputStream(TS_OBJECT_FILE));
        verifier.verifySeries(expected,actual.collect());
    }
}
