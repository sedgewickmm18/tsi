/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.segmentation;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * <p>Created on 5/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        UnarySegmentationTest.class,
        BinarySegmentationTest.class,
        NarySegmentationTest.class
})
public class SegmentationTestSuite {
}
