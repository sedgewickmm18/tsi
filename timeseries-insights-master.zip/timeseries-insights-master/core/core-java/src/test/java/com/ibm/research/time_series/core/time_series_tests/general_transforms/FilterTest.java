/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.general_transforms;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

/**
 * <p>Created on 7/22/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FilterTest {

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();
    private ObservationCollection<Double> input1 = Observations.empty();

    @Before
    public void setUp(){
        input1 = Observations.<Double>newBuilder()
                .add(new Observation<>(1,2.0))
                .add(new Observation<>(3,3.0))
                .add(new Observation<>(7,5.0))
                .add(new Observation<>(8,8.0))
                .add(new Observation<>(10,5.0))
                .add(new Observation<>(11,9.0))
                .add(new Observation<>(12,11.0))
                .add(new Observation<>(14,1.0))
                .result();
    }

    @Test
    public void filterTest() throws Exception {
        ObservationCollection<Double> expectedOutput = Observations.<Double>newBuilder()
                .add(new Observation<>(1,2.0))
                .add(new Observation<>(3,3.0))
                .add(new Observation<>(14,1.0))
                .result();
        TimeSeries<Double> si = TimeSeries.fromObservations(input1).filter(x -> x < 5);

        verifier.verifyOutput(1,14,expectedOutput,si);
    }
}
