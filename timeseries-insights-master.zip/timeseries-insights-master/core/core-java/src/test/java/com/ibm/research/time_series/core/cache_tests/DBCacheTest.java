/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache_tests;

import com.ibm.research.time_series.core.cache.Cache;
import com.ibm.research.time_series.core.constants.CacheHit;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DummyDBCache;
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

/**
 * <p>Created on 8/17/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DBCacheTest {

    private static String path = new File("").getAbsolutePath() + "/src/test/resources/gps_speed.txt";
    private TimeSeries<String> timeSeries;
    private TimeSeriesVerifier<String> verifier = new StringTimeSeriesVerifier();

    @Before
    public void setup() {
        timeSeries = TimeSeries.textFile(
                path,
                x -> Optional.of(new Observation<>(Long.parseLong(x.split(",")[0]), x.split(",")[1])),
                false
        );
    }


    @Test
    public void testBeforeCacheHit() {
        Cache<String> cache = new DummyDBCache<>();
        timeSeries.userDefinedCache(cache,3);
        TSBuilder<String> tsBuilderSeries = Observations.newBuilder();
        tsBuilderSeries.add(1331667614466L,"40.08918737661366");
        tsBuilderSeries.add(1331667615436L,"40.08918737661366");
        tsBuilderSeries.add(1331667616431L,"40.08918737661366");
        tsBuilderSeries.add(1331667617440L,"40.08918737661366");
        tsBuilderSeries.add(1331667618459L,"40.08918737661366");
        tsBuilderSeries.add(1331667619500L,"40.08918737661366");
        tsBuilderSeries.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderCache = Observations.newBuilder();
        tsBuilderCache.add(1331667618459L,"40.08918737661366");
        tsBuilderCache.add(1331667619500L,"40.08918737661366");
        tsBuilderCache.add(1331667620447L,"40.08918737661366");

        verifier.verifySeries(tsBuilderSeries.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCache.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.NONE);

        verifier.verifySeries(tsBuilderSeries.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCache.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.BEFORE);

    }

    @Test
    public void testFullCacheHit() {
        Cache<String> cache = new DummyDBCache<>();
        timeSeries.userDefinedCache(cache,3);
        TSBuilder<String> tsBuilderSeries = Observations.newBuilder();
        tsBuilderSeries.add(1331667614466L,"40.08918737661366");
        tsBuilderSeries.add(1331667615436L,"40.08918737661366");
        tsBuilderSeries.add(1331667616431L,"40.08918737661366");
        tsBuilderSeries.add(1331667617440L,"40.08918737661366");
        tsBuilderSeries.add(1331667618459L,"40.08918737661366");
        tsBuilderSeries.add(1331667619500L,"40.08918737661366");
        tsBuilderSeries.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderCache = Observations.newBuilder();
        tsBuilderCache.add(1331667618459L,"40.08918737661366");
        tsBuilderCache.add(1331667619500L,"40.08918737661366");
        tsBuilderCache.add(1331667620447L,"40.08918737661366");

        verifier.verifySeries(tsBuilderSeries.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCache.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.NONE);

        verifier.verifySeries(tsBuilderCache.result(),timeSeries.getValues(1331667618459L,1331667620447L,true));
        verifyCache(tsBuilderCache.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.FULL);

    }

    @Test
    public void testAfterCacheHit() {
        Cache<String> cache = new DummyDBCache<>();
        timeSeries.userDefinedCache(cache,3);
        TSBuilder<String> tsBuilderSeriesBefore = Observations.newBuilder();
        tsBuilderSeriesBefore.add(1331667614466L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667615436L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667616431L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667617440L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderSeriesAfter = Observations.newBuilder();
        tsBuilderSeriesAfter.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667621506L,"40.08918737661366");


        TSBuilder<String> tsBuilderCacheBefore = Observations.newBuilder();
        tsBuilderCacheBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderCacheAfter = Observations.newBuilder();
        tsBuilderCacheAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667621506L,"40.08918737661366");

        verifier.verifySeries(tsBuilderSeriesBefore.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCacheBefore.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.NONE);

        verifier.verifySeries(tsBuilderSeriesAfter.result(),timeSeries.getValues(1331667618459L,1331667620500L,true));
        verifyCache(tsBuilderCacheAfter.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.AFTER);

    }

    @Test
    public void testMiddleCacheHit() {
        Cache<String> cache = new DummyDBCache<>();
        timeSeries.userDefinedCache(cache,3);
        TSBuilder<String> tsBuilderSeriesBefore = Observations.newBuilder();
        tsBuilderSeriesBefore.add(1331667614466L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667615436L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667616431L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667617440L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderSeriesAfter = Observations.newBuilder();
        tsBuilderSeriesAfter.add(1331667613474L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667614466L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667615436L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667616431L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667617440L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667621506L,"40.08918737661366");


        TSBuilder<String> tsBuilderCacheBefore = Observations.newBuilder();
        tsBuilderCacheBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderCacheAfter = Observations.newBuilder();
        tsBuilderCacheAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667621506L,"40.08918737661366");

        verifier.verifySeries(tsBuilderSeriesBefore.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCacheBefore.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.NONE);

        verifier.verifySeries(tsBuilderSeriesAfter.result(),timeSeries.getValues(1331667614465L,1331667620448L,true));
        verifyCache(tsBuilderCacheAfter.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.MIDDLE);

    }

    @Test
    public void testCacheHitMaxSizeNotSet() {
        Cache<String> cache = new DummyDBCache<>();
        timeSeries.userDefinedCache(cache);
        TSBuilder<String> tsBuilderSeriesBefore = Observations.newBuilder();
        tsBuilderSeriesBefore.add(1331667614466L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667615436L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667616431L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667617440L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderSeriesAfter = Observations.newBuilder();
        tsBuilderSeriesAfter.add(1331667613474L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667614466L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667615436L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667616431L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667617440L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667618459L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderSeriesAfter.add(1331667621506L,"40.08918737661366");

        TSBuilder<String> tsBuilderCacheBefore = Observations.newBuilder();
        tsBuilderCacheBefore.add(1331667614466L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667615436L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667616431L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667617440L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667618459L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheBefore.add(1331667620447L,"40.08918737661366");

        TSBuilder<String> tsBuilderCacheAfter = Observations.newBuilder();
        tsBuilderCacheAfter.add(1331667613474L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667614466L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667615436L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667616431L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667617440L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667618459L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667619500L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667620447L,"40.08918737661366");
        tsBuilderCacheAfter.add(1331667621506L,"40.08918737661366");

        verifier.verifySeries(tsBuilderSeriesBefore.result(),timeSeries.getValues(1331667614466L,1331667620447L,true));
        verifyCache(tsBuilderCacheBefore.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.NONE);

        verifier.verifySeries(tsBuilderSeriesAfter.result(),timeSeries.getValues(1331667614465L,1331667620448L,true));
        verifyCache(tsBuilderCacheAfter.result().iterator(),timeSeries.getCache());
        assertEquals(timeSeries.getMostRecentCacheHitType(), CacheHit.MIDDLE);

    }

    private void verifyCache(Iterator<Observation<String>> expected,Iterator<Observation<String>> actual) {
        List<Observation> expectedList = new ArrayList<>();
        List<Observation> actualList = new ArrayList<>();
        expected.forEachRemaining(expectedList::add);
        actual.forEachRemaining(actualList::add);

        assertEquals(expectedList.size(),actualList.size());

        for (int i = 0;i < expectedList.size();i++) {
            assertEquals(expectedList.get(i).getTimeTick(),actualList.get(i).getTimeTick());
            assertEquals(expectedList.get(i).getValue(),actualList.get(i).getValue());
        }
    }
}
