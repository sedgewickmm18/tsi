/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * This is the Helper interface.
 * <p>This interface is intended for all methods that don't add value to the inheritance model of classes, but may
 * be useful to reduceSeries code duplication and to add some quick utility for developing in the framework</p>
 * <p>Created on 12/14/15.</p>
 *
 * @author Joshua Rosenkranz
 */
interface Helper<T> extends Serializable {

    /**
     * gets the values between timestamps t1 and t2.
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @param tss_iter the iterator to the LinkedList that contains the TimeStampSensors that t1 and t2 will check against
     * @return a LinkedList to the resulting TimeStampSensors
     */
    LinkedList<Observation<T>> getValuesInRange(long t1, long t2, Iterator<Observation<T>> tss_iter);

    /**
     * gets the floor of a Observation in our NavigableSet given a starting timestamp t1.
     * @param set the NavigableSet to check against
     * @param t1 the starting timestamp
     * @return a Observation that is the floor in our NavigableSet given some t1
     */
    Observation<T> getFloor(ObservationCollection<T> set, long t1);

    /**
     * gets the ceiling of a Observation in our NavigableSet given an ending timestamp t2.
     * @param set the NavigableSet to check against
     * @param t2 the ending timestamp
     * @return a Observation that is the ceiling in our NavigableSet given some t2
     */
    Observation<T> getCeiling(ObservationCollection<T> set, long t2);
 }
