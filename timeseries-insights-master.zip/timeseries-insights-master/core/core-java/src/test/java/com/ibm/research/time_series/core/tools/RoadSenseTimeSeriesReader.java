/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;


import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Created by Joshua Rosenkranz on 1/26/16.
 */
public class RoadSenseTimeSeriesReader implements TimeSeriesReader<Double> {
    String filepath;//the path to the file
    String metric;

    Helper<Double> helper = new HelperGeneral<>();

    public RoadSenseTimeSeriesReader(String filepath, String metric){
        this.filepath = filepath;
        this.metric = metric;
    }

    @Override
    public Iterator<Observation<Double>> read(long t1, long t2,boolean inclusive) {
        String temp_file_string = "";
        try {
            temp_file_string = new Scanner(new File(filepath)).useDelimiter("\\A").next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Queue<Observation<Double>> values_as_queue = new LinkedList<Observation<Double>>();
        //assuming simple csv for now
        String ts_readings[] = temp_file_string.split(",");
        long artificial_timestamp = 1;
        for (String ts_reading : ts_readings) {
            if (ts_reading.contains(metric)) {
                String separatedValues[] = ts_reading.split(":");
                Observation<Double> tssToAdd = new Observation<Double>(artificial_timestamp, Double.valueOf(separatedValues[1]));
                values_as_queue.add(tssToAdd);
                artificial_timestamp++;
            }
        }

        return helper.getValuesInRange(t1,t2,values_as_queue.iterator()).iterator();
    }

    @Override
    public void close() {

    }
}
