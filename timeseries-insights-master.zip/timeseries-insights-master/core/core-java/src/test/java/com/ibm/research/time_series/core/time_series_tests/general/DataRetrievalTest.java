/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.general;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Iterator;
import java.util.Optional;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

/**
 * <p>Created on 7/25/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DataRetrievalTest {

    private double delta = .01;
    private static final String GPS_SPEED_FILE = new File("").getAbsolutePath() + "/src/test/resources/gps_speed.txt";
    private MutableObservationCollection<Double> input = new MutableObservationCollection<>();
    private MutableObservationCollection<Double> expectedOutput = new MutableObservationCollection<>();
    private TimeSeriesVerifier<String> sVerifier = new StringTimeSeriesVerifier();
    private TimeSeriesVerifier<Double> dVerifier = new DoubleTimeSeriesVerifier();


    @Before
    public void setup(){
        input.add(new Observation<>(3,5.0));
        input.add(new Observation<>(10,6.0));
        input.add(new Observation<>(7,7.0));

        expectedOutput.add(new Observation<>(3,5.0));
        expectedOutput.add(new Observation<>(7,7.0));
        expectedOutput.add(new Observation<>(10,6.0));
    }

    @Test
    public void poll() {
        MutableObservationCollection<Double> data = new MutableObservationCollection<>();;
        TimeSeries<Double> ts = TimeSeries.fromObservations(data,false);//must make it not copy as then adding would not do anything

        dVerifier.verifySeries(Observations.empty(),ts.poll());

        data.add(new Observation<>(1,2.0));
        data.add(new Observation<>(2,3.0));

        dVerifier.verifySeries(
                Observations.<Double>newBuilder().add(1,2.0).add(2,3.0).result(),
                ts.poll()
        );

        data.add(new Observation<>(1,1.0));
        data.add(new Observation<>(4,5.0));

        dVerifier.verifySeries(Observations.<Double>newBuilder().add(4,5.0).result(), ts.poll());
    }

    @Test
    public void testGetValuesInclusive(){
        TimeSeries<Double> si = TimeSeries.fromObservations(input);

        ObservationCollection<Double> actual = si.getValues(4,8,true);

        Iterator<Observation<Double>> expectedIter = expectedOutput.iterator();
        Iterator<Observation<Double>> actualIter = actual.iterator();

        while(expectedIter.hasNext()){
            if(!actualIter.hasNext()) fail("actual does not have enough values");
            Observation<Double> expectedCurrent = expectedIter.next();
            Observation<Double> actualCurrent = actualIter.next();

            assertEquals(expectedCurrent.getTimeTick(),actualCurrent.getTimeTick());
            assertEquals(expectedCurrent.getValue(),actualCurrent.getValue(),delta);
        }

        if(actualIter.hasNext()) fail("actual has too many values");
    }

    @Test
    public void testGetValuesNonInclusive() {
        TimeSeries<Double> ts = input.toTimeSeriesStream();

        ObservationCollection<Double> actual = ts.getValues(4, 8);

        ObservationCollection<Double> expected = Observations.<Double>newBuilder()
                .add(7,7.0)
                .result();

        dVerifier.verifySeries(expected,actual);
    }

    @Test
    public void testCollectFromNavigableCollection() {
        MutableObservationCollection<Double> expected = new MutableObservationCollection<>();

        expected.add(new Observation<>(1,1.0));
        expected.add(new Observation<>(2,2.0));
        expected.add(new Observation<>(3,3.0));
        expected.add(new Observation<>(3,3.0));

        TimeSeries<Double> tsActual = TimeSeries.fromObservations(expected);

        ObservationCollection<Double> actual = tsActual.collect();

        assertEquals(expected.size(),actual.size());

        Iterator<Observation<Double>> expectedIter = expected.iterator();

        actual.forEach(actualObs -> {
            Observation<Double> expectedObs = expectedIter.next();
            assertEquals(expectedObs.getTimeTick(),actualObs.getTimeTick());
            assertEquals(expectedObs.getValue(),actualObs.getValue(),delta);
        });

    }

    @Test
    public void testCollectFromTextFile() {
        Observation<String> expectedFirst = new Observation<>(
                1331667606731L,
                "1331667606731,40.08918737661366,-88.21121098107939,0.0"
        );

        Observation<String> expectedLast = new Observation<>(
                1331670811493L,
                "1331670811493,40.113572625616335,-88.2243701605378,1.0"
        );


        TimeSeries<String> tsFromText = TimeSeries.textFile(
                GPS_SPEED_FILE,
                s -> Optional.of(new Observation<>(Long.parseLong(s.split(",")[0]),s)),
                false
        );

        ObservationCollection<String> actual = tsFromText.collect(true);

        assertEquals(expectedFirst.getTimeTick(),actual.first().getTimeTick());
        assertEquals(expectedFirst.getValue(),actual.first().getValue());

        assertEquals(expectedLast.getTimeTick(),actual.last().getTimeTick());
        assertEquals(expectedLast.getValue(),actual.last().getValue());
    }

    @Test
    public void testCollectFromTextFileWithNonInclusiveBounds() {
        Observation<String> expectedFirst = new Observation<>(
                1331667606731L,
                "1331667606731,40.08918737661366,-88.21121098107939,0.0"
        );

        Observation<String> expectedLast = new Observation<>(
                1331670811493L,
                "1331670811493,40.113572625616335,-88.2243701605378,1.0"
        );


        TimeSeries<String> tsFromText = TimeSeries.textFile(
                GPS_SPEED_FILE,
                s -> Optional.of(new Observation<>(Long.parseLong(s.split(",")[0]),s)),
                false
        );

        ObservationCollection<String> actual = tsFromText.collect();

        assertEquals(expectedFirst.getTimeTick(),actual.first().getTimeTick());
        assertEquals(expectedFirst.getValue(),actual.first().getValue());

        assertEquals(expectedLast.getTimeTick(),actual.last().getTimeTick());
        assertEquals(expectedLast.getValue(),actual.last().getValue());
    }

    @Test
    public void testGetValuesWithZonedDateTimeMillis() {
        ZonedDateTime start = ZonedDateTime.ofInstant(Instant.ofEpochMilli(1331667610561L), ZoneId.systemDefault());
        ZonedDateTime end = ZonedDateTime.ofInstant(Instant.ofEpochMilli(1331667612429L), ZoneId.systemDefault());

        TimeSeries<String> ts = TimeSeries.textFile(
                GPS_SPEED_FILE,
                s -> Optional.of(new Observation<>(Long.parseLong(s.split(",")[0]),s)),
                false
        );

        TSBuilder<String> expected = Observations.newBuilder();
        expected.add(1331667610561L,"1331667610561,40.08918737661366,-88.21121098107939,0.0");
        expected.add(1331667611538L,"1331667611538,40.08918737661366,-88.21121098107939,0.0");
        expected.add(1331667612429L,"1331667612429,40.08918737661366,-88.21121098107939,0.0");
        final ObservationCollection<String> actual = ts.getValues(start, end, true);
        sVerifier.verifySeries(expected.result(),actual);
    }

//    @Test
//    public void testGetValuesWithZonedDateTimeSeconds() {
//        ZonedDateTime start = ZonedDateTime.ofInstant(Instant.ofEpochSecond(1331667610L), ZoneId.systemDefault());
//        ZonedDateTime end = ZonedDateTime.ofInstant(Instant.ofEpochSecond(1331667612L), ZoneId.systemDefault());
//        TimeSeries<String> ts = TimeSeries.textFile(
//                GPS_SPEED_FILE,
//                s -> Long.valueOf(s.split(",")[0].substring(0,s.split(",")[0].length() - 3))
//        );
//
//        TSBuilder<String> expected = Observations.newBuilder();
//        expected.add(1331667610L,"1331667610561,40.08918737661366,-88.21121098107939,0.0");
//        expected.add(1331667611L,"1331667611538,40.08918737661366,-88.21121098107939,0.0");
//        expected.add(1331667612L,"1331667612429,40.08918737661366,-88.21121098107939,0.0");
//        sVerifier.verifySeries(expected.result(),ts.getValues(start,end, TimeUnit.SECONDS,true));
//    }

    //this was added for issue_87 since empty time series in memory would result in noSuchElementException
    @Test
    public void testRetrieveFromEmptyTimeSeries() {
        TimeSeries<String> ts = TimeSeries.list(Collections.emptyList());

        ObservationCollection<String> expected = Observations.empty();
        ObservationCollection<String> actual = ts.collect();

        assertEquals(expected.size(),actual.size());
    }



}
