/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.transform.UnaryTransform;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.Properties;

/**
 * <p>This transform is intended for learning purposes.</p>
 *
 * <p>Each transform is some form a generic class, in this case since we are doing a UnaryTransform,
 * we expect only a T_in(type in) and T_out(type out), in this case Double - Double</p>
 *
 * <p>Generally, transforms should be written in a type safe manner where the type out can be some other type than
 * the type in. For some cases, this is not possible, but usually it is something you should consider</p>
 *
 * <p>In some cases, you may want to be more explicit about your input and output types, for instance, lets say you wanted
 * the type in to be Integer and the type out to enforce List[Integer], you may do something like this</p>
 *
 * <p>public class AddOnTransform extends UnaryTransform[Integer,List[Integer]]</p>
 *
 * <p>Created on 12/11/15.</p>
 *
 * @author Joshua Rosenkranz
 */
public class AddOneTransform extends UnaryTransform<Double,Double> {

    /**
     * You should always make a constructor for your class,
     * For this case, we only need one that will take in an output type
     */
    public AddOneTransform(){

    }

    /**
     * <p>The idea behind evaluate is you will, based on whatever transform you are trying to implement,
     * transform your linked list you get from your sensor information getter into some other linked list,
     * and return that linked list.</p>
     *
     * <p>In our case here, we are doing a simple transform where we add 1 to each value in our linked list.</p>
     *
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return the TreeSet with Observation values that have been transformed with + 1
     */
    @Override
    public ObservationCollection<Double> evaluate(long t1, long t2,boolean inclusive) {

        //using our getter method to access the time series as a linked list
        //once you have this linked list you can operate on this however you would like
        ObservationCollection<Double> time_series_in = this.getTimeSeries().getValues(t1,t2,inclusive);

        //this will be our resulting linked list since it has Observation values of type T_out
        //ObservationCollection<Double> time_series_out = Observations.empty();
        TSBuilder<Double> time_series_out = Observations.newBuilder();

        for(Observation<Double> current_tss : time_series_in){

            Double value = current_tss.getValue() + 1.0;
            Observation<Double> tss_out = new Observation<>(current_tss.getTimeTick(), value);
            time_series_out.add(tss_out);

        }

        //return your time_series_out which is of type T_out == this.type
        return time_series_out.result();
    }
}

/*
TSBuilder<Double> tsBuilder = Observations.newBuilder();
tsBuilder.add(new Observations<>(1,2.0));
ObservationCollection<Double> result = tsBuilder.result();
 */
