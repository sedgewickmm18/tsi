package com.ibm.research.time_series.core.time_series_tests.general_transforms;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TRS;
import org.junit.Before;
import org.junit.Test;

import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class WithTRSTest {
    private ObservationCollection<String> indexTimestamps;
    private ObservationCollection<String> realTimestamps;
    private TimeSeriesVerifier<String> verifier = new StringTimeSeriesVerifier();
    private ZonedDateTime offset = ZonedDateTime.of(1990,1,1,0,0,0,0, ZoneId.of("UTC"));

    private long toSecond(ZonedDateTime zdt) {
        return zdt.toInstant().getEpochSecond();
    }

    @Before
    public void setUp(){
        indexTimestamps = Observations.<String>newBuilder()
                .add(0,"2.0")
                .add(1,"3.0")
                .add(2,"4.0")
                .add(3,"5.0")
                .add(4,"6.0")
                .add(5,"7.0")
                .result();

        realTimestamps = Observations.<String>newBuilder()
                .add(toSecond(offset),"2.0")
                .add(toSecond(offset.plusMinutes(1)),"3.0")
                .add(toSecond(offset.plusMinutes(2)),"4.0")
                .add(toSecond(offset.plusMinutes(3)),"5.0")
                .add(toSecond(offset.plusMinutes(4)),"6.0")
                .add(toSecond(offset.plusMinutes(5)),"7.0")
                .result();

    }

    @Test
    public void testSetTRSFromIndexThenWithTRS() {
        TRS ti = TRS.of(Duration.ofMinutes(1), offset);
        TimeSeries<String> ts = indexTimestamps.toTimeSeriesStream(ti).withTRS(TRS.of(Duration.ofMinutes(2), offset));

        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"2.0")
                .add(0,"3.0")
                .add(1,"4.0")
                .add(1,"5.0")
                .add(2,"6.0")
                .add(2,"7.0")
                .result();
        verifier.verifySeries(expected, ts.collect());
    }

    @Test
    public void testSetIndex() {
        TRS ti = TRS.of(Duration.ofMinutes(1), offset);
        TimeSeries<String> ts = TimeSeries.fromObservations(indexTimestamps, ti);
        verifier.verifySeries(indexTimestamps,ts.collect());
    }

    @Test
    public void testWithIndex() {
        TRS ti = TRS.of(Duration.ofMinutes(1), offset);
        TimeSeries<String> ts = TimeSeries.fromObservations(realTimestamps,TRS.of(Duration.ofSeconds(1))).withTRS(ti);

        verifier.verifySeries(indexTimestamps,ts.collect());
    }

    @Test
    public void testGetValuesZDTSetIndex() {
        TRS ti = TRS.of(Duration.ofMinutes(1), offset);
        TimeSeries<String> ts = TimeSeries.fromObservations(indexTimestamps, ti);

        verifier.verifySeries(indexTimestamps,ts.getValues(offset,offset.plusMinutes(5)));
    }

    @Test
    public void testGetValuesZDTWithIndex() {
        TRS ti = TRS.of(Duration.ofMinutes(1), offset);
        TimeSeries<String> ts = TimeSeries.fromObservations(realTimestamps,TRS.of(Duration.ofSeconds(1))).withTRS(ti);

        verifier.verifySeries(indexTimestamps,ts.getValues(offset,offset.plusMinutes(5)));
    }

    @Test
    public void testWithIndexAndSegmentByTime() {
        TimeSeries<String> ts = TimeSeries.fromObservations(realTimestamps,TRS.of(Duration.ofSeconds(1)))
                .withTRS(TRS.of(Duration.ofMinutes(1), offset))
                .segmentByTime(2,2)
                .map(x -> x.toString());

        ts.print();

        TimeSeries<String> expected = TimeSeries.fromObservations(indexTimestamps,TRS.of(Duration.ofMinutes(1),ZonedDateTime.of(1990,1,1,0,0,0,0,ZoneId.of("UTC")))).segmentByTime(2,2).map(x -> x.toString());

        expected.print();
        verifier.verifySeries(expected.collect(),ts.collect());
    }
}
