/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.time_series_tests.join;

import com.ibm.research.time_series.core.core_transforms.map.MapTransformers;
import com.ibm.research.time_series.core.functions.Interpolator;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import org.junit.Before;
import org.junit.Test;
import com.ibm.research.time_series.core.tools.DoubleListTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.DoubleTimeSeriesVerifier;
import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;

import java.util.Arrays;
import java.util.List;

/**
 * <p>Created on 8/5/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class InnerJoinTest {
    private TimeSeriesVerifier<List<Double>> verifierList = new DoubleListTimeSeriesVerifier();
    private TimeSeriesVerifier<Double> verifierDouble = new DoubleTimeSeriesVerifier();

    private MutableObservationCollection<Double> input1 = new MutableObservationCollection<>();
    private MutableObservationCollection<Double> input2 = new MutableObservationCollection<>();
    private Interpolator<Double> interpolator = (history, future, timestamp) -> {
        if(history.isEmpty()) return future.first().getValue();
        if(future.isEmpty()) return history.first().getValue();
        return history.first().getValue() + (future.first().getValue() - history.first().getValue()) * ((timestamp - (double)history.first().getTimeTick()) / ((double)future.first().getTimeTick() - (double)history.first().getTimeTick()));
    };

    private BinaryTransform<Double,Double,List<Double>> binaryTransform = MapTransformers.binaryMap((x1, x2) -> Arrays.asList(x1,x2));

    @Before
    public void setUp(){
        input1.add(new Observation<>(1,2.0));
        input1.add(new Observation<>(3,3.0));
        input1.add(new Observation<>(7,5.0));
        input1.add(new Observation<>(8,8.0));
        input1.add(new Observation<>(10,5.0));
        input1.add(new Observation<>(11,9.0));
        input1.add(new Observation<>(12,11.0));
        input1.add(new Observation<>(14,1.0));

        input2.add(new Observation<>(2,3.0));
        input2.add(new Observation<>(3,5.0));
        input2.add(new Observation<>(4,9.0));
        input2.add(new Observation<>(9,6.0));
        input2.add(new Observation<>(10,13.0));
        input2.add(new Observation<>(11,14.0));
        input2.add(new Observation<>(13,17.0));
        input2.add(new Observation<>(14,21.0));
    }

    @Test
    public void testInnerJoin() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1)
                .innerJoin(TimeSeries.fromObservations(input2), (x1, x2) -> Arrays.asList(x1,x2));
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }

    @Test
    public void testInnerJoinMap() throws Exception {
        MutableObservationCollection<List<Double>> expectedOutput = new MutableObservationCollection<>();
        expectedOutput.add(new Observation<>(3,Arrays.asList(3.0,5.0)));
        expectedOutput.add(new Observation<>(10,Arrays.asList(5.0,13.0)));
        expectedOutput.add(new Observation<>(11,Arrays.asList(9.0,14.0)));
        expectedOutput.add(new Observation<>(14,Arrays.asList(1.0,21.0)));

        TimeSeries<List<Double>> si = TimeSeries.fromObservations(input1)
                .innerJoin(TimeSeries.fromObservations(input2), (x, y) -> Arrays.asList(x,y));
        verifierList.verifyOutput(1,14,expectedOutput,si);
    }
}
