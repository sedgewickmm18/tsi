///*
// * ************* Begin Copyright - Do not add comments here **************
// *  * Licensed Materials - Property of IBM
// *  *
// *  *   OCO Source Materials
// *  *
// *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
// *  *
// *  * The source code for this program is not published or other-
// *  * wise divested of its trade secrets, irrespective of what has
// *  * been deposited with the U.S. Copyright Office.
// *  ***************************** End Copyright ***************************
// */
//
//package com.ibm.research.time_series.core.time_series_tests.forecast;
//
//import com.ibm.research.time_series.core.constants.BlockMode;
//import com.ibm.research.time_series.core.constants.ForecastConsts;
//import com.ibm.research.time_series.core.constants.ForecastModelUpdate;
//import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel;
//import com.ibm.research.time_series.core.observation.Observation;
//import com.ibm.research.time_series.core.timeseries.TimeSeries;
//import com.ibm.research.time_series.core.tools.DummyForecastor;
//import com.ibm.research.time_series.core.tools.StringTimeSeriesVerifier;
//import com.ibm.research.time_series.core.tools.TimeSeriesVerifier;
//import com.ibm.research.time_series.core.utils.ObservationCollection;
//import com.ibm.research.time_series.core.utils.Observations;
//import com.ibm.research.time_series.core.utils.TSBuilder;
//import org.junit.Before;
//import org.junit.Test;
//
//import java.util.Properties;
//
///**
// * <p>Created on 8/16/17.</p>
// *
// * @author Joshua Rosenkranz
// */
//public class ForecastTest {
//    private ObservationCollection<String> data;
//    private ObservationCollection<String> data2;
//    private TimeSeriesVerifier<String> verifier = new StringTimeSeriesVerifier();
//    private ObservationForecastingModel<String> fm = new DummyForecastor(4);
//
//    @Before
//    public void setUp(){
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//        tsBuilder.add(1,"2.0");
//        tsBuilder.add(2,"3.0");
//        tsBuilder.add(3,"4.0");
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        data = tsBuilder.result();
//
//        tsBuilder.clear();
//        tsBuilder.add(1,"2.0");
//        tsBuilder.add(2,"3.0");
//        tsBuilder.add(3,"4.0");
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        tsBuilder.add(7,"8.0");
//        tsBuilder.add(8,"9.0");
//        tsBuilder.add(9,"10.0");
//        tsBuilder.add(10,"11.0");
//        tsBuilder.add(11,"12.0");
//        tsBuilder.add(12,"13.0");
//        tsBuilder.add(13,"14.0");
//        tsBuilder.add(14,"15.0");
//        tsBuilder.add(15,"16.0");
//        tsBuilder.add(16,"17.0");
//        data2 = tsBuilder.result();
//    }
//
//    @Test
//    public void testForecastNotInitializedNonBlocking() throws Exception {
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        ObservationCollection<String> expected = tsBuilder.result();
//
//        TimeSeries<String> ts = TimeSeries.fromObservations(data);
//        ts.forecast(fm);
//        ObservationCollection<String> actual = ts.getValues(4,8);
//
//        verifier.verifySeries(expected,actual);
//
//    }
//
//    @Test
//    public void testForecastInitializedNonBlocking() throws Exception {
//        Properties p = new Properties();
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR,Double.NEGATIVE_INFINITY);
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING,Double.POSITIVE_INFINITY);
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//        tsBuilder.add(2,"3.0");
//        tsBuilder.add(3,"4.0");
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        tsBuilder.add(new Observation<>(7,"7.0",p));
//        tsBuilder.add(new Observation<>(8,"7.0",p));
//        ObservationCollection<String> expected = tsBuilder.result();
//
//        TimeSeries<String> ts = TimeSeries.fromObservations(data);
//        ts.forecast(fm);
//        ObservationCollection<String> actual = ts.getValues(2,8);
//
//        verifier.verifySeries(expected,actual);
//
//    }
//
//    @Test
//    public void testForecastInitializedBlocking() throws Exception {
//        Properties p = new Properties();
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR,Double.NEGATIVE_INFINITY);
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING,Double.POSITIVE_INFINITY);
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//        tsBuilder.add(2,"3.0");
//        tsBuilder.add(3,"4.0");
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        tsBuilder.add(new Observation<>(7,"7.0",p));
//        tsBuilder.add(new Observation<>(8,"7.0",p));
//        ObservationCollection<String> expected = tsBuilder.result();
//
//        TimeSeries<String> ts = TimeSeries.fromObservations(data);
//        ts.forecast(fm);
//        ObservationCollection<String> actual = ts.getValues(2,8, BlockMode.BLOCK);
//
//        verifier.verifySeries(expected,actual);
//    }
//
//    @Test
//    public void testForecastInitializedConditionalBlockingMet() throws Exception {
//
//        Properties p = new Properties();
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR,2.0);
//        p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING,4.0);
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//        tsBuilder.add(2,"3.0");
//        tsBuilder.add(3,"4.0");
//        tsBuilder.add(4,"5.0");
//        tsBuilder.add(5,"6.0");
//        tsBuilder.add(6,"7.0");
//        tsBuilder.add(7,"8.0");
//        tsBuilder.add(8,"9.0");
//        tsBuilder.add(9,"10.0");
//        tsBuilder.add(10,"11.0");
//        tsBuilder.add(11,"12.0");
//        tsBuilder.add(12,"13.0");
//        tsBuilder.add(13,"14.0");
//        tsBuilder.add(14,"15.0");
//        tsBuilder.add(15,"16.0");
//        tsBuilder.add(16,"17.0");
//        tsBuilder.add(new Observation<>(17,"17.0",p));
//        tsBuilder.add(new Observation<>(18,"17.0",p));
//        tsBuilder.add(new Observation<>(19,"17.0",p));
//        tsBuilder.add(new Observation<>(20,"17.0",p));
//        ObservationCollection<String> expected = tsBuilder.result();
//
//        TimeSeries<String> ts = TimeSeries.fromObservations(data2);
//        ts.forecast(fm,ForecastModelUpdate.CONTINUOUS,1.0,.4);
//        ObservationCollection<String> actual = ts.getValues(2,20, BlockMode.CONDITIONAL_BLOCK);
//
//        verifier.verifySeries(expected,actual);
//    }
//}
