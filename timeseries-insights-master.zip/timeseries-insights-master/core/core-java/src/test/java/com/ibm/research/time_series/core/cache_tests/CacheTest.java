/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.cache_tests;

import com.ibm.research.time_series.core.constants.CacheHit;
import com.ibm.research.time_series.core.core_transforms.join.JoinTransformers;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.tools.*;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.tools.TestHelper;
import com.ibm.research.time_series.core.utils.MutableObservationCollection;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import org.junit.Test;
import com.ibm.research.time_series.core.transform.BinaryTransform;
import com.ibm.research.time_series.core.transform.NaryTransform;
import com.ibm.research.time_series.core.transform.UnaryTransform;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;

/**
 * This test bucket is intended to test caching in our framework.
 * Created by Joshua Rosenkranz on 12/4/15.
 */
public class CacheTest {
    private TestHelper testHelper = new TestHelper();

    private TimeSeriesVerifier<Double> verifier = new DoubleTimeSeriesVerifier();

    @Test
    public void testNeverCache() {

        TimeSeriesReader<Double> reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeries<Double> ts = TimeSeries.reader(reader);

        ts.getValues(5,9);
        MutableObservationCollection<Double> cacheActual = new MutableObservationCollection<>();
        ts.getCache().forEachRemaining(cacheActual::add);

        verifier.verifySeries(Observations.empty(),cacheActual);
        assertEquals(ts.getMaximumCacheSize(),0);

    }

    @Test
    public void testUncache() {
        ObservationCollection<Double> cacheExpected = Observations.<Double>newBuilder()
                .add(5,1.0)
                .add(6,2.4)
                .add(7,3.1)
                .add(8,10.0)
                .add(9,4.0)
                .result();

        TimeSeriesReader<Double> reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeries<Double> ts = TimeSeries.reader(reader).cache();

        ts.getValues(5,9);
        MutableObservationCollection<Double> cacheActual = new MutableObservationCollection<>();
        ts.getCache().forEachRemaining(cacheActual::add);

        verifier.verifySeries(cacheExpected,cacheActual);

        ts.uncache();

        cacheActual = new MutableObservationCollection<>();
        ts.getCache().forEachRemaining(cacheActual::add);
        verifier.verifySeries(cacheActual,Observations.empty());
        assertEquals(ts.getMaximumCacheSize(),0);
    }


    /**
     * This variation is testing that with a unary ntransform, if we are to get a full cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testUnaryFullCacheHit(){
        Double expected_value1[] = {-1.6,1.4,.7,6.9,-6.0};
        long expected_timestamp1[] = {5,6,7,8,9};

        Double expected_cache_value1[] = {.7,6.9,-6.0};
        long expected_cache_timestamp1[] = {7,8,9};

        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());

        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();

        TimeSeries<Double> accelerationTS = TimeSeries.reader(ts_reader)
                .transform(diff_doub_to_double);

        accelerationTS.cache(3);

        //testing that our intial cache and values are correct
        testHelper.checkEqualsDouble(expected_value1,accelerationTS.getValues(5,9).iterator(),expected_timestamp1);
        testHelper.checkEqualsDouble(expected_cache_value1,accelerationTS.getCache(),expected_cache_timestamp1);


        Double expected_value2[] = {.7,6.9,-6.0};
        long expected_timestamp2[] = {7,8,9};

        Double expected_cache_value2[] = {.7,6.9,-6.0};
        long expected_cache_timestamp2[] = {7,8,9};

        //testing that we hit our cache
        testHelper.checkEqualsDouble(expected_value2,accelerationTS.getValues(7,9).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,accelerationTS.getCache(),expected_cache_timestamp2);

        //test if we went down the path and indeed had a cache hit
        assertEquals(accelerationTS.getMostRecentCacheHitType(),CacheHit.FULL);
    }

    /**
     * This variation is testing that with a unary ntransform, if we are to get a middle cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testUnaryMiddleCacheHit(){
        Double expected_value1[] = {-1.6,1.4,.7,6.9,-6.0};
        long expected_timestamp1[] = {5,6,7,8,9};

        Double expected_cache_value1[] = {.7,6.9,-6.0};
        long expected_cache_timestamp1[] = {7,8,9};

        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());

        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();

        TimeSeries<Double> accelerationTS = TimeSeries.reader(ts_reader)
                .transform(diff_doub_to_double);

        accelerationTS.cache(3);

        //testing that our intial cache and values are correct
        testHelper.checkEqualsDouble(expected_value1,accelerationTS.getValues(5,9).iterator(),expected_timestamp1);
        testHelper.checkEqualsDouble(expected_cache_value1,accelerationTS.getCache(),expected_cache_timestamp1);


        Double expected_value2[] = {2.4,-1.9,-1.6,1.4,.7,6.9,-6.0,17.2};
        long expected_timestamp2[] = {3,4,5,6,7,8,9,10};

        Double expected_cache_value2[] = {6.9,-6.0,17.2};
        long expected_cache_timestamp2[] = {8,9,10};

        //testing that we hit our cache
        testHelper.checkEqualsDouble(expected_value2,accelerationTS.getValues(3,10).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,accelerationTS.getCache(),expected_cache_timestamp2);

        //test if we went down the path and indeed had a cache hit
        assertEquals(accelerationTS.getMostRecentCacheHitType(),CacheHit.MIDDLE);

    }

    /**
     * This variation is testing that with a unary ntransform, if we are to get a before cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testUnaryBeforeCacheHit(){
        Double expected_value1[] = {-1.6,1.4,.7,6.9,-6.0};
        long expected_timestamp1[] = {5,6,7,8,9};

        Double expected_cache_value1[] = {.7,6.9,-6.0};
        long expected_cache_timestamp1[] = {7,8,9};

        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());

        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();

        TimeSeries<Double> accelerationTS = TimeSeries.reader(ts_reader)
                .transform(diff_doub_to_double);

        accelerationTS.cache(3);

        ObservationCollection<Double> res = accelerationTS.getValues(5,9);
        res.size();

        //testing that our intial cache and values are correct
        testHelper.checkEqualsDouble(expected_value1,accelerationTS.getValues(5,9).iterator(),expected_timestamp1);
        testHelper.checkEqualsDouble(expected_cache_value1,accelerationTS.getCache(),expected_cache_timestamp1);

        Double expected_value2[] = {2.4,-1.9,-1.6,1.4,.7,6.9};
        long expected_timestamp2[] = {3,4,5,6,7,8};

        Double expected_cache_value2[] = {.7,6.9,-6.0};
        long expected_cache_timestamp2[] = {7,8,9};

        //testing that we hit our cache
        testHelper.checkEqualsDouble(expected_value2,accelerationTS.getValues(3,8).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,accelerationTS.getCache(),expected_cache_timestamp2);

        //test if we went down the path and indeed had a cache hit
        assertEquals(accelerationTS.getMostRecentCacheHitType(),CacheHit.BEFORE);
    }

    /**
     * This variation is testing that with a unary ntransform, if we are to get an after cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testUnaryAfterCacheHit(){
        Double expected_value1[] = {-1.6,1.4,.7,6.9,-6.0};
        long expected_timestamp1[] = {5,6,7,8,9};

        Double expected_cache_value1[] = {.7,6.9,-6.0};
        long expected_cache_timestamp1[] = {7,8,9};

        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());

        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();

        TimeSeries<Double> accelerationTS = TimeSeries.reader(ts_reader)
                .transform(diff_doub_to_double);

        accelerationTS.cache(3);

        //testing that our intial cache and values are correct
        testHelper.checkEqualsDouble(expected_value1,accelerationTS.getValues(5,9).iterator(),expected_timestamp1);
        testHelper.checkEqualsDouble(expected_cache_value1,accelerationTS.getCache(),expected_cache_timestamp1);

        Double expected_value2[] = {.7,6.9,-6.0,17.2};
        long expected_timestamp2[] = {7,8,9,10};

        Double expected_cache_value2[] = {6.9,-6.0,17.2};
        long expected_cache_timestamp2[] = {8,9,10};

        //testing that we hit our cache
        testHelper.checkEqualsDouble(expected_value2,accelerationTS.getValues(7,10).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,accelerationTS.getCache(),expected_cache_timestamp2);

        //test if we went down the path and indeed had a cache hit
        assertEquals(accelerationTS.getMostRecentCacheHitType(),CacheHit.AFTER);

    }

    /**
     * This variation is testing that with a binary ntransform, if we are to get a full cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testBinaryFullCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,7).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,7).size());

        Double expected_value2[] = {-.055,-.488};
        long expected_timestamp2[] = {4,6};

        Double expected_cache_value2[] = {-.055,-.488};
        long expected_cache_timestamp2[] = {4,6};

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,6).iterator(),expected_timestamp2);//we can compute 6 even though we didnt ask for 6-8, since its in the cache
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.FULL);

        assertEquals(expected_value2.length,correlationTS.getValues(4,6).size());

        //check size of cache here
    }

    /**
     * This variation is testing that with a binary ntransform, if we are to get a middle cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testBinaryMiddleCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,6).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,6).size());

        Double expected_value2[] = {.887,-.055,-.488,-.249};
        long expected_timestamp2[] = {2,4,6,8};

        Double expected_cache_value2[] = {-.055,-.488,-.249};
        long expected_cache_timestamp2[] = {4,6,8};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(2,8).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.MIDDLE);

        assertEquals(expected_value2.length,correlationTS.getValues(2,8).size());


    }

    /**
     * This variation is testing that with a binary ntransform, if we are to get a before cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testBinaryBeforeCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,7).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,7).size());

        Double expected_value2[] = {.887,-.055,-.488};
        long expected_timestamp2[] = {2,4,6};

        Double expected_cache_value2[] = {.887,-.055,-.488};
        long expected_cache_timestamp2[] = {2,4,6};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(2,6).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.BEFORE);

        assertEquals(expected_value2.length,correlationTS.getValues(2,6).size());


    }

    /**
     * This variation is testing that with a binary ntransform, if we are to get an after cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testBinaryAfterCacheHit(){

        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,7).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,7).size());

        Double expected_value2[] = {-.488,-.249};
        long expected_timestamp2[] = {6,8};

        Double expected_cache_value2[] = {-.055,-.488,-.249};
        long expected_cache_timestamp2[] = {4,6,8};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(6,8).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.AFTER);

        assertEquals(expected_value2.length,correlationTS.getValues(6,8).size());


    }

    /**
     * This variation is testing that with a ntransform that contains a step function, if we are to get an after cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testStepFunctionAfterCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,6).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,6).size());

        Double expected_value2[] = {-.055,-.488};
        long expected_timestamp2[] = {4,6};

        Double expected_cache_value2[] = {-.055,-.488};
        long expected_cache_timestamp2[] = {4,6};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(5,7,true).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.AFTER);

        assertEquals(expected_value2.length,correlationTS.getValues(5,7,true).size());


    }

    /**
     * This variation is testing that with a ntransform that contains a step function, if we are to get a before cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testStepFunctionBeforeCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(4,6).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,6).size());

        Double expected_value2[] = {.887,-.055,-.488};
        long expected_timestamp2[] = {2,4,6};

        Double expected_cache_value2[] = {.887,-.055,-.488};
        long expected_cache_timestamp2[] = {2,4,6};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(2,6).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.BEFORE);

        assertEquals(expected_value2.length,correlationTS.getValues(2,6).size());


    }

    /**
     * This variation is testing that with a ntransform that contains a step function, if we are to get a full cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testStepFunctionFullCacheHit(){
        Double expected_value[] = {.887,-.055,-.488,-.249};
        long expected_timestamp[] = {2,4,6,8};

        Double expected_cache_value1[] = {.887,-.055,-.488,-.249};
        long expected_cache_timestamp1[] = {2,4,6,8};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(4);

        testHelper.checkEqualsDouble(expected_value,correlationTS.getValues(2,8).iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(2,8).size());

        Double expected_value2[] = {.887,-.055,-.488};
        long expected_timestamp2[] = {2,4,6};

        Double expected_cache_value2[] = {.887,-.055,-.488,-.249};
        long expected_cache_timestamp2[] = {2,4,6,8};

        testHelper.checkEqualsDouble(expected_value2,correlationTS.getValues(3,5,true).iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.FULL);

        assertEquals(expected_value2.length,correlationTS.getValues(3,5,true).size());


    }

    /**
     * This variation is testing that with a ntransform that contains a step function, if we are to get a middle cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     *  3: the values start on the correct boundary(cache issue 1 comment 1)
     */
    @Test
    public void testStepFunctionMiddleCacheHit(){
        Double expected_value[] = {-.055,-.488};
        long expected_timestamp[] = {4,6};

        Double expected_cache_value1[] = {-.055,-.488};
        long expected_cache_timestamp1[] = {4,6};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);

        TimeSeries<Double> correlationTS = TimeSeries.reader(ts_reader_x)
                .transform(TimeSeries.reader(ts_reader_y), corr);

        correlationTS.cache(3);

        ObservationCollection<Double> ts = correlationTS.getValues(4,6,true);

        testHelper.checkEqualsDouble(expected_value,ts.iterator(),expected_timestamp);
        testHelper.checkEqualsDouble(expected_cache_value1,correlationTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value.length,correlationTS.getValues(4,6,true).size());

        Double expected_value2[] = {.945,.998,-.055,-.487,-.248};
        long expected_timestamp2[] = {1,3,4,6,8};

        Double expected_cache_value2[] = {-.055,-.487,-.248};
        long expected_cache_timestamp2[] = {4,6,8};

        ts = correlationTS.getValues(1,9);

        testHelper.checkEqualsDouble(expected_value2,ts.iterator(),expected_timestamp2);
        testHelper.checkEqualsDouble(expected_cache_value2,correlationTS.getCache(),expected_cache_timestamp2);

        assertEquals(correlationTS.getMostRecentCacheHitType(),CacheHit.MIDDLE);

        assertEquals(expected_value2.length,correlationTS.getValues(1,9,true).size());


    }

    /**
     * This variation is testing that with a Nary ntransform, if we are to get a full cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testNaryFullCacheHit(){

        Double expected_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_timestamp1[] = {2,3,4};

        Double expected_cache_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp1[] = {2,3,4};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
                Collections.emptyList(),
                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
        );

        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();

        si_array.add(TimeSeries.reader(ts_reader_y));

        TimeSeries<List<Double>> joinTS = TimeSeries.reader(ts_reader_x).transform(si_array, join);

        joinTS.cache(3);

        Iterator<Observation<List<Double>>> join_actual = joinTS.getValues(2,4,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value1,join_actual,expected_timestamp1);
        testHelper.checkEqualsDoubleArray(expected_cache_value1,joinTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value1.length,joinTS.getValues(2,4,true).size());


        Double expected_value2[][] = {{4.5,9.1},{2.6,7.1}};
        long expected_timestamp2[] = {3,4};

        Double expected_cache_value2[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp2[] = {2,3,4};

        join_actual = joinTS.getValues(3,4,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value2,join_actual,expected_timestamp2);
        testHelper.checkEqualsDoubleArray(expected_cache_value2,joinTS.getCache(),expected_cache_timestamp2);

        assertEquals(joinTS.getMostRecentCacheHitType(),CacheHit.FULL);

        assertEquals(expected_value2.length,joinTS.getValues(3,4,true).size());


    }

    /**
     * This variation is testing that with a Nary ntransform, if we are to get a before cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testNaryBeforeCacheHit(){

        Double expected_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_timestamp1[] = {2,3,4};

        Double expected_cache_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp1[] = {2,3,4};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
                Collections.emptyList(),
                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
        );

        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();

        si_array.add(TimeSeries.reader(ts_reader_y));

        TimeSeries<List<Double>> joinTS = TimeSeries.reader(ts_reader_x).transform(si_array, join);

        joinTS.cache(3);

        Iterator<Observation<List<Double>>> join_actual = joinTS.getValues(2,4,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value1,join_actual,expected_timestamp1);
        testHelper.checkEqualsDoubleArray(expected_cache_value1,joinTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value1.length,joinTS.getValues(2,4,true).size());


        Double expected_value2[][] = {{1.2,4.0},{2.1,3.6},{4.5,9.1}};
        long expected_timestamp2[] = {1,2,3};

        Double expected_cache_value2[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp2[] = {2,3,4};

        join_actual = joinTS.getValues(1,3,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value2,join_actual,expected_timestamp2);
        testHelper.checkEqualsDoubleArray(expected_cache_value2,joinTS.getCache(),expected_cache_timestamp2);

        assertEquals(joinTS.getMostRecentCacheHitType(),CacheHit.BEFORE);

        assertEquals(expected_value2.length,joinTS.getValues(1,3,true).size());


    }

    /**
     * This variation is testing that with a Nary ntransform, if we are to get an after cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testNaryAfterCacheHit(){

        Double expected_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_timestamp1[] = {2,3,4};

        Double expected_cache_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp1[] = {2,3,4};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
                Collections.emptyList(),
                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
        );

        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();

        si_array.add(TimeSeries.reader(ts_reader_y));

        TimeSeries<List<Double>> joinTS = TimeSeries.reader(ts_reader_x).transform(si_array, join);

        joinTS.cache(3);

        Iterator<Observation<List<Double>>> join_actual = joinTS.getValues(2,4,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value1,join_actual,expected_timestamp1);
        testHelper.checkEqualsDoubleArray(expected_cache_value1,joinTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value1.length,joinTS.getValues(2,4,true).size());


        Double expected_value2[][] = {{4.5,9.1},{2.6,7.1},{1.0,5.1},{2.4,1.4}};
        long expected_timestamp2[] = {3,4,5,6};

        Double expected_cache_value2[][] = {{2.6,7.1},{1.0,5.1},{2.4,1.4}};
        long expected_cache_timestamp2[] = {4,5,6};

        join_actual = joinTS.getValues(3,6,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value2,join_actual,expected_timestamp2);
        testHelper.checkEqualsDoubleArray(expected_cache_value2,joinTS.getCache(),expected_cache_timestamp2);

        assertEquals(joinTS.getMostRecentCacheHitType(),CacheHit.AFTER);

        assertEquals(expected_value2.length,joinTS.getValues(3,6,true).size());


    }

    /**
     * This variation is testing that with a Nary ntransform, if we are to get a middle cache hit:
     *  1: our path is correctly taken
     *  2: the values received are correct
     */
    @Test
    public void testNaryMiddleCacheHit(){

        Double expected_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_timestamp1[] = {2,3,4};

        Double expected_cache_value1[][] = {{2.1,3.6},{4.5,9.1},{2.6,7.1}};
        long expected_cache_timestamp1[] = {2,3,4};

        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());

        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
                Collections.emptyList(),
                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
        );

        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();

        si_array.add(TimeSeries.reader(ts_reader_y));

        TimeSeries<List<Double>> joinTS = TimeSeries.reader(ts_reader_x).transform(si_array, join);

        joinTS.cache(3);

        Iterator<Observation<List<Double>>> join_actual = joinTS.getValues(2,4).iterator();

        testHelper.checkEqualsDoubleArray(expected_value1,join_actual,expected_timestamp1);
        testHelper.checkEqualsDoubleArray(expected_cache_value1,joinTS.getCache(),expected_cache_timestamp1);

        assertEquals(expected_value1.length,joinTS.getValues(2,4,true).size());


        Double expected_value2[][] = {{1.2,4.0},{2.1,3.6},{4.5,9.1},{2.6,7.1},{1.0,5.1},{2.4,1.4}};
        long expected_timestamp2[] = {1,2,3,4,5,6};

        Double expected_cache_value2[][] = {{2.6,7.1},{1.0,5.1},{2.4,1.4}};
        long expected_cache_timestamp2[] = {4,5,6};

        join_actual = joinTS.getValues(1,6,true).iterator();

        testHelper.checkEqualsDoubleArray(expected_value2,join_actual,expected_timestamp2);
        testHelper.checkEqualsDoubleArray(expected_cache_value2,joinTS.getCache(),expected_cache_timestamp2);

        assertEquals(joinTS.getMostRecentCacheHitType(), CacheHit.MIDDLE);

        assertEquals(expected_value2.length,joinTS.getValues(1,6,true).size());


    }

    /**
     * this variation is testing that cache size propagates with unary ntransform sensor information
     * when propagate is true
     */
//    @Test
//    public void testCacheSizePropagateUnary(){
//        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//
//        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();
//
//        TimeSeries<Double> physTS = TimeSeries.reader(ts_reader);
//
//        TimeSeries<Double> derTS = physTS.transform(diff_doub_to_double);
//
//        derTS.cache(30,true);
//
//        assertEquals(30,physTS.getMaximumCacheSize());
//        assertEquals(30,derTS.getMaximumCacheSize());
//
//    }

    /**
     * this variation is testing that cache size propagates with binary ntransform sensor information
     * when propagate is true
     */
//    @Test
//    public void testCacheSizePropagateBinary(){
//        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());
//
//        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);
//
//        TimeSeries<Double> x_ts = TimeSeries.reader(ts_reader_x);
//        TimeSeries<Double> y_ts = TimeSeries.reader(ts_reader_y);
//
//        TimeSeries<Double> correlationTS = x_ts.transform(y_ts, corr);
//
//        correlationTS.setCacheSize(25,true);
//
//        assertEquals(25,x_ts.getMaximumCacheSize());
//        assertEquals(25,y_ts.getMaximumCacheSize());
//        assertEquals(25,correlationTS.getMaximumCacheSize());
//    }
//
//    /**
//     * this variation is testing that cache size propagates with nary ntransform sensor information
//     * when propagate is true
//     */
//    @Test
//    public void testCacheSizePropagateNary(){
//        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());
//
//        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
//                Collections.emptyList(),
//                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
//        );
//
//        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();
//
//        si_array.add(TimeSeries.reader(ts_reader_y));
//
//        TimeSeries<Double> rootTS = TimeSeries.reader(ts_reader_x);
//
//        TimeSeries<List<Double>> joinTS = rootTS.transform(si_array, join);
//
//        joinTS.setCacheSize(3,true);
//
//        assertEquals(3,rootTS.getMaximumCacheSize());
//        assertEquals(3,si_array.get(0).getMaximumCacheSize());
//        assertEquals(3,joinTS.getMaximumCacheSize());
//
//    }
//
//    /**
//     * this variation is testing that cache size doesn't propagate with unary ntransform sensor information
//     * when propagate is false
//     */
//    @Test
//    public void testCacheSizeNoPropagateUnary(){
//        TimeSeriesReader<Double> ts_reader = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//
//        UnaryTransform<Double,Double> diff_doub_to_double = new DifferenceTransform();
//
//        TimeSeries<Double> physTS = TimeSeries.reader(ts_reader);
//
//        TimeSeries<Double> derTS = physTS.transform(diff_doub_to_double);
//
//        derTS.setCacheSize(30,false);
//
//        assertEquals(Integer.MAX_VALUE,physTS.getMaximumCacheSize());
//        assertEquals(30,derTS.getMaximumCacheSize());
//
//    }
//
//    /**
//     * this variation is testing that cache size doesn't propagate with binary ntransform sensor information
//     * when propagate is false
//     */
//    @Test
//    public void testCacheSizeNoPropagateBinary(){
//        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());
//
//        BinaryTransform<Double,Double,Double> corr = new CorrelationTransform(3,2);
//
//        TimeSeries<Double> x_ts = TimeSeries.reader(ts_reader_x);
//        TimeSeries<Double> y_ts = TimeSeries.reader(ts_reader_y);
//
//        TimeSeries<Double> correlationTS = x_ts.transform(y_ts, corr);
//
//        correlationTS.setCacheSize(25,false);
//
//        assertEquals(Integer.MAX_VALUE,x_ts.getMaximumCacheSize());
//        assertEquals(Integer.MAX_VALUE,y_ts.getMaximumCacheSize());
//        assertEquals(25,correlationTS.getMaximumCacheSize());
//    }
//
//    /**
//     * this variation is testing that cache size doesn't propagate with nary ntransform sensor information
//     * when propagate is false
//     */
//    @Test
//    public void testCacheSizeNoPropagateNary(){
//        TimeSeriesReader<Double> ts_reader_x = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_x.txt").getFile());
//        TimeSeriesReader<Double> ts_reader_y = new FileTimeSeriesReader(getClass().getResource("/sensor_corr_y.txt").getFile());
//
//        NaryTransform<Double,List<Double>> join = JoinTransformers.indexJoin(
//                Collections.emptyList(),
//                (agg,cur) -> Stream.concat(agg.stream(), Stream.of(cur)).collect(Collectors.toList())
//        );
//
//        ArrayList<TimeSeries<Double>> si_array = new ArrayList<>();
//
//        si_array.add(TimeSeries.reader(ts_reader_y));
//
//        TimeSeries<Double> rootTS = TimeSeries.reader(ts_reader_x);
//
//        TimeSeries<List<Double>> joinTS = rootTS.transform(si_array, join);
//
//        joinTS.setCacheSize(3,false);
//
//        assertEquals(Integer.MAX_VALUE,rootTS.getMaximumCacheSize());
//        assertEquals(Integer.MAX_VALUE,si_array.get(0).getMaximumCacheSize());
//        assertEquals(3,joinTS.getMaximumCacheSize());
//
//    }




}
