/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.Pair;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNull;


/**
 * <p>Created on 8/18/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class TupleMultiTimeSeriesVerifier extends MultiTimeSeriesVerifier<Pair<Double,Double>> {
    @Override
    protected void assertObservationEquals(
            Observation<Pair<Double, Double>> expected,
            Observation<Pair<Double, Double>> actual) {
        assertEquals(expected.getTimeTick(),actual.getTimeTick());

        if (expected.getValue().left == null) {
            assertNull(expected.getValue().left);
            assertNull(actual.getValue().left);
        } else {
            assertEquals(expected.getValue().left,actual.getValue().left,.01);
        }

        if (expected.getValue().right == null) {
            assertNull(expected.getValue().right);
            assertNull(actual.getValue().right);
        } else {
            assertEquals(expected.getValue().right,actual.getValue().right,.01);
        }
    }
}
