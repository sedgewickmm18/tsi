/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.core.tools;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.Enumeration;
import java.util.Iterator;

import static org.junit.Assert.assertEquals;

/**
 * <p>Created on 6/13/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class TimeSeriesVerifier<T> {

    public void verifyOutput(long t1, long t2, ObservationCollection<T> expectedOutput, TimeSeries<T> timeSeries){
        verifyOutput(t1,t2,true,expectedOutput,timeSeries);
    }

    public void verifyOutput(long t1, long t2, boolean inclusive, ObservationCollection<T> expectedOutput, TimeSeries<T> timeSeries){
        ObservationCollection<T> actualOutput = timeSeries.getValues(t1,t2,inclusive);

        assertEquals(expectedOutput.size(),actualOutput.size());//verify that both outputs have the same size

        Iterator<Observation<T>> actualIter = actualOutput.iterator();
        expectedOutput.forEach(expected -> {
            Observation<T> actual = actualIter.next();

            //make sure timestamps are equal
            assertEquals(expected.getTimeTick(),actual.getTimeTick());

            //make sure doubles are equal to within padding
            assertValuesEqual(expected.getValue(),actual.getValue());

            //make sure metadata is equal
            assertEquals(expected.getAnnotationKeys(),actual.getAnnotationKeys());

            for (String key : expected.getAnnotationKeys()) {
                assertEquals(expected.<String>getAnnotation(key),actual.<String>getAnnotation(key));
            }
        });
    }

    public void verifySeries(
            ObservationCollection<T> expected,
            ObservationCollection<T> actual) {
        assertEquals(expected.size(),actual.size());

        Iterator<Observation<T>> actualIter = actual.iterator();
        expected.forEach(expectedObs -> {
            Observation<T> actualObs = actualIter.next();

            //make sure timestamps are equal
            assertEquals(expectedObs.getTimeTick(),actualObs.getTimeTick());

            //make sure doubles are equal to within padding
            assertValuesEqual(expectedObs.getValue(),actualObs.getValue());

            //make sure metadata is equal
            assertEquals(expectedObs.getAnnotationKeys(),actualObs.getAnnotationKeys());

            for (String key : expectedObs.getAnnotationKeys()) {
                assertEquals(expectedObs.<String>getAnnotation(key),actualObs.<String>getAnnotation(key));
            }
        });
    }

    protected abstract void assertValuesEqual(T expected,T actual);

}
