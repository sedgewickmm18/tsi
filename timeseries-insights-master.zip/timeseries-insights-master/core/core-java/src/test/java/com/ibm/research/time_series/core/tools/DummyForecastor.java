///*
// * ************* Begin Copyright - Do not add comments here **************
// *  * Licensed Materials - Property of IBM
// *  *
// *  *   OCO Source Materials
// *  *
// *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
// *  *
// *  * The source code for this program is not published or other-
// *  * wise divested of its trade secrets, irrespective of what has
// *  * been deposited with the U.S. Copyright Office.
// *  ***************************** End Copyright ***************************
// */
//
//package com.ibm.research.time_series.core.tools;
//
//import com.ibm.research.time_series.core.constants.ForecastConsts;
//import com.ibm.research.time_series.core.forecasting.ObservationForecastingModel;
//import com.ibm.research.time_series.core.observation.Observation;
//import com.ibm.research.time_series.core.utils.ObservationCollection;
//import com.ibm.research.time_series.core.utils.Observations;
//import com.ibm.research.time_series.core.utils.Prediction;
//import com.ibm.research.time_series.core.utils.TSBuilder;
//
//import java.util.Properties;
//
///**
// * <p>Created on 8/16/17.</p>
// *
// * @author Joshua Rosenkranz
// */
//public class DummyForecastor implements ObservationForecastingModel<String> {
//    private ObservationCollection<String> dummyModel;
//    private int initNum;
//    public DummyForecastor(int initNum) {
//        this.dummyModel = Observations.empty();
//        this.initNum = initNum;
//    }
//
//    @Override
//    public void resetModel() {
//        dummyModel.clear();
//    }
//
//    @Override
//    public void updateModel(Observation<String> value) {
//        dummyModel.add(value);
//    }
//
//    @Override
//    public Prediction<String> forecastAt(long time) {
//        return null;
//    }
//
//    @Override
//    public ObservationCollection<String> getValuesFromForecast(long t1, long t2) {
//        TSBuilder<String> tsBuilder = Observations.newBuilder();
//
//        Properties p = new Properties();
//        if (dummyModel.size() >= 2*initNum) {
//            p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR,2.0);
//            p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING,4.0);
//        } else {
//            p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_FLOOR,Double.NEGATIVE_INFINITY);
//            p.put(ForecastConsts.FORECAST_CONFIDENCE_BOUND_CEILING,Double.POSITIVE_INFINITY);
//        }
//
//        for(long i = t1;i <= t2;i++) {
//            tsBuilder.add(new Observation<>(i,dummyModel.last().getValue(),p));
//        }
//        return tsBuilder.result();
//    }
//
//    @Override
//    public boolean isInitialized() {
//        return dummyModel.size() >= initNum;
//    }
//
//    @Override
//    public void setConfidence(double confidence) {
//    }
//
//    @Override
//    public long getAverageInterval() {
//        return 1;
//    }
//
//    @Override
//    public double getConfidence() {
//        return 0;
//    }
//}
