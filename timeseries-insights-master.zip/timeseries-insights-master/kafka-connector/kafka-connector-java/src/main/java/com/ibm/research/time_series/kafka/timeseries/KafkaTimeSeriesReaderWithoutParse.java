package com.ibm.research.time_series.kafka.timeseries;

import com.ibm.research.time_series.core.observation.Observation;

import java.util.concurrent.atomic.AtomicLong;

public class KafkaTimeSeriesReaderWithoutParse extends KafkaTimeSeriesReader {

    private AtomicLong currentTimestamp;

    public KafkaTimeSeriesReaderWithoutParse(String host, int port, String topic, long cacheSize) {
        super(host,port,topic,cacheSize);
        this.currentTimestamp = new AtomicLong(0);
    }

    @Override
    protected Observation<String> getCurrentObservation(String record) {
        return new Observation<>(currentTimestamp.incrementAndGet(),record);
    }
}
