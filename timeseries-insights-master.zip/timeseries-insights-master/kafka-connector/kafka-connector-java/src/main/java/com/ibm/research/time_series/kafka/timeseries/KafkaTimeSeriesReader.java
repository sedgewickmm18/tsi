package com.ibm.research.time_series.kafka.timeseries;

import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.util.*;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Executors;

//todo this should allow other types
public abstract class KafkaTimeSeriesReader implements TimeSeriesReader<String> {

    private final String topic;
    private long cacheSize;
    private NavigableSet<Observation<String>> buffer;
    private KafkaConsumer<String,String> consumer;

    public KafkaTimeSeriesReader(String host, int port, String topic, long cacheSize) {
        this.topic = topic;
        this.buffer = new ConcurrentSkipListSet<>();
        this.cacheSize = cacheSize;
        setupConnection(host,port);
    }

    private void setupConnection(String host, int port) {
        Properties properties = new Properties();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,host + ":" + port);
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringDeserializer");
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringDeserializer");
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, UUID.randomUUID().toString());
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"latest");
        this.consumer = new KafkaConsumer<>(properties);
        consumer.subscribe(Collections.singletonList(topic));
        Executors.newSingleThreadExecutor().execute(() -> {
            while(true) {
                final ConsumerRecords<String, String> records = consumer.poll(1000);
                records.forEach(r -> {
                    if (buffer.size() == cacheSize) {
                        buffer.remove(buffer.first());
                    }
                    buffer.add(getCurrentObservation(r.value()));
                });
            }
        });
    }

    protected abstract Observation<String> getCurrentObservation(String record);


    @Override
    public Iterator<Observation<String>> read(long t1, long t2, boolean inclusiveIfBoundsNotExist) {
        if (buffer.isEmpty()) return buffer.iterator();

        final Observation<String> floor = (buffer.first().getTimeTick() < t1 && inclusiveIfBoundsNotExist)
                ? buffer.floor(new Observation<>(t1,null,null))
                : new Observation<>(t1,null,null);

        final Observation<String> ceiling = (buffer.last().getTimeTick() > t2 && inclusiveIfBoundsNotExist)
                ? buffer.ceiling(new Observation<>(t2,null,null))
                : new Observation<>(t2,null,null);

        return buffer.subSet(floor,true,ceiling,true).iterator();
    }

    @Override
    public void close() {
        consumer.close();
    }

    /**
     * @return first timestamp in our buffer
     */
    @Override
    public long start() {
        return (buffer.isEmpty()) ? Long.MIN_VALUE : buffer.first().getTimeTick();
    }

    /**
     * @return last timestamp in our buffer
     */
    @Override
    public long end() {
        return (buffer.isEmpty()) ? Long.MAX_VALUE : buffer.last().getTimeTick();
    }
}
