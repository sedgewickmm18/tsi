package com.ibm.research.time_series.kafka.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

public class KafkaTimeSeries {
    public static TimeSeries<String> kafka(String host, int port, String topic, long cacheSize, UnaryMapFunction<String,Long> toTimestampOp) {
        return TimeSeries.reader(new KafkaTimeSeriesReaderWithParse(host,port,topic,cacheSize,toTimestampOp));
    }

    public static TimeSeries<String> kafka(String host, String topic, UnaryMapFunction<String,Long> toTimestampOp) {
        return kafka(host, 9092, topic, Long.MAX_VALUE, toTimestampOp);
    }

    public static TimeSeries<String> kafka(String topic, UnaryMapFunction<String,Long> toTimestampOp) {
        return kafka("localhost",topic,toTimestampOp);
    }

    public static TimeSeries<String> kafka(String host, int port, String topic, long cacheSize) {
        return TimeSeries.reader(new KafkaTimeSeriesReaderWithoutParse(host,port,topic,cacheSize));
    }

    public static TimeSeries<String> kafka(String host, String topic) {
        return kafka(host, 9092, topic, Long.MAX_VALUE);
    }

    public static TimeSeries<String> kafka(String topic) {
        return kafka("localhost",topic);
    }
}
