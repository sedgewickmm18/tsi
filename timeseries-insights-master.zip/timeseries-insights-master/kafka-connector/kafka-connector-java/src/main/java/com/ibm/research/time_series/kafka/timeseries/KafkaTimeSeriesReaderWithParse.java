package com.ibm.research.time_series.kafka.timeseries;

import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import org.apache.kafka.clients.consumer.ConsumerRecord;

public class KafkaTimeSeriesReaderWithParse extends KafkaTimeSeriesReader {

    private UnaryMapFunction<String,Long> toTimestampOp;

    public KafkaTimeSeriesReaderWithParse(String host, int port, String topic, long cacheSize, UnaryMapFunction<String, Long> toTimestampOp) {
        super(host,port,topic,cacheSize);
        this.toTimestampOp = toTimestampOp;
    }

    @Override
    protected Observation<String> getCurrentObservation(String record) {
        return new Observation<>(toTimestampOp.evaluate(record),record);
    }
}
