package com.ibm.research.time_series.kafka.scala_api

import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.kafka.timeseries.KafkaTimeSeries
import com.ibm.research.time_series.core.scala_api.utils.Implicits._


object KafkaImplicits {

  object KafkaFunctions {
    def kafka
        (
          topic: String,
          host: String = "localhost",
          port: Int = 9092,
          cacheSize: Long = Long.MaxValue,
          toTimestampOp: Option[String => Long] = None
        ): ScalaTimeSeries[String] = {
      if (toTimestampOp.isEmpty) {
        KafkaTimeSeries.kafka(host,port,topic,cacheSize).asScala
      } else {
        KafkaTimeSeries.kafka(host,port,topic,cacheSize,TSFunctionUtils.uMapFunction(toTimestampOp.get(_))).asScala
      }
    }
  }

  implicit def fromScalaTimeSeriesObject(tsEntry: TimeSeries.type): KafkaFunctions.type = {
    KafkaFunctions
  }

}
