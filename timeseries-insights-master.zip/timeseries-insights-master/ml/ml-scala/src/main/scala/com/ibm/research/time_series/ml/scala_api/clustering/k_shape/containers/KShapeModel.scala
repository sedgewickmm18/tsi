package com.ibm.research.time_series.ml.scala_api.clustering.k_shape.containers

import java.io.{InputStream, OutputStream}

import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel
import com.ibm.research.time_series.ml.clustering.k_shape.containers.{KShapeModel => JKShapeModel}
import com.ibm.research.time_series.ml.scala_api.clustering.ScalaTimeSeriesClusteringModel

//todo redundant
class KShapeModel(kShapeModel: JKShapeModel)
  extends ScalaTimeSeriesClusteringModel[Double](kShapeModel.asInstanceOf[TimeSeriesClusteringModel[Double]]){
}

object KShapeModel {
  def load(inputStream: InputStream): KShapeModel = {
    new KShapeModel(JKShapeModel.load(inputStream))
  }
}
