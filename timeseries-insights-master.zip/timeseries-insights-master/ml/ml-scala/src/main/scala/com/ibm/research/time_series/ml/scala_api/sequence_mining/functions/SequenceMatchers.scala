
/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.scala_api.sequence_mining.functions

import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.sequence_mining.containers.{ItemSet, ItemSetSequence, MatcherThreshold}
import com.ibm.research.time_series.ml.sequence_mining.functions.{SequenceMatcher, SequenceMatchers => JSequenceMatchers}

/**
  *
  * <p>Created on 8/29/17.</p>
  *
  * @author Joshua Rosenkranz
  */
object SequenceMatchers {
  def subseq[T](threshold: Double = 0.0, mt: MatcherThreshold = MatcherThreshold.PS): (ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]] = {
    new ScalaSequenceMatcher[T](JSequenceMatchers.subseq[T](threshold,mt))
  }

  def seq[T]: (ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]] = {
    new ScalaSequenceMatcher[T](JSequenceMatchers.seq[T]())
  }

  def sublist[T](threshold: Double = 0.0): (ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]] = {
    new ScalaSequenceMatcher[T](JSequenceMatchers.sublist(threshold))
  }

  @SerialVersionUID(- 7364530529625066000L)
  private class ScalaSequenceMatcher[T](jSequenceMatcher: SequenceMatcher[T]) extends ((ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]]) with Serializable {
    override def apply(v1: ItemSetSequence[T], v2: ObservationCollection[ItemSet[T]]): Option[ObservationCollection[ItemSet[T]]] = Option(jSequenceMatcher.matches(v1,v2))
    override def toString(): String = jSequenceMatcher.toString
  }

}
