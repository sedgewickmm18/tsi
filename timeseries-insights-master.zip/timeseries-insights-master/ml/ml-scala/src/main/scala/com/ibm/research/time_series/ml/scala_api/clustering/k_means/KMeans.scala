package com.ibm.research.time_series.ml.scala_api.clustering.k_means

import java.lang

import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.clustering.k_means.functions.{DistanceComputer, WeightedSumFunction}
import com.ibm.research.time_series.ml.scala_api.clustering.k_means.containers.{ConstraintKMeansModel, NonConstraintKMeansModel}
import com.ibm.research.time_series.ml.clustering.k_means.{KMeansUtils, KMeans => JKMeans}
import com.ibm.research.time_series.transforms.reducers.distance.dtw.algorithm.IObjectDistanceCalculator
import com.ibm.research.time_series.core.scala_api.utils.Implicits._
import com.ibm.research.time_series.transforms.scala_api.utils.Implicits._
import scala.collection.JavaConverters._


object KMeans {
  def trainConstraint[T]
      (
        multiTimeSeries: ScalaMultiTimeSeries[_,T],
        distanceOp: (T,T) => Double,
        weightedSumOp: (T,T,Double,Double) => T
      )
      (
        initialCentroidGetter: InitialCentroidGetter[T],
        maxIterations: Int,
        minShiftDistance: Double
      ): ConstraintKMeansModel[T] = {
    val initialCentroids = initialCentroidGetter.get(
      multiTimeSeries,
      new DistanceComputer[T] {
        override def compute(x: ObservationCollection[T], y: ObservationCollection[T]): lang.Double = {
          x.toTimeSeries.manhattanDistance(y.toTimeSeries)(distanceOp)
        }
      }
    )

    new ConstraintKMeansModel(JKMeans.trainConstraint(
      multiTimeSeries.mts,
      new IObjectDistanceCalculator[T] {
        override def distance(o1: T, o2: T) = distanceOp(o1,o2)
      },
      new WeightedSumFunction[T] {
        override def apply(value1: T, value2: T, weight1: Double, weight2: Double) = weightedSumOp(value1, value2, weight1, weight2)
      },
      initialCentroids.toSeq.asJava,
      maxIterations,
      minShiftDistance
    ))
  }

  def trainNonConstraint[T]
      (
        multiTimeSeries: ScalaMultiTimeSeries[_,T],
        distanceOp: (ObservationCollection[T],ObservationCollection[T]) => Double,
        weightedSumOp: (T,T,Double,Double) => T
      )
      (
        initialCentroidGetter: InitialCentroidGetter[T],
        maxIterations: Int,
        minShiftDistance: Double
      ): NonConstraintKMeansModel[T] = {
    val initialCentroids = initialCentroidGetter.get(
      multiTimeSeries,
      new DistanceComputer[T] {
        override def compute(x: ObservationCollection[T], y: ObservationCollection[T]): lang.Double = {
          distanceOp(x,y)
        }
      }
    )

    new NonConstraintKMeansModel[T](JKMeans.trainNonConstraint[T](
      multiTimeSeries.mts,
      TSFunctionUtils.bMapFunction[ObservationCollection[T],ObservationCollection[T],java.lang.Double]((x,y) => distanceOp(x,y)),
      new WeightedSumFunction[T] {
        override def apply(value1: T, value2: T, weight1: Double, weight2: Double) = weightedSumOp(value1, value2, weight1, weight2)
      },
      initialCentroids.toSeq.asJava,
      maxIterations,
      minShiftDistance
    ))
  }

  trait InitialCentroidGetter[T] {
    def get(scalaMultiTimeSeries: ScalaMultiTimeSeries[_,T],distanceComputer: DistanceComputer[T]): Iterable[ObservationCollection[T]]
  }

  case class ComputeCentroids[T](numCentroids: Int) extends InitialCentroidGetter[T] {
    override def get(scalaMultiTimeSeries: ScalaMultiTimeSeries[_, T], distanceComputer: DistanceComputer[T]) = {
      KMeansUtils.computeSeedCentroids(scalaMultiTimeSeries.mts,distanceComputer,numCentroids).asScala
    }
  }

  case class ReferenceCentroids[T](iterable: ObservationCollection[T]*) extends InitialCentroidGetter[T] {
    override def get(scalaMultiTimeSeries: ScalaMultiTimeSeries[_, T], distanceComputer: DistanceComputer[T]) = {
      iterable
    }
  }
}
