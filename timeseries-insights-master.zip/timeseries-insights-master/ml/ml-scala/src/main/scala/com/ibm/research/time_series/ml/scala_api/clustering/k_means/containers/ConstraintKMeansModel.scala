package com.ibm.research.time_series.ml.scala_api.clustering.k_means.containers

import java.io.{InputStream, OutputStream}

import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel
import com.ibm.research.time_series.ml.clustering.k_means.containers.{ConstraintKMeansModel => JKMeansModel}
import com.ibm.research.time_series.ml.scala_api.clustering.ScalaTimeSeriesClusteringModel

//todo redundant
class ConstraintKMeansModel[T](kMeansModel: JKMeansModel[T])
  extends ScalaTimeSeriesClusteringModel[T](kMeansModel.asInstanceOf[TimeSeriesClusteringModel[T]]) with Serializable {
}

object ConstraintKMeansModel {
  def load[T](inputStream: InputStream): ConstraintKMeansModel[T] = {
    new ConstraintKMeansModel[T](JKMeansModel.load(inputStream))
  }
}
