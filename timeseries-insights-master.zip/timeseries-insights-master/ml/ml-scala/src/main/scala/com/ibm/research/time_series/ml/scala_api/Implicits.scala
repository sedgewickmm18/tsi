/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.scala_api

import java.io.Serializable

import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.itemset_mining.containers.{DiscriminatoryItemSetModel, DiscriminatoryItemSetStatistics, FrequentItemSetModel}
import com.ibm.research.time_series.ml.sequence_mining.containers.{ItemSet, _}

import scala.collection.JavaConverters._
/**
  *
  * <p>Created on 8/29/17.</p>
  *
  * @author Joshua Rosenkranz
  */
@SerialVersionUID(3149170998118859088L)
object Implicits extends Serializable{

  implicit class ScalaDiscriminatorySubSequenceGroupFunctions[T](dssg: DiscriminatorySubSequenceGroup[T]) {
    def sequencesAndCoveragesAsScala: Array[(DiscriminatorySubSequence[T],Double)] = dssg.sequencesAndCoverages.asScala.map(pair => {
      (pair.left,pair.right.toDouble)
    }).toArray
  }

  implicit class ScalaDiscriminatorySubSequenceModelFunctions[T]
  (dss: DiscriminatorySubSequenceModel[T]) {

    def sequenceMatcherAsScala: (ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]] = {
      (v1: ItemSetSequence[T], v2: ObservationCollection[ItemSet[T]]) => {
        Option(dss.sequenceMatcher.matches(v1,v2))
      }
    }

    def score(series: ObservationCollection[ItemSet[T]],scoreOp: (DiscriminatorySubSequenceModel[T],ObservationCollection[ItemSet[T]]) => Double): Double = {
      scoreOp(dss,series)
    }
  }

  implicit class ScalaFrequentSubSequenceModelFunctions[T](fss: FrequentSubSequenceModel[T]) {
    def sequenceMatcherAsScala: (ItemSetSequence[T],ObservationCollection[ItemSet[T]]) => Option[ObservationCollection[ItemSet[T]]] = {
      (v1: ItemSetSequence[T], v2: ObservationCollection[ItemSet[T]]) => {
        Option(fss.sequenceMatcher.matches(v1,v2))
      }
    }
  }

  implicit class ScalaDiscriminatoryItemSetModelFunctions[T]
  (diss: DiscriminatoryItemSetModel[T]) {

    def itemSetMatcherAsScala: (ItemSet[T],ObservationCollection[T]) => Option[ObservationCollection[T]] = {
      (v1: ItemSet[T], v2: ObservationCollection[T]) => {
        Option(diss.itemSetMatcher.matches(v1,v2))
      }
    }

    def score(series: ObservationCollection[T],scoreOp: (DiscriminatoryItemSetModel[T],ObservationCollection[T]) => Double): Double = {
      scoreOp(diss,series)
    }
  }

  implicit class ScalaFrequentItemSetModelFunctions[T](fiss: FrequentItemSetModel[T]) {
    def itemSetMatcherAsScala: (ItemSet[T],ObservationCollection[T]) => Option[ObservationCollection[T]] = {
      (v1: ItemSet[T], v2: ObservationCollection[T]) => {
        Option(fiss.itemSetMatcher.matches(v1,v2))
      }
    }
  }

  implicit class ScalaDiscriminatorySequenceStatisticsFunctions(dss: DiscriminatorySubSequenceStatistics) {
    def interArrivalStatisticsAsScala: Option[Array[InterArrivalStatistics]] = {
      if (dss.interArrivalStatistics != null)
        Some(dss.interArrivalStatistics.asScala.toArray)
      else
        None
    }
  }

  implicit class ScalaFrequentSequenceStatisticsFunctions[T](fss: FrequentSubSequenceStatistics) {
    def interArrivalStatisticsAsScala: Option[Array[InterArrivalStatistics]] = {
      if (fss.interArrivalStatistics != null)
        Some(fss.interArrivalStatistics.asScala.toArray)
      else
        None
    }
  }

  implicit class seqToItemSet[T](seq: Seq[T]) {
    def itemSet: ItemSet[T] = new ItemSet[T](seq.asJava)
  }
}