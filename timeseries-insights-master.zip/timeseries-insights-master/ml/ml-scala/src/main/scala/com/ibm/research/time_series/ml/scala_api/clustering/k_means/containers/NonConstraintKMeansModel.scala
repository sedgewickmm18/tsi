package com.ibm.research.time_series.ml.scala_api.clustering.k_means.containers

import java.io.InputStream

import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel
import com.ibm.research.time_series.ml.clustering.k_means.containers.{NonConstraintKMeansModel => JKMeansModel}
import com.ibm.research.time_series.ml.scala_api.clustering.ScalaTimeSeriesClusteringModel

class NonConstraintKMeansModel[T](kMeansModel: JKMeansModel[T])
  extends ScalaTimeSeriesClusteringModel[T](kMeansModel.asInstanceOf[TimeSeriesClusteringModel[T]]) with Serializable {
}

object NonConstraintKMeansModel {
  def load[T](inputStream: InputStream): NonConstraintKMeansModel[T] = {
    new NonConstraintKMeansModel[T](JKMeansModel.load(inputStream))
  }
}
