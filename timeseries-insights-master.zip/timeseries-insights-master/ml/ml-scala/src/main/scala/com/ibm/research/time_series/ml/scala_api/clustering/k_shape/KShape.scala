package com.ibm.research.time_series.ml.scala_api.clustering.k_shape

import com.ibm.research.time_series.core.exceptions.TSException
import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.clustering.k_shape.{KShape => JKShape}
import com.ibm.research.time_series.ml.clustering.k_shape.containers.{InitializationStrategies, KShapeModel => JKShapeModel}
import com.ibm.research.time_series.ml.scala_api.clustering.k_shape.containers.KShapeModel

import scala.collection.JavaConverters._


object KShape {
  def run[KEY]
      (multiTimeSeries: ScalaMultiTimeSeries[KEY,Double])
      (kClusters: Int, numRuns: Int = 1,useEigen: Boolean = true, initStrategy: InitializationStrategies = InitializationStrategies.Zero): Option[KShapeModel] = {

    val model = try {
      JKShape.run[KEY](
        multiTimeSeries.map(x => x.asInstanceOf[java.lang.Double]).mts,
        kClusters,
        numRuns,
        useEigen,
        initStrategy
      )
    } catch {
      case e: TSException =>
        e.printStackTrace()
        null.asInstanceOf[JKShapeModel]
      case e: Exception => throw e
    }


    if (Option(model).isDefined) {
      Some(new KShapeModel(model))
    } else {
      None
    }
  }

  def runWithSeed[KEY]
      (multiTimeSeries: ScalaMultiTimeSeries[KEY,Double])
      (seedCentroids:Iterable[ObservationCollection[Double]])
      (numRuns: Int = 1,useEigen: Boolean = true): Option[KShapeModel] = {
    val model = try {
      JKShape.runWithSeed[KEY](
        multiTimeSeries.map(x => x.asInstanceOf[java.lang.Double]).mts,
        seedCentroids.map(x => x.asInstanceOf[ObservationCollection[java.lang.Double]]).toSeq.asJava,
        numRuns,
        useEigen
      )
    } catch {
      case e: TSException =>
        e.printStackTrace()
        null.asInstanceOf[JKShapeModel]
      case e: Exception => throw e
    }

    if (Option(model).isDefined) {
      Some(new KShapeModel(model))
    } else {
      None
    }
  }

  def update[KEY]
      (multiTimeSeries: ScalaMultiTimeSeries[KEY,Double])
      (kShapeModel: KShapeModel, useEigen: Boolean = true, numRuns: Int = 2): Option[KShapeModel] = {
    val model = try {
      JKShape.update[KEY](
        multiTimeSeries.map(x => x.asInstanceOf[java.lang.Double]).mts,
        kShapeModel.model.asInstanceOf[JKShapeModel],
        useEigen,
        numRuns
      )
    } catch {
      case e: TSException =>
        e.printStackTrace()
        null.asInstanceOf[JKShapeModel]
      case e: Exception => throw e
    }

    if (Option(model).isDefined) {
      Some(new KShapeModel(model))
    } else {
      None
    }
  }

  def explore[KEY]
      (multiTimeSeries: ScalaMultiTimeSeries[KEY,Double])
      (numRuns: Int,maxK: Int, minK: Int = 0, useEigen: Boolean = true,initStrategy: InitializationStrategies = InitializationStrategies.Zero): Option[KShapeModel] = {

    val model = try {
      JKShape.explore(
        multiTimeSeries.map(x => x.asInstanceOf[java.lang.Double]).mts,
        numRuns,
        maxK,
        minK,
        useEigen,
        initStrategy
      )
    } catch {
      case e: TSException =>
        e.printStackTrace()
        null.asInstanceOf[JKShapeModel]
      case e: Exception => throw e
    }

    if (Option(model).isDefined) {
      Some(new KShapeModel(model))
    } else {
      None
    }
  }
}
