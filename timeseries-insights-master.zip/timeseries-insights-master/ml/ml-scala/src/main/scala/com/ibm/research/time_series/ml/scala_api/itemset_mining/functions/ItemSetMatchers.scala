package com.ibm.research.time_series.ml.scala_api.itemset_mining.functions

import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.sequence_mining.containers.{ItemSet, MatcherThreshold}
import com.ibm.research.time_series.ml.itemset_mining.functions.{ItemSetMatcher, ItemSetMatchers => JItemSetMatchers}

object ItemSetMatchers {
  def subset[ITEM](threshold: Double = 0.0, matchThreshold: MatcherThreshold = MatcherThreshold.PS): (ItemSet[ITEM],ObservationCollection[ITEM]) => Option[ObservationCollection[ITEM]] = {
    new ScalaItemSetMatcher[ITEM](JItemSetMatchers.subset(threshold,matchThreshold))
  }

  @SerialVersionUID(3636510918631360833L)
  private class ScalaItemSetMatcher[ITEM](jMatcher: ItemSetMatcher[ITEM]) extends ((ItemSet[ITEM],ObservationCollection[ITEM]) => Option[ObservationCollection[ITEM]]) with Serializable {
    override def apply(v1: ItemSet[ITEM], v2: ObservationCollection[ITEM]): Option[ObservationCollection[ITEM]] = Option(jMatcher.matches(v1,v2))
    override def toString(): String = jMatcher.toString
  }

}
