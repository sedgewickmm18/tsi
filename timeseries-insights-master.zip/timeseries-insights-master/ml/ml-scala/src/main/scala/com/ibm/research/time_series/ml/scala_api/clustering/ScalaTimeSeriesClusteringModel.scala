package com.ibm.research.time_series.ml.scala_api.clustering

import java.io.OutputStream

import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.utils.ObservationCollection
import com.ibm.research.time_series.ml.clustering.{Drift, TimeSeriesClusteringModel}

import scala.collection.JavaConverters._

/**
  * This is a scala friendly class to describe a [[TimeSeriesClusteringModel]] (a model that was built by mining a set
  * of TimeSeries to produce clusters)
  *
  * Created on 8/30/17.
  *
  * @author Joshua Rosenkranz
  */
case class ScalaTimeSeriesClusteringModel[V](model: TimeSeriesClusteringModel[V]) {

  /**
    * a set of in memory time series which denote the centroids of this model
    */
  def centroids: Seq[ObservationCollection[V]] = model.centroids.asScala

  /**
    * this is the intra-cluster distance per centroid in this model
    *
    * the intra-cluster distance per centroid is defined as:
    * the average between all points in a cluster from its cluster center
    */
  def intraClusterDistances: Seq[Double] = model.intraClusterDistances.asScala.map(_.toDouble)

  /**
    * this is the inter-cluster distance per centroid in this model
    *
    * the inter-cluster distance per centroid is defined as:
    * the average distance from the second closest centroid for each point grouped by its closest centroid
    * For all ci in C_1i, the inter cluster distance per centroid is computed as avg(distance(ci,C_2i)) where ci
    * is a time series in a cluster with centroid C_1i and C_2i is the second closest cluster centroid to ci
    *
    */
  def interClusterDistances: Seq[Double] = model.interClusterDistances.asScala.map(_.toDouble)

  /**
    * this is the silhouette coefficient per centroid in this model
    *
    * the silhouette coefficient per centroid is defined as:
    * for each cluster, (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
    */
  def silhouetteCoefficients: Seq[Double] = model.silhouetteCoefficients.asScala.map(_.toDouble)

  /**
    * save this model to an [[OutputStream]]
    *
    * @param outputStream the given OutputStream
    */
  def save(outputStream: OutputStream): Unit = model.save(outputStream)

  /**
    * score a given TimeSeries to find its closest cluster's ID
    *
    * @param observations an in memory collection of observations
    * @return a cluster ID
    */
  def score(observations: ObservationCollection[V]): Int = model.score(observations)

  /**
    * score a given TimeSeries to find its closest cluster's ID and additionally compute its silhouette coefficient
    *
    * the silhouette coefficient with respect to this model is defined as:
    * the distance from the second closest centroid to the given time series minus the first closest centroid to
    * the given time series all over the second closest centroid to the given time series
    *
    * For a given time series t, the first closest centroid C_1 with respect to t, and the second closest centroid
    * C_2 with respect to t, the silhouette coefficient is defined as
    * (distance(t,C_2) - distance(t,C_1)) / distance(t,C_2)
    *
    * @param observations an in memory collection of observations
    * @return a pair with cluster ID and silhouette coefficient
    */
  def scoreWithSilhouette(observations: ObservationCollection[V]): (Int,Double) = {
    val pair = model.scoreWithSilhouette(observations)
    (pair.left,pair.right)
  }

  /**
    * compute the EMD (Wasserstein Distance) between both models
    *
    * A definition of the distance can be found at https://en.wikipedia.org/wiki/Earth_mover%27s_distance
    *
    * @param otherModel the other model
    * @return a double representing the EMD distance between this model and another model
    */
  def diffEMD(otherModel: ScalaTimeSeriesClusteringModel[V]): Double = model.diffEMD(otherModel.model)

  /**
    * compute the WBM (Weighted Bipartite Matching or Hungarian Algorithm) between this model and another model
    *
    * A definition of WBM can be found in https://en.wikipedia.org/wiki/Hungarian_algorithm
    *
    * @param otherModel the other model
    * @return the minimum cost matching of workers to jobs based upon the provided cost matrix. A matching value of -1
    *         indicates that the corresponding worker is unassigned.
    */
  def diffWBM(otherModel: ScalaTimeSeriesClusteringModel[V]): Seq[Int] = {
    model.diffWBM(otherModel.model).asScala.map(_.toInt)
  }

  /**
    * Given an old and new set of TimeSeries and a new model detect the [[Drift]] for each TimeSeries
    *
    * Note: scoring for the old data will use this model and scoring for the new data will use the given newModel
    *
    * @param oldData  old set of TimeSeries
    * @param newData  new set of TimeSeries
    * @param newModel the new model (by default is the current model)
    * @tparam K key to a given TimeSeries
    * @return a map where each key denotes a TimeSeries and the value is a [[Drift]]
    */
  def detectDrift[K]
      (
        oldData: ScalaMultiTimeSeries[K,V],
        newData: ScalaMultiTimeSeries[K,V],
        newModel: ScalaTimeSeriesClusteringModel[V] = this
      ): Map[K,Drift] = {
    model.detectDrift(oldData.mts,newData.mts,newModel.model).asScala.toMap
  }
}
