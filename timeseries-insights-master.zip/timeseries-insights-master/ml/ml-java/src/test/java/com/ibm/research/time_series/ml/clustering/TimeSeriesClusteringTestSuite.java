package com.ibm.research.time_series.ml.clustering;

import com.ibm.research.time_series.ml.clustering.itemset_mining.ItemSetMatcherTest;
import com.ibm.research.time_series.ml.clustering.k_means.ConstraintKMeansTest;
import com.ibm.research.time_series.ml.clustering.k_means.NonConstraintKMeansTest;
import com.ibm.research.time_series.ml.clustering.k_shape.KShapeTest;
import com.ibm.research.time_series.ml.clustering.sequence_mining.SequenceMatcherTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        ConstraintKMeansTest.class,
        NonConstraintKMeansTest.class,
        KShapeTest.class,
        SequenceMatcherTest.class,
        ItemSetMatcherTest.class
})
public class TimeSeriesClusteringTestSuite {
}
