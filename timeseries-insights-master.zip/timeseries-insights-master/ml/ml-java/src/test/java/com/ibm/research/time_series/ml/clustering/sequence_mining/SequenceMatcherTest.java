package com.ibm.research.time_series.ml.clustering.sequence_mining;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;
import com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold;
import com.ibm.research.time_series.ml.sequence_mining.functions.SequenceMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static junit.framework.Assert.assertNull;
import static junit.framework.TestCase.assertEquals;

public class SequenceMatcherTest {

    private ObservationCollection<ItemSet<String>> ts1;
    private ObservationCollection<ItemSet<String>> ts2;
    private ObservationCollection<ItemSet<String>> ts3;
    private List<ItemSet<String>> pattern1;
    private List<ItemSet<String>> pattern2;

    @Before
    public void setup() {
        ts1 = TimeSeries.list(Arrays.asList("a", "b", "c", "d", "e", "f", "g", "h")).map(x -> new ItemSet<>(Collections.singletonList(x))).collect();
        ts2 = TimeSeries.list(Arrays.asList("a", "b", "d", "c", "e", "f", "g", "h")).map(x -> new ItemSet<>(Collections.singletonList(x))).collect();
        ts3 = TimeSeries.list(Arrays.asList("a", "c", "b")).map(x -> new ItemSet<>(Collections.singletonList(x))).collect();

        pattern1 = Stream.of("a","b","c").map(x -> new ItemSet<>(Collections.singletonList(x))).collect(Collectors.toList());
        pattern2 = Stream.of("a", "b", "c", "d", "e", "f", "g", "h").map(x -> new ItemSet<>(Collections.singletonList(x))).collect(Collectors.toList());
    }

    private void seriesEquals(ObservationCollection<ItemSet<String>> expected, ObservationCollection<ItemSet<String>> actual) {
        assertEquals(expected.size(),actual.size());
        Iterator<Observation<ItemSet<String>>> expectedIter = expected.iterator();
        Iterator<Observation<ItemSet<String>>> actualIter = actual.iterator();

        while(expectedIter.hasNext()) {
            final Observation<ItemSet<String>> expectedObs = expectedIter.next();
            final Observation<ItemSet<String>> actualObs = actualIter.next();

            assertEquals(expectedObs.getTimeTick(), actualObs.getTimeTick());
            assertEquals(expectedObs.getValue(), actualObs.getValue());
        }
    }

    @Test
    public void testSublist1() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>sublist(.25).matches(new ItemSetSequence<>(pattern1), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSublist2() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>sublist(.5).matches(new ItemSetSequence<>(pattern1), ts1);
        assertNull(actual);
    }

    @Test
    public void testSublist3() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>sublist(.25).matches(new ItemSetSequence<>(pattern1), ts2);
        assertNull(actual);
    }

    @Test
    public void testExact1() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>seq().matches(new ItemSetSequence<>(pattern1), ts1);
        assertNull(actual);
    }

    @Test
    public void testExact2() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .add(3,"d")
                .add(4,"e")
                .add(5,"f")
                .add(6,"g")
                .add(7,"h")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>seq().matches(new ItemSetSequence<>(pattern2), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPS1() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();

        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.25, MatcherThreshold.PS).matches(new ItemSetSequence<>(pattern1), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPS2() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.5, MatcherThreshold.PS).matches(new ItemSetSequence<>(pattern1), ts1);
        assertNull(actual);
    }

    @Test
    public void testSubSeqPS3() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(3,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();

        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.25, MatcherThreshold.PS).matches(new ItemSetSequence<>(pattern1), ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPS4() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(0.0, MatcherThreshold.PS).matches(new ItemSetSequence<>(pattern1), ts3);
        assertNull(actual);
    }

    @Test
    public void testSubSeqPM1() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.25, MatcherThreshold.PM).matches(new ItemSetSequence<>(pattern1), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPM2() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.5, MatcherThreshold.PM).matches(new ItemSetSequence<>(pattern1), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPM3() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(3,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.75,MatcherThreshold.PM).matches(new ItemSetSequence<>(pattern1), ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqPM4() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(7.0/8.0,MatcherThreshold.PM).matches(new ItemSetSequence<>(pattern1), ts2);
        assertNull(actual);
    }

    @Test
    public void testSubSeqPM5() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(0.0,MatcherThreshold.PM).matches(new ItemSetSequence<>(pattern1), ts3);
        assertNull(actual);
    }

    @Test
    public void testSubSeqMS1() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(3.0/8.0,MatcherThreshold.MS).matches(new ItemSetSequence<>(pattern1), ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqMS2() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.5,MatcherThreshold.MS).matches(new ItemSetSequence<>(pattern1), ts1);
        assertNull(actual);
    }

    @Test
    public void testSubSeqMS3() {
        ObservationCollection<ItemSet<String>> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"d")
                .add(3,"c")
                .result()
                .toTimeSeriesStream()
                .map(x -> new ItemSet<>(Collections.singletonList(x)))
                .collect();
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.5,MatcherThreshold.MS).matches(new ItemSetSequence<>(pattern1), ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubSeqMS4() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(.75,MatcherThreshold.MS).matches(new ItemSetSequence<>(pattern1), ts2);
        assertNull(actual);
    }

    @Test
    public void testSubSeqMS5() {
        final ObservationCollection<ItemSet<String>> actual = SequenceMatchers.<String>subseq(0.0,MatcherThreshold.MS).matches(new ItemSetSequence<>(pattern1), ts3);
        assertNull(actual);
    }
}
