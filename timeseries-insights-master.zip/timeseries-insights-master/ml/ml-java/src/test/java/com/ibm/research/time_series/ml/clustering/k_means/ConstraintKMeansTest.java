package com.ibm.research.time_series.ml.clustering.k_means;


import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotSame;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.fail;


public class ConstraintKMeansTest {
    private MultiTimeSeries<Integer,Double> mts;

    @Before
    public void setup() {

        List<Double> vector1 = IntStream.range(0,100).mapToObj(x -> Math.random()).collect(Collectors.toList());
        List<Double> vector2 = vector1.stream().map(x -> x + Math.random()).collect(Collectors.toList());

        List<Double> vector3 = IntStream.range(0,100).mapToObj(x -> Math.random() + 100).collect(Collectors.toList());
        List<Double> vector4 = vector3.stream().map(x -> x + Math.random()).collect(Collectors.toList());

        List<Double> vector5 = IntStream.range(0,100).mapToObj(x -> Math.random() + 1000).collect(Collectors.toList());
        List<Double> vector6 = vector5.stream().map(x -> x + Math.random()).collect(Collectors.toList());


        TimeSeries<Double> ts1 = TimeSeries.list(vector1);
        TimeSeries<Double> ts2 = TimeSeries.list(vector2);
        TimeSeries<Double> ts3 = TimeSeries.list(vector3);
        TimeSeries<Double> ts4 = TimeSeries.list(vector4);
        TimeSeries<Double> ts5 = TimeSeries.list(vector5);
        TimeSeries<Double> ts6 = TimeSeries.list(vector6);

        mts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts1,ts2,ts3,ts4,ts5,ts6));
    }

    @Test
    public void testKMeansPlusPlus() {
        TimeSeriesClusteringModel<Double> model = KMeans.trainConstraint(
                mts,
                (x,y) -> Math.abs(x - y),
                (x,y,w1,w2) -> (x * w1 + y * w2) / (w1 + w2),
                3,
                20,
                .2
        );

        Map<Integer, Integer> resultClusters = mts.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));
        assertEquals(resultClusters.get(4),resultClusters.get(5));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));
        assertNotSame(resultClusters.get(4),resultClusters.get(0));
    }

    @Test
    public void testKMeans() {
        ObservationCollection<Double> ts1 = TimeSeries.list(
                IntStream.range(0,100).mapToObj(x -> 0.0).collect(Collectors.toList())
        ).collect();

        ObservationCollection<Double> ts2 = TimeSeries.list(
                IntStream.range(0,100).mapToObj(x -> 100.0).collect(Collectors.toList())
        ).collect();

        ObservationCollection<Double> ts3 = TimeSeries.list(
                IntStream.range(0,100).mapToObj(x -> 1000.0).collect(Collectors.toList())
        ).collect();

        TimeSeriesClusteringModel<Double> model = KMeans.trainConstraint(
                mts,
                (x,y) -> Math.abs(x - y),
                (x,y,w1,w2) -> (x * w1 + y * w2) / (w1 + w2),
                Arrays.asList(ts1,ts2,ts3),
                20,
                .2
        );

        Map<Integer, Integer> resultClusters = mts.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));
        assertEquals(resultClusters.get(4),resultClusters.get(5));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));
        assertNotSame(resultClusters.get(4),resultClusters.get(0));
    }

    @Test
    public void testKMeansParams() {
        TimeSeriesClusteringModel<Double> model = KMeans.trainConstraint(
                mts,
                (x,y) -> Math.abs(x - y),
                (x,y,w1,w2) -> (x * w1 + y * w2) / (w1 + w2),
                3,
                20,
                .2
        );

        boolean correctIntraInter = IntStream.range(0,model.centroids.size()).mapToObj(i -> {
            return model.intraClusterDistances.get(i) < model.interClusterDistances.get(i);
        }).allMatch(x -> x);

        assertTrue(correctIntraInter);
    }

    @Test
    public void testKMeansRobustWhenAllTimeSeriesSame() {
        List<Double> vector1 = IntStream.range(0,100).mapToObj(x -> Math.random()).collect(Collectors.toList());
        List<Double> vector2 = IntStream.range(0,100).mapToObj(x -> Math.random()).collect(Collectors.toList());
        TimeSeries<Double> ts1 = TimeSeries.list(vector1);
        TimeSeries<Double> ts2 = TimeSeries.list(vector2);
        MultiTimeSeries<Integer,Double> sameMTS = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts1,ts1,ts1,ts2,ts2,ts2));

        try {
            TimeSeriesClusteringModel<Double> model = KMeans.trainConstraint(
                    sameMTS,
                    (x,y) -> Math.abs(x - y),
                    (x,y,w1,w2) -> (x * w1 + y * w2) / (w1 + w2),
                    3,
                    20,
                    .2
            );
            assertEquals(2,model.centroids.size());
        } catch (NullPointerException e) {
            fail("exception was thrown");
        }
    }
}
