package com.ibm.research.time_series.ml.clustering.itemset_mining;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.ml.itemset_mining.functions.ItemSetMatchers;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Iterator;

import static junit.framework.Assert.assertNull;
import static junit.framework.TestCase.assertEquals;

public class ItemSetMatcherTest {
    private ObservationCollection<String> ts1;
    private ObservationCollection<String> ts2;
    private ObservationCollection<String> ts3;
    private ItemSet<String> pattern;

    @Before
    public void setup() {
        ts1 = TimeSeries.list(Arrays.asList("a", "b", "c", "d", "e", "f", "g", "h")).collect();
        ts2 = TimeSeries.list(Arrays.asList("a", "b", "d", "c", "e", "f", "g", "h")).collect();
        ts3 = TimeSeries.list(Arrays.asList("a", "c", "b")).collect();

        pattern = new ItemSet<>(Arrays.asList("a","b","c"));
    }

    private void seriesEquals(ObservationCollection<String> expected, ObservationCollection<String> actual) {
        assertEquals(expected.size(),actual.size());
        Iterator<Observation<String>> expectedIter = expected.iterator();
        Iterator<Observation<String>> actualIter = actual.iterator();

        while(expectedIter.hasNext()) {
            final Observation<String> expectedObs = expectedIter.next();
            final Observation<String> actualObs = actualIter.next();

            assertEquals(expectedObs.getTimeTick(), actualObs.getTimeTick());
            assertEquals(expectedObs.getValue(), actualObs.getValue());
        }
    }

    @Test
    public void testSubsetPS1() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result();

        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.25, MatcherThreshold.PS).matches(pattern, ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPS2() {
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.5, MatcherThreshold.PS).matches(pattern, ts1);
        assertNull(actual);
    }

    @Test
    public void testSubsetPS3() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(3,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.25, MatcherThreshold.PS).matches(pattern, ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPS4() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"c")
                .add(2,"b")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(0.0, MatcherThreshold.PS).matches(pattern, ts3);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPM1() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.25,MatcherThreshold.PM).matches(pattern, ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPM2() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.5,MatcherThreshold.PM).matches(pattern, ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPM3() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(3,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.75,MatcherThreshold.PM).matches(pattern, ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetPM4() {
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(7.0/8.0,MatcherThreshold.PM).matches(pattern, ts2);
        assertNull(actual);
    }

    @Test
    public void testSubsetPM5() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"c")
                .add(2,"b")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(0.0,MatcherThreshold.PM).matches(pattern, ts3);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetMS1() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(3.0/8.0,MatcherThreshold.MS).matches(pattern, ts1);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetMS2() {
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.5,MatcherThreshold.MS).matches(pattern, ts1);
        assertNull(actual);
    }

    @Test
    public void testSubsetMS3() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"b")
                .add(2,"d")
                .add(3,"c")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.5,MatcherThreshold.MS).matches(pattern, ts2);
        seriesEquals(expected,actual);
    }

    @Test
    public void testSubsetMS4() {
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(.75,MatcherThreshold.MS).matches(pattern, ts2);
        assertNull(actual);
    }

    @Test
    public void testSubsetMS5() {
        ObservationCollection<String> expected = Observations.<String>newBuilder()
                .add(0,"a")
                .add(1,"c")
                .add(2,"b")
                .result();
        ObservationCollection<String> actual = ItemSetMatchers.<String>subset(0.0,MatcherThreshold.MS).matches(pattern, ts3);
        seriesEquals(expected,actual);
    }




}
