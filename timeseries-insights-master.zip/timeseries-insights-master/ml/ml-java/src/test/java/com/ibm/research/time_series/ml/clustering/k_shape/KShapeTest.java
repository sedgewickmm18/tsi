package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.Drift;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.InitializationStrategies;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.KShapeModel;
import com.ibm.research.time_series.transforms.transformers.math.MathTransformers;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotSame;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class KShapeTest {

    private MultiTimeSeries<Integer,Double> mts;
    private MultiTimeSeries<Integer,Double> mts2;
    private List<Double> vector1;
    private List<Double> vector2;
    private List<Double> vector3;
    private List<Double> vector4;
    private Random random;

    @Before
    public void setup() {
        random = new Random(0);

        vector1 = IntStream.range(0,100).mapToObj(x -> random.nextGaussian()).collect(Collectors.toList());

        vector2 = Stream.concat(
                Stream.of(0.0,0.0),
                vector1.subList(0,vector1.size()-2).stream().map(x -> 2 * x + Math.random() * .05)
        ).collect(Collectors.toList());

        vector3 = IntStream.range(0,100).mapToObj(x -> random.nextGaussian()).collect(Collectors.toList());

        vector4 = Stream.concat(
                Stream.of(0.0,0.0,0.0,0.0),
                vector3.subList(0,vector3.size()-4).stream().map(x -> 2 * x + Math.random() * .05)
        ).collect(Collectors.toList());

        TimeSeries<Double> ts1 = TimeSeries.list(vector1);
        TimeSeries<Double> ts2 = TimeSeries.list(vector2);
        TimeSeries<Double> ts3 = TimeSeries.list(vector3);
        TimeSeries<Double> ts4 = TimeSeries.list(vector4);

        mts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts1,ts2,ts3,ts4));

        Map<Integer,TimeSeries<Double>> map2 = new HashMap<>();
        map2.put(0,ts1.map(x -> x + (.01 * Math.random())));
        map2.put(1,ts2.map(x -> x + (.01 * Math.random())));
        map2.put(2,ts1.map(x -> x + (.01 * Math.random())));
        map2.put(4,ts2.map(x -> x + (.01 * Math.random())));

        mts2 = new MultiTimeSeries<>(map2);
    }

    @Test
    public void testKShapeNotInitialized() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                mtsZScored,
                2,
                20,
                true,
                InitializationStrategies.Zero
        );

        Map<Integer, Integer> resultClusters = mtsZScored.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));

    }

    @Test
    public void testKShapeInitialized() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());

        Map<Integer,ObservationCollection<Double>> seriesMap = mtsZScored.collect();

        List<ObservationCollection<Double>> initialCentroids = Arrays.asList(seriesMap.get(0),seriesMap.get(2));

        KShapeModel model = KShape.runWithSeed(
                mtsZScored,
                initialCentroids,
                20,
                true
        );

        Map<Integer, Integer> resultClusters = mtsZScored.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));
    }

    @Test
    public void testKShapeUsingAveraging() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                mtsZScored,
                2,
                20,
                false,
                InitializationStrategies.Random
        );

        Map<Integer, Integer> resultClusters = mtsZScored.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));
    }

    @Test
    public void testKShapeModelParams() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                mtsZScored,
                2,
                20,
                true,
                InitializationStrategies.Random
        );

        boolean correctIntraInter = IntStream.range(0,model.centroids.size()).mapToObj(i -> {
            return model.intraClusterDistances.get(i) < model.interClusterDistances.get(i);
        }).allMatch(x -> x);

        assertTrue(correctIntraInter);
    }

    @Test
    public void testKShapePluPlusModelInitialization() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                mtsZScored,
                2,
                100,
                true,
                InitializationStrategies.PlusPlus
        );

        Map<Integer, Integer> resultClusters = mtsZScored.reduce(ts -> model.score(ts));

        assertEquals(resultClusters.get(0),resultClusters.get(1));
        assertEquals(resultClusters.get(2),resultClusters.get(3));

        assertNotSame(resultClusters.get(0),resultClusters.get(3));
        assertNotSame(resultClusters.get(1),resultClusters.get(2));
    }

    @Test
    public void testKShapeDriftSameModel() throws TSException {
        MultiTimeSeries<Integer,Double> mtsZScored = mts.transform(MathTransformers.zscore());
        MultiTimeSeries<Integer,Double> mtsZScored2 = mts2.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                mtsZScored,
                2,
                100,
                true,
                InitializationStrategies.PlusPlus
        );

        final Map<Integer, Drift> driftMap = model.detectDrift(mtsZScored, mtsZScored2);

        assertEquals(driftMap.get(0).oldClusterID,driftMap.get(0).newClusterID);
        assertEquals(driftMap.get(1).oldClusterID,driftMap.get(1).newClusterID);
        assertEquals(driftMap.get(2).newClusterID,(driftMap.get(2).oldClusterID == 0) ? 1 : 0);
        assertEquals(driftMap.get(3).newClusterID,-1);
        assertEquals(driftMap.get(4).oldClusterID,-1);
    }

    @Test
    public void testKShapeDriftNewModel() throws TSException {
        Random locRandom = new Random(1);

        List<Double> locVector1 = IntStream.range(0,100).mapToObj(x -> locRandom.nextGaussian()).collect(Collectors.toList());

        List<Double> locVector2 = Stream.concat(
                Stream.of(0.0,0.0),
                locVector1.subList(0,locVector1.size()-2).stream().map(x -> 2 * x + Math.random() * .05)
        ).collect(Collectors.toList());

        List<Double> locVector3 = IntStream.range(0,100).mapToObj(x -> locRandom.nextGaussian()).collect(Collectors.toList());

        List<Double> locVector4 = Stream.concat(
                Stream.of(0.0,0.0,0.0,0.0),
                locVector3.subList(0,locVector3.size()-4).stream().map(x -> 2 * x + Math.random() * .05)
        ).collect(Collectors.toList());

        TimeSeries<Double> ts1 = TimeSeries.list(locVector1);
        TimeSeries<Double> ts2 = TimeSeries.list(locVector2);
        TimeSeries<Double> ts3 = TimeSeries.list(locVector3);
        TimeSeries<Double> ts4 = TimeSeries.list(locVector4);

        MultiTimeSeries<Integer,Double> oldMts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts1,ts2,ts3,ts4));

        MultiTimeSeries<Integer,Double> oldMtsZScored = oldMts.transform(MathTransformers.zscore());

        KShapeModel model = KShape.run(
                oldMtsZScored,
                2,
                100,
                true,
                InitializationStrategies.PlusPlus
        );

        List<Double> vector5 = locVector1.stream().map(x -> 2 * x + Math.random() * .05).collect(Collectors.toList());

        List<Double> vector6 = locVector2.stream().map(x -> 2 * x + Math.random() * .05).collect(Collectors.toList());

        List<Double> vector7 = locVector3.stream().map(x -> 2 * x + Math.random() * .05).collect(Collectors.toList());

        List<Double> vector8 = locVector4.stream().map(x -> 2 * x + Math.random() * .05).collect(Collectors.toList());

        TimeSeries<Double> ts5 = TimeSeries.list(vector5);
        TimeSeries<Double> ts6 = TimeSeries.list(vector6);
        TimeSeries<Double> ts7 = TimeSeries.list(vector7);
        TimeSeries<Double> ts8 = TimeSeries.list(vector8);

        MultiTimeSeries<Integer,Double> newMts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts5,ts6,ts7,ts8));

        MultiTimeSeries<Integer,Double> newMtsZScored = newMts
                .transform(MathTransformers.zscore());

        KShapeModel newModel = KShape.update(newMtsZScored,model,true,100);

        final Map<Integer,Drift> driftMap = model.detectDrift(oldMtsZScored,newMtsZScored,newModel);

        driftMap.entrySet().forEach(entry -> {
            assertEquals(entry.getValue().oldClusterID,entry.getValue().newClusterID);
        });
    }
}
