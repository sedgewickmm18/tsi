package com.ibm.research.time_series.ml.data_curation;

import java.io.Serializable;
import java.util.List;

public class LabeledPoint<LABEL,FEATURE> implements Serializable {
    private static final long serialVersionUID = 702794569915897026L;
    public final LABEL label;
    public final List<FEATURE> featureVector;

    public LABEL label() {
        return label;
    }

    public List<FEATURE> featureVector() {
        return featureVector;
    }

    public LabeledPoint(LABEL label, List<FEATURE> featureVector) {
        this.label = label;
        this.featureVector = featureVector;
    }
}
