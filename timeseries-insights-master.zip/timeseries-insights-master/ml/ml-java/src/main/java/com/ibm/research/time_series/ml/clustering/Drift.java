package com.ibm.research.time_series.ml.clustering;

import java.io.Serializable;

/**
 * This is the class to denote a centroid drift
 *
 * It is composed of a previous cluster ID, a next cluster ID, a previous silhouette coefficient, and a next
 * silhouette coefficient
 */
public class Drift implements Serializable{
    private static final long serialVersionUID = -7164095096967234826L;

    /**
     * the score of a time series with respect to the previous {@link TimeSeriesClusteringModel}
     */
    public final int oldClusterID;
    /**
     * the score of a time series with respect to the next {@link TimeSeriesClusteringModel}
     */
    public final int newClusterID;
    /**
     * the silhouette coefficient of a time series with respect to the previous {@link TimeSeriesClusteringModel}
     */
    public final double oldSilhouetteCoefficient;
    /**
     * the silhouette coefficient of a time series with respect to the next {@link TimeSeriesClusteringModel}
     */
    public final double newSilhouetteCoefficient;

    /**
     * Construct a Drift object
     *
     * @param oldClusterID the score of a time series with respect to the previous {@link TimeSeriesClusteringModel}
     * @param newClusterID the score of a time series with respect to the next {@link TimeSeriesClusteringModel}
     * @param oldSilhouetteCoefficient the silhouette coefficient of a time series with respect to the previous
     *                                  {@link TimeSeriesClusteringModel}
     * @param newSilhouetteCoefficient the silhouette coefficient of a time series with respect to the next
     *                                  {@link TimeSeriesClusteringModel}
     */
    public Drift(
            final int oldClusterID,
            final int newClusterID,
            final double oldSilhouetteCoefficient,
            final double newSilhouetteCoefficient) {
        this.oldClusterID = oldClusterID;
        this.newClusterID = newClusterID;
        this.oldSilhouetteCoefficient = oldSilhouetteCoefficient;
        this.newSilhouetteCoefficient = newSilhouetteCoefficient;
    }

    @Override
    public String toString() {
        return "old cluster: " + oldClusterID + "\n" +
                "new cluster: " + newClusterID + "\n" +
                "old silhouette coefficient: " + oldSilhouetteCoefficient + "\n" +
                "new silhouette coefficient: " + newSilhouetteCoefficient;
    }
}
