/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.stream.Collectors;


/**
 * A holder class for a frequent subsequence that is computed.
 *
 * All immutable variables can be accessed a public variables, for example, fss.sequence (Scala), fss.sequence (Java).
 *
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FrequentSubSequence<T> implements JsonIO,Serializable {
    private static final long serialVersionUID = -6483215800856919547L;
    //todo make these all private, no real need for them to be public

    /**
     * holding the frequent subsequence {@link ItemSetSequence}
     */
    public final ItemSetSequence<T> sequence;
    /**
     * holding statistics {@link FrequentSubSequenceStatistics}
     */
    public final FrequentSubSequenceStatistics statistics;

    /**
     * unique identifier for this FrequentSubSequence in the {@link FrequentSubSequenceModel}
     */
    public final long sequenceID;

    public ItemSetSequence<T> sequence() {
        return sequence;
    }

    public long sequenceID() {
        return sequenceID;
    }

    public FrequentSubSequenceStatistics statistics() {
        return statistics;
    }

    /**
     * @param sequence Immutable variable, holding the frequent subsequence
     * @param statistics Immutable variable, holding statistics [[FrequentSubSequenceStatistics]]
     * @param sequenceID Immutable variable, unique id for this FrequentSubSequence in the {@link FrequentSubSequenceModel}
     */
    public FrequentSubSequence(
            ItemSetSequence<T> sequence,
            FrequentSubSequenceStatistics statistics,
            long sequenceID) {
        this.sequence = sequence;
        this.statistics = statistics;
        this.sequenceID = sequenceID;
    }

    /**
     * @return A string representation of this FSS.
     */
    @Override
    public String toString() {
        return "frequent-sub-sequence(" + "\n" +
                "\t" + "sequence-id=" + sequenceID + "\n" +
                "\t" + "statistics=" + "frequent-sub-sequence-statistics(" + "\n" +
                "\t\t" + "inter-arrival-statistics=" + ((statistics.interArrivalStatistics != null) ? "(\n" + statistics.interArrivalStatistics.stream().map(x -> "\t\t\t" + x.toString()).collect(Collectors.joining("\n")) + "\n\t\t)\n" : "None\n") +
                "\t\t" + "original-size=" + statistics.originalSize + "\n" +
                "\t\t" + "multi-match-norm-frequency=" + statistics.multiMatchNormFrequency + "\n" +
                "\t\t" + "binary-match-norm-frequency=" + statistics.binaryMatchNormFrequency + "\n" +
                "\t\t" + "coverage=" + statistics.coverage() + "\n" +
                "\t)\n" +
                "\t" + "sequence=" + sequence.toString() + "\n" +
                ")";
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();

        //append the sequence id
        jsonGen.writeNumberField("sequence-id",sequenceID);

        //append freq-seq-statistics object;
        statistics.writeJson(jsonGen);

        //append sequence
        sequence.writeJson(jsonGen);

        jsonGen.writeEndObject();
    }

    static <T> FrequentSubSequence<T> fromJson(JsonNode seqObj) throws IOException, ClassNotFoundException {
        long sequenceID = seqObj.get("sequence-id").asLong();

        FrequentSubSequenceStatistics frequentSubSequenceStatistics = FrequentSubSequenceStatistics.fromJson(seqObj);

        ItemSetSequence<T> sequences = ItemSetSequence.fromJson(seqObj);

        return new FrequentSubSequence<>(
                sequences,
                frequentSubSequenceStatistics,
                sequenceID
        );
    }
}
