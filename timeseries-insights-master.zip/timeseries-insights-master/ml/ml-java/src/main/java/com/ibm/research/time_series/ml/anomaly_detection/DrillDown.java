package com.ibm.research.time_series.ml.anomaly_detection;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.transforms.transformers.math.MathTransformers;
import com.ibm.watson.pm.algorithms.BATS.BATSAlgorithm;
import com.ibm.watson.pm.models.ForecastingModel;
import com.ibm.watson.pm.models.IForecastingModel;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DrillDown {
    private String name;
    private int total;
    private int level;
    private List<DrillDown> children;

    public DrillDown(String name, List<DrillDown> children, int level, int total) {
        this.name = name;
        this.children = children;
        this.level = level;
        this.total = total;
    }

    public List<DrillDown> getChildren() {
        return children;
    }

    public String getName() {
        return name;
    }

    public int getTotal() {
        return total;
    }

    public int getLevel() {
        return level;
    }
    public String toString() {
        if (children.isEmpty()) {
            return IntStream.range(0, level).mapToObj(i -> "\t").collect(Collectors.joining()) + "Leaf: (" + name + ", "+total+")";
        } else {
            String treeTab = IntStream.range(0, level).mapToObj(i -> "\t").collect(Collectors.joining());

            return treeTab + "Tree: (" + name + ", "+total+")" +
                    children.stream().map(x -> x.toString()).collect(Collectors.joining("\n", "\n", ""));
        }
    }

    public static DrillDown run(DrillDownSchema drillDownSchema, MultiTimeSeries<String, Double> mts, IForecastingModel model, double confidence) {
        MultiTimeSeries<String,Double> metricsMts = mts.filterSeriesKey(k -> drillDownSchema.getLeaves().contains(k));

        Map<String, ObservationCollection<Double>> anomaliesMap =  metricsMts
                .transform(MathTransformers.detectAnomalies(model, confidence, true))
                .collect();

        return create(drillDownSchema.drillDownNode, anomaliesMap);
    }

    public static DrillDownNode node(String name) {
        return new DrillDownNode(name);
    }

    private static DrillDown create(DrillDownNode drillDownNode, Map<String, ObservationCollection<Double>> anomaliesMap) {
        if (drillDownNode.isLeaf()) {
            int numAnomalies = anomaliesMap.get(drillDownNode.getName()).size();
            return new DrillDown(drillDownNode.getName(), Collections.emptyList(), drillDownNode.getLevel(), numAnomalies);
        } else {
            List<DrillDown> drillDowns = drillDownNode.getChildren().stream().map(c -> create(c, anomaliesMap)).collect(Collectors.toList());

            return new DrillDown(
                    drillDownNode.getName(),
                    drillDownNode.getChildren().stream().map(c -> create(c, anomaliesMap)).collect(Collectors.toList()),
                    drillDownNode.getLevel(),
                    drillDowns.stream().mapToInt(x -> x.total).sum()
            );
        }
    }
}
