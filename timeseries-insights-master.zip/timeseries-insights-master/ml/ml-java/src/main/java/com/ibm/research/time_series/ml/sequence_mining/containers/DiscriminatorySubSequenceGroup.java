package com.ibm.research.time_series.ml.sequence_mining.containers;

import com.ibm.research.time_series.core.utils.Pair;

import java.io.Serializable;
import java.util.List;

/**
 * a container to represent a grouping of {@link DiscriminatorySubSequence}
 * @param <ITEM> the {@link ItemSetSequence} value type
 */
public class DiscriminatorySubSequenceGroup<ITEM> implements Serializable {

    /**
     * the head discriminatory sub that all incremental coverages in this group are with respect to
     */
    public final DiscriminatorySubSequence<ITEM> head;

    /**
     * each discriminatory sub sequence and its incremental coverage with respect to the head
     */
    public final List<Pair<DiscriminatorySubSequence<ITEM>,Double>> sequencesAndCoverages;

    /**
     * Construct a {@link DiscriminatorySubSequenceGroup}
     * @param head the head sequence that all incremental coverages in this group are with respect to
     * @param sequencesAndCoverages each sequence and its incremental coverage with respect to the head
     */
    public DiscriminatorySubSequenceGroup(
            DiscriminatorySubSequence<ITEM> head,
            List<Pair<DiscriminatorySubSequence<ITEM>,Double>> sequencesAndCoverages) {
        this.head = head;
        this.sequencesAndCoverages = sequencesAndCoverages;
    }

    /**
     * @return the head sequence that all incremental coverages in this group are with respect to
     */
    public DiscriminatorySubSequence<ITEM> head() {
        return head;
    }

    /**
     * @return each sequence and its incremental coverage with respect to the head
     */
    public List<Pair<DiscriminatorySubSequence<ITEM>,Double>> sequencesAndCoverages() {
        return sequencesAndCoverages;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("head").append("\n").append(head.toString()).append("\n");
        stringBuilder.append("sequences and coverage").append("\n");
        sequencesAndCoverages.forEach(sac -> stringBuilder.append(sac.toString()));
        stringBuilder.append("\n");
        return stringBuilder.toString();
    }

}
