package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.ml.sequence_mining.containers.FrequentSubSequenceStatistics;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;

/**
 * Deeper statistics for a given {@link FrequentItemSet}
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FrequentItemSetStatistics implements Serializable, Comparable<FrequentItemSetStatistics>, JsonIO {
    private static final long serialVersionUID = -8007622880918052526L;

    /**
     * the number of time series on which these statistics were computed
     */
    public final long originalSize;

    /**
     * this statistics {@link DurationStatistics}
     */
    public final DurationStatistics durationStatistics;

    /**
     * provides the total number of matches given a set of sets and a subset, with one
     * set possibly matching a subset multiple times.
     */
    public final long multiMatchNormFrequency;
    /**
     * Immutable variable, provides the total number of matches given a set of sets and a
     * subset, where multiple matches to a set is counted as only one.
     */
    public final long binaryMatchNormFrequency;

    public long originalSize() {
        return originalSize;
    }

    public DurationStatistics durationStatistics() {
        return durationStatistics;
    }

    public long multiMatchNormFrequency() {
        return multiMatchNormFrequency;
    }

    public long binaryMatchNormFrequency() {
        return binaryMatchNormFrequency;
    }

    /**
     * Constructs a {@link FrequentItemSetStatistics}
     *
     * @param originalSize the number of time series on which these statistics were computed
     * @param durationStatistics Immutable variable, represents duration statistics
     * @param multiMatchNormFrequency Immutable variable, provides the total number of matches given a set of sets
     *                               and a subset, with one sequence possibly matching a subset multiple times.
     * @param binaryMatchNormFrequency Immutable variable, provides the total number of matches given a set of subsets
     *                                and a subset, where multiple matches to a set is counted as only one.
     */
    public FrequentItemSetStatistics(long originalSize, DurationStatistics durationStatistics, long multiMatchNormFrequency, long binaryMatchNormFrequency) {
        this.originalSize = originalSize;
        this.durationStatistics = durationStatistics;
        this.multiMatchNormFrequency = multiMatchNormFrequency;
        this.binaryMatchNormFrequency = binaryMatchNormFrequency;
    }

    /**
     * @return the coverage for this given statistics model
     */
    public double coverage() {
        return binaryMatchNormFrequency * 1.0 / originalSize;
    }

    /**
     * Merge this {@link FrequentItemSetStatistics} with the given input.
     *
     * @param other Frequent set statistics to merge with.
     * @return a new FrequentsetStatistics that has been merged
     */
    public FrequentItemSetStatistics update(FrequentItemSetStatistics other) {
        if (durationStatistics == null) {
            return new FrequentItemSetStatistics(
                    other.originalSize,
                    other.durationStatistics,
                    other.multiMatchNormFrequency,
                    other.binaryMatchNormFrequency
            );
        } else {
            return new FrequentItemSetStatistics(
                    originalSize,
                    durationStatistics.update(other.durationStatistics.sum,other.durationStatistics.sumLeadTime,other.durationStatistics.sumEndTime),
                    multiMatchNormFrequency + other.multiMatchNormFrequency,
                    binaryMatchNormFrequency + other.binaryMatchNormFrequency
            );
        }
    }

    /**
     * @return A string representation of the frequent set statistics
     */
    @Override
    public String toString() {

        return "frequent-item-set-statistics(" + "\n" +
                "\t" + "duration-statistics=" + "duration-statistics(" + "\n" +
                "\t\tmin=" + durationStatistics.min + "\n" +
                "\t\tmax=" + durationStatistics.max + "\n" +
                "\t\tsum=" + durationStatistics.sum + "\n" +
                "\t\tavg=" + durationStatistics.average + "\n" +
                "\t\tvariance=" + durationStatistics.variance + "\n" +
                "\t\tsd=" + durationStatistics.sd + "\n" +
                "\t\tmin-lead-time=" + durationStatistics.minLeadTime + "\n" +
                "\t\tmax-lead-time=" + durationStatistics.maxLeadTime + "\n" +
                "\t\tsum-lead-time=" + durationStatistics.sumLeadTime + "\n" +
                "\t\tavg-lead-time=" + durationStatistics.averageLeadTime + "\n" +
                "\t\tvariance-lead-time=" + durationStatistics.varianceLeadTime + "\n" +
                "\t\tsd-lead-time=" + durationStatistics.sdLeadTime + "\n" +
                "\t\tmin-end-time=" + durationStatistics.minEndTime + "\n" +
                "\t\tmax-end-time=" + durationStatistics.maxEndTime + "\n" +
                "\t\tsum-end-time=" + durationStatistics.sumEndTime + "\n" +
                "\t\tavg-end-time=" + durationStatistics.averageEndTime + "\n" +
                "\t\tvariance-end-time=" + durationStatistics.varianceEndTime + "\n" +
                "\t\tsd-end-time=" + durationStatistics.sdEndTime + "\n" +
                "\t" + ")" + "\n" +
                "\t" + "original-size=" + originalSize + "\n" +
                "\t" + "binary-match-norm-frequency=" + binaryMatchNormFrequency + "\n" +
                "\t" + "multi-match-norm-frequency=" + multiMatchNormFrequency + "\n" +
                "\t" + "coverage=" + coverage() + "\n" +
                ")";
    }

    @Override
    public int compareTo(FrequentItemSetStatistics o) {
        return Double.compare(this.coverage(),o.coverage());
    }

    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeFieldName("frequent-item-set-statistics");
        jsonGen.writeStartObject();

        //append item-set-statistics;
        durationStatistics.writeJson(jsonGen);

        //append the original size
        jsonGen.writeNumberField("original-size", originalSize);

        //append binary match norm frequency
        jsonGen.writeNumberField(
                "binary-match-norm-frequency", binaryMatchNormFrequency
        );

        //append multi match norm frequency
        jsonGen.writeNumberField("multi-match-norm-frequency", multiMatchNormFrequency);

        jsonGen.writeEndObject();//end frequent-sequence-statistics
    }

    static FrequentItemSetStatistics fromJson(JsonNode jsonNode) {
        JsonNode statisticsObj = jsonNode.get("frequent-item-set-statistics");

        //get our inter arrival statistics
        DurationStatistics durationStatistics = DurationStatistics.fromJson(statisticsObj);

        long originalSize = statisticsObj.get("original-size").asLong();
        long binaryMatchNormFrequency = statisticsObj.get("binary-match-norm-frequency").asLong();
        long multiMatchNormFrequency = statisticsObj.get("multi-match-norm-frequency").asLong();

        return new FrequentItemSetStatistics(
                originalSize,
                durationStatistics,
                multiMatchNormFrequency,
                binaryMatchNormFrequency
        );
    }
}
