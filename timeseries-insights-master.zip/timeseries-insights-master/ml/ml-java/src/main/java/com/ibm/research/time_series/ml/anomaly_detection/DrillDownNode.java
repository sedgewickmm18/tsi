package com.ibm.research.time_series.ml.anomaly_detection;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DrillDownNode {

    private final List<DrillDownNode> children;
    private final String name;
    private int level;

    DrillDownNode(String name) {
        this.level = 0;
        this.name = name;
        this.children = new ArrayList<>();
    }

    List<DrillDownNode> getChildren() {
        return children;
    }

    void setLevel(int level) {
        this.level = level;
    }

    public DrillDownNode children(DrillDownNode... drillDownNodes) {
        children.addAll(Arrays.asList(drillDownNodes));
        return this;
    }

    boolean isLeaf() {
        return this.children.isEmpty();
    }

    String getName() {
        return name;
    }

    int getLevel() {
        return level;
    }

    public String toString() {
        if (children.isEmpty()) {
            return IntStream.range(0, level).mapToObj(i -> "\t").collect(Collectors.joining()) + "Leaf: " + name;
        } else {
            String treeTab = IntStream.range(0, level).mapToObj(i -> "\t").collect(Collectors.joining());

            return treeTab + "Tree: (" + name + ")" +
                    children.stream().map(x -> x.toString()).collect(Collectors.joining("\n", "\n", ""));
        }
    }
}
