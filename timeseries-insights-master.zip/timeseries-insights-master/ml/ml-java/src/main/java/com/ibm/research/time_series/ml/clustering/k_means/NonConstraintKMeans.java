package com.ibm.research.time_series.ml.clustering.k_means;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.ml.clustering.k_means.containers.NonConstraintKMeansModel;
import com.ibm.research.time_series.ml.clustering.k_means.functions.WeightedSumFunction;

import java.io.Serializable;
import java.util.List;

/**
 * NonConstraintKMeansModel implementation of a {@link KMeansComputer}
 *
 * NonConstraintKMeans uses a distance function that calculates the distance between 2 TimeSeries
 *
 * @param <V> the observation value type
 */
class NonConstraintKMeans<V> extends KMeansComputer<V> implements Serializable {

    /**
     * a distance function that calculates the distance between 2 TimeSeries
     */
    private BinaryMapFunction<ObservationCollection<V>,ObservationCollection<V>,Double> distanceOp;

    /**
     * construct a NonConstraintKMeans computer
     * @param distanceOp distance function that calculates the distance between 2 TimeSeries
     */
    NonConstraintKMeans(
            BinaryMapFunction<ObservationCollection<V>,ObservationCollection<V>,Double> distanceOp) {
        this.distanceOp = distanceOp;
    }

    /**
     * train a {@link NonConstraintKMeansModel} given a set of time series and initial centroids
     *
     * @param multiTimeSeries a set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * @param tsCentroids initial centroids
     * @param weightedSumOp the {@link WeightedSumFunction}
     * @param maxIterations the maximum iterations to run
     * @param minShiftDistance the minimum shift distance
     * @return a new {@link NonConstraintKMeansModel}
     */
    NonConstraintKMeansModel<V> train(
            MultiTimeSeries<?,V> multiTimeSeries,
            List<ObservationCollection<V>> tsCentroids,
            WeightedSumFunction<V> weightedSumOp,
            int maxIterations,
            double minShiftDistance) {
        List<ObservationCollection<V>> result = performTrain(
                multiTimeSeries,
                tsCentroids,
                weightedSumOp,
                maxIterations,
                minShiftDistance
        );

        List<List<Double>> metrics = TimeSeriesClusteringModel.perClusterMetrics(
                multiTimeSeries,
                result,
                (x,y) -> compute(x,y)
        );

        return new NonConstraintKMeansModel<>(distanceOp,result,metrics.get(0),metrics.get(1),metrics.get(2),metrics.get(3),metrics.get(4));
    }

    /**
     * NonConstraintKMeans implementation of
     * {@link com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer} where a distance is
     * produced between each {@link ObservationCollection}
     *
     * @param x first collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @param y second collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @return the total distance between both {@link ObservationCollection}
     */
    @Override
    public Double compute(ObservationCollection<V> x, ObservationCollection<V> y) {
        return distanceOp.evaluate(x,y);
    }
}
