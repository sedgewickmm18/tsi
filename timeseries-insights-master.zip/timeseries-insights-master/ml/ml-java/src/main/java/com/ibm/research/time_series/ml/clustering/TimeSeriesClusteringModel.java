/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.clustering;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer;
import com.ibm.research.time_series.transforms.reducers.distance.emd.algorithm.EMD;
import com.ibm.research.time_series.transforms.reducers.distance.hungarian.algorithm.WBM;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.util.DefaultPrettyPrinter;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * This is the abstract class to describe a TimeSeriesClustering model (a model that was built by mining a set
 * of TimeSeries to produce clusters)
 *
 * <p>a TimeSeriesClustering model's centroids are TimeSeries themselves</p>
 *
 * <p>
 *     the model also holds statistics such as the intraClusterDistances, interClusterDistances and the silhouette
 *     coefficients
 * </p>
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public abstract class TimeSeriesClusteringModel<T> implements Serializable {

    /**
     * a set of in memory time series which denote the centroids of this model
     */
    public final List<ObservationCollection<T>> centroids;
    /**
     * this is the intra-cluster distance per centroid in this model
     *
     * the intra-cluster distance per centroid is defined as:
     *      the average between all points in a cluster from its cluster center
     */
    public final List<Double> intraClusterDistances;

    /**
     * this is the inter-cluster distance per centroid in this model
     *
     * the inter-cluster distance per centroid is defined as:
     *      the average distance from the second closest centroid for each point grouped by its closest centroid
     *      For all ci in C_1i, the inter cluster distance per centroid is computed as avg(distance(ci,C_2i)) where ci
     *      is a time series in a cluster with centroid C_1i and C_2i is the second closest cluster centroid to ci
     *
     */
    public final List<Double> interClusterDistances;

    /**
     * this is the silhouette coefficient per centroid in this model
     *
     * the silhouette coefficient per centroid is defined as:
     *      for each cluster, (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     */
    public final List<Double> silhouetteCoefficients;

    /**
     * this is the cluster distribution per centroid in this model
     *
     * cluster distribution is defined as:
     *      for each cluster, (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     */
    public final List<Double> clusterDistributions;

    /**
     * Sum of squares of distance from each time series to centroid in this model per centroid
     */
    public final List<Double> sumSquares;

    /**
     * construct a TimeSeriesClusteringModel
     *
     * @param centroids list of {@link ObservationCollection} that denote a list of centroid time series
     * @param intraClusterDistances the average distance from the second closest centroid for each point
     *                              grouped by its closest centroid
     * @param interClusterDistances the average between all points in a cluster from its cluster center
     * @param silhouetteCoefficients for each cluster,
     *                               (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     * @param clusterDistributions for each cluster,
     *                             (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     * @param sumSquares for each cluster, the sum of squared distances from a point to its cluster centrer
     */
    public TimeSeriesClusteringModel(
            List<ObservationCollection<T>> centroids,
            List<Double> intraClusterDistances,
            List<Double> interClusterDistances,
            List<Double> silhouetteCoefficients,
            List<Double> clusterDistributions,
            List<Double> sumSquares) {
        this.centroids = centroids;
        this.intraClusterDistances = intraClusterDistances;
        this.interClusterDistances = interClusterDistances;
        this.silhouetteCoefficients = silhouetteCoefficients;
        this.clusterDistributions = clusterDistributions;
        this.sumSquares = sumSquares;
    }

    /**
     * score a given TimeSeries to find its closest cluster's ID
     *
     * @param realizedTimeSeries an in memory time series
     * @return a cluster ID
     */
    public int score(ObservationCollection<T> realizedTimeSeries) {
        Optional<Pair<Integer,Double>> minDistance = IntStream.range(0, centroids.size()).mapToObj(clusterID -> {
            double d = computeDistance(centroids.get(clusterID),realizedTimeSeries);
            return new Pair<>(clusterID,d);
        }).min(Comparator.comparing(pair -> pair.right));

        if (minDistance.isPresent()) {
            return minDistance.get().left;
        } else {
            return -1;
        }
    }

    /**
     * @param ts1 the first {@link ObservationCollection}
     * @param ts2 the second {@link ObservationCollection}
     * @return the distance between 2 collections of observations
     */
    protected abstract double computeDistance(ObservationCollection<T> ts1,ObservationCollection<T> ts2);

    /**
     * score a given TimeSeries to find its closest cluster's ID and additionally compute its silhouette coefficient
     *
     * the silhouette coefficient with respect to this model is defined as:
     *      the distance from the second closest centroid to the given time series minus the first closest centroid to
     *      the given time series all over the second closest centroid to the given time series
     *
     *      For a given time series t, the first closest centroid C_1 with respect to t, and the second closest centroid
     *      C_2 with respect to t, the silhouette coefficient is defined as
     *      (distance(t,C_2) - distance(t,C_1)) / distance(t,C_2)
     * @param realizedTimeSeries an in memory time series
     * @return a pair with cluster ID and silhouette coefficient
     */
    public Pair<Integer,Double> scoreWithSilhouette(ObservationCollection<T> realizedTimeSeries) {
        List<Pair<Integer,Double>> sortedByClosest = IntStream.range(0,centroids.size()).parallel().mapToObj(i -> {
            return new Pair<>(i,computeDistance(centroids.get(i),realizedTimeSeries));
        })
                .sorted(Comparator.comparing(x -> x.right))
                .collect(Collectors.toList());

        if (sortedByClosest.size() >= 2) {
            final int score = sortedByClosest.get(0).left;
            final double silhouetteCoefficient = (sortedByClosest.get(1).right - sortedByClosest.get(0).right) / sortedByClosest.get(1).right;
            return new Pair<>(score, silhouetteCoefficient);
        } else {
            return new Pair<>(-1,0.0);
        }
    }

    /**
     * compute the EMD (Wasserstein Distance) between both models
     *
     * A definition of the distance can be found at https://en.wikipedia.org/wiki/Earth_mover%27s_distance
     *
     * @param otherModel the other model
     * @return a double representing the EMD distance between this model and another model
     */
    public Double diffEMD(TimeSeriesClusteringModel<T> otherModel) {
        double[] p = clusterDistributions.stream().mapToDouble(x -> x).toArray();
        double[] q = otherModel.clusterDistributions.stream().mapToDouble(x -> x).toArray();
        double[][] distanceMatrix = new double[p.length][q.length];

        for (int i = 0;i < distanceMatrix.length;i++) {
            for (int j = 0;j < distanceMatrix[i].length;j++) {
                distanceMatrix[i][j] = computeDistance(centroids.get(i),otherModel.centroids.get(j));
            }
        }

        return EMD.solve(p,q,distanceMatrix).left;
    }

    /**
     * compute the WBM (Weighted Bipartite Matching or Hungarian Algorithm) between this model and another model
     *
     * A definition of WBM can be found in https://en.wikipedia.org/wiki/Hungarian_algorithm
     *
     * @param otherModel the other model
     * @return the minimum cost matching of workers to jobs based upon the provided cost matrix. A matching value of -1
     *         indicates that the corresponding worker is unassigned.
     */
    public List<Integer> diffWBM(TimeSeriesClusteringModel<T> otherModel) {
        double[][] distanceMatrix = new double[centroids.size()][otherModel.centroids.size()];

        for (int i = 0;i < distanceMatrix.length;i++) {
            for (int j = 0;j < distanceMatrix[i].length;j++) {
                distanceMatrix[i][j] = computeDistance(centroids.get(i),otherModel.centroids.get(j)) * -1.0;
            }
        }

        int[] haResult = WBM.execute(distanceMatrix);

        return IntStream.of(haResult).boxed().collect(Collectors.toList());
    }

    /**
     * Given an old and new set of TimeSeries detect the {@link Drift} for each TimeSeries with respect to this Model
     *
     * <p>
     *     Note:
     *
     *     scoring for the old data will use this model and scoring for the new data will use the given newModel
     *
     * </p>
     *
     * @param oldData old set of TimeSeries
     * @param newData new set of TimeSeries
     * @param <KEY> key to a given TimeSeries
     * @return a map where each key denotes a TimeSeries and the value is a {@link Drift}
     */
    public <KEY> Map<KEY,Drift> detectDrift(
            MultiTimeSeries<KEY,T> oldData,
            MultiTimeSeries<KEY,T> newData) {
        return detectDrift(oldData,newData,this);
    }

    /**
     * Given an old and new set of TimeSeries and a new model detect the {@link Drift} for each TimeSeries
     *
     * <p>
     *     Note:
     *
     *     new model must be created using the old model as a seed
     *     scoring for the old data will use this model and scoring for the new data will use the given newModel
     *
     * </p>
     *
     * @param oldData old set of TimeSeries
     * @param newData new set of TimeSeries
     * @param newModel the new model
     * @param <KEY> key to a given TimeSeries
     * @return a map where each key denotes a TimeSeries and the value is a {@link Drift}
     */
    public <KEY> Map<KEY,Drift> detectDrift(
            MultiTimeSeries<KEY,T> oldData,
            MultiTimeSeries<KEY,T> newData,
            TimeSeriesClusteringModel<T> newModel) {


        Map<KEY,ObservationCollection<T>> oldMap = oldData.collect();
        Map<KEY,ObservationCollection<T>> newMap = newData.collect();

        Set<KEY> oldKeys = oldMap.keySet();
        Set<KEY> newKeys = newMap.keySet();

        //splitting this out for readability since it is not computationally expensive
        Set<KEY> intersectKeys = oldKeys.stream().filter(newKeys::contains).collect(Collectors.toSet());
        Set<KEY> oldExclusive = oldKeys.stream().filter(k -> !newKeys.contains(k)).collect(Collectors.toSet());
        Set<KEY> newExclusive = newKeys.stream().filter(k -> !oldKeys.contains(k)).collect(Collectors.toSet());

        final Stream<Pair<KEY, Drift>> intersectStream = intersectKeys.stream().map(key -> {
            final Pair<Integer, Double> oldScore = scoreWithSilhouette(oldMap.get(key));
            final Pair<Integer, Double> newScore = newModel.scoreWithSilhouette(newMap.get(key));
            return new Pair<>(key, new Drift(oldScore.left, newScore.left, oldScore.right, newScore.right));
        });

        final Stream<Pair<KEY, Drift>> oldExclusiveStream = oldExclusive.stream().map(key -> {
            final Pair<Integer, Double> oldScore = scoreWithSilhouette(oldMap.get(key));
            return new Pair<>(key,new Drift(oldScore.left,-1,oldScore.right,Double.NaN));
        });

        final Stream<Pair<KEY, Drift>> newExclusiveStream = newExclusive.stream().map(key -> {
            final Pair<Integer, Double> newScore = newModel.scoreWithSilhouette(newMap.get(key));
            return new Pair<>(key,new Drift(-1,newScore.left,Double.NaN,newScore.right));
        });

        return Stream.concat(Stream.concat(intersectStream,oldExclusiveStream),newExclusiveStream)
                .collect(Collectors.toMap(x -> x.left,x -> x.right));
    }

    /**
     * save this model to an {@link OutputStream}
     * @param outputStream the given OutputStream
     */
    public void save(OutputStream outputStream) {
        JsonFactory jsonFactory = new JsonFactory();

        JsonGenerator jsonGen;
        try {
            jsonGen = jsonFactory.createJsonGenerator(outputStream, JsonEncoding.UTF8);
            jsonGen.setPrettyPrinter(new DefaultPrettyPrinter());
            jsonGen.writeStartObject();//starting the object

            //write intra cluster distance per centroid
            jsonGen.writeFieldName("intra-cluster-distance-per-centroid");
            jsonGen.writeStartArray();
            for (Double d : intraClusterDistances) {
                jsonGen.writeNumber(d);
            }
            jsonGen.writeEndArray();

            //write inter cluster distance per centroid
            jsonGen.writeFieldName("inter-cluster-distance-per-centroid");
            jsonGen.writeStartArray();
            for (Double d : interClusterDistances) {
                jsonGen.writeNumber(d);
            }
            jsonGen.writeEndArray();

            //write silhouette coefficients per centroid
            jsonGen.writeFieldName("silhouette-coefficients-per-centroid");
            jsonGen.writeStartArray();
            for (Double d : silhouetteCoefficients) {
                jsonGen.writeNumber(d);
            }
            jsonGen.writeEndArray();

            //write cluster distributions per centroid
            jsonGen.writeFieldName("cluster-distributions-per-centroid");
            jsonGen.writeStartArray();
            for (Double d : clusterDistributions) {
                jsonGen.writeNumber(d);
            }
            jsonGen.writeEndArray();

            jsonGen.writeFieldName("sum-square-per-centroid");
            jsonGen.writeStartArray();
            for (Double d : sumSquares) {
                jsonGen.writeNumber(d);
            }
            jsonGen.writeEndArray();


            jsonGen.writeFieldName("centroids");//starting centroids

            jsonGen.writeStartArray();

            for (ObservationCollection<T> centroid : centroids) {

                jsonGen.writeStartArray();//starting centroid

                for (Observation<T> observation : centroid) {
                    jsonGen.writeStartObject();//starting observation

                    jsonGen.writeNumberField("timestamp",observation.getTimeTick());
                    writeObservationValueToJSON(jsonGen,observation.getValue());
                    jsonGen.writeEndObject();//ending observation
                }

                jsonGen.writeEndArray();//ending centroid

            }

            jsonGen.writeEndArray();//ending centroids

            //writes any custom fields a model may have to the json
            writeCustomFieldsToJSON(jsonGen);

            jsonGen.writeEndObject();//ending the object

            jsonGen.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected abstract void writeObservationValueToJSON(JsonGenerator jsonGen, T value) throws IOException;

    protected abstract void writeCustomFieldsToJSON(JsonGenerator jsonGen) throws IOException;

    /**
     * @return a set of in memory time series which denote the centroids of this model
     */
    public List<ObservationCollection<T>> centroids() {
        return centroids;
    }

    /**
     * the inter-cluster distance per centroid is defined as:
     *      the average distance from the second closest centroid for each point grouped by its closest centroid
     *      For all ci in C_1i, the inter cluster distance per centroid is computed as avg(distance(ci,C_2i)) where ci
     *      is a time series in a cluster with centroid C_1i and C_2i is the second closest cluster centroid to ci
     *
     * @return the inter-cluster distance per centroid in this model
     */
    public List<Double> interClusterDistances() {
        return interClusterDistances;
    }

    /**
     * the intra-cluster distance per centroid is defined as:
     *      the average between all points in a cluster from its cluster center
     *
     * @return the intra-cluster distance per centroid in this model
     */
    public List<Double> intraClusterDistances() {
        return intraClusterDistances;
    }

    /**
     * the silhouette coefficient per centroid is defined as:
     *      for each cluster, (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     *
     * @return the silhouette coefficient per centroid in this model
     */
    public List<Double> silhouetteCoefficients() {
        return silhouetteCoefficients;
    }

    /**
     * this is the cluster distribution per centroid in this model
     *
     * cluster distribution is defined as:
     *      for each cluster, (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     *
     * @return the distribution per centroid in this model
     */
    public List<Double> clusterDistributions() {
        return clusterDistributions;
    }

    /**
     * computes the per cluster metrics (intra-cluster distances, inter-cluster distances, silhouette coefficients)
     *
     * Step 1: for each TimeSeries in given MultiTimeSeries, find the 1st closest and 2nd closest centroids using the
     * given distance computer function
     * Step 2: group each TimeSeries by its 1st closest cluster, making sure to save the second closest cluster distance
     * Step 3: for each grouping compute the inter/intra/silhouettes/cluster distributions
     *
     * @param multiTimeSeries the initial MultiTimeSeries
     * @param centroids the list of computed centroids
     * @param distanceComputer the {@link DistanceComputer}
     * @return a multi-dimensional List of doubles representing the intra cluster distance per centroid, the inter
     * cluster distance per centroid, and the silhouette coefficient per centroid
     */
    public static <KEY,VALUE> List<List<Double>> perClusterMetrics(
            MultiTimeSeries<KEY,VALUE> multiTimeSeries,
            List<ObservationCollection<VALUE>> centroids,
            DistanceComputer<VALUE> distanceComputer) {
        Map<Integer,Pair<List<Double>,List<Double>>> result = new HashMap<>();
        //Step 1: find the first and second closest centroids for each TimeSeries in multiTimeSeries
        Map<KEY,ObservationCollection<VALUE>> tsMap = multiTimeSeries.collect();
        tsMap.entrySet().stream().map(entry -> {

            //find the distance from this time series to all centroids and sort in ascending order
            List<Pair<Integer,Double>> distancePerCentroid = IntStream.range(0,centroids.size()).mapToObj(index -> {
                Double distance = distanceComputer.compute(centroids.get(index),entry.getValue());
                return new Pair<>(index,(distance.equals(Double.NaN)) ? 1.0 : distance);
            })
                    .sorted(Comparator.comparing(x -> x.right))
                    .collect(Collectors.toList());
            //take the first 2 distances, these are the first and second closest centroids
            return new Pair<>(
                    distancePerCentroid.get(0).left,
                    new Pair<>(distancePerCentroid.get(0).right,distancePerCentroid.get(1).right)//first and second closest distances
            );

            //Step 2: group each TimeSeries by its 1st closest cluster, save 2nd closest cluster distance to be used later
        }).forEach(pair -> {

            if (result.containsKey(pair.left)) {
                List<Double> firstClosestDistances = new ArrayList<>(result.get(pair.left).left);
                List<Double> secondClosestDistances = new ArrayList<>(result.get(pair.left).right);
                firstClosestDistances.add(pair.right.left);
                secondClosestDistances.add(pair.right.right);
                result.put(pair.left,new Pair<>(firstClosestDistances,secondClosestDistances));
            } else {
                List<Double> firstClosestDistances = new ArrayList<>();
                List<Double> secondClosestDistances = new ArrayList<>();
                firstClosestDistances.add(pair.right.left);
                secondClosestDistances.add(pair.right.right);
                result.put(pair.left,new Pair<>(firstClosestDistances,secondClosestDistances));
            }
        });

        //added this since we want to make sure all centroids are represented
        for (int i = 0;i < centroids.size();i++) {
            if (!result.containsKey(i)) {
                result.put(i,new Pair<>(Collections.emptyList(), Collections.emptyList()));
            }
        }

        List<Double> squaredDistances = result.entrySet().stream()
                .map(entry -> entry.getValue().left.stream().mapToDouble(x -> Math.pow(x,2)).sum())
                .collect(Collectors.toList());

        //Step 3: for each grouping compute the inter/intra/silhouettes/distributions
        List<Double> intraClusterDistances = result.entrySet().stream()
                .map(entry -> {
                    OptionalDouble avgOpt = entry.getValue().left.stream().mapToDouble(x -> x.doubleValue()).average();
                    if (avgOpt.isPresent()) {
                        return new Pair<>(entry.getKey(),avgOpt.getAsDouble());
                    } else {
                        return new Pair<>(entry.getKey(),1.0);
                    }
                })
                .sorted(Comparator.comparing(x -> x.left))
                .map(x -> x.right)
                .collect(Collectors.toList());

        List<Double> interClusterDistances = result.entrySet().stream()
                .map(entry -> {
                    OptionalDouble avgOpt = entry.getValue().right.stream().mapToDouble(x -> x.doubleValue()).average();
                    if (avgOpt.isPresent()) {
                        return new Pair<>(entry.getKey(),avgOpt.getAsDouble());
                    } else {
                        return new Pair<>(entry.getKey(),0.0);
                    }
                })
                .sorted(Comparator.comparing(x -> x.left))
                .map(x -> x.right)
                .collect(Collectors.toList());

        List<Double> silhouetteDistances = IntStream.range(0,centroids.size()).mapToObj(i -> {
            double distB = interClusterDistances.get(i);
            double distA = intraClusterDistances.get(i);
            return (distB == 0.0) ? 0.0 : (distB - distA) / distB;
        }).collect(Collectors.toList());


        List<Double> clusterDistributions = result.entrySet().stream()
                .map(entry -> new Pair<>(entry.getKey(),entry.getValue().left.size() * 1.0 / tsMap.size()))
                .sorted(Comparator.comparing(x -> x.left))
                .map(x -> x.right)
                .collect(Collectors.toList());

        return Arrays.asList(intraClusterDistances,interClusterDistances,silhouetteDistances,clusterDistributions,squaredDistances);
    }

}
