/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Created on 8/29/17.</p>
 *
 * @author Joshua Rosenkranz
 */
@Deprecated
public class SubsetSequenceMatcher<T> implements SequenceMatcher<T> {
    private double threshold;

    public SubsetSequenceMatcher() {
        this.threshold = -1.0;
    }

    public SubsetSequenceMatcher(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public ObservationCollection<ItemSet<T>>matches(
            ItemSetSequence<T> freqSeq,
            ObservationCollection<ItemSet<T>>series) {

        if (threshold >= 0 && freqSeq.itemsets.size() * 1.0 / series.size() * 1.0 < threshold) {
            return null;
        }
        List<Observation<ItemSet<T>>> observationsList = new ArrayList<>(series.toCollection());

        TSBuilder<ItemSet<T>>tsBuilder = Observations.newBuilder();

        int currentIndex = 0;

        for (ItemSet<T> sequence : freqSeq.itemsets) {

            for (int i = currentIndex;i < observationsList.size();i++) {
                if (isSubset(sequence,observationsList.get(i).getValue())) {
                    currentIndex = i + 1;
                    tsBuilder.add(observationsList.get(i));
                    break;
                }
            }
        }

        ObservationCollection<ItemSet<T>>result = tsBuilder.result();

        if (result.size() != freqSeq.itemsets.size()) {
            return null;
        } else {
            return result;
        }
    }

    private boolean isSubset(ItemSet<T> itemsToCheck,ItemSet<T> itemsAgainstCheck) {
        for (T item : itemsToCheck) {
            if (!itemsAgainstCheck.contains(item)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "type=subset, " + "threshold=" + threshold;
    }
}
