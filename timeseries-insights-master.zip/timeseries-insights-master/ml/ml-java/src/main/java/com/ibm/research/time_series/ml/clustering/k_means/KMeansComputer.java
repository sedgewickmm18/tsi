package com.ibm.research.time_series.ml.clustering.k_means;

import com.ibm.research.time_series.core.constants.Padding;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;
import com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer;
import com.ibm.research.time_series.ml.clustering.k_means.functions.WeightedSumFunction;
import com.ibm.research.time_series.transforms.reducers.math.MathReducers;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * This is the abstract class that handles the mining on {@link MultiTimeSeries} to produce KMeans clusters
 *
 * The implementation is based on the KMeans++ algorithm (https://en.wikipedia.org/wiki/K-means%2B%2B)
 *
 * @param <V> observation value type
 */
abstract class KMeansComputer<V> implements DistanceComputer<V> {

    /**
     * For a map of centroids, produce a function {@link UnaryReducer} where for a given segment(time series) in a
     * {@link TimeSeries}, an ID is produced, which denotes the minimum distance centroid from the given
     * segment(time series)
     *
     * @param finalOldCentroids immutable map of centroids to check distances against a TimeSeries
     * @return a {@link UnaryReducer} where for a given segment(time series) in a
     * {@link TimeSeries}, an ID is produced, which denotes the minimum distance centroid from the given
     * segment(time series)
     */
    private UnaryReducer<V,Pair<Integer,ObservationCollection<V>>> minDistanceCluster(
            final Map<Integer,ObservationCollection<V>> finalOldCentroids) {
        return new UnaryReducer<V, Pair<Integer,ObservationCollection<V>>>() {
            @Override
            public Pair<Integer,ObservationCollection<V>> reduceSegment(Segment<V> segment) {
                //this is the TimeSeries record from a multiTimeSeries
                TimeSeries<V> outerTS = segment.toTimeSeriesStream();

                //get the minimum distance cluster from outerTS and set this ID to that clusters ID
                int resultID = finalOldCentroids.entrySet().stream().map(rts -> {

                    //produce a TimeSeries of distances if the windowSize doesn't fill the entire TimeSeries in the
                    //case of NonConstraint TimeSeries
                    long windowSize = rts.getValue().last().getTimeTick() - rts.getValue().first().getTimeTick() + 1;
                    TimeSeries<Double> distances = outerTS
                            .segmentByTime(windowSize,windowSize, Padding.NONE)
                            .map(x -> compute(x,rts.getValue()));
                    //average the TimeSeries distances, but in most cases there will be just one value since the
                    //window size will be the size of the TimeSeries so the average will be the distance itself
                    return new Pair<>(rts.getKey(),distances.reduce(MathReducers.average()));
                }).min(Comparator.comparing(x -> x.right)).get().left;

                return new Pair<>(resultID,segment);
            }
        };
    }

    /**
     * mine the given multiTimeSeries for a list of cluster Centroids
     *
     * Step0: create the initial old centroids
     * Step1: annotate each record with a cluster ID
     * Step2: compute new centroids
     * Step3: compute shift in centroids
     * Step4: update centroids
     * Step5: break if centroid shift distance is less than the threshold
     *
     * @param multiTimeSeries the set of TimeSeries to mine for centroids
     * @param centroids the initial centroids for KMeans clustering
     * @param weightedSumOp the {@link WeightedSumFunction}
     * @param maxIterations the maximum number of iterations
     * @param minShiftDistance minimum shift in centroids from one iteration to the next (if the shift in centroids is
     *                         below this threshold, then the iterations are terminated)
     * @return the cluster centroids that were mined from this set of TimeSeries
     */
    protected List<ObservationCollection<V>> performTrain(
            MultiTimeSeries<?,V> multiTimeSeries,
            List<ObservationCollection<V>> centroids,
            WeightedSumFunction<V> weightedSumOp,
            int maxIterations,
            double minShiftDistance) {

        //Step0: create our initial old centroids
        Map<Integer,ObservationCollection<V>> oldCentroids = IntStream.range(0,centroids.size())
                .mapToObj(index -> new Pair<>(index,centroids.get(index)))
                .collect(Collectors.toMap(x -> x.left,x -> x.right));

        //create a loop where for max number of iterations we update our centroids until either:
        //      max iterations is met or...
        //      centroid shift distance is less than the threshold
        for (int i = 0;i < maxIterations;i++) {
            final Map<Integer, ObservationCollection<V>> finalOldCentroids = oldCentroids;

            //Step1: annotate each record with a cluster ID
            List<Map.Entry<?, Pair<Integer, ObservationCollection<V>>>> collect = new ArrayList<>(
                    multiTimeSeries.reduce(minDistanceCluster(finalOldCentroids)).entrySet()
            );

            //Step2: compute our new centroids
            Map<Integer,Pair<ObservationCollection<V>,Double>> newCentroids = new HashMap<>();
            collect.forEach(x -> {

                //if new centroids doesn't contain the key, create an entry with the given collection
                if (!newCentroids.containsKey(x.getValue().left)) {
                    newCentroids.put(x.getValue().left,new Pair<>(x.getValue().right,1.0));
                //else compute new centroid, update the entry with the prior collection and the new incoming collection
                } else {
                    Pair<ObservationCollection<V>,Double> aggregate = newCentroids.get(x.getValue().left);
                    newCentroids.put(
                            x.getValue().left,
                            new Pair<>(
                                    KMeansUtils.computeNewCentroid(aggregate.left,x.getValue().right,aggregate.right,1.0,weightedSumOp),
                                    aggregate.right + 1.0
                            )
                    );
                }
            });

            //Step3: compute shift in centroids
            //this loop maps from newCentroids since it is possible that newCentroids will not contain all ids from
            //oldCentroids which, if is the case would result in a null pointer exception if we had mapped from oldCentroids
            double shiftDistances = newCentroids.entrySet().stream().mapToDouble(entry -> {
                ObservationCollection<V> leftSeries = finalOldCentroids.get(entry.getKey());
                ObservationCollection<V> rightSeries = entry.getValue().left;
                return compute(leftSeries,rightSeries);
            }).sum();

            //Step4: update centroids
            oldCentroids = newCentroids.entrySet().stream()
                    .map(x -> new Pair<>(x.getKey(),x.getValue().left))
                    .collect(Collectors.toMap(x -> x.left,x -> x.right));

            //Step5: break if centroid shift distance is less than the threshold
            if (shiftDistances <= minShiftDistance) {
                break;
            }
        }

        //give back the list of centroids
        return oldCentroids.entrySet().stream().map(Map.Entry::getValue).collect(Collectors.toList());
    }
}
