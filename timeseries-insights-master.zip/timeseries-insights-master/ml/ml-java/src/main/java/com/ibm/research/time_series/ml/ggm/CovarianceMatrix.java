package com.ibm.research.time_series.ml.ggm;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryReducer;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.RealMatrix;

import java.util.Map;

public class CovarianceMatrix {
    public static RealMatrix compute(MultiTimeSeries<Integer, Double> mts, BinaryReducer<Double, Double, Double> reducer) {
        Map<Integer, TimeSeries<Double>> allts = mts.getTimeSeriesMap();
        int n = allts.size();
        double[][] covMatrix = new double[n][n];

        for(Map.Entry<Integer, TimeSeries<Double>> entry : allts.entrySet()) {
            int i = entry.getKey();
            Map<Integer, Double>  row = mts.reduce(ts -> ts.toTimeSeriesStream().reduce(entry.getValue(), reducer));
            for(Map.Entry<Integer, Double> rowEntry : row.entrySet()) {
                int j = rowEntry.getKey();
                covMatrix[i][j] = rowEntry.getValue();
            }
        }

        RealMatrix result = new Array2DRowRealMatrix(covMatrix, false);
        return result;
    }
}
