package com.ibm.research.time_series.ml.sequence_mining.containers;

import org.codehaus.jackson.JsonGenerator;

import java.io.IOException;
import java.io.Serializable;

public interface JsonIO extends Serializable {
    void writeJson(JsonGenerator jsonGen) throws IOException;
}
