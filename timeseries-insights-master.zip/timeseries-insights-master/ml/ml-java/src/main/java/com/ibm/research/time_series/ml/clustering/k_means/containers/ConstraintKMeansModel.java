/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.clustering.k_means.containers;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;
import com.ibm.research.time_series.transforms.reducers.distance.dtw.algorithm.IObjectDistanceCalculator;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.*;
import java.util.*;

/**
 * Container to hold a Constraint K-Means Model as described in (https://en.wikipedia.org/wiki/K-means%2B%2B)
 *
 * A Constraint KMeans model has the property that, each centroid is of the same size
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ConstraintKMeansModel<T> extends KMeansModel<T> implements Serializable {

    /**
     * distance function that calculates the distance between 2 observation values
     */
    private final IObjectDistanceCalculator<T> distanceOp;

    /**
     * create a Constraint K-Means Model
     *
     * @param distanceOp distance function that calculates the distance between 2 observation values
     * @param centroids list of {@link ObservationCollection} that denote a list of centroid time series
     * @param intraClusterDistancePerCentroid the average between all points in a cluster from its cluster center
     * @param interClusterDistancePerCentroid the average distance from the second closest centroid for each point
     *                                        grouped by its closest centroid
     * @param silhouetteCoefficientsPerCentroid for each cluster,
     *                                          (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     * @param clusterDistributionsPerCentroid for each cluster,
     *                                        (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     */
    public ConstraintKMeansModel(
            IObjectDistanceCalculator<T> distanceOp,
            List<ObservationCollection<T>> centroids,
            List<Double> intraClusterDistancePerCentroid,
            List<Double> interClusterDistancePerCentroid,
            List<Double> silhouetteCoefficientsPerCentroid,
            List<Double> clusterDistributionsPerCentroid,
            List<Double> sumSquaresPerCentroid) {
        super(
                centroids,
                intraClusterDistancePerCentroid,
                interClusterDistancePerCentroid,
                silhouetteCoefficientsPerCentroid,
                clusterDistributionsPerCentroid,
                sumSquaresPerCentroid
        );
        this.distanceOp = distanceOp;
    }

    /**
     * @param ts1 the first {@link ObservationCollection}
     * @param ts2 the second {@link ObservationCollection}
     * @return the distance between 2 collections of observations
     */
    protected double computeDistance(ObservationCollection<T> ts1,ObservationCollection<T> ts2) {
        return ts1.toTimeSeriesStream()
                .reduce(ts2.toTimeSeriesStream(), DistanceReducers.nonTimewarpedDtw(distanceOp));
    }

    /**
     * load a model from an InputStream
     * @param inputStream the given InputStream
     * @return a new ConstraintKMeansModel
     */
    public static <T> ConstraintKMeansModel<T> load(InputStream inputStream) {
        String jsonString = null;
        try {
            jsonString = IOUtils.toString(inputStream, "UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            List<Double> intraClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonIntraDistancePerCluster = jsonNode.get("intra-cluster-distance-per-centroid");
            for (int i = 0; i < jsonIntraDistancePerCluster.size(); i++) {
                intraClusterDistancePerCentroid.add(jsonIntraDistancePerCluster.get(i).asDouble());
            }

            List<Double> interClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonInterDistancePerCluster = jsonNode.get("inter-cluster-distance-per-centroid");
            for (int i = 0; i < jsonInterDistancePerCluster.size(); i++) {
                interClusterDistancePerCentroid.add(jsonInterDistancePerCluster.get(i).asDouble());
            }

            List<Double> silhouetteCoefficientsPerCentroid = new ArrayList<>();
            JsonNode jsonSilhouetteCoefficientsPerCluster = jsonNode.get("silhouette-coefficients-per-centroid");
            for (int i = 0; i < jsonSilhouetteCoefficientsPerCluster.size(); i++) {
                silhouetteCoefficientsPerCentroid.add(jsonSilhouetteCoefficientsPerCluster.get(i).asDouble());
            }

            List<Double> clusterDistributionsPerCentroid = new ArrayList<>();
            JsonNode jsonClusterDistributionsPerCentroid = jsonNode.get("cluster-distributions-per-centroid");
            for (int i = 0; i < jsonClusterDistributionsPerCentroid.size(); i++) {
                clusterDistributionsPerCentroid.add(jsonClusterDistributionsPerCentroid.get(i).asDouble());
            }

            List<Double> sumSquaresPerCentroid = new ArrayList<>();
            JsonNode jsonSumSquaresPerCentroid = jsonNode.get("cluster-distributions-per-centroid");
            for (int i = 0; i < jsonSumSquaresPerCentroid.size(); i++) {
                sumSquaresPerCentroid.add(jsonSumSquaresPerCentroid.get(i).asDouble());
            }

            byte[] bArrayDistanceOp = Base64.getDecoder().decode(jsonNode.get("distance-op").asText().getBytes("UTF-8"));
            ByteArrayInputStream baStreamDistanceOp = new ByteArrayInputStream(bArrayDistanceOp);
            ObjectInputStream oStreamDistanceOp = new ObjectInputStream(baStreamDistanceOp);
            IObjectDistanceCalculator<T> loadedDistanceOp = (IObjectDistanceCalculator<T>) oStreamDistanceOp.readObject();

            List<ObservationCollection<T>> loadedCentroids = KMeansModel.loadCentroids(jsonNode);
            return new ConstraintKMeansModel<>(
                    loadedDistanceOp,
                    loadedCentroids,
                    intraClusterDistancePerCentroid,
                    interClusterDistancePerCentroid,
                    silhouetteCoefficientsPerCentroid,
                    clusterDistributionsPerCentroid,
                    sumSquaresPerCentroid
            );
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

        @Override
    protected void writeCustomFieldsToJSON(JsonGenerator jsonGen) throws IOException {
        //append matcher
        ByteArrayOutputStream baStreamDistanceOp = new ByteArrayOutputStream();
        ObjectOutputStream ooStreamDistanceOp = new ObjectOutputStream(baStreamDistanceOp);
        ooStreamDistanceOp.writeObject(distanceOp);
        ooStreamDistanceOp.close();
        ooStreamDistanceOp.close();
        jsonGen.writeBinaryField("distance-op",baStreamDistanceOp.toByteArray());
    }
}
