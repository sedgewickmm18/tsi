package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold;

public class ItemSetMatchers {
    @Deprecated
    public static <ITEM> ItemSetMatcher<ITEM> firstOccurrence() {
        return new FirstOccurrenceItemSetMatcher<>();
    }

    public static <ITEM> ItemSetMatcher<ITEM> subset(double threshold, MatcherThreshold mt) {
        switch (mt) {
            case PM:
                return new SubSetItemSetMatcherPM<>(threshold);
            case PS:
                return new SubSetItemSetMatcherPS<>(threshold);
            case MS:
                return new SubSetItemSetMatcherMS<>(threshold);
            default:
                throw new TSRuntimeException("Must be one of PM, PS, MS");
        }
    }
}
