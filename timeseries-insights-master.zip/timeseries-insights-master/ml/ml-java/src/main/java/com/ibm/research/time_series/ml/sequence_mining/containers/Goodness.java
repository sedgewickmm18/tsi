/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import java.io.Serializable;

/**
 * This provides goodness metrics on the {@link DiscriminatorySubSequenceModel}, this is placeholder class that keeps the metrics stored.
 * Computation happens in the goodness function defined in {@link DiscriminatorySubSequenceModel}.
 *
 *
 * <p>Created on 8/14/17.</p>
 * @author Joshua Rosenkranz
 */
public class Goodness implements Serializable{
    private static final long serialVersionUID = -5533784411207273532L;

    //todo make these all private, no real need for them to be public

    /**
     * Number of true positives <pre>{@code (# in left dataset with score >= threshold)}</pre>
     */
    public final long tp;
    /**
     * Number of false positives <pre>{@code (# in right dataset with score < threshold)}</pre>
     */
    public final long fp;
    /**
     * Number of true negatives <pre>{@code (# in left dataset with score < threshold)}</pre>
     */
    public final long tn;
    /**
     * Number of false negatves <pre>{@code (# in right dataset with score >= threshold)}</pre>
     */
    public final long fn;
    /**
     * Precision of left dataset <pre>{@code (tp / total # in left dataset)}</pre>
     */
    public final double precisionLeft;
    /**
     * Precision of right dataset <pre>{@code (tn / total # in right dataset)}</pre>
     */
    public final double precisionRight;
    /**
     * False alarm rate of left dataset <pre>{@code (fn / (tp + fn))}</pre>
     */
    public final double falseAlarmRateLeft;
    /**
     * False alarm rate of right dataset <pre>{@code (fp / (tn + fp))}</pre>
     */
    public final double falseAlarmRateRight;
    /**
     * Probability without using scoring function <pre>{@code (total # in left dataset / (total # in left dataset + total # in right dataset))}</pre>
     */
    public final double oddsBeforeScore;
    /**
     * Probability with using scoring function <pre>{@code (tp / (tp + fn))}</pre>
     */
    public final double oddsAfterScore;

    /**
     * Percentage of the sequences covered by at least one subsequence in the model (over the left input training data)
     */
    public final double coverageLeft;

    /**
     * Percentage of the sequences covered by at least one subsequence in the model (over the right input training data)
     */
    public final double coverageRight;

    /**
     * Construct a model goodness object
     * @param tp                  Number of true positives <pre>{@code (# in left dataset with score >= threshold)}</pre>
     * @param fp                  Number of false positives <pre>{@code (# in right dataset with score < threshold)}</pre>
     * @param tn                  Number of true negatives <pre>{@code (# in left dataset with score < threshold)}</pre>
     * @param fn                  Number of false negatves <pre>{@code (# in right dataset with score >= threshold)}</pre>
     * @param precisionLeft       Precision of left dataset <pre>{@code (tp / total # in left dataset)}</pre>
     * @param precisionRight      Precision of right dataset <pre>{@code (tn / total # in right dataset)}</pre>
     * @param falseAlarmRateLeft  False alarm rate of left dataset <pre>{@code (fn / (tp + fn))}</pre>
     * @param falseAlarmRateRight False alarm rate of right dataset <pre>{@code (fp / (tn + fp))}</pre>
     * @param oddsBeforeScore     Probability without using scoring function
     *                            <pre>{@code (total # in left dataset / (total # in left dataset + total # in right dataset))}</pre>
     * @param oddsAfterScore      Probability with using scoring function <pre>{@code (tp / (tp + fn))}</pre>
     * @param coverageLeft        Percentage of the sequences covered by at least one subsequence in the model (over the left input training data)
     * @param coverageRight       Percentage of the sequences covered by at least one subsequence in the model (over the right input training data)
     */
    public Goodness(
            long tp,
            long fp,
            long tn,
            long fn,
            double precisionLeft,
            double precisionRight,
            double falseAlarmRateLeft,
            double falseAlarmRateRight,
            double oddsBeforeScore,
            double oddsAfterScore,
            double coverageLeft,
            double coverageRight) {
        this.tp = tp;
        this.fp = fp;
        this.tn = tn;
        this.fn = fn;
        this.precisionLeft = precisionLeft;
        this.precisionRight = precisionRight;
        this.falseAlarmRateLeft = falseAlarmRateLeft;
        this.falseAlarmRateRight = falseAlarmRateRight;
        this.oddsBeforeScore = oddsBeforeScore;
        this.oddsAfterScore = oddsAfterScore;
        this.coverageLeft = coverageLeft;
        this.coverageRight = coverageRight;
    }

    public long getTp() {
        return tp;
    }

    public long getFp() {
        return fp;
    }

    public long getTn() {
        return tn;
    }

    public long getFn() {
        return fn;
    }

    public double precisionLeft() {
        return precisionLeft;
    }

    public double precisionRight() {
        return precisionRight;
    }

    public double falseAlarmRateLeft() {
        return falseAlarmRateLeft;
    }

    public double falseAlarmRateRight() {
        return falseAlarmRateRight;
    }

    public double oddsBeforeScore() {
        return oddsBeforeScore;
    }

    public double oddsAfterScore() {
        return oddsAfterScore;
    }

    public double coverageLeft() {
        return coverageLeft;
    }

    public double coverageRight() {
        return coverageRight;
    }

    /**
     * @return A human readable String representation of the goodness metrics for a given model
     */
    @Override
    public String toString() {
        return new StringBuilder()
                .append("true positive: ").append(tp).append("\n")
                .append("false positive: ").append(fp).append("\n")
                .append("true negative: ").append(tn).append("\n")
                .append("false negative: ").append(fn).append("\n")
                .append("precision left: ").append(precisionLeft).append("\n")
                .append("precision right: ").append(precisionRight).append("\n")
                .append("false alarm rate left: ").append(falseAlarmRateLeft).append("\n")
                .append("false alarm rate right: ").append(falseAlarmRateRight).append("\n")
                .append("odds before score: ").append(oddsBeforeScore).append("\n")
                .append("odds after score: ").append(oddsAfterScore).append("\n")
                .append("coverage left: ").append(coverageLeft).append("\n")
                .append("coverage right: ").append(coverageRight).append("\n")
                .toString();
    }
}