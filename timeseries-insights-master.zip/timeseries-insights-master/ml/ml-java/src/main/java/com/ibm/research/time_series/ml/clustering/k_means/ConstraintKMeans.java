package com.ibm.research.time_series.ml.clustering.k_means;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.ml.clustering.k_means.containers.ConstraintKMeansModel;
import com.ibm.research.time_series.ml.clustering.k_means.functions.WeightedSumFunction;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;
import com.ibm.research.time_series.transforms.reducers.distance.dtw.algorithm.IObjectDistanceCalculator;

import java.io.Serializable;
import java.util.List;

/**
 * ConstraintKMeansModel implementation of a {@link KMeansComputer}
 *
 * ConstraintKMeans uses a distance function that calculates the distance between 2 TimeSeries values
 *
 * @param <V> the observation value type
 */
class ConstraintKMeans<V> extends KMeansComputer<V> implements Serializable{

    /**
     * distance function that calculates the distance between 2 observation values
     */
    private IObjectDistanceCalculator<V> distanceOp;

    /**
     * construct a ConstraintKMeans computer
     * @param distanceOp distance function that calculates the distance between 2 observation values
     */
    ConstraintKMeans(IObjectDistanceCalculator<V> distanceOp) {
        this.distanceOp = distanceOp;
    }

    /**
     * train a {@link ConstraintKMeansModel} given a set of time series and initial centroids
     *
     * @param multiTimeSeries a set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries}
     * @param tsCentroids initial centroids
     * @param weightedSumOp the {@link WeightedSumFunction}
     * @param maxIterations the maximum iterations to run
     * @param minShiftDistance the minimum shift distance
     * @return a new {@link ConstraintKMeansModel}
     */
    ConstraintKMeansModel<V> train(
            MultiTimeSeries<?,V> multiTimeSeries,
            List<ObservationCollection<V>> tsCentroids,
            WeightedSumFunction<V> weightedSumOp,
            int maxIterations,
            double minShiftDistance) {
        List<ObservationCollection<V>> result = performTrain(
                multiTimeSeries,tsCentroids,weightedSumOp,maxIterations,minShiftDistance);

        List<List<Double>> metrics = TimeSeriesClusteringModel.perClusterMetrics(
                multiTimeSeries,
                result,
                (x,y) -> compute(x,y)
        );


        return new ConstraintKMeansModel<>(distanceOp,result,metrics.get(0),metrics.get(1),metrics.get(2),metrics.get(3),metrics.get(4));
    }

    /**
     * ConstrainKMeans implementation of
     * {@link com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer} where for each value in 2
     * {@link ObservationCollection} of the same size, compute the sum of distances between each value
     * @param x first collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @param y second collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @return the total distance between both {@link ObservationCollection}
     */
    @Override
    public Double compute(ObservationCollection<V> x, ObservationCollection<V> y) {
        return x.toTimeSeriesStream().reduce(
                y.toTimeSeriesStream(),
                DistanceReducers.nonTimewarpedDtw(distanceOp)
        );
    }
}
