package com.ibm.research.time_series.ml.clustering.k_shape;

import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

/**
 * interface for shape extraction strategies to be used in Algorithm 2 of
 * http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
 */
interface ShapeExtraction {
    /**
     * Given a matrix, compute a vector that best represents that matrix
     * @param matrix the given matrix to compute shape extraction against
     * @return the vector that is a best possible representation of the matrix
     */
    RealVector apply(RealMatrix matrix);
}
