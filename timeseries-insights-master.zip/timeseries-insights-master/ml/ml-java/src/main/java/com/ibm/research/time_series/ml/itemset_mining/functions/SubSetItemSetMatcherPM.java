package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;

import java.util.HashSet;
import java.util.Set;

public class SubSetItemSetMatcherPM<T> implements ItemSetMatcher<T>{
    private static final long serialVersionUID = 9196082768102438623L;
    private double threshold;

    public SubSetItemSetMatcherPM(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public ObservationCollection<T> matches(ItemSet<T> s1, ObservationCollection<T> s2) {
        //original size of the item set
        final int originalSetSize = s1.size();

        //set of values not found from within the time series initialized to all the values in our item set
        Set<T> notFoundValues = new HashSet<>(s1);

        TSBuilder<T> tsBuilder = Observations.newBuilder();

        int matchCount = 0;

        //for each observation, add to our result if a value is contained in our set or at least one of our values from
        //our item set has already matched
        for (Observation<T> obs : s2) {

            //if our not found values set contains the current observation value, add this observation to the resulting
            //time series and remove this value from our not found values set
            if (notFoundValues.contains(obs.getValue())) {
                tsBuilder.add(obs);
                notFoundValues.remove(obs.getValue());
                matchCount++;

                //once all values are found from within our time series, we are done
                if (notFoundValues.isEmpty()) {
                    break;
                }
                //otherwise, only add to our time series if our not found values set is missing any of its original values
            } else {
                if (originalSetSize != notFoundValues.size()) {
                    matchCount++;
                }
            }
        }

        final ObservationCollection<T> result = tsBuilder.result();

        //only return a time series if all of our values from within the item set have been found at some point in the
        //time series, otherwise return null
        return (notFoundValues.size() == 0 && s1.size() * 1.0 / matchCount * 1.0 >= threshold) ? result : null;
    }

    @Override
    public String toString() {
        return "matcher(type=itemset match_threshold=" + threshold + " threshold_type=pm)";
    }
}
