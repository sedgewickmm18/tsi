package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;


/**
 * An immutable holder class for a frequent ItemSet that has been realized
 *
 * <p>Created on 1/3/18.</p>
 *
 * @param <T> item type
 * @author Joshua Rosenkranz
 */
public class FrequentItemSet<T> implements Serializable, JsonIO {
    private static final long serialVersionUID = -1587877958369649444L;

    /**
     * holding {@link FrequentItemSetStatistics}
     */
    public final FrequentItemSetStatistics statistics;

    /**
     * unique identifier for this FrequentItemSet in the {@link FrequentItemSetModel}
     */
    public final long itemSetID;

    /**
     * holding the {@link ItemSet} for this FrequentItemSet
     */
    public final ItemSet<T> itemSet;

    public FrequentItemSetStatistics statistics() {
        return statistics;
    }

    public long itemSetID() {
        return itemSetID;
    }

    public ItemSet<T> itemSet() {
        return itemSet;
    }

    /**
     * Constructs a {@link FrequentItemSet}
     *
     * @param itemSet Immutable variable, holding the item set
     * @param statistics Immutable variable, holding the item set statistics
     * @param itemSetID Immutable variable, unique id for this FrequentItemSet in the {@link FrequentItemSetModel}
     */
    public FrequentItemSet(ItemSet<T> itemSet, FrequentItemSetStatistics statistics, long itemSetID) {
        this.itemSet = itemSet;
        this.statistics = statistics;
        this.itemSetID = itemSetID;
    }

    /**
     * @return a String representation of this Frequent ItemSet
     */
    @Override
    public String toString() {
        return "frequent-item-set(" + "\n" +
                "\t" + "item-set-id=" + itemSetID + "\n" +
                "\t" + "statistics=" + "frequent-item-set-statistics(" + "\n" +
                "\t\t" + "duration-statistics=" + "duration-statistics(" + "\n" +
                "\t\t\tmin=" + statistics.durationStatistics.min + "\n" +
                "\t\t\tmax=" + statistics.durationStatistics.max + "\n" +
                "\t\t\tsum=" + statistics.durationStatistics.sum + "\n" +
                "\t\t\tavg=" + statistics.durationStatistics.average + "\n" +
                "\t\t\tvariance=" + statistics.durationStatistics.variance + "\n" +
                "\t\t\tsd=" + statistics.durationStatistics.sd + "\n" +
                "\t\t\tmin-lead-time=" + statistics.durationStatistics.minLeadTime + "\n" +
                "\t\t\tmax-lead-time=" + statistics.durationStatistics.maxLeadTime + "\n" +
                "\t\t\tsum-lead-time=" + statistics.durationStatistics.sumLeadTime + "\n" +
                "\t\t\tavg-lead-time=" + statistics.durationStatistics.averageLeadTime + "\n" +
                "\t\t\tvariance-lead-time=" + statistics.durationStatistics.varianceLeadTime + "\n" +
                "\t\t\tsd-lead-time=" + statistics.durationStatistics.sdLeadTime + "\n" +
                "\t\t\tmin-end-time=" + statistics.durationStatistics.minEndTime + "\n" +
                "\t\t\tmax-end-time=" + statistics.durationStatistics.maxEndTime + "\n" +
                "\t\t\tsum-end-time=" + statistics.durationStatistics.sumEndTime + "\n" +
                "\t\t\tavg-end-time=" + statistics.durationStatistics.averageEndTime + "\n" +
                "\t\t\tvariance-end-time=" + statistics.durationStatistics.varianceEndTime + "\n" +
                "\t\t\tsd-end-time=" + statistics.durationStatistics.sdEndTime + "\n" +
                "\t\t" + ")" + "\n" +
                "\t\t" + "original-size=" + statistics.originalSize + "\n" +
                "\t\t" + "binary-match-norm-frequency=" + statistics.binaryMatchNormFrequency + "\n" +
                "\t\t" + "multi-match-norm-frequency=" + statistics.multiMatchNormFrequency + "\n" +
                "\t\t" + "coverage=" + statistics.coverage() + "\n" +
                "\t)\n" +
                "\t" + "item-set=" + itemSet.toString() + "\n" +
                ")";
    }

    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();

        //append the sequence id
        jsonGen.writeNumberField("set-id", itemSetID);

        //append freq-seq-statistics object;
        statistics.writeJson(jsonGen);

        itemSet.writeJson(jsonGen);

        jsonGen.writeEndObject();
    }

    static <T> FrequentItemSet<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        long sequenceID = jsonNode.get("set-id").asLong();

        FrequentItemSetStatistics frequentSequenceStatistics = FrequentItemSetStatistics.fromJson(jsonNode);

        ItemSet<T> itemSet = ItemSet.fromJson(jsonNode);

        return new FrequentItemSet<>(itemSet,frequentSequenceStatistics,sequenceID);
    }
}
