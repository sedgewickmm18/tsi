/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.Base64;

/**
 * <p>Created on 8/29/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public interface SequenceMatcher<T> extends Serializable, JsonIO {
    ObservationCollection<ItemSet<T>> matches(ItemSetSequence<T> s1, ObservationCollection<ItemSet<T>> s2);

    @Override
    default void writeJson(JsonGenerator jsonGen) throws IOException {
        ByteArrayOutputStream baStreamMatcher = new ByteArrayOutputStream();
        ObjectOutputStream ooStreamMatcher = new ObjectOutputStream(baStreamMatcher);
        ooStreamMatcher.writeObject(this);
        ooStreamMatcher.close();
        ooStreamMatcher.close();
        jsonGen.writeBinaryField("matcher", baStreamMatcher.toByteArray());

    }

    static <T> SequenceMatcher<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        byte[] bArrayMatcher = Base64.getDecoder().decode(jsonNode.get("matcher").asText().getBytes("UTF-8"));
        ByteArrayInputStream baStreamMatcher = new ByteArrayInputStream(bArrayMatcher);
        ObjectInputStream oStreamMatcher = new ObjectInputStream(baStreamMatcher);
        return (SequenceMatcher<T>)oStreamMatcher.readObject();
    }
}
