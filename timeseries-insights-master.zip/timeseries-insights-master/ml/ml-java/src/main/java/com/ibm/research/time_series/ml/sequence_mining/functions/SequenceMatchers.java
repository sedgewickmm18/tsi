/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold;

/**
 * <p>Created on 8/29/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class SequenceMatchers {
    public static <T> SequenceMatcher<T> seq() {
        return new ExactSequenceMatcher<>();
    }

    public static <T> SequenceMatcher<T> subseq(double threshold, MatcherThreshold mt) {
        switch (mt) {
            case PM:
                return new SubSeqSequenceMatcherPM<>(threshold);
            case PS:
                return new SubSeqSequenceMatcherPS<>(threshold);
            case MS:
                return new SubSeqSequenceMatcherMS<>(threshold);
            default:
                throw new TSRuntimeException("Must be one of PM, PS, MS");
        }
    }

    public static <T> SequenceMatcher<T> subseq() {
        return subseq(0.0, MatcherThreshold.PS);
    }

    public static <T> SequenceMatcher<T> sublist(double threshold) {
        return new SublistSequenceMatcher<>(threshold);
    }

    public static <T> SequenceMatcher<T> sublist() {
        return sublist(0.0);
    }
}
