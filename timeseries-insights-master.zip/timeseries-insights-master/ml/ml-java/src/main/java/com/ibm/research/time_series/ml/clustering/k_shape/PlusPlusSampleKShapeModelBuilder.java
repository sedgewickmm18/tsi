package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.k_means.KMeansUtils;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;

import java.util.ArrayList;
import java.util.List;

public class PlusPlusSampleKShapeModelBuilder<KEY> extends KShapeModelBuilder<KEY> {
    private int numClusters;

    /**
     * Construct a PlusPlusKShapeModelBuilder with numCluster clusters initialized using KMeans++ computation of seed
     * centroids
     *
     * @param multiTimeSeries the initial data to mine
     * @param shapeExtraction the shape extraction strategy to be used in the {@link KShapeModelBuilder}
     * @param numClusters the final number of clusters to be created
     */
    PlusPlusSampleKShapeModelBuilder(MultiTimeSeries<KEY, Double> multiTimeSeries, ShapeExtraction shapeExtraction, int numClusters) throws TSException {
        super(multiTimeSeries, shapeExtraction);
        this.numClusters = numClusters;
    }

    @Override
    protected double[][] getInitialClusters() {
        //use seed centroid computation from k-means implementation
        List<ObservationCollection<Double>> seedCentroids = KMeansUtils.computeSeedCentroids(
                multiTimeSeries,
                (x, y) -> Math.abs(x.toTimeSeriesStream().reduce(y.toTimeSeriesStream(), DistanceReducers.sbd())),
                numClusters
        );
        double[][] initialClusters = new double[numClusters][data[0].length];
        for (int i = 0;i < initialClusters.length;i++) {
            List<Observation<Double>> centroid = new ArrayList<>(seedCentroids.get(i).toCollection());
            for (int j = 0;j < initialClusters[i].length;j++) {
                initialClusters[i][j] = centroid.get(j).getValue();
            }
        }
        return initialClusters;
    }

    @Override
    protected int getNumClusters() {
        return numClusters;
    }
}
