package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.InitializationStrategies;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.KShapeModel;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

/**
 * Entry point to creating a {@link KShapeModel}
 */
public class KShape {

    /**
     * create a {@link KShapeModel}
     *
     * Note: In the event that a model cannot be created, this method will return null
     *
     * @param data {@link MultiTimeSeries} to mine for clusters
     * @param kClusters final number of clusters
     * @param numRuns number of runs of clustering
     * @param useEigen uses {@link org.apache.commons.math3.linear.EigenDecomposition} for shape extraction if set to
     *                 true, otherwise uses simple averaging
     * @param initializationStrategies denotes the centroid initialization strategy
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model if one is present, otherwise null
     */
    public static <KEY> KShapeModel run(MultiTimeSeries<KEY,Double> data, int kClusters, int numRuns, boolean useEigen, InitializationStrategies initializationStrategies) throws TSException {
        ShapeExtraction shapeExtraction = (useEigen) ? new EigenShapeExtraction() : new AverageShapeExtraction();

        KShapeModelBuilder<KEY> modelBuilder = null;
        switch (initializationStrategies) {
            case Zero:
                modelBuilder = new ZeroKShapeModelBuilder<>(data,shapeExtraction,kClusters);
                break;
            case Random:
                modelBuilder = new RandomSampleKShapeModelBuilder<>(data,shapeExtraction,kClusters);
                break;
            case PlusPlus:
                modelBuilder = new PlusPlusSampleKShapeModelBuilder<>(data,shapeExtraction,kClusters);
                break;
            default:
                throw new TSException("no initialization strategy was given");
        }

        return chooseBestModel(modelBuilder,numRuns);
    }

    /**
     * create a {@link KShapeModel} given see centroids. The number of seed centroids given will be the resulting number
     * of clusters.
     *
     * @param data {@link MultiTimeSeries} to mine for clusters
     * @param seedCentroids seed centroids
     * @param numRuns number of runs of clustering
     * @param useEigen uses {@link org.apache.commons.math3.linear.EigenDecomposition} for shape extraction if set to
     *                 true, otherwise uses simple averaging
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model
     */
    public static <KEY> KShapeModel runWithSeed(
            MultiTimeSeries<KEY,Double> data,
            List<ObservationCollection<Double>> seedCentroids,
            int numRuns,
            boolean useEigen) throws TSException {
        ShapeExtraction shapeExtraction = (useEigen) ? new EigenShapeExtraction() : new AverageShapeExtraction();

        KShapeModelBuilder<KEY> modelBuilder = new InitializedKShapeModelBuilder<>(data,shapeExtraction,seedCentroids);

        return chooseBestModel(modelBuilder,numRuns);
    }

    /**
     * create a {@link KShapeModel} using a pre-existing initialized K-Shape model
     *
     * initial seed centroids will be set to the pre-existing initialized K-Shape model centroids
     *
     * @param data {@link MultiTimeSeries} to mine for clusters
     * @param model pre-existing K-Shape model
     * @param useEigen uses {@link org.apache.commons.math3.linear.EigenDecomposition} for shape extraction if set to
     *                 true, otherwise uses simple averaging
     * @param numRuns number of runs of clustering
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model if one is present, otherwise null
     */
    public static <KEY> KShapeModel update(MultiTimeSeries<KEY,Double> data,KShapeModel model,boolean useEigen, int numRuns) throws TSException {
        ShapeExtraction shapeExtraction = (useEigen) ? new EigenShapeExtraction() : new AverageShapeExtraction();

        KShapeModelBuilder<KEY> modelBuilder = new InitializedKShapeModelBuilder<>(data,shapeExtraction,model.centroids);

        return chooseBestModel(modelBuilder,numRuns);
    }

    /**
     * create a {@link KShapeModel} using a pre-existing initialized K-Shape model
     *
     * initial seed centroids will be set to the pre-existing initialized K-Shape model centroids
     *
     * @param data {@link MultiTimeSeries} to mine for clusters
     * @param model pre-existing K-Shape model
     * @param useEigen uses {@link org.apache.commons.math3.linear.EigenDecomposition} for shape extraction if set to
     *                 true, otherwise uses simple averaging
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model if one is present, otherwise null
     */
    public static <KEY> KShapeModel update(MultiTimeSeries<KEY,Double> data,KShapeModel model,boolean useEigen) throws TSException {
        return update(data,model,useEigen,2);
    }

    /**
     * create a {@link KShapeModel} using a pre-existing initialized K-Shape model
     *
     * initial seed centroids will be set to the pre-existing initialized K-Shape model centroids
     *
     * @param data {@link MultiTimeSeries} to mine for clusters
     * @param model pre-existing K-Shape model
     *
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model if one is present, otherwise null
     */
    public static <KEY> KShapeModel update(MultiTimeSeries<KEY,Double> data,KShapeModel model) throws TSException {
        return update(data,model,true);
    }

    /**
     * create a best guess {@link KShapeModel} given a range of k-cluster amounts.
     *
     * This method will perform K-Shape clustering for each value of k in range maxK to minK and then will choose the
     * best model based on the min sum of square distances of all centroids
     *
     * Note: In the event that a model cannot be created, this method will return null
     *
     * @param multiTimeSeries {@link MultiTimeSeries} to mine for clusters
     * @param numRuns number of runs of clustering
     * @param maxK max clusters to check
     * @param minK min clusters to check
     * @param useEigen uses {@link org.apache.commons.math3.linear.EigenDecomposition} for shape extraction if set to
     *                 true, otherwise uses simple averaging
     * @param initializationStrategies denotes the centroid initialization strategy
     * @param <KEY> MultiTimeSeries key type
     * @return an initialized K-Shape Model if one is present, otherwise null
     */
    public static <KEY> KShapeModel explore(
            MultiTimeSeries<KEY,Double> multiTimeSeries,
            int numRuns,
            int maxK,
            int minK,
            boolean useEigen,
            InitializationStrategies initializationStrategies) throws TSException {
        KShapeModel result = IntStream.rangeClosed(minK,maxK).mapToObj(k -> {
            System.out.println("run clustering for " + k + " clusters!");
            try {
                return run(multiTimeSeries,k,numRuns,useEigen,initializationStrategies);
            } catch (TSException e) {
                e.printStackTrace();
                return null;
            }
        })
                .filter(Objects::nonNull)
                .min(Comparator.comparing(x -> IntStream.range(0,x.centroids.size()).mapToDouble(x.sumSquares::get).sum()))
                .orElse(null);
        if (result == null) {
            throw new TSException("Could not determine best KShape Model");
        } else {
            return result;
        }
    }


    /**
     * choose the best {@link KShapeModel} for numRuns iterations of KShape
     *
     * todo may want to use different metric for this
     * The best model is defined as the model with the min sum of square distances of all centroids
     *
     * @param keykShapeModelBuilder a {@link KShapeModelBuilder}
     * @param numRuns number of runs of KShape to perform
     * @param <KEY> TimeSeries key type
     * @return the best KSuhapeModel
     */
    private static <KEY> KShapeModel chooseBestModel(KShapeModelBuilder<KEY> keykShapeModelBuilder, int numRuns) throws TSException{
        KShapeModel result = IntStream.range(0,numRuns).parallel().mapToObj(index -> {
            KShapeModel model;
            try {
                model = keykShapeModelBuilder.build();
            } catch (Exception e) {
                model = null;
            }
            return model;
        })
                .filter(Objects::nonNull)
                .min(Comparator.comparing(x -> IntStream.range(0,x.centroids.size()).mapToDouble(x.sumSquares::get).sum()))
                .orElse(null);

        if (result == null) {
            throw new TSException("Could not determine best KShape Model");
        } else {
            return result;
        }
    }
}
