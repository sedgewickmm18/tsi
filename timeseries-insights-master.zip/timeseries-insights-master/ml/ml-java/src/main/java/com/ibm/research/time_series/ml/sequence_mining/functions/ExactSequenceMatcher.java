/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * <p>Created on 8/29/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ExactSequenceMatcher<T> implements SequenceMatcher<T>{
    private static final long serialVersionUID = 7125527164648749792L;

    @Override
    public ObservationCollection<ItemSet<T>> matches(
            ItemSetSequence<T> freqSeq,
            ObservationCollection<ItemSet<T>> series) {
        if (freqSeq.itemsets.size() != series.size())
            return null;

        TSBuilder<ItemSet<T>> matches = Observations.newBuilder();
        final Iterator<ItemSet<T>> freqSeqItemIter = freqSeq.itemsets.iterator();
        for (Observation<ItemSet<T>> obs : series) {
            final ItemSet<T> next = freqSeqItemIter.next();
            if (obs.getValue().equals(next)) {
                matches.add(obs);
            } else {
                break;
            }
        }

        ObservationCollection<ItemSet<T>> result = matches.result();

        if (freqSeq.itemsets.size() != result.size()) {
            return null;
        } else {
            return result;
        }
    }

    @Override
    public String toString() {
        return "matcher(type=exact)";
    }
}
