package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.Collections;
import java.util.List;

public class PythonListMatcher {
    private SequenceMatcher<Object> sequenceMatcher;
    private ObservationCollection<ItemSet<Object>> isSeries;

    public PythonListMatcher(SequenceMatcher<Object> sequenceMatcher, ObservationCollection<List<Object>> series) {
        this.sequenceMatcher = sequenceMatcher;
        this.isSeries = series.toTimeSeriesStream().map(x -> new ItemSet<>(x)).collect();
    }

    public ObservationCollection<List<Object>> matches(ItemSetSequence<Object> itemSetSequence) {
        ObservationCollection<ItemSet<Object>> matches = sequenceMatcher.matches(itemSetSequence, isSeries);
        if (matches == null) {
            return null;
        } else {
            return matches.toTimeSeriesStream().map(i -> (List<Object>)i).collect();
        }
    }
}
