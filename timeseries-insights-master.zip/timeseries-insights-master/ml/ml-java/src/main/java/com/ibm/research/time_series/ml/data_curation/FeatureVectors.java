package com.ibm.research.time_series.ml.data_curation;

import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.SegmentTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.*;
import java.util.stream.Collectors;

public class FeatureVectors {
    public static <T, LABEL> List<LabeledPoint<List<List<T>>,List<T>>> preparePython(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            UnaryMapFunction<Segment<List<T>>, List<Number>> labelValueOp,
            UnaryMapFunction<Segment<List<T>>, List<Number>> featureOp,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        return prepare(
                dataTS,
                labelTS,
                labelOp,
                leftDelta.longValue(),
                rightDelta.longValue(),
                s -> {
                    final List<Number> evaluate = labelValueOp.evaluate(s);
                    return new Pair<>(evaluate.get(0).longValue(),evaluate.get(1).longValue());
                },
                s -> {
                    final List<Number> evaluate = featureOp.evaluate(s);
                    return new Pair<>(evaluate.get(0).longValue(),evaluate.get(1).longValue());
                },
                positivePerc,
                negitivePerc,
                withReplacement
        );
    }

    public static <T, LABEL> List<LabeledPoint<Boolean,List<T>>> preparePython(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            UnaryMapFunction<Segment<List<T>>, List<Number>> featureOp,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        return prepare(
                dataTS,
                labelTS,
                labelOp,
                leftDelta.longValue(),
                rightDelta.longValue(),
                s -> {
                    final List<Number> evaluate = featureOp.evaluate(s);
                    return new Pair<>(evaluate.get(0).longValue(),evaluate.get(1).longValue());
                },
                positivePerc,
                negitivePerc,
                withReplacement
        );
    }

    public static <T, LABEL> List<LabeledPoint<Boolean,List<T>>> preparePython(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        return prepare(
                dataTS,
                labelTS,
                labelOp,
                leftDelta.longValue(),
                rightDelta.longValue(),
                positivePerc,
                negitivePerc,
                withReplacement
        );
    }


    public static <T, LABEL> List<LabeledPoint<Boolean,List<T>>> prepare(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            double positivePerc,
            double negativePerc,
            boolean withReplacement) {
        return prepare(dataTS,labelTS,labelOp,leftDelta,rightDelta,null,positivePerc,negativePerc,withReplacement);
    }

    public static <T, LABEL> List<LabeledPoint<Boolean,List<T>>> prepare(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> featureVectorOp,
            double positivePerc,
            double negativePerc,
            boolean withReplacement) {
        final Set<Long> positiveSegmentTimes = labelTS.filter(labelOp).collect().stream().map(x -> x.getTimeTick()).collect(Collectors.toSet());
        final Set<Long> negativeSegmentTimes = labelTS
                .flatMapObservation(o -> {
                    if (positiveSegmentTimes.contains(o.getTimeTick())) return Collections.emptyList();
                    if (withReplacement) {
                        return Collections.singletonList(o);
                    } else {
                        if (positiveSegmentTimes.stream().anyMatch(l -> o.getTimeTick() >= l - leftDelta && o.getTimeTick() <= l + rightDelta))
                            return Collections.emptyList();
                        else
                            return Collections.singletonList(o);
                    }
                })
                .collect()
                .stream()
                .map(Observation::getTimeTick)
                .collect(Collectors.toSet());

        final List<LabeledPoint<Boolean, List<T>>> positiveLabels = dataTS.mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                .segmentByAnchor(p -> positiveSegmentTimes.contains(p.left), leftDelta, rightDelta, positivePerc)
                .mapSegments(p -> p.right)
                .map(segment -> {
                    if (featureVectorOp == null) {
                        return new LabeledPoint<>(true,segment.stream().map(o -> o.getValue()).collect(Collectors.toList()));
                    } else {
                        Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                        List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                .stream()
                                .map(x -> x.getValue())
                                .collect(Collectors.toList());

                        return new LabeledPoint<>(true, feature);
                    }
                })
                .collect()
                .stream()
                .map(Observation::getValue)
                .collect(Collectors.toList());

        final List<LabeledPoint<Boolean, List<T>>> negativeLabels = dataTS.mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                .segmentByAnchor(p -> negativeSegmentTimes.contains(p.left), leftDelta, rightDelta, negativePerc)
                .mapSegments(p -> p.right)
                .map(segment -> {
                    if (featureVectorOp == null) {
                        return new LabeledPoint<>(false,segment.stream().map(o -> o.getValue()).collect(Collectors.toList()));
                    } else {
                        Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                        List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                .stream()
                                .map(x -> x.getValue())
                                .collect(Collectors.toList());

                        return new LabeledPoint<>(false, feature);
                    }
                })
                .collect()
                .stream()
                .map(Observation::getValue)
                .collect(Collectors.toList());

        List<LabeledPoint<Boolean,List<T>>> result = new ArrayList<>(positiveLabels.size() + negativeLabels.size());
        result.addAll(positiveLabels);
        result.addAll(negativeLabels);
        return result;
    }

    public static <T, LABEL> List<LabeledPoint<List<List<T>>,List<T>>> prepare(
            TimeSeries<List<T>> dataTS,
            TimeSeries<LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> labelValueOp,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> featureVectorOp,
            double positivePerc,
            double negativePerc,
            boolean withReplacement
            ) {
        final Set<Long> positiveSegmentTimes = labelTS.filter(labelOp).collect().stream().map(x -> x.getTimeTick()).collect(Collectors.toSet());
        final Set<Long> negativeSegmentTimes = labelTS
                .flatMapObservation(o -> {
                    if (positiveSegmentTimes.contains(o.getTimeTick())) return Collections.emptyList();
                    if (withReplacement) {
                        return Collections.singletonList(o);
                    } else {
                        if (positiveSegmentTimes.stream().anyMatch(l -> o.getTimeTick() >= l - leftDelta && o.getTimeTick() <= l + rightDelta))
                            return Collections.emptyList();
                        else
                            return Collections.singletonList(o);
                    }
                })
                .collect()
                .stream()
                .map(Observation::getTimeTick)
                .collect(Collectors.toSet());



        final List<LabeledPoint<List<List<T>>, List<T>>> positiveLabels = dataTS.mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                .segmentByAnchor(p -> positiveSegmentTimes.contains(p.left), leftDelta, rightDelta, positivePerc)
                .mapSegments(p -> p.right)
                .map(segment -> {
                    Pair<Long, Long> labelRange = labelValueOp.evaluate(segment);
                    Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                    List<List<T>> label = segment.subSet(labelRange.left, true, labelRange.right, true)
                            .stream()
                            .map(x -> x.getValue())
                            .collect(Collectors.toList());

                    List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                            .stream()
                            .map(x -> x.getValue())
                            .collect(Collectors.toList());


                    return new LabeledPoint<>(label, feature);
                })
                .collect()
                .stream()
                .map(Observation::getValue)
                .collect(Collectors.toList());

        final List<LabeledPoint<List<List<T>>, List<T>>> negativeLabels = dataTS.mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                .segmentByAnchor(p -> negativeSegmentTimes.contains(p.left), leftDelta, rightDelta, negativePerc)
                .mapSegments(p -> p.right)
                .map(segment -> {
                    Pair<Long, Long> labelRange = labelValueOp.evaluate(segment);
                    Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                    List<List<T>> label = segment.subSet(labelRange.left, true, labelRange.right, true)
                            .stream()
                            .map(x -> x.getValue())
                            .collect(Collectors.toList());

                    List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                            .stream()
                            .map(x -> x.getValue())
                            .collect(Collectors.toList());


                    return new LabeledPoint<>(label, feature);
                })
                .collect()
                .stream()
                .map(Observation::getValue)
                .collect(Collectors.toList());

        List<LabeledPoint<List<List<T>>,List<T>>> result = new ArrayList<>(positiveLabels.size() + negativeLabels.size());
        result.addAll(positiveLabels);
        result.addAll(negativeLabels);
        return result;
    }







//    public static List<LabeledPoint<List<Double>>> prepare(TimeSeries<List<Double>> ts, )

    //beginning and end of feature vector
    //beginning and end of label
//    public static List<LabeledPoint<Boolean>> prepare(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double positivePerc,
//            double negativePerc) {
//
//        final List<LabeledPoint<Boolean>> positive = produceFeatureVectors(ts,anchor,leftDelta,rightDelta,positivePerc,true);
//
//        final List<LabeledPoint<Boolean>> negative = produceFeatureVectors(ts,v -> !anchor.evaluate(v),leftDelta,rightDelta,negativePerc,false);
//
//        List<LabeledPoint<Boolean>> result = new ArrayList<>(positive.size() + negative.size());
//        result.addAll(positive);
//        result.addAll(negative);
//        return result;
//    }

//    public static List<LabeledPoint<Boolean>> prepare(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double positivePerc,
//            double negativePerc,
//            boolean withReplacement) {
//
//        final SegmentTimeSeries<List<Double>> positiveSegments = ts.segmentByAnchor(anchor, leftDelta, rightDelta, positivePerc);
//
//        final Set<Pair<Long, Long>> startEndSet = positiveSegments.collect().stream().map(o -> new Pair<>(o.getValue().start, o.getValue().end)).collect(Collectors.toSet());
//
//        List<LabeledPoint<Boolean>> positiveLabels = positiveSegments
//                .map(segment -> {
//                    List<Double> featureVector = new ArrayList<>();
//                    for (Observation<List<Double>> obs : segment) {
//                        featureVector.addAll(obs.getValue());
//                    }
//                    return new LabeledPoint<>(true, featureVector);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//
//        List<LabeledPoint<Boolean>> negativeLabels = ts.segmentByAnchor(x -> !anchor.evaluate(x),leftDelta,rightDelta,negativePerc)
//                .filter(s -> {
//                    if (withReplacement) return true;
//                    if (s.isEmpty()) return false;
//                    return startEndSet.stream().allMatch(p -> {
//                        return (s.first().getTimeTick() < p.left || s.first().getTimeTick() > p.right) &&
//                                (s.last().getTimeTick() < p.left || s.last().getTimeTick() > p.right);
//                    });
//                })
//                .map(segment -> {
//                    List<Double> featureVector = new ArrayList<>();
//                    for (Observation<List<Double>> obs : segment) {
//                        featureVector.addAll(obs.getValue());
//                    }
//                    return new LabeledPoint<>(false, featureVector);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//
//        List<LabeledPoint<Boolean>> result = new ArrayList<>(positiveLabels.size() + negativeLabels.size());
//        result.addAll(positiveLabels);
//        result.addAll(negativeLabels);
//        return result;
//    }
//
//    public static List<LabeledPoint<Boolean>> prepare(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double positivePerc,
//            double negativePerc,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> labelOp,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> featureOp,
//            boolean withReplacement) {
//
//        final SegmentTimeSeries<List<Double>> positiveSegments = ts.segmentByAnchor(anchor, leftDelta, rightDelta, positivePerc);
//
//        final Set<Pair<Long, Long>> startEndSet = positiveSegments.collect().stream().map(o -> new Pair<>(o.getValue().start, o.getValue().end)).collect(Collectors.toSet());
//
//        List<LabeledPoint<List<Double>>> positiveLabels = positiveSegments
//                .map(segment -> {
//                    Pair<Long,Long> labelRange = labelOp.evaluate(segment);
//                    Pair<Long,Long> featureRange = featureOp.evaluate(segment);
//
//                    List<Double> label = segment.subSet(labelRange.left, true, labelRange.right, true)
//                            .stream()
//                            .flatMap(x -> x.getValue().stream())
//                            .collect(Collectors.toList());
//
//                    List<Double> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
//                            .stream()
//                            .flatMap(x -> x.getValue().stream())
//                            .collect(Collectors.toList());
//
//
//                    return new LabeledPoint<>(label,feature);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//
//        List<LabeledPoint<Boolean>> negativeLabels = ts.segmentByAnchor(x -> !anchor.evaluate(x),leftDelta,rightDelta,negativePerc)
//                .filter(s -> {
//                    if (withReplacement) return true;
//                    if (s.isEmpty()) return false;
//                    return startEndSet.stream().allMatch(p -> {
//                        return (s.first().getTimeTick() < p.left || s.first().getTimeTick() > p.right) &&
//                                (s.last().getTimeTick() < p.left || s.last().getTimeTick() > p.right);
//                    });
//                })
//                .map(segment -> {
//                    List<Double> featureVector = new ArrayList<>();
//                    for (Observation<List<Double>> obs : segment) {
//                        featureVector.addAll(obs.getValue());
//                    }
//                    return new LabeledPoint<>(false, featureVector);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//
//        List<LabeledPoint<Boolean>> result = new ArrayList<>(positiveLabels.size() + negativeLabels.size());
//        result.addAll(positiveLabels);
//        result.addAll(negativeLabels);
//        return result;
//    }
//
//    public static List<LabeledPoint<List<Double>>> prepare(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double positivePerc,
//            double negativePerc,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> labelOp,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> featureOp) {
//        final List<LabeledPoint<List<Double>>> positive = produceFeatureVectors(ts,anchor,leftDelta,rightDelta,positivePerc,labelOp,featureOp,true);
//
//        final List<LabeledPoint<List<Double>>> negative = produceFeatureVectors(ts,v -> !anchor.evaluate(v),leftDelta,rightDelta,negativePerc,labelOp,featureOp,false);
//
//        List<LabeledPoint<List<Double>>> result = new ArrayList<>(positive.size() + negative.size());
//        result.addAll(positive);
//        result.addAll(negative);
//        return result;
//    }
//
//    public static List<LabeledPoint<List<Double>>> preparePython(
//            TimeSeries<List<Number>> ts,
//            FilterFunction<List<Number>> anchor,
//            Number leftDelta,
//            Number rightDelta,
//            double positivePerc,
//            double negitivePerc,
//            UnaryMapFunction<Segment<List<Number>>, List<Number>> labelOp,
//            UnaryMapFunction<Segment<List<Number>>, List<Number>> featureOp) {
//
//        ts.cache();
//
//        return prepare(
//                ts.map(x -> x.stream().map(Number::doubleValue).collect(Collectors.toList())),
//                l -> anchor.evaluate(l.stream().map(x -> (Number) x).collect(Collectors.toList())),
//                leftDelta.longValue(),
//                rightDelta.longValue(),
//                positivePerc,
//                negitivePerc,
//                x -> {
//                    List<Number> result = labelOp.evaluate(Segment.fromSeries(
//                            x.start,
//                            x.end,
//                            TimeSeries.list(
//                                    x.stream().map(l -> {
//                                        return new Observation<>(l.getTimeTick(), (l.getValue().stream().map(y -> (Number) y).collect(Collectors.toList())));
//                                    }).collect(Collectors.toList()),
//                                    r -> r.getTimeTick()
//                            ).map(r -> r.getValue()).collect()
//                    ));
//                    return new Pair<>(result.get(0).longValue(), result.get(1).longValue());
//                },
//                x -> {
//                    List<Number> result = featureOp.evaluate(Segment.fromSeries(
//                            x.start,
//                            x.end,
//                            TimeSeries.list(
//                                    x.stream().map(l -> {
//                                        return new Observation<>(l.getTimeTick(), (l.getValue().stream().map(y -> (Number) y).collect(Collectors.toList())));
//                                    }).collect(Collectors.toList()),
//                                    r -> r.getTimeTick()
//                            ).map(r -> r.getValue()).collect()
//                    ));
//                    return new Pair<>(result.get(0).longValue(), result.get(1).longValue());
//                }
//        );
//
//
//    }
//
//    public static List<LabeledPoint<Boolean>> preparePython(
//            TimeSeries<List<Number>> ts,
//            FilterFunction<List<Number>> anchor,
//            Number leftDelta,
//            Number rightDelta,
//            double positivePerc,
//            double negitivePerc) {
//
//        ts.cache();
//
//        return prepare(
//                ts.map(x -> x.stream().map(Number::doubleValue).collect(Collectors.toList())),
//                l -> anchor.evaluate(l.stream().map(x -> (Number) x).collect(Collectors.toList())),
//                leftDelta.longValue(),
//                rightDelta.longValue(),
//                positivePerc,
//                negitivePerc
//        );
//    }
//
//    private static List<LabeledPoint<List<Double>>> produceFeatureVectors(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double perc,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> labelOp,
//            UnaryMapFunction<Segment<List<Double>>, Pair<Long, Long>> featureOp,
//            boolean posOrNeg) {
//        return ts.segmentByAnchor(anchor, leftDelta, rightDelta, perc)
//                .map(segment -> {
//                    Pair<Long,Long> labelRange = labelOp.evaluate(segment);
//                    Pair<Long,Long> featureRange = featureOp.evaluate(segment);
//
//                    List<Double> label = segment.subSet(labelRange.left, true, labelRange.right, true)
//                            .stream()
//                            .flatMap(x -> x.getValue().stream())
//                            .collect(Collectors.toList());
//
//                    List<Double> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
//                            .stream()
//                            .flatMap(x -> x.getValue().stream())
//                            .collect(Collectors.toList());
//
//
//                    return new LabeledPoint<>(label,feature);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//    }
//
//    private static List<LabeledPoint<Boolean>> produceFeatureVectors(
//            TimeSeries<List<Double>> ts,
//            FilterFunction<List<Double>> anchor,
//            long leftDelta,
//            long rightDelta,
//            double perc,
//            boolean posOrNeg) {
//        return ts.segmentByAnchor(anchor, leftDelta, rightDelta, perc)
//                .map(segment -> {
//                    List<Double> featureVector = new ArrayList<>();
//                    for (Observation<List<Double>> obs : segment) {
//                        featureVector.addAll(obs.getValue());
//                    }
//                    return new LabeledPoint<>(posOrNeg, featureVector);
//                })
//                .collect()
//                .stream()
//                .map(Observation::getValue)
//                .collect(Collectors.toList());
//    }
}
