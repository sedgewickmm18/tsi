package com.ibm.research.time_series.ml.clustering.graph.containers;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.KShapeModel;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class GraphClusteringModel extends TimeSeriesClusteringModel<Double> {
    /**
     * construct a TimeSeriesClusteringModel
     *
     * @param centroids              list of {@link ObservationCollection} that denote a list of centroid time series
     * @param intraClusterDistances  the average distance from the second closest centroid for each point
     *                               grouped by its closest centroid
     * @param interClusterDistances  the average between all points in a cluster from its cluster center
     * @param silhouetteCoefficients for each cluster,
     *                               (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     * @param clusterDistributions   for each cluster,
     *                               (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     * @param sumSquares             for each cluster, the sum of squared distances from a point to its cluster centrer
     */
    public GraphClusteringModel(List<ObservationCollection<Double>> centroids, List<Double> intraClusterDistances, List<Double> interClusterDistances, List<Double> silhouetteCoefficients, List<Double> clusterDistributions, List<Double> sumSquares) {
        super(centroids, intraClusterDistances, interClusterDistances, silhouetteCoefficients, clusterDistributions, sumSquares);
    }

    @Override
    protected double computeDistance(ObservationCollection<Double> ts1, ObservationCollection<Double> ts2) {
        return 0;
    }

    @Override
    protected void writeObservationValueToJSON(JsonGenerator jsonGen, Double value) throws IOException {
        jsonGen.writeNumberField("value",value);
    }

    @Override
    protected void writeCustomFieldsToJSON(JsonGenerator jsonGen) throws IOException {

    }

    public static GraphClusteringModel load(InputStream inputStream) {
        String jsonString;
        try {
            jsonString = IOUtils.toString(inputStream,"UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            List<Double> intraClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonIntraDistancePerCluster = jsonNode.get("intra-cluster-distance-per-centroid");
            for (int i = 0;i < jsonIntraDistancePerCluster.size();i++) {
                intraClusterDistancePerCentroid.add(jsonIntraDistancePerCluster.get(i).asDouble());
            }

            List<Double> interClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonInterDistancePerCluster = jsonNode.get("inter-cluster-distance-per-centroid");
            for (int i = 0;i < jsonInterDistancePerCluster.size();i++) {
                interClusterDistancePerCentroid.add(jsonInterDistancePerCluster.get(i).asDouble());
            }

            List<Double> silhouetteCoefficientsPerCentroid = new ArrayList<>();
            JsonNode jsonSilhouetteCoefficientsPerCluster = jsonNode.get("silhouette-coefficients-per-centroid");
            for (int i = 0;i < jsonSilhouetteCoefficientsPerCluster.size();i++) {
                silhouetteCoefficientsPerCentroid.add(jsonSilhouetteCoefficientsPerCluster.get(i).asDouble());
            }

            List<Double> clusterDistributionsPerCentroid = new ArrayList<>();
            JsonNode jsonClusterDistributionsPerCentroid = jsonNode.get("cluster-distributions-per-centroid");
            for (int i = 0;i < jsonClusterDistributionsPerCentroid.size();i++) {
                clusterDistributionsPerCentroid.add(jsonClusterDistributionsPerCentroid.get(i).asDouble());
            }

            List<Double> sumSquarePerCentroid = new ArrayList<>();
            JsonNode jsonSumSquarePerCentroid = jsonNode.get("sum-square-per-centroid");
            for (int i = 0;i < jsonSumSquarePerCentroid.size();i++) {
                sumSquarePerCentroid.add(jsonSumSquarePerCentroid.get(i).asDouble());
            }

            JsonNode jsonClusters = jsonNode.get("centroids");

            List<ObservationCollection<Double>> clusters = new ArrayList<>();

            for (int i = 0;i < jsonClusters.size();i++) {
                JsonNode jsonCluster = jsonClusters.get(i);
                TSBuilder<Double> tsBuilder = Observations.newBuilder();
                for (int j = 0;j < jsonCluster.size();j++) {
                    JsonNode jsonObservation = jsonCluster.get(j);
                    tsBuilder.add(new Observation<>(jsonObservation.get("timestamp").asLong(),jsonObservation.get("value").asDouble()));
                }

                clusters.add(tsBuilder.result());
            }

            inputStream.close();

            return new GraphClusteringModel(
                    clusters,
                    intraClusterDistancePerCentroid,
                    interClusterDistancePerCentroid,
                    silhouetteCoefficientsPerCentroid,
                    clusterDistributionsPerCentroid,
                    sumSquarePerCentroid
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new GraphClusteringModel(new ArrayList<>(),null,null,null,null, null);
    }
}
