package com.ibm.research.time_series.ml.clustering.k_shape;

import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

/**
 * Implementation of ShapeExtraction that uses Eigen Decomposition to produce a vector from a matrix.
 *
 * This implementation is what is described in the paper
 * http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf for Algorithm 2
 */
class EigenShapeExtraction implements ShapeExtraction{
    @Override
    public RealVector apply(RealMatrix matrix) {
        RealMatrix S = matrix.transpose().multiply(matrix);
        RealMatrix I = MatrixUtils.createRealIdentityMatrix(S.getRowDimension());

        double[][] onesData = new double[S.getRowDimension()][S.getColumnDimension()];
        for (int i = 0;i < onesData.length;i++) {
            for (int j = 0;j < onesData[i].length;j++) {
                onesData[i][j] = 1.0;
            }
        }

        RealMatrix O = MatrixUtils.createRealMatrix(onesData);
        RealMatrix Q = I.add(O.scalarMultiply(-1.0 / matrix.getColumnDimension()));
        RealMatrix M = Q.transpose().multiply(S).multiply(Q);
        for (int i = 0;i < M.getRowDimension();i++) {
            for (int j = i + 1;j < M.getColumnDimension();j++) {
                M.setEntry(i,j,M.getEntry(j,i));
            }
        }
        EigenDecomposition ed = new EigenDecomposition(M);

        return ed.getEigenvector(0);
    }
}
