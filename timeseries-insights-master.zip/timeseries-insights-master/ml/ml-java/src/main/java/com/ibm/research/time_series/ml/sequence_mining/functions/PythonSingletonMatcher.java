package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.Collections;

class PythonSingletonMatcher {
    private SequenceMatcher<Object> sequenceMatcher;
    private ObservationCollection<ItemSet<Object>> isSeries;

    public PythonSingletonMatcher(SequenceMatcher<Object> sequenceMatcher, ObservationCollection<Object> series) {
        this.sequenceMatcher = sequenceMatcher;
        this.isSeries = series.toTimeSeriesStream().map(x -> new ItemSet<>(Collections.singletonList(x))).collect();
    }

    public ObservationCollection<Object> matches(ItemSetSequence<Object> itemSetSequence) {
        ObservationCollection<ItemSet<Object>> matches = sequenceMatcher.matches(itemSetSequence, isSeries);
        if (matches == null) {
            return null;
        } else {
            return matches.toTimeSeriesStream().map(x -> x.get(0)).collect();
        }
    }
}
