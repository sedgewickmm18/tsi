/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class provides various statistics on the DSM subsequence, this is associated with a DSM subsequence.
 * Statistics range from (1) Coverage, (2) Lift, (3) Inter-arrival
 * statistics (which can be used to analyze time spent between transitions from one element to another in the subsequence.
 *
 * All immutable variables can be accessed as public variables, e.g. dssStatistics.originalSizeLeft
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DiscriminatorySubSequenceStatistics implements Serializable,Comparable<DiscriminatorySubSequenceStatistics>, JsonIO{
    private static final Logger logger = Logger.getLogger(DiscriminatorySubSequenceStatistics.class);
    private static final long serialVersionUID = 7696166473408255486L;
    //todo make these all private, no real need for them to be public
    /**
     * indicating the number of sequences in L-set that match the DSM subsequence
     */
    public final long originalSizeLeft;
    /**
     * indicating the number of sequences in R-set that match the DSM subsequence
     */
    public final long originalSizeRight;
    /**
     * indicating the ratio of match to the L-set (# matches / total # of subsequences)
     */
    public final long binaryMatchNormalizedFrequencyLeft;
    /**
     * indicating the ratio of match to the R-set (# matches / total # of subsequences)
     */
    public final long binaryMatchNormalizedFrequencyRight;
    /**
     * Inter-arrival statistics (timing) for the DSM subsequence
     */
    public final List<InterArrivalStatistics> interArrivalStatistics;

    /**
     * The lift for each subset from 0th position of the sequence to every position of the sequence.
     */
    public final List<Double> lifts;

    /**
     * Construct a Discriminatory Sequence Statistics
     *
     * @param originalSizeLeft Immutable variable, indicating the number of sequences in L-set that match the DSM subsequence
     * @param originalSizeRight Immutable variable, indicating the number of sequences in R-set that match the DSM subsequence
     * @param binaryMatchNormalizedFrequencyLeft Immutable variable, indicating the ratio of match to the L-set (# matches / total # of subsequences)
     * @param binaryMatchNormalizedFrequencyRight Immutable variable, indicating the ratio of match to the R-set (# matches / total # of subsequences)
     * @param interArrivalStatistics Inter-arrival statistics (timing) for the DSM subsequence
     * @param lifts lifts at each point in the sequence
     */
    public DiscriminatorySubSequenceStatistics(
            long originalSizeLeft,
            long originalSizeRight,
            long binaryMatchNormalizedFrequencyLeft,
            long binaryMatchNormalizedFrequencyRight,
            List<InterArrivalStatistics> interArrivalStatistics,
            List<Double> lifts) {
        this.originalSizeLeft = originalSizeLeft;
        this.originalSizeRight = originalSizeRight;
        this.binaryMatchNormalizedFrequencyLeft = binaryMatchNormalizedFrequencyLeft;
        this.binaryMatchNormalizedFrequencyRight = binaryMatchNormalizedFrequencyRight;
        this.interArrivalStatistics = interArrivalStatistics;
        this.lifts = lifts;
    }

    public List<Double> lifts() {
        return lifts;
    }

    public long originalSizeLeft() {
        return originalSizeLeft;
    }

    public long originalSizeRight() {
        return originalSizeRight;
    }

    public long binaryMatchNormalizedFrequencyLeft() {
        return binaryMatchNormalizedFrequencyLeft;
    }

    public long binaryMatchNormalizedFrequencyRight() {
        return binaryMatchNormalizedFrequencyRight;
    }

    public List<InterArrivalStatistics> interArrivalStatistics() {
        return interArrivalStatistics;
    }

    /**
     * @return The coverage of the L-set for the DSM subsequence.
     */
    public double coverageLeft() {
        return binaryMatchNormalizedFrequencyLeft * 1.0 / originalSizeLeft * 1.0;
    }

    /**
     * @return The coverage of the R-set the DSM subsequence.
     */
    public double coverageRight() {
        return binaryMatchNormalizedFrequencyRight * 1.0 / originalSizeRight * 1.0;
    }

    /**
     * @return Lift, a measure indicating how many times the DSM subsequence is more likely to occur
     *         in L-set than R-set.
     */
    public double lift() {
        return coverageLeft() / coverageRight();
    }

    /**
     * @return A string representation of this statistics.
     */
    @Override
    public String toString() {
        return "discriminatory-sub-sequence-statistics(" + "\n" +
                "\t" + "inter-arrival-statistics=" + ((interArrivalStatistics != null) ? "(\n" + interArrivalStatistics.stream().map(x -> "\t\t" + x.toString()).collect(Collectors.joining("\n")) + "\n\t)\n" : "None\n") +
                "\t" + "original-size-left=" + originalSizeLeft + "\n" +
                "\t" + "original-size-right=" + originalSizeRight + "\n" +
                "\t" + "binary-match-norm-frequency-left=" + binaryMatchNormalizedFrequencyLeft + "\n" +
                "\t" + "binary-match-norm-frequency-right=" + binaryMatchNormalizedFrequencyRight + "\n" +
                "\t" + "coverage-left=" + coverageLeft() + "\n" +
                "\t" + "coverage-right=" + coverageRight() + "\n" +
                "\t" + "lift=" + lift() + "\n" +
                "\t" + "lift-sequence=" + ((lifts != null) ? lifts.stream().map(x -> x.toString()).collect(Collectors.joining(",","[","]")) : "lift sequence not supported by this model") + "\n" +
                ")";
    }

    @Override
    public int compareTo(DiscriminatorySubSequenceStatistics o) {
        return Double.compare(lift(), o.lift());
    }

    @Override
    public int hashCode() {
        return Long.hashCode(originalSizeLeft) +
                Long.hashCode(originalSizeRight) +
                Long.hashCode(binaryMatchNormalizedFrequencyLeft) +
                Long.hashCode(binaryMatchNormalizedFrequencyRight) +
                interArrivalStatistics.stream().mapToInt(Object::hashCode).sum();
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return false;
        }

        if(o == this){
            return true;
        }

        if (!(o instanceof DiscriminatorySubSequenceStatistics)) {
            return false;
        }

        DiscriminatorySubSequenceStatistics other = (DiscriminatorySubSequenceStatistics)o;

        if (other.binaryMatchNormalizedFrequencyLeft != binaryMatchNormalizedFrequencyLeft) return false;
        if (other.binaryMatchNormalizedFrequencyRight != binaryMatchNormalizedFrequencyRight) return false;
        if (other.originalSizeLeft != originalSizeLeft) return false;
        if (other.originalSizeRight != originalSizeRight) return false;
        if (!other.interArrivalStatistics.equals(interArrivalStatistics)) return false;
        return true;
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeNumberField("coverage-left", coverageLeft());
        jsonGen.writeNumberField("coverage-right", coverageRight());
        jsonGen.writeNumberField(
                "binary-match-normalized-frequency-left",
                binaryMatchNormalizedFrequencyLeft
        );
        jsonGen.writeNumberField(
                "binary-match-normalized-frequency-right",
                binaryMatchNormalizedFrequencyRight
        );
        jsonGen.writeNumberField("original-size-left", originalSizeLeft);
        jsonGen.writeNumberField("original-size-right", originalSizeRight);
        jsonGen.writeNumberField("lift", lift());

        if (lifts != null) {
            jsonGen.writeFieldName("lifts");
            jsonGen.writeStartArray();
            for (double l : lifts()) {
                jsonGen.writeNumber(l);
            }
            jsonGen.writeEndArray();
        }

        jsonGen.writeFieldName("inter-arrival-statistics");
        jsonGen.writeStartArray();
        for (InterArrivalStatistics interArrivalStatistics : interArrivalStatistics) {
            interArrivalStatistics.writeJson(jsonGen);
        }
        jsonGen.writeEndArray();
    }

    static DiscriminatorySubSequenceStatistics fromJson(JsonNode seqObj) {
        int binFreqLeft = seqObj.get("binary-match-normalized-frequency-left").asInt();
        int binFreqRight = seqObj.get("binary-match-normalized-frequency-right").asInt();
        long originalSizeLeft = seqObj.get("original-size-left").asLong();
        long originalSizeRight = seqObj.get("original-size-right").asLong();
        List<Double> lifts = new ArrayList<>();
        if (seqObj.has("lifts")) {
            final JsonNode liftsNode = seqObj.get("lifts");
            for (int j = 0; j < liftsNode.size(); j++) {
                lifts.add(liftsNode.get(j).asDouble());
            }
        } else {
            lifts = null;
            logger.warn("This model did not contain lift sequences, so therefore will not support that functionality");
        }

        //get our inter arrival statistics
        JsonNode interArrivalStatistics = seqObj.get("inter-arrival-statistics");
        List<InterArrivalStatistics> iasList = new ArrayList<>();
        for (int j = 0;j < interArrivalStatistics.size();j++) {
            JsonNode iasObject = interArrivalStatistics.get(j);
            iasList.add(InterArrivalStatistics.fromJson(iasObject));
        }

        return new DiscriminatorySubSequenceStatistics(
                originalSizeLeft,
                originalSizeRight,
                binFreqLeft,
                binFreqRight,
                iasList,
                lifts
        );
    }
}
