package com.ibm.research.time_series.ml.clustering.k_means.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.io.Serializable;

/**
 * Interface for computing the distance between 2 {@link ObservationCollection} to be used in
 * {@link com.ibm.research.time_series.ml.clustering.k_means.containers.ConstraintKMeansModel} and
 * {@link com.ibm.research.time_series.ml.clustering.k_means.containers.NonConstraintKMeansModel} construction
 *
 * @param <T> observation value type
 */
public interface DistanceComputer<T> extends Serializable{
    /**
     * given 2 {@link ObservationCollection}, compute the distance. ex: DTW distance, SBD distance, etc.
     *
     * @param x first collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @param y second collection of {@link com.ibm.research.time_series.core.observation.Observation}
     * @return a double representing the distance between both collection of Observations
     */
    Double compute(ObservationCollection<T> x,ObservationCollection<T> y);
}
