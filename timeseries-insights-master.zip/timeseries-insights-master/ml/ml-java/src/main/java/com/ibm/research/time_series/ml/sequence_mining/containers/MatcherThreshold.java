package com.ibm.research.time_series.ml.sequence_mining.containers;

public enum MatcherThreshold {
    PM, PS, MS
}
