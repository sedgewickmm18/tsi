/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

/**
 * Deeper statistics for a given frequent subsequence.
 *
 * All immutable variables can be accessed as public variables, e.g., fsStats.interArrivalStatistics
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FrequentSubSequenceStatistics implements Serializable, Comparable<FrequentSubSequenceStatistics>, JsonIO{
    private static final long serialVersionUID = -6573335567270886190L;
    //todo make these all private, no real need for them to be public

    /**
     * the number of time series on which these statistics were computed
     */
    public final long originalSize;

    /**
     * represents inter arrival statistics, [[InterArrivalStatistics]]
     */
    public final List<InterArrivalStatistics> interArrivalStatistics;
    /**
     * provides the total number of matches given a set of sequences and a subsequence, with one
     * sequence possibly matching a subsequence multiple times.
     */
    public final long multiMatchNormFrequency;
    /**
     * Immutable variable, provides the total number of matches given a set of sequences and a
     * subsequence, where multiple matches to a sequence is counted as only one.
     */
    public final long binaryMatchNormFrequency;

    /**
     * @param originalSize the number of time series on which these statistics were computed
     * @param interArrivalStatistics Immutable variable, represents inter arrival statistics, [[InterArrivalStatistics]]
     * @param multiMatchNormFrequency Immutable variable, provides the total number of matches given a set of sequences
     *                               and a subsequence, with one sequence possibly matching a subsequence multiple times.
     * @param binaryMatchNormFrequency Immutable variable, provides the total number of matches given a set of sequences
     *                                and a subsequence, where multiple matches to a sequence is counted as only one.
     */
    public FrequentSubSequenceStatistics(
            long originalSize,
            List<InterArrivalStatistics> interArrivalStatistics,
            long multiMatchNormFrequency,
            long binaryMatchNormFrequency) {
        this.originalSize = originalSize;
        this.interArrivalStatistics = interArrivalStatistics;
        this.multiMatchNormFrequency = multiMatchNormFrequency;
        this.binaryMatchNormFrequency = binaryMatchNormFrequency;
    }

    /**
     * @return the coverage for this given statistics model
     */
    public double coverage() {
        return binaryMatchNormFrequency * 1.0 / originalSize;
    }

    public long originalSize() {
        return originalSize;
    }

    public List<InterArrivalStatistics> interArrivalStatistics() {
        return interArrivalStatistics;
    }

    public long multiMatchNormFrequency() {
        return multiMatchNormFrequency;
    }

    public long binaryMatchNormFrequency() {
        return binaryMatchNormFrequency;
    }


    public FrequentSubSequenceStatistics update(FrequentSubSequenceStatistics other) {
        if (interArrivalStatistics == null) {
            return new FrequentSubSequenceStatistics(
                    other.originalSize,
                    other.interArrivalStatistics,
                    other.multiMatchNormFrequency,
                    other.binaryMatchNormFrequency
            );
        } else {
            List<InterArrivalStatistics> iasList = new ArrayList<>();
            for (int i = 0;i < interArrivalStatistics.size();i++) {
                iasList.add(interArrivalStatistics.get(i).update(other.interArrivalStatistics.get(i)));
            }
            return new FrequentSubSequenceStatistics(
                    originalSize,
                    iasList,
                    multiMatchNormFrequency + other.multiMatchNormFrequency,
                    binaryMatchNormFrequency + other.binaryMatchNormFrequency
            );
        }
    }

    /**
     * @return A string representation of the frequent sequence statistics
     */
    @Override
    public String toString() {
        return "frequent-sub-sequence-statistics(" + "\n" +
                "\t" + "inter-arrival-statistics=" + ((interArrivalStatistics != null) ? "(\n" + interArrivalStatistics.stream().map(x -> "\t\t" + x.toString()).collect(Collectors.joining("\n")) + "\n\t)\n" : "None\n") +
                "\t" + "original-size=" + originalSize + "\n" +
                "\t" + "multi-match-norm-frequency=" + multiMatchNormFrequency + "\n" +
                "\t" + "binary-match-norm-frequency=" + binaryMatchNormFrequency + "\n" +
                "\t" + "coverage=" + coverage() + "\n" +
                ")";
    }

    @Override
    public int compareTo(FrequentSubSequenceStatistics o) {
        return Double.compare(this.coverage(),o.coverage());
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        //append freq-seq-statistics object;
        jsonGen.writeFieldName("frequent-sequence-statistics");
        jsonGen.writeStartObject();

        //append inter-arrival-statistics;
        jsonGen.writeFieldName("inter-arrival-statistics");
        jsonGen.writeStartArray();
        for (InterArrivalStatistics interArrivalStatistics : interArrivalStatistics) {
            interArrivalStatistics.writeJson(jsonGen);
        }
        jsonGen.writeEndArray();

        //append the original size
        jsonGen.writeNumberField("original-size",originalSize);

        //append binary match norm frequency
        jsonGen.writeNumberField(
                "binary-match-norm-frequency",binaryMatchNormFrequency
        );

        //append multi match norm frequency
        jsonGen.writeNumberField("multi-match-norm-frequency",multiMatchNormFrequency);

        jsonGen.writeEndObject();//end frequent-sequence-statistics
    }

    static FrequentSubSequenceStatistics fromJson(JsonNode jsonNode) {
        //get our statistics
        JsonNode statisticsObj = jsonNode.get("frequent-sequence-statistics");

        //get our inter arrival statistics
        JsonNode interArrivalStatistics = statisticsObj.get("inter-arrival-statistics");
        List<InterArrivalStatistics> iasList = new ArrayList<>();
        for (int j = 0;j < interArrivalStatistics.size();j++) {
            JsonNode iasObject = interArrivalStatistics.get(j);
            iasList.add(InterArrivalStatistics.fromJson(iasObject));
        }

        long originalSize = statisticsObj.get("original-size").asLong();
        long binaryMatchNormFrequency = statisticsObj.get("binary-match-norm-frequency").asLong();
        long multiMatchNormFrequency = statisticsObj.get("multi-match-norm-frequency").asLong();

        return new FrequentSubSequenceStatistics(
                originalSize,
                iasList,
                multiMatchNormFrequency,
                binaryMatchNormFrequency
        );
    }
}
