package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;

/**
 * This is a deeper statistics holder class that maintains the duration statistics, where duration statistics is the
 * duration of a given match in a time-series.
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DurationStatistics implements Serializable, JsonIO {
    private static final long serialVersionUID = 6484710762446516961L;

    public final double variance;
    public final double varianceLeadTime;
    public final double varianceEndTime;

    /**
     * minimum duration
     */
    public final long min;

    /**
     * maximum duration
     */
    public final long max;

    /**
     * sum of all durations
     */
    public final long sum;

    /**
     * count of matches
     */
    public final int count;

    public final double average;

    public final double sd;

    public final long minLeadTime;

    public final long maxLeadTime;

    public final long sumLeadTime;

    public final double averageLeadTime;

    public final double sdLeadTime;

    public final long minEndTime;

    public final long maxEndTime;

    public final long sumEndTime;

    public final double averageEndTime;

    public final double sdEndTime;

    public long min() {
        return min;
    }

    public long max() {
        return max;
    }

    public long sum() {
        return sum;
    }

    public int count() {
        return count;
    }

    public double sd() {
        return sd;
    }

    public long minLeadTime() {
        return minLeadTime;
    }

    public long maxLeadTime() {
        return maxLeadTime;
    }

    public long sumLeadTime() {
        return sumLeadTime;
    }

    public double averageLeadTime() {
        return averageLeadTime;
    }

    public double sdLeadTime() {
        return sdLeadTime;
    }

    public long minEndTime() {
        return minEndTime;
    }

    public long maxEndTime() {
        return maxEndTime;
    }

    public long sumEndTime() {
        return sumEndTime;
    }

    public double averageEndTime() {
        return averageEndTime;
    }

    public double sdEndTime() {
        return sdEndTime;
    }

    public double variance() {
        return variance;
    }
    public double varianceLeadTime() {
        return varianceLeadTime;
    }
    public double varianceEndTime() {
        return varianceEndTime;
    }

    /**
     * Constructs a DurationStatistics object
     *
     * @param min minimum duration
     * @param max maximum duration
     * @param sum sum of all durations
     * @param count count of matches
     */
    public DurationStatistics(long min, long max, long sum, int count,double average,double sd,long minLeadTime,long maxLeadTime,long sumLeadTime, double averageLeadTime,double sdLeadTime,long minEndTime,long maxEndTime,long sumEndTime,double averageEndTime, double sdEndTime,double variance,double varianceLeadTime, double varianceEndTime) {
        this.min = min;
        this.max = max;
        this.sum = sum;
        this.count = count;
        this.average = average;
        this.sd = sd;
        this.minLeadTime = minLeadTime;
        this.maxLeadTime = maxLeadTime;
        this.sumLeadTime = sumLeadTime;
        this.averageLeadTime = averageLeadTime;
        this.sdLeadTime = sdLeadTime;
        this.minEndTime = minEndTime;
        this.maxEndTime = maxEndTime;
        this.sumEndTime = sumEndTime;
        this.averageEndTime = averageEndTime;
        this.sdEndTime = sdEndTime;
        this.variance = variance;
        this.varianceLeadTime = varianceLeadTime;
        this.varianceEndTime = varianceEndTime;
    }

    /**
     * Given another DurationStatistics, merge the Duration statistics into a new Duration Statistics object
     *
     * @param duration the other DurationStatistics
     * @return a new DurationStatistics object
     */
    public DurationStatistics update(long duration,long leadTime,long endTime) {

        long newMax = Math.max(max,duration);
        long newMin = Math.min(min,duration);
        long newSum = sum + duration;
        double newMean = ((average * count) + duration) * 1.0 / (count + 1);
        double newVariance = variance + (duration - average) * (duration - newMean);
        double newSD = Math.sqrt(newVariance / count);

        long newMaxLeadTime = Math.max(maxLeadTime,leadTime);
        long newMinLeadTime = Math.min(minLeadTime,leadTime);
        long newSumLeadTime = sumLeadTime + leadTime;
        double newLeadMean = ((averageLeadTime * count) + leadTime) * 1.0 / (count + 1);
        double newLeadVariance = varianceLeadTime + (leadTime - averageLeadTime) * (leadTime - newLeadMean);
        double newLeadSD = Math.sqrt(newLeadVariance / count);

        long newMaxEndTime = Math.max(maxEndTime,endTime);
        long newMinEndTime = Math.min(minEndTime,endTime);
        long newSumEndTime = sumEndTime + endTime;
        double newEndMean = ((averageEndTime * count) + endTime) * 1.0 / (count + 1);
        double newEndVariance = varianceEndTime + (endTime - averageEndTime) * (endTime - newEndMean);
        double newEndSD = Math.sqrt(newEndVariance / count);

        int newCount = count + 1;

        return new DurationStatistics(
                newMin,
                newMax,
                newSum,
                newCount,
                newMean,
                newSD,
                newMinLeadTime,
                newMaxLeadTime,
                newSumLeadTime,
                newLeadMean,
                newLeadSD,
                newMinEndTime,
                newMaxEndTime,
                newSumEndTime,
                newEndMean,
                newEndSD,
                newVariance,
                newLeadVariance,
                newEndVariance
        );
    }

    /**
     * @return the average duration
     */
    public double average() {
        return sum * 1.0 / count;
    }

    /**
     * @return a human readable representation of this class
     */
    @Override
    public String toString() {
        return "duration-statistics(" + "\n" +
                "\tmin=" + min + "\n" +
                "\tmax=" + max + "\n" +
                "\tsum=" + sum + "\n" +
                "\tavg=" + average + "\n" +
                "\tvariance=" + variance + "\n" +
                "\tsd=" + sd + "\n" +
                "\tmin-lead-time=" + minLeadTime + "\n" +
                "\tmax-lead-time=" + maxLeadTime + "\n" +
                "\tsum-lead-time=" + sumLeadTime + "\n" +
                "\tavg-lead-time=" + averageLeadTime + "\n" +
                "\tvariance-lead-time=" + varianceLeadTime + "\n" +
                "\tsd-lead-time=" + sdLeadTime + "\n" +
                "\tmin-end-time=" + minEndTime + "\n" +
                "\tmax-end-time=" + maxEndTime + "\n" +
                "\tsum-end-time=" + sumEndTime + "\n" +
                "\tavg-end-time=" + averageEndTime + "\n" +
                "\tvariance-end-time=" + varianceEndTime + "\n" +
                "\tsd-end-time=" + sdEndTime + "\n" +
                ")";
    }

    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeObjectFieldStart("duration-statistics");
        jsonGen.writeNumberField("min", min);
        jsonGen.writeNumberField("max", max);
        jsonGen.writeNumberField("average", average);
        jsonGen.writeNumberField("variance", variance);
        jsonGen.writeNumberField("standard-deviation", sd);
        jsonGen.writeNumberField("count", count);
        jsonGen.writeNumberField("sum", sum);
        jsonGen.writeNumberField("min-lead-time", minLeadTime);
        jsonGen.writeNumberField("max-lead-time", maxLeadTime);
        jsonGen.writeNumberField("sum-lead-time",sumLeadTime);
        jsonGen.writeNumberField("average-lead-time",averageLeadTime);
        jsonGen.writeNumberField("variance-lead-time",varianceLeadTime);
        jsonGen.writeNumberField("standard-deviation-lead-time",sdLeadTime);
        jsonGen.writeNumberField("min-end-time", minEndTime);
        jsonGen.writeNumberField("max-end-time", maxEndTime);
        jsonGen.writeNumberField("sum-end-time",sumEndTime);
        jsonGen.writeNumberField("average-end-time",averageEndTime);
        jsonGen.writeNumberField("variance-end-time",varianceEndTime);
        jsonGen.writeNumberField("standard-deviation-end-time",sdEndTime);
        jsonGen.writeEndObject();
    }

    static DurationStatistics fromJson(JsonNode jsonNode) {
        JsonNode lengthObject = jsonNode.get("duration-statistics");
        return new DurationStatistics(
                lengthObject.get("min").asLong(),
                lengthObject.get("max").asLong(),
                lengthObject.get("sum").asLong(),
                lengthObject.get("count").asInt(),
                lengthObject.get("average").asDouble(),
                lengthObject.get("standard-deviation").asDouble(),
                lengthObject.get("min-lead-time").asLong(),
                lengthObject.get("max-lead-time").asLong(),
                lengthObject.get("sum-lead-time").asLong(),
                lengthObject.get("average-lead-time").asDouble(),
                lengthObject.get("standard-deviation-lead-time").asDouble(),
                lengthObject.get("min-end-time").asLong(),
                lengthObject.get("max-end-time").asLong(),
                lengthObject.get("sum-end-time").asLong(),
                lengthObject.get("average-end-time").asDouble(),
                lengthObject.get("standard-deviation-end-time").asDouble(),
                lengthObject.get("variance").asDouble(),
                lengthObject.get("variance-lead-time").asDouble(),
                lengthObject.get("variance-end-time").asDouble()
        );
    }
}
