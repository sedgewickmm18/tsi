package com.ibm.research.time_series.ml.ggm;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.BinaryReducer;
import com.ibm.research.time_series.transforms.reducers.math.MathReducers;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularValueDecomposition;

import java.util.Arrays;

public class GraphicalGaussianModel {
	public static RealMatrix compute(MultiTimeSeries<Integer, Double> mts, BinaryReducer<Double, Double, Double> reducer, int numSingularValues, double threshold) {
        RealMatrix covarianceMatrix = CovarianceMatrix.compute(mts, reducer);
        return compute(covarianceMatrix, numSingularValues, threshold);
	}

	public static RealMatrix compute(RealMatrix covarianceMatrix, int numSingularValues, double threshold) {
        SingularValueDecomposition svd = new SingularValueDecomposition(covarianceMatrix);
        return compute(svd, numSingularValues, threshold);
    }

    public static RealMatrix compute(SingularValueDecomposition svd, int numSingularValues, double threshold) {
        RealMatrix U = svd.getU();
        RealMatrix S = svd.getS().copy();
        RealMatrix Vt = svd.getVT();

        //set the rest of it to 0
        for(int i = numSingularValues; i < S.getColumnDimension(); i++) {
            S.setEntry(i, i, 0);
        }

        RealMatrix result = U.multiply(S).multiply(Vt);
        return binarize(result, threshold);
    }

    public static RealMatrix binarize(RealMatrix covarianceMatrix, double threshold) {
	    for(int i = 0; i < covarianceMatrix.getRowDimension(); i++) {
	        for(int j = 0; j < covarianceMatrix.getColumnDimension(); j++) {
	            covarianceMatrix.setEntry(i, j, Math.abs(covarianceMatrix.getEntry(i, j)) >= threshold ? 1 : 0);
            }
        }

        return covarianceMatrix;
    }

	public static void main(String[] args) {
		TimeSeries<Double> ts1 = TimeSeries.list(Arrays.asList(1.0, 2.0, 3.0));
		TimeSeries<Double> ts2 = TimeSeries.list(Arrays.asList(3.0, 4.0, 5.0));
		TimeSeries<Double> ts3 = TimeSeries.list(Arrays.asList(6.0, 5.0, 4.0));
				
		MultiTimeSeries<Integer, Double> mts = MultiTimeSeries.fromTimeSeriesList(Arrays.asList(ts1, ts2, ts3));

		RealMatrix depMatrix = GraphicalGaussianModel.compute(mts, MathReducers.correlation(), 1, 0.9);
		System.out.println(depMatrix);
	}
}
