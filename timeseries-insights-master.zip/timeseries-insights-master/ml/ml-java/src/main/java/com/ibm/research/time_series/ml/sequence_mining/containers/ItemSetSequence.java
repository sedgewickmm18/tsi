/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;


import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A holder class for each subsequence.
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ItemSetSequence<T> implements Serializable, JsonIO{
    private static final long serialVersionUID = -239830333002298080L;

    //todo make these all private, no real need for them to be public

    /**
     * the itemsets that exist within this sequence
     */
    public final List<ItemSet<T>> itemsets;

    /**
     * Construct an ItemSetSequence object
     * @param itemsets the itemsets to be wrapped in this seqeunce
     */
    public ItemSetSequence(List<ItemSet<T>> itemsets) {
        this.itemsets = itemsets;
    }

    /**
     * @return the itemsets that exist within this sequence
     */
    public List<ItemSet<T>> itemsets() {
        return itemsets;
    }

    /**
     * @return human readable representation of ItemSetSequence
     */
    @Override
    public String toString() {
        return itemsets.stream().map(i ->
                i.stream().map(Object::toString).collect(Collectors.joining(",","[","]"))
        ).collect(Collectors.joining(",","[","]"));
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeFieldName("itemsets");
        jsonGen.writeStartArray();

        for (ItemSet<T> frequentItemSet : itemsets) {
            jsonGen.writeStartObject();
            jsonGen.writeFieldName("items");
            jsonGen.writeStartArray();

            for (T item : frequentItemSet) {
                ByteArrayOutputStream baStream = new ByteArrayOutputStream();
                ObjectOutputStream ooStream = new ObjectOutputStream(baStream);
                ooStream.writeObject(item);
                ooStream.close();
                baStream.close();
                jsonGen.writeBinary(baStream.toByteArray());
            }
            jsonGen.writeEndArray();
            jsonGen.writeEndObject();
        }
        jsonGen.writeEndArray();
    }

    static <T> ItemSetSequence<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        JsonNode itemSets = jsonNode.get("itemsets");
        List<ItemSet<T>> sequences = new ArrayList<>();
        for (int j = 0;j < itemSets.size();j++) {
            JsonNode items = itemSets.get(j).get("items");
            List<T> sequence = new ArrayList<>();
            for (int k = 0;k < items.size();k++) {
                byte[] bArray = Base64.getDecoder().decode((items.get(k).asText()).getBytes("UTF-8"));
                ByteArrayInputStream baStream = new ByteArrayInputStream(bArray);
                ObjectInputStream oStream = new ObjectInputStream(baStream);
                sequence.add((T)oStream.readObject());
            }
            sequences.add(new ItemSet<>(sequence));
        }
        return new ItemSetSequence<>(sequences);
    }
}
