package com.ibm.research.time_series.ml.clustering.k_means;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.transform.UnaryReducer;
import com.ibm.research.time_series.core.utils.*;
import com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer;
import com.ibm.research.time_series.ml.clustering.k_means.functions.WeightedSumFunction;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * a set of utilities that are used through the KMeans clustering implementation on TimeSeries data
 */
public class KMeansUtils {

    /**
     * For a list of centroids, produce a function {@link UnaryReducer} where for a given segment(time series)
     * {@link TimeSeries}, a distance is produced, which is the minimum distance centroid from the given
     * segment(time series)
     *
     * @param centroids list of centroids to check distances against a TimeSeries
     * @return a {@link UnaryReducer} where for a given segment(time series) in a {@link TimeSeries}, a minimum distance
     * is produced
     */
    private static <T> UnaryReducer<T, Pair<Double, ObservationCollection<T>>> minDistance(
            List<ObservationCollection<T>> centroids,
            DistanceComputer<T> distanceOp) {

        return new UnaryReducer<T, Pair<Double, ObservationCollection<T>>>() {
            @Override
            public Pair<Double, ObservationCollection<T>> reduceSegment(Segment<T> segment) {
                double minDistance = centroids.stream()
                        .mapToDouble(centroid -> distanceOp.compute(centroid,segment))
                        .min()
                        .getAsDouble();

                return new Pair<>(minDistance,segment);
            }
        };
    }

    /**
     * Given 2 series, compute a new centroid using a {@link WeightedSumFunction}
     *
     * @param series1 first TimeSeries
     * @param series2 second TimeSeries
     * @param series1Weight first TimeSeries weight
     * @param series2Weight second TimeSeries weight
     * @param weightedSumOp the {@link WeightedSumFunction}
     * @param <T> the observation value type
     * @return a new centroid that is the product of the {@link WeightedSumFunction}
     */
    public static <T> ObservationCollection<T> computeNewCentroid(
            ObservationCollection<T> series1,
            ObservationCollection<T> series2,
            double series1Weight,
            double series2Weight,
            WeightedSumFunction<T> weightedSumOp) {

        //matches our weighted field function to each pair of observations at a given index from
        //ts1 and ts2... This will produce a new observation
        List<Observation<T>> list1 = new ArrayList<>(series1.toCollection());
        List<Observation<T>> list2 = new ArrayList<>(series2.toCollection());
        TSBuilder<T> tsBuilder = Observations.newBuilder();
        for (int i = 0;i < series1.size();i++) {
            Observation<T> obs1 = list1.get(i);
            Observation<T> obs2 = list2.get(i);
            //given 2 values and their corresponding weights, produce a new value using the given weighted sum function
            tsBuilder.add(
                    obs1.getTimeTick(),
                    weightedSumOp.apply(obs1.getValue(),obs2.getValue(), series1Weight,series2Weight)
            );
        }

        //return the new centroid
        return tsBuilder.result();
    }

    /**
     * compute numCentroids initial centroids given our set of TimeSeries and our distance computer
     *
     * Step0: create our initial list of centroids with IDs
     * Step1: take a random sample from our initial list of centroids to use as a seed
     * Step2: annotate each record in the input with a min distance to the current list of centroids
     * Step3: sum all of our min distances
     * Step4: select a record with probability = (min distance) / (agg distance) ...until a valid record is found
     *
     * @param multiTimeSeries the set of TimeSeries to mine for centroids
     * @param distanceOp the {@link DistanceComputer}
     * @param numCentroids the final number of centroids
     * @param <V> the observation value type
     * @return a list of seed centroids (numCentroid size)
     */
    public static <V> List<ObservationCollection<V>> computeSeedCentroids(
            MultiTimeSeries<?,V> multiTimeSeries,
            DistanceComputer<V> distanceOp,
            int numCentroids) {
        Random r = new Random();

        //Step0: create our initial list of centroids with IDs
        //create our list of initial centroids
        List<Map.Entry<?, ObservationCollection<V>>> intialTimeSeries  = multiTimeSeries
                .collect()
                .entrySet()
                .parallelStream()
                .collect(Collectors.toList());

        //Step1: take a random sample from our initial list of centroids to use as a seed
        //take a random sample from our initial centroids
        ObservationCollection<V> initial = intialTimeSeries.get(r.nextInt(intialTimeSeries.size())).getValue();

        List<ObservationCollection<V>> centroids = new ArrayList<>();
        centroids.add(initial);

        for (int i = 0;i < numCentroids - 1;i++) {


		    //Step2: annotate each record in the input with a min distance to the current list of centroids
            Map<?,Pair<Double,ObservationCollection<V>>> seriesWithUnNormalizedProbability = multiTimeSeries
                    .reduce(minDistance(centroids,distanceOp));

            //Step3: sum all of our min distances
            //The next centroid is picked with probability proportional to the min distance to the current list of
            //centroids. In order to compute this probability we need the total min distance (to normalize the
            //probability measure).
            final double finalSummedDistance = seriesWithUnNormalizedProbability
                    .values().stream()
                    .filter(x -> !Double.isNaN(x.left))
                    .mapToDouble(x -> x.left)
                    .sum();

			//Select a record with probability = (min distance) / (agg distance). Note that 0, 1 or more records could
            //be selected in this process
            //We added a check if finalSummedDistance is 0 because if it is 0, the following while loop will become
            //infinite since we are diving by the finalSummedDistance which will result in a NaN and therefore always
            //result in an empty set of samples
            //Note: the sample will remain null if a proper record is not found in the given iteration, in which case
            //      we will continue the process again with a new random number
            ObservationCollection<V> sample = (finalSummedDistance == 0.0)
                    ? seriesWithUnNormalizedProbability.get(r.nextInt(seriesWithUnNormalizedProbability.size() - 1)) .right
                    : null;
            while (sample == null) {
                List<ObservationCollection<V>> observationCollectionList = seriesWithUnNormalizedProbability.entrySet().stream()
                        .flatMap(distAndSeries -> {
                            final double random = Math.random();
                            final double pr = distAndSeries.getValue().left / finalSummedDistance;
                            if (random < pr) {
                                return Stream.of(distAndSeries.getValue().right);
                            } else {
                                return Stream.empty();
                            }
                        })
                        .collect(Collectors.toList());

                //make sure our list has at least 1 value, if it does not, we must repeat the process
                if (observationCollectionList.size() != 0) {
                    //take a random sample
                    ObservationCollection<V> randSample = observationCollectionList
                            .get(r.nextInt(observationCollectionList.size()));

                    sample = (!randSample.isEmpty()) ? randSample : null;
                }
            }

            centroids.add(sample);
        }
        return centroids;
    }
}
