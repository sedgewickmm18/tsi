package com.ibm.research.time_series.ml.clustering.k_shape;

import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

import java.util.stream.DoubleStream;

/**
 * Implementation of ShapeExtraction that for each column of the given matrix, will compute the average over the column
 * and return a matrix of the averages (This is used as a performance boost as opposed to using
 * {@link EigenShapeExtraction} but may reduce accuracy)
 */
class AverageShapeExtraction implements ShapeExtraction{
    @Override
    public RealVector apply(RealMatrix matrix) {
        double[] averaged = new double[matrix.getColumnDimension()];

        for (int i = 0;i < matrix.getColumnDimension();i++) {
            averaged[i] = DoubleStream.of(matrix.getColumn(i)).average().getAsDouble();
        }
        return MatrixUtils.createRealVector(averaged);
    }
}
