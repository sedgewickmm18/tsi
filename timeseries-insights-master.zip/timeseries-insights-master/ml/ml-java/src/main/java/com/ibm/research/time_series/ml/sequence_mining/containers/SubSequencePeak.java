package com.ibm.research.time_series.ml.sequence_mining.containers;


import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class SubSequencePeak<T> implements Serializable, JsonIO {

    private static final long serialVersionUID = -7478315523589001072L;
    public final int numOccurrences;
    public final ItemSetSequence<T> peakSequence;

    public SubSequencePeak(ItemSetSequence<T> peakSequence, int numOccurrences) {
        this.peakSequence = peakSequence;
        this.numOccurrences = numOccurrences;
    }

    public int numOccurreces() {
        return numOccurrences;
    }

    public ItemSetSequence<T> peakSequence() {
        return peakSequence;
    }

    @Override
    public String toString() {
        return "sub-sequence-peak(" + "\n" +
                "\t" + "peak=" + peakSequence.toString() + "\n" +
                "\t" + "occurrences=" + numOccurrences + "\n" +
                ")";
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();
        jsonGen.writeNumberField("num-occurrences", numOccurrences);
        peakSequence.writeJson(jsonGen);
        jsonGen.writeEndObject();
    }

    static <T> SubSequencePeak<T> fromJson(JsonNode peakNode) throws IOException, ClassNotFoundException {
        int numOccurrences = peakNode.get("num-occurrences").asInt();
        ItemSetSequence<T> iss = ItemSetSequence.fromJson(peakNode);
        return new SubSequencePeak<>(iss,numOccurrences);
    }
}
