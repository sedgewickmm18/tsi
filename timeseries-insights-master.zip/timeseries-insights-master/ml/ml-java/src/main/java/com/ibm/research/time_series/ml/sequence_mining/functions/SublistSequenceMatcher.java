package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.List;
import java.util.stream.Collectors;

public class SublistSequenceMatcher<T> implements SequenceMatcher<T> {

    private static final long serialVersionUID = -7598177213526374144L;
    private double threshold;
    public SublistSequenceMatcher(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public ObservationCollection<ItemSet<T>> matches(ItemSetSequence<T> pattern, ObservationCollection<ItemSet<T>> sequence) {

        if (pattern.itemsets.size() * 1.0 / sequence.size() * 1.0 < threshold) return null;

        List<Observation<ItemSet<T>>> obsList = sequence.stream().collect(Collectors.toList());
        //using isList for sublist and obslist to keep the indexes for timeticks
        List<ItemSet<T>> isList = obsList.stream().map(x -> x.getValue()).collect(Collectors.toList());

        for (int i = 0;i < isList.size() - pattern.itemsets.size() + 1;i++) {
            final List<ItemSet<T>> isToMatch = isList.subList(i, i + pattern.itemsets.size());
            if (isToMatch.equals(pattern.itemsets)) {
                TSBuilder<ItemSet<T>> tsBuilder = Observations.newBuilder();
                tsBuilder.addAll(obsList.subList(i,i+pattern.itemsets.size()));
                return tsBuilder.result();
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "matcher(type=sublist)";
    }
}
