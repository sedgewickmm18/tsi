package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.itemset_mining.functions.ItemSetMatcher;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.util.DefaultPrettyPrinter;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Representation of a Frequent ItemSet model
 *
 * Additionally, this provides a scoring function that allows for computing a score, a metric that indicates how well
 * an ItemSet matches this model.
 *
 * <p>Created on 1/3/18.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FrequentItemSetModel<T> implements Serializable {
    private static final long serialVersionUID = -1755366843145814393L;

    /**
     * Immutable variable, a list of all {@link FrequentItemSet}
     */
    public final List<FrequentItemSet<T>> frequentItemSets;

    /**
     * Immutable variable, a sequence matcher function used to generate this {@link FrequentItemSetModel}
     */
    public final ItemSetMatcher<T> itemSetMatcher;

    /**
     * the minSupport used to generate this Frequent ItemSet Model
     */
    public final double minSupport;

    /**
     * time of creation of model
     */
    public final LocalDateTime creationDate;

    public List<FrequentItemSet<T>> frequentItemSets() {
        return frequentItemSets;
    }

    public ItemSetMatcher<T> itemSetMatcher() {
        return itemSetMatcher;
    }

    public double minSupport() {
        return minSupport;
    }

    /**
     * This method allows for loading a frequent item-set model saved to a file. It takes in an InputStream
     * object and returns a {@link FrequentItemSetModel}
     *
     * @param inputStream input stream
     * @param <T> value type
     * @return frequent item-set model
     */
    public static <T> FrequentItemSetModel<T> load(InputStream inputStream) {
        try {
            String jsonString = IOUtils.toString(inputStream,"UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            //get matcher
            ItemSetMatcher<T> matcher = ItemSetMatcher.fromJson(jsonNode);

            LocalDateTime creationDate = LocalDateTime.parse(jsonNode.get("creation-date").asText());
            double minSupport = jsonNode.get("min-support").asDouble();

            List<FrequentItemSet<T>> frequentItemSets = new ArrayList<>();
            JsonNode freqSeq = jsonNode.get("frequent-item-sets");
            for (int i = 0;i < freqSeq.size();i++) {
                frequentItemSets.add(FrequentItemSet.fromJson(freqSeq.get(i)));
            }

            return new FrequentItemSetModel<>(
                    frequentItemSets,
                    matcher,
                    minSupport,
                    creationDate
            );

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Construct a {@link FrequentItemSetModel}
     *
     * @param frequentItemSets Immutable variable, an list of all {@link FrequentItemSet}
     * @param itemSetMatcher Immutable variable, a sequence matcher function used to generate this FrequenceSubSequenceModel
     * @param minSupport Immutable variable, min support used
     * @param creationDate creation date of this model
     */
    public FrequentItemSetModel(
            List<FrequentItemSet<T>> frequentItemSets,
            ItemSetMatcher<T> itemSetMatcher,
            double minSupport,
            LocalDateTime creationDate) {
        this.minSupport = minSupport;
        this.frequentItemSets = frequentItemSets;
        this.itemSetMatcher = itemSetMatcher;
        this.creationDate = creationDate;
    }

    /**
     * Scala version: Given a TimeSeries and a threshold, computes the number of item-sets in this
     * model that match the input series.
     *
     * @param series Input time series to compute the score on
     * @return a score for the given TimeSeries
     */
    public double score(ObservationCollection<T> series) {
        int count = 0;
        for (FrequentItemSet<T> fss : frequentItemSets) {
            if (itemSetMatcher.matches(fss.itemSet,series) != null) {
                count++;
            }
        }

        return count * 1.0 / frequentItemSets.size();
    }

    /**
     * Save this model to an OutputStream. It writes out this model in a JSON format with some
     * components of the model in a serialized form.
     *
     * @param outputStream given outputStream
     */
    public void save(OutputStream outputStream) {
        JsonFactory jsonFactory = new JsonFactory();
        try {
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(outputStream, JsonEncoding.UTF8);

            jsonGen.setPrettyPrinter(new DefaultPrettyPrinter());

            jsonGen.writeStartObject();
            //append min support;
            jsonGen.writeNumberField("min-support", minSupport);
            jsonGen.writeStringField("creation-date",creationDate.toString());

            jsonGen.writeFieldName("frequent-item-sets");
            jsonGen.writeStartArray();
            for (FrequentItemSet<T> fss : frequentItemSets) {
                fss.writeJson(jsonGen);
            }
            jsonGen.writeEndArray();

            //append matcher
            itemSetMatcher.writeJson(jsonGen);

            jsonGen.writeEndObject();
            jsonGen.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @return A string representation of this Frequent ItemSet model, for human readability.
     */
    @Override
    public String toString() {
        String dssList = "None";

        if (!frequentItemSets.isEmpty()) {
            dssList = "(\n" + frequentItemSets.stream().map(dss ->
                    "\t\tfrequent-item-set(" + "\n" +
                            "\t\t\t" + "item-set-id=" + dss.itemSetID + "\n" +
                            "\t\t\t" + "statistics=" + "frequent-item-set-statistics(" + "\n" +
                            "\t\t\t\t" + "duration-statistics=" + "duration-statistics(" + "\n" +
                            "\t\t\t\t\tmin=" + dss.statistics.durationStatistics.min + "\n" +
                            "\t\t\t\t\tmax=" + dss.statistics.durationStatistics.max + "\n" +
                            "\t\t\t\t\tsum=" + dss.statistics.durationStatistics.sum + "\n" +
                            "\t\t\t\t\tavg=" + dss.statistics.durationStatistics.average + "\n" +
                            "\t\t\t\t\tvariance=" + dss.statistics.durationStatistics.variance + "\n" +
                            "\t\t\t\t\tsd=" + dss.statistics.durationStatistics.sd + "\n" +
                            "\t\t\t\t\tmin-lead-time=" + dss.statistics.durationStatistics.minLeadTime + "\n" +
                            "\t\t\t\t\tmax-lead-time=" + dss.statistics.durationStatistics.maxLeadTime + "\n" +
                            "\t\t\t\t\tsum-lead-time=" + dss.statistics.durationStatistics.sumLeadTime + "\n" +
                            "\t\t\t\t\tavg-lead-time=" + dss.statistics.durationStatistics.averageLeadTime + "\n" +
                            "\t\t\t\t\tvariance-lead-time=" + dss.statistics.durationStatistics.varianceLeadTime + "\n" +
                            "\t\t\t\t\tsd-lead-time=" + dss.statistics.durationStatistics.sdLeadTime + "\n" +
                            "\t\t\t\t\tmin-end-time=" + dss.statistics.durationStatistics.minEndTime + "\n" +
                            "\t\t\t\t\tmax-end-time=" + dss.statistics.durationStatistics.maxEndTime + "\n" +
                            "\t\t\t\t\tsum-end-time=" + dss.statistics.durationStatistics.sumEndTime + "\n" +
                            "\t\t\t\t\tavg-end-time=" + dss.statistics.durationStatistics.averageEndTime + "\n" +
                            "\t\t\t\t\tvariance-end-time=" + dss.statistics.durationStatistics.varianceEndTime + "\n" +
                            "\t\t\t\t\tsd-end-time=" + dss.statistics.durationStatistics.sdEndTime + "\n" +
                            "\t\t\t\t" + ")" + "\n" +
                            "\t\t\t\t" + "original-size=" + dss.statistics.originalSize + "\n" +
                            "\t\t\t\t" + "binary-match-norm-frequency=" + dss.statistics.binaryMatchNormFrequency + "\n" +
                            "\t\t\t\t" + "multi-match-norm-frequency=" + dss.statistics.multiMatchNormFrequency + "\n" +
                            "\t\t\t\t" + "coverage=" + dss.statistics.coverage() + "\n" +
                            "\t\t\t)\n" +
                            "\t\t\t" + "item-set=" + dss.itemSet.toString() + "\n" +
                            "\t\t)"
            ).collect(Collectors.joining("\n")) + "\n\t)";
        }
        return "frequent-item-set-model(" + "\n" +
                "\tmatcher=" + itemSetMatcher.toString() + "\n" +
                "\titem-sets=" + dssList +
                "\n)";
    }
}
