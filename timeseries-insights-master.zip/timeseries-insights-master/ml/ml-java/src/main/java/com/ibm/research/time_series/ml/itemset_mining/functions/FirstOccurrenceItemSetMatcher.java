package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Implementation of Set Matcher to be used with
 * {@link com.ibm.research.time_series.ml.itemset_mining.containers.FrequentItemSetModel} where the first occurrence of a
 * value from an {@link ItemSet} is taken if it is contained from within the time series.
 *
 * <p>
 *     Example:
 *     itemset = [a,b,c]
 *     time series = [(1,z), (2,a), (3,c), (4,d), (5,a), (6,a), (7,b), (8,c), (9,b)]
 *     result = [(2,a), (3,c), (4,d), (5,a), (6,a), (7,b)]
 * </p>
 *
 *
 *
 * @param <T> type for each item in the {@link ItemSet}
 */
@Deprecated
public class FirstOccurrenceItemSetMatcher<T> implements ItemSetMatcher<T>, Serializable {
    private static final long serialVersionUID = 7109879004382555276L;

    /**
     * the first occurrence of a value is taken if it is contained from within the time series. Once all values from the
     * item set have been found within the time series, the resulting time series match will be from the first value
     * found, to the last value found.
     *
     * @param s1 the {@link ItemSet} of values
     * @param s2 the time series
     * @return a time series if all values from the {@link ItemSet} were found within the time series, otherwise return
     * null
     */
    @Override
    public ObservationCollection<T> matches(ItemSet<T> s1, ObservationCollection<T> s2) {

        //original size of the item set
        final int originalSetSize = s1.size();

        //set of values not found from within the time series initialized to all the values in our item set
        Set<T> notFoundValues = new HashSet<>(s1);

        TSBuilder<T> tsBuilder = Observations.newBuilder();

        //for each observation, add to our result if a value is contained in our set or at least one of our values from
        //our item set has already matched
        for (Observation<T> obs : s2) {

            //if our not found values set contains the current observation value, add this observation to the resulting
            //time series and remove this value from our not found values set
            if (notFoundValues.contains(obs.getValue())) {
                tsBuilder.add(obs);
                notFoundValues.remove(obs.getValue());

                //once all values are found from within our time series, we are done
                if (notFoundValues.isEmpty()) {
                    break;
                }
            //otherwise, only add to our time series if our not found values set is missing any of its original values
            } else {
                if (originalSetSize != notFoundValues.size()) {
                    tsBuilder.add(obs);
                }
            }
        }

        //only return a time series if all of our values from within the item set have been found at some point in the
        //time series, otherwise return null
        return (notFoundValues.size() == 0) ? tsBuilder.result() : null;
    }
}
