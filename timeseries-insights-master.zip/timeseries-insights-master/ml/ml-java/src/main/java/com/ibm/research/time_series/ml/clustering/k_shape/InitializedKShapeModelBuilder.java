package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;

import java.util.List;

/**
 * Implementation of {@link KShapeModelBuilder} where the initial centroids are given by the user
 * @param <KEY> the key type per TimeSeries
 */
class InitializedKShapeModelBuilder<KEY> extends KShapeModelBuilder<KEY> {
    private double[][] initialClusters;

    /**
     * Construct a InitializedKShapeModelBuilder with the given initial clusters
     * @param multiTimeSeries the initial data to mine
     * @param shapeExtractionAggregator the shape extraction strategy to be used in the {@link KShapeModelBuilder}
     * @param initialClusterTimeSeries the initial clusters
     */
    InitializedKShapeModelBuilder(
            MultiTimeSeries<KEY,Double> multiTimeSeries,
            ShapeExtraction shapeExtractionAggregator,
            List<ObservationCollection<Double>> initialClusterTimeSeries) throws TSException {
        super(multiTimeSeries, shapeExtractionAggregator);
        this.initialClusters = new double[initialClusterTimeSeries.size()][initialClusterTimeSeries.get(0).size()];
        for (int i = 0; i < initialClusterTimeSeries.size(); i++) {
            this.initialClusters[i] = initialClusterTimeSeries.get(i).stream().mapToDouble(Observation::getValue).toArray();
        }
    }

    @Override
    protected double[][] getInitialClusters() {
        return initialClusters;
    }

    @Override
    protected int getNumClusters() {
        return initialClusters.length;
    }
}
