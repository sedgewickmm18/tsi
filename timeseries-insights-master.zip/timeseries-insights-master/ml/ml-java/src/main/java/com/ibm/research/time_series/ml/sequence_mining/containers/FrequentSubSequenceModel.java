/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.sequence_mining.functions.SequenceMatcher;
import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.util.DefaultPrettyPrinter;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Representation of a Frequent SubSequence model
 *
 * Additionally, this provides a scoring function that allows for computing a score, a metric that indiciates how well
 * a sequence matches this model.
 *
 *
 * <p>Created on 7/26/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class FrequentSubSequenceModel<T> implements Serializable{

    //todo make these all private, no real need for them to be public

    /**
     * Immutable variable, a list of all [[FrequentSubSequence]]
     */
    public final List<FrequentSubSequence<T>> frequentSubSequences;

    /**
     * Immutable variable, a sequence matcher function used to generate this FrequenceSubSequenceModel
     */
    public final SequenceMatcher<T> sequenceMatcher;

    /**
     * the minSupport used to generate this FSS Model
     */
    public final double minSupport;

    /**
     * the maxLength used to generate this FSS Model
     */
    public final int maxPatternLength;

    /**
     * time of creation of model
     */
    public final LocalDateTime creationDate;

    public List<FrequentSubSequence<T>> frequentSubSequences() {
        return frequentSubSequences;
    }

    public SequenceMatcher<T> sequenceMatcher() {
        return sequenceMatcher;
    }

    /**
     * This method allows for loading a frequent subsequence model saved to a file. It takes in an InputStream
     * object and returns a List/Array (Java/Scala) of [[FrequentSubSequence]].
     *
     * @param inputStream input stream
     * @param <T> value type
     * @return frequent subsequence model
     */
    public static <T> FrequentSubSequenceModel<T> load(InputStream inputStream) {
        try {
            String jsonString = IOUtils.toString(inputStream,"UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            //get matcher
            SequenceMatcher<T> matcher = SequenceMatcher.fromJson(jsonNode);

            LocalDateTime creationDate = LocalDateTime.parse(jsonNode.get("creation-date").asText());
            double minSupport = jsonNode.get("min-support").asDouble();
            int maxLength = jsonNode.get("max-length").asInt();
            List<FrequentSubSequence<T>> frequentSubSequences = new ArrayList<>();
            JsonNode freqSeq = jsonNode.get("frequent-subsequences");

            for (int i = 0;i < freqSeq.size();i++) {
                frequentSubSequences.add(FrequentSubSequence.fromJson(freqSeq.get(i)));
            }

            return new FrequentSubSequenceModel<>(
                    frequentSubSequences,
                    matcher,
                    minSupport,
                    maxLength,
                    creationDate
            );

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Construct a frequent subsequence model
     * @param frequentSubSequences Immutable variable, an array of all [[FrequentSubSequence]]
     * @param sequenceMatcher Immutable variable, a sequence matcher function used to generate this FrequenceSubSequenceModel
     * @param minSupport Immutable variable, min support used
     * @param maxPatternLength Immutable variable, max pattern length used
     * @param creationDate creation date of this model
     */
    public FrequentSubSequenceModel(
            List<FrequentSubSequence<T>> frequentSubSequences,
            SequenceMatcher<T> sequenceMatcher,
            double minSupport,
            int maxPatternLength,
            LocalDateTime creationDate) {
        this.minSupport = minSupport;
        this.maxPatternLength = maxPatternLength;
        this.frequentSubSequences = frequentSubSequences;
        this.sequenceMatcher = sequenceMatcher;
        this.creationDate = creationDate;
    }

    /**
     * Scala version: Given a TimeSeries and a threshold, computes the number of subsequences in this
     * model that match the input series.
     *
     * @param series Input timeseries to compute the score on, this is a sequence.
     * @return a score for the given TimeSeries
     */
    public double score(ObservationCollection<ItemSet<T>> series) {
        int count = 0;
        for (FrequentSubSequence<T> fss : frequentSubSequences) {
            if (sequenceMatcher.matches(fss.sequence,series) != null) {
                count++;
            }
        }

        return count * 1.0 / frequentSubSequences.size();
    }

    /**
     * Save this model to an OutputStream. It writes out this model in a JSON format with some
     * components of the model in a serialized form.
     *
     * @param outputStream given outputStream
     */
    public void save(OutputStream outputStream) {
        JsonFactory jsonFactory = new JsonFactory();
        try {
            JsonGenerator jsonGen = jsonFactory.createJsonGenerator(outputStream, JsonEncoding.UTF8);

            jsonGen.setPrettyPrinter(new DefaultPrettyPrinter());
            jsonGen.writeStartObject();
            //append min support;
            jsonGen.writeNumberField("min-support", minSupport);
            //append max length;
            jsonGen.writeNumberField("max-length", maxPatternLength);
            jsonGen.writeStringField("creation-date",creationDate.toString());

            jsonGen.writeFieldName("frequent-subsequences");
            jsonGen.writeStartArray();
            for (FrequentSubSequence<T> fss : frequentSubSequences) {
                fss.writeJson(jsonGen);
            }
            jsonGen.writeEndArray();

            //append matcher
            sequenceMatcher.writeJson(jsonGen);

            jsonGen.writeEndObject();
            jsonGen.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @return A string representation of this FSM model, for human readability.
     */
    @Override
    public String toString() {
        String fssList = "None";

        if (!frequentSubSequences.isEmpty()) {
            fssList = "(\n" + frequentSubSequences.stream().map(fss ->
                    "\t\tfrequent-sub-sequence(" + "\n" +
                            "\t\t\t" + "sequence-id=" + fss.sequenceID + "\n" +
                            "\t\t\t" + "statistics=" + "frequent-sub-sequence-statistics(" + "\n" +
                            "\t\t\t\t" + "inter-arrival-statistics=" + ((fss.statistics.interArrivalStatistics != null) ? "(\n" + fss.statistics.interArrivalStatistics.stream().map(x -> "\t\t\t\t\t" + x.toString()).collect(Collectors.joining("\n")) + "\n\t\t\t\t)\n" : "None\n") +
                            "\t\t\t\t" + "original-size=" + fss.statistics.originalSize + "\n" +
                            "\t\t\t\t" + "multi-match-norm-frequency=" + fss.statistics.multiMatchNormFrequency + "\n" +
                            "\t\t\t\t" + "binary-match-norm-frequency=" + fss.statistics.binaryMatchNormFrequency + "\n" +
                            "\t\t\t\t" + "coverage=" + fss.statistics.coverage() + "\n" +
                            "\t\t\t)\n" +
                            "\t\t\t" + "sequence=" + fss.sequence.toString() + "\n" +
                            "\t\t)"
            ).collect(Collectors.joining("\n")) + "\n\t)";
        }
        return "frequent-sub-sequence-model(" + "\n" +
                "\tmatcher=" + sequenceMatcher.toString() + "\n" +
                "\tsub-sequences=" + fssList +
                "\n)";
    }
}
