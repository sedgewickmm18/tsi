package com.ibm.research.time_series.ml.data_curation;

import com.ibm.research.time_series.core.exceptions.TSRuntimeException;
import com.ibm.research.time_series.core.functions.FilterFunction;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.core.utils.Segment;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FeatureVectors2 {

    public static <K, LABEL> List<Pair<String,LabeledPoint<List<List<Number>>,List<Number>>>> preparePython(
            MultiTimeSeries<String, List<Number>> dataTS,
            MultiTimeSeries<String, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            Number labelOffsetStart,
            Number labelOffsetEnd,
            Number featureOffsetStart,
            Number featureOffsetEnd,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        List<Pair<String,LabeledPoint<List<List<Number>>,List<Number>>>> result;
        if (positivePerc == -1.0) {
            result = preparePredictions(
                    dataTS,
                    labelTS,
                    labelOp,
                    leftDelta.longValue(),
                    rightDelta.longValue(),
                    s -> {
                        long start = s.start + labelOffsetStart.longValue();
                        long end = s.start + labelOffsetEnd.longValue();
                        return new Pair<>(start, end);
                    },
                    s -> {
                        long start = s.start + featureOffsetStart.longValue();
                        long end = s.start + featureOffsetEnd.longValue();
                        return new Pair<>(start, end);
                    },
                    withReplacement
            );
        } else {
            result = prepare(
                    dataTS,
                    labelTS,
                    labelOp,
                    leftDelta.longValue(),
                    rightDelta.longValue(),
                    s -> {
                        long start = s.start + labelOffsetStart.longValue();
                        long end = s.start + labelOffsetEnd.longValue();
                        return new Pair<>(start, end);
                    },
                    s -> {
                        long start = s.start + featureOffsetStart.longValue();
                        long end = s.start + featureOffsetEnd.longValue();
                        return new Pair<>(start, end);
                    },
                    positivePerc,
                    negitivePerc,
                    withReplacement
            );
        }
        return result;
    }

    public static <K, LABEL> List<Pair<String,LabeledPoint<Boolean,List<Number>>>> preparePython(
            MultiTimeSeries<String, List<Number>> dataTS,
            MultiTimeSeries<String, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            Number featureOffsetStart,
            Number featureOffsetEnd,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        return prepare(
                dataTS,
                labelTS,
                labelOp,
                leftDelta.longValue(),
                rightDelta.longValue(),
                s -> {
                    long start = s.start + featureOffsetStart.longValue();
                    long end = s.start + featureOffsetEnd.longValue();
                    return new Pair<>(start, end);
                },
                positivePerc,
                negitivePerc,
                withReplacement
        )
                .stream()
                .collect(Collectors.toList());
    }

    public static <LABEL> List<Pair<String,LabeledPoint<Boolean,List<Number>>>> preparePython(
            MultiTimeSeries<String, List<Number>> dataTS,
            MultiTimeSeries<String, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            Number leftDelta,
            Number rightDelta,
            double positivePerc,
            double negitivePerc,
            boolean withReplacement) {
        return prepare(
                dataTS,
                labelTS,
                labelOp,
                leftDelta.longValue(),
                rightDelta.longValue(),
                positivePerc,
                negitivePerc,
                withReplacement
        );
    }

    public static <K, T, LABEL> List<Pair<K,LabeledPoint<Boolean,List<T>>>> prepare(
            MultiTimeSeries<K, List<T>> dataTS,
            MultiTimeSeries<K, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            double positivePerc,
            double negativePerc,
            boolean withReplacement) {
        return prepare(dataTS,labelTS,labelOp,leftDelta,rightDelta,null,positivePerc,negativePerc,withReplacement);
    }

    public static <K, T, LABEL> List<Pair<K,LabeledPoint<Boolean,List<T>>>> prepare(
            MultiTimeSeries<K, List<T>> dataTS,
            MultiTimeSeries<K, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> featureVectorOp,
            double positivePerc,
            double negativePerc,
            boolean withReplacement) {
        final Map<K,Set<Long>> positiveSegmentTimesMap = labelTS
                .filter(labelOp)
                .collect()
                .entrySet()
                .stream()
                .map(e -> new Pair<>(e.getKey(),e.getValue().stream().map(Observation::getTimeTick).collect(Collectors.toSet())))
                .collect(Collectors.toMap(x -> x.left,  x ->  x.right));
        final Map<K,Set<Long>> negativeSegmentTimesMap = labelTS
                .collect()
                .entrySet()
                .parallelStream()
                .map(e -> {
                    final Set<Long> positiveSegmentTimes = positiveSegmentTimesMap.get(e.getKey());
                    ObservationCollection<LABEL> observations = e.getValue();

                    final Set<Long> negativeTimes = observations.toTimeSeriesStream().flatMapObservation(o -> {
                        if (positiveSegmentTimes.contains(o.getTimeTick())) return Collections.emptyList();
                        if (withReplacement) {
                            return Collections.singletonList(o);
                        } else {
                            if (positiveSegmentTimes.stream().anyMatch(l -> o.getTimeTick() >= l - leftDelta && o.getTimeTick() <= l + rightDelta))
                                return Collections.emptyList();
                            else
                                return Collections.singletonList(o);
                        }
                    }).collect()
                            .stream()
                            .map(Observation::getTimeTick)
                            .collect(Collectors.toSet());
                    return new Pair<>(e.getKey(),negativeTimes);
                })
                .collect(Collectors.toMap(x -> x.left, x -> x.right));

        final Stream<Pair<K,LabeledPoint<Boolean, List<T>>>> positiveLabels = dataTS
                .collect()
                .entrySet()
                .parallelStream()
                .flatMap(e -> {
                    ObservationCollection<List<T>> observations = e.getValue();

                    return observations.toTimeSeriesStream()
                            .mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                            .segmentByAnchor(p -> positiveSegmentTimesMap.get(e.getKey()).contains(p.left), leftDelta, rightDelta, positivePerc)
                            .mapSegments(p -> p.right)
                            .filter(segment -> !segment.isEmpty())
                            .map(segment -> {
                                if (featureVectorOp == null) {
                                    return new LabeledPoint<>(true,segment.stream().map(o -> o.getValue()).collect(Collectors.toList()));
                                } else {
                                    Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                                    List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                            .stream()
                                            .map(x -> x.getValue())
                                            .collect(Collectors.toList());

                                    return new LabeledPoint<>(true, feature);
                                }
                            })
                            .collect()
                            .stream()
                            .map(o -> new Pair<>(e.getKey(),o.getValue()));
                });

        final Stream<Pair<K,LabeledPoint<Boolean, List<T>>>> negativeLabels = dataTS
                .collect()
                .entrySet()
                .parallelStream()
                .flatMap(e -> {
                    ObservationCollection<List<T>> observations = e.getValue();

                    return observations.toTimeSeriesStream()
                            .mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                            .segmentByAnchor(p -> negativeSegmentTimesMap.get(e.getKey()).contains(p.left), leftDelta, rightDelta, negativePerc)
                            .mapSegments(p -> p.right)
                            .filter(segment -> !segment.isEmpty())
                            .map(segment -> {
                                if (featureVectorOp == null) {
                                    return new LabeledPoint<>(false,segment.stream().map(o -> o.getValue()).collect(Collectors.toList()));
                                } else {
                                    Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                                    List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                            .stream()
                                            .map(x -> x.getValue())
                                            .collect(Collectors.toList());

                                    return new LabeledPoint<>(false, feature);
                                }
                            })
                            .collect()
                            .stream()
                            .map(o -> new Pair<>(e.getKey(),o.getValue()));

                });
        return Stream.concat(positiveLabels,negativeLabels).collect(Collectors.toList());
    }

    public static <K, T, LABEL> List<Pair<K,LabeledPoint<List<List<T>>,List<T>>>> prepare(
            MultiTimeSeries<K, List<T>> dataTS,
            MultiTimeSeries<K, LABEL> labelTS,
            FilterFunction<LABEL> labelOp,
            long leftDelta,
            long rightDelta,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> labelValueOp,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> featureVectorOp,
            double positivePerc,
            double negativePerc,
            boolean withReplacement
    ) {
        final Map<K, Set<Long>> positiveSegmentTimesMap = labelTS
                .filter(labelOp)
                .collect()
                .entrySet()
                .stream()
                .map(e -> new Pair<>(e.getKey(),e.getValue().stream().map(Observation::getTimeTick).collect(Collectors.toSet())))
                .collect(Collectors.toMap(x -> x.left,  x ->  x.right));
        final Map<K,Set<Long>> negativeSegmentTimesMap = labelTS
                .collect()
                .entrySet()
                .parallelStream()
                .map(e -> {
                    final Set<Long> positiveSegmentTimes = positiveSegmentTimesMap.get(e.getKey());
                    ObservationCollection<LABEL> observations = e.getValue();

                    final Set<Long> negativeTimes = observations.toTimeSeriesStream().flatMapObservation(o -> {
                        if (positiveSegmentTimes.contains(o.getTimeTick())) return Collections.emptyList();
                        if (withReplacement) {
                            return Collections.singletonList(o);
                        } else {
                            if (positiveSegmentTimes.stream().anyMatch(l -> o.getTimeTick() >= l - leftDelta && o.getTimeTick() <= l + rightDelta))
                                return Collections.emptyList();
                            else
                                return Collections.singletonList(o);
                        }
                    }).collect()
                            .stream()
                            .map(Observation::getTimeTick)
                            .collect(Collectors.toSet());
                    return new Pair<>(e.getKey(),negativeTimes);
                })
                .collect(Collectors.toMap(x -> x.left, x -> x.right));

        final Stream<Pair<K,LabeledPoint<List<List<T>>,List<T>>>> positiveLabels = dataTS
                .collect()
                .entrySet()
                .parallelStream()
                .flatMap(e -> {
                    ObservationCollection<List<T>> observations = e.getValue();

                    return observations.toTimeSeriesStream()
                            .mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                            .segmentByAnchor(p -> positiveSegmentTimesMap.get(e.getKey()).contains(p.left), leftDelta, rightDelta, positivePerc)
                            .mapSegments(p -> p.right)
                            .filter(segment -> !segment.isEmpty())
                            .map(segment -> {
                                Pair<Long, Long> labelRange = labelValueOp.evaluate(segment);
                                Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                                List<List<T>> label = segment.subSet(labelRange.left, true, labelRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());

                                List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());


                                return new LabeledPoint<>(label, feature);
                            })
                            .collect()
                            .stream()
                            .map(o -> new Pair<>(e.getKey(),o.getValue()));
                });

        final Stream<Pair<K,LabeledPoint<List<List<T>>,List<T>>>> negativeLabels = dataTS
                .collect()
                .entrySet()
                .parallelStream()
                .flatMap(e -> {
                    ObservationCollection<List<T>> observations = e.getValue();

                    return observations.toTimeSeriesStream()
                            .mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                            .segmentByAnchor(p -> negativeSegmentTimesMap.get(e.getKey()).contains(p.left), leftDelta, rightDelta, negativePerc)
                            .mapSegments(p -> p.right)
                            .filter(segment -> !segment.isEmpty())
                            .map(segment -> {
                                Pair<Long, Long> labelRange = labelValueOp.evaluate(segment);
                                Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                                List<List<T>> label = segment.subSet(labelRange.left, true, labelRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());

                                List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());


                                return new LabeledPoint<>(label, feature);
                            })
                            .collect()
                            .stream()
                            .map(o -> new Pair<>(e.getKey(),o.getValue()));

                });

        return Stream.concat(positiveLabels,negativeLabels).collect(Collectors.toList());
    }

    public static <K, T, LABEL> List<Pair<K,LabeledPoint<List<List<T>>,List<T>>>> preparePredictions(
            MultiTimeSeries<K, List<T>> dataTS,
            MultiTimeSeries<K, LABEL> labelTS,
            FilterFunction<LABEL> anchor,
            long leftDelta,
            long rightDelta,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> labelValueOp,
            UnaryMapFunction<Segment<List<T>>, Pair<Long, Long>> featureVectorOp,
            boolean withReplacement
    ) {
        final Map<K, Set<Long>> positiveSegmentTimesMap;

        if (labelTS == null) {
            positiveSegmentTimesMap = dataTS
                    .collect()
                    .entrySet()
                    .stream()
                    .map(e -> new Pair<>(e.getKey(),e.getValue().stream().map(Observation::getTimeTick).collect(Collectors.toSet())))
                    .collect(Collectors.toMap(x -> x.left,  x ->  x.right));
        } else {
            positiveSegmentTimesMap = labelTS
                    .filter(x -> (anchor == null) || anchor.evaluate(x))
                    .collect()
                    .entrySet()
                    .stream()
                    .map(e -> new Pair<>(e.getKey(),e.getValue().stream().map(Observation::getTimeTick).collect(Collectors.toSet())))
                    .collect(Collectors.toMap(x -> x.left,  x ->  x.right));
        }

        final Stream<Pair<K,LabeledPoint<List<List<T>>,List<T>>>> positiveLabels = dataTS
                .collect()
                .entrySet()
                .parallelStream()
                .flatMap(e -> {
                    ObservationCollection<List<T>> observations = e.getValue();

                    return observations.toTimeSeriesStream()
                            .mapObservation(o -> new Observation<>(o.getTimeTick(), new Pair<>(o.getTimeTick(), o.getValue())))
                            .segmentByAnchor(p -> positiveSegmentTimesMap.get(e.getKey()).contains(p.left), leftDelta, rightDelta)
                            .mapSegments(p -> p.right)
                            .filter(segment -> !segment.isEmpty())
                            .map(segment -> {
                                Pair<Long, Long> labelRange = labelValueOp.evaluate(segment);
                                Pair<Long, Long> featureRange = featureVectorOp.evaluate(segment);

                                List<List<T>> label = segment.subSet(labelRange.left, true, labelRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());

                                List<List<T>> feature = segment.subSet(featureRange.left, true, featureRange.right, true)
                                        .stream()
                                        .map(x -> x.getValue())
                                        .collect(Collectors.toList());


                                return new LabeledPoint<>(label, feature);
                            })
                            .collect()
                            .stream()
                            .map(o -> new Pair<>(e.getKey(),o.getValue()));
                });

        return positiveLabels.collect(Collectors.toList());
    }
}
