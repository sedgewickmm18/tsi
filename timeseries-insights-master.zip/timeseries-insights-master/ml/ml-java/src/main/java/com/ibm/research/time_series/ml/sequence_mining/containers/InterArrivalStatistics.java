/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.transforms.reducers.math.MathReducers;
import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.JsonNodeFactory;
import org.codehaus.jackson.node.ObjectNode;

import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.DoubleStream;

/**
 * This is a deeper statistics holder class that maintains the inter-arrival times, where inter-arrival time is the time elapsed
 * between two consecutive events in the subsequence. For every consecutive pair of events in a sequence, one inter-arrival
 * statistics object is maintained. The values are across all the matching sequences for that single step in the subsequence.
 * For example, if the subsequence is {a,b,c}, the interarrival statistics are maintained for {a,b} and {b,c}.
 *
 * All times are in seconds and the immutable variables can be accessed as public variables, e.g. interArrivalStats.min.
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class InterArrivalStatistics implements Serializable, JsonIO{
    private static final long serialVersionUID = -8239605647723198858L;

    //todo make these all private, no real need for them to be public

    /**
     * Minimum inter-arrival time across all the sequences that match the subsequence
     */
    public final long min;
    /**
     * Maximum inter-arrival time across all the sequences that match the subsequence
     */
    public final long max;
    /**
     * Immutable variable, Sum of inter-arrival time across all the sequences that match the subsequence
     */
    public final long sum;
    /**
     * Number of sequences that matched this subsequence
     */
    public final int count;

    public final double average;

    public final double sd;

    /**
     * Construct an InterArrivalStatistics object
     * @param min Immutable variable, Minimum inter-arrival time across all the sequences that match the subsequence
     * @param max Immutable variable, Maximum inter-arrival time across all the sequences that match the subsequence
     * @param sum Immutable variable, Sum of inter-arrival time across all the sequences that match the subsequence
     * @param count Immutable variable, Number of sequences that matched this subsequence
     */
    public InterArrivalStatistics(long min, long max, long sum, int count,double average,double sd) {
        this.min = min;
        this.max = max;
        this.sum = sum;
        this.count = count;
        this.average = average;
        this.sd = sd;
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();
        jsonGen.writeNumberField("min", min);
        jsonGen.writeNumberField("max", max);
        jsonGen.writeNumberField("average", average);
        jsonGen.writeNumberField("standard-deviation", sd);
        jsonGen.writeNumberField("count", count);
        jsonGen.writeNumberField("sum", sum);
        jsonGen.writeEndObject();
    }

    static InterArrivalStatistics fromJson(JsonNode jsonNode) {
        return new InterArrivalStatistics(
                jsonNode.get("min").asLong(),
                jsonNode.get("max").asLong(),
                jsonNode.get("sum").asLong(),
                jsonNode.get("count").asInt(),
                jsonNode.get("average").asDouble(),
                jsonNode.get("standard-deviation").asDouble()
        );
    }

    /**
     * merge this InterArrivalStatistics with another InterArrivalStatistics
     * @param other the other inter arrival time object to merge with
     * @return a newly merged InterArrivalStatistic
     */
    public InterArrivalStatistics update(InterArrivalStatistics other) {
        double newMean = ((count * average) + (other.count * other.average)) / (count + other.count);
        double newSD = Math.sqrt(
                ((
                        (((sd * sd) + (average * average)) * count) +
                        (((other.sd * other.sd) + (other.average * other.average)) * other.count)
                ) /
                (
                        count + other.count
                )) -
                (newMean * newMean)
        );
        int newCount = count + other.count;
        long newMax = Math.max(max, other.max);
        long newMin = Math.min(min, other.min);
        long newSum = sum + other.sum;
        return new InterArrivalStatistics(newMin,newMax,newSum,newCount,newMean,newSD);
    }

    /**
     * @return Minimum inter-arrival time across all the sequences that match the subsequence
     */
    public long min() {
        return min;
    }

    /**
     * @return Maximum inter-arrival time across all the sequences that match the subsequence
     */
    public long max() {
        return max;
    }

    /**
     * @return Sum of inter-arrival time across all the sequences that match the subsequence
     */
    public long sum() {
        return sum;
    }

    /**
     * @return Number of sequences that matched this subsequence
     */
    public int count() {
        return count;
    }

    /**
     * @return Average of inter-arrival time across all the sequences that match the subsequence
     */
    public double average() {
        return average;
    }

    /**
     * @return Standard deviation of inter-arrival-time across all sequences that match the subsequence
     */
    public double sd() {
        return sd;
    }

    /**
     * @return a human readable representation of this class
     */
    @Override
    public String toString() {
        return "IAT(" +
                "min=" + min + " " +
                "max=" + max + " " +
                "sum=" + sum + " " +
                "count=" + count + " " +
                "avg=" + average + " " +
                "sd=" + sd + ")";
    }

    @Override
    public int hashCode() {
        return Long.hashCode(min) +
                Long.hashCode(max) +
                Double.hashCode(average) +
                Integer.hashCode(count) +
                Double.hashCode(sd) +
                Double.hashCode(sum);
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return false;
        }

        if(o == this){
            return true;
        }

        if (!(o instanceof InterArrivalStatistics)) {
            return false;
        }

        InterArrivalStatistics other = (InterArrivalStatistics) o;

        if (other.min != min) return false;
        if (other.max != max) return false;
        if (other.average != average) return false;
        if (other.count != count) return false;
        if (other.sd != sd) return false;
        if (other.sum != sum) return false;
        return true;
    }

    public static void main(String... args) {
//        double[] x = {0.0,1.0};
//
//        System.out.println(TimeSeries.list(Arrays.asList(1.0,2.0)).reduce(MathReducers.standardDeviation()));
//
//        double sd = new StandardDeviation(false).evaluate(x);
//
//        System.out.println(sd);
//
//        InterArrivalStatistics iasX = new InterArrivalStatistics((long)x[0],(long)x[0],(long)x[0],1,x[0],0.0);
//        for (int i = 1; i < x.length; i++) {
//            iasX = iasX.update(new InterArrivalStatistics((long)x[i],(long)x[i],(long)x[i],1,x[i],0.0));
//        }




        double[] x = {1.0,2.0,3.0,4.0,5.0};
        double[] y = {10.0,20.0,30.0,40.0,50.0};

        double sdX = new StandardDeviation(false).evaluate(x);
        double sdY = new StandardDeviation(false).evaluate(y);

        double[] xy = DoubleStream.concat(DoubleStream.of(x), DoubleStream.of(y)).toArray();

        double sdXY = new StandardDeviation(false).evaluate(xy);

        InterArrivalStatistics iasX = new InterArrivalStatistics((long)x[0],(long)x[0],(long)x[0],1,x[0],0.0);
        for (int i = 1; i < x.length; i++) {
            iasX = iasX.update(new InterArrivalStatistics((long)x[i],(long)x[i],(long)x[i],1,x[i],0.0));
        }

        System.out.println(sdX);
        System.out.println(iasX);

        InterArrivalStatistics iasY = new InterArrivalStatistics((long)y[0],(long)y[0],(long)y[0],1,y[0],0.0);
        for (int i = 1; i < y.length; i++) {
            iasY = iasY.update(new InterArrivalStatistics((long)y[i],(long)y[i],(long)y[i],1,y[i],0.0));
        }

        System.out.println(sdY);
        System.out.println(iasY);

        InterArrivalStatistics iasXY = iasX.update(iasY);

        System.out.println(sdXY);
        System.out.println(iasXY);

    }
}
