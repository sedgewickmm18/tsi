package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;

/**
 * Implementation of {@link KShapeModelBuilder} where the initial centroids are selected using a random sampling
 * strategy
 * @param <KEY> the key type per TimeSeries
 */
class RandomSampleKShapeModelBuilder<KEY> extends KShapeModelBuilder<KEY> {
    private int numClusters;

    /**
     * Construct a RandomSampleKShapeModelBuilder with numCluster clusters initialized using random sampling from the
     * initial given multiTimeSeries
     * @param multiTimeSeries the initial data to mine
     * @param shapeExtractionAggregator the shape extraction strategy to be used in the {@link KShapeModelBuilder}
     * @param numClusters the final number of clusters to be created
     */
    RandomSampleKShapeModelBuilder(MultiTimeSeries<KEY,Double> multiTimeSeries, ShapeExtraction shapeExtractionAggregator, int numClusters) throws TSException {
        super(multiTimeSeries, shapeExtractionAggregator);
        this.numClusters = numClusters;
    }

    @Override
    protected double[][] getInitialClusters() {
        double[][] initialClusters = new double[numClusters][data[0].length];
        for (int i = 0;i < initialClusters.length;i++) {
            initialClusters[i] = this.data[(int)(Math.random() * data.length)];
        }
        return initialClusters;
    }

    @Override
    protected int getNumClusters() {
        return numClusters;
    }
}
