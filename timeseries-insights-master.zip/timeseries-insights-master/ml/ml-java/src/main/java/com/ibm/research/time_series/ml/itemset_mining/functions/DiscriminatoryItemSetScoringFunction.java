package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.itemset_mining.containers.DiscriminatoryItemSetModel;

import java.io.Serializable;

public interface DiscriminatoryItemSetScoringFunction<T> extends Serializable {
    double apply(DiscriminatoryItemSetModel<T> model, ObservationCollection<T> series);
}
