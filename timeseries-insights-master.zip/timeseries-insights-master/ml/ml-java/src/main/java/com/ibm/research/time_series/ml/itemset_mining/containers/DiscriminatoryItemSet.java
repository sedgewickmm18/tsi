package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * A holder class for holding a single discriminatory item-set. This is used by the model class,
 * {@link DiscriminatoryItemSetModel}
 *
 * <p>Created on 1/3/18.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DiscriminatoryItemSet<T> implements JsonIO,Serializable {
    private static final long serialVersionUID = 7017926517595100074L;

    /**
     * holder of the item-set created by the Discriminatory ItemSet Mining algorithm
     */
    public final ItemSet<T> itemSet;

    /**
     * holder of the statistics for this item-set
     */
    public final DiscriminatoryItemSetStatistics statistics;

    /**
     * unique identifier for this DiscriminatoryItemSet in the {@link DiscriminatoryItemSetModel}
     */
    public final long itemSetID;

    public ItemSet<T> itemSet() {
        return itemSet;
    }

    public DiscriminatoryItemSetStatistics statistics() {
        return statistics;
    }

    public long itemSetID() {
        return itemSetID;
    }

    /**
     * Construct a Discriminatory ItemSet
     *
     * @param itemSet Immutable variable, holder of the item-Set created by the Discriminatory ItemSet Mining algorithm
     * @param statistics Immutable variable, holder of the statistics for this item-set
     * @param itemSetID Immutable variable, unique identifier for this DiscriminatoryItemSet in the {@link DiscriminatoryItemSetModel}
     */
    public DiscriminatoryItemSet(
            ItemSet<T> itemSet,
            DiscriminatoryItemSetStatistics statistics,
            long itemSetID) {
        this.itemSet = itemSet;
        this.statistics = statistics;
        this.itemSetID = itemSetID;
    }

    /**
     * @return human readable representation of Discriminatory ItemSet
     */
    @Override
    public String toString() {
        return "discriminatory-item-set(" + "\n" +
                "\t" + "item-set-id=" + itemSetID + "\n" +
                "\t" + "statistics=" + "discriminatory-item-set-statistics(" + "\n" +
                "\t\t" + "duration-statistics=" + "duration-statistics(" + "\n" +
                "\t\t\tmin=" + statistics.durationStatistics.min + "\n" +
                "\t\t\tmax=" + statistics.durationStatistics.max + "\n" +
                "\t\t\tsum=" + statistics.durationStatistics.sum + "\n" +
                "\t\t\tavg=" + statistics.durationStatistics.average + "\n" +
                "\t\t\tvariance=" + statistics.durationStatistics.variance + "\n" +
                "\t\t\tsd=" + statistics.durationStatistics.sd + "\n" +
                "\t\t\tmin-lead-time=" + statistics.durationStatistics.minLeadTime + "\n" +
                "\t\t\tmax-lead-time=" + statistics.durationStatistics.maxLeadTime + "\n" +
                "\t\t\tsum-lead-time=" + statistics.durationStatistics.sumLeadTime + "\n" +
                "\t\t\tavg-lead-time=" + statistics.durationStatistics.averageLeadTime + "\n" +
                "\t\t\tvariance-lead-time=" + statistics.durationStatistics.varianceLeadTime + "\n" +
                "\t\t\tsd-lead-time=" + statistics.durationStatistics.sdLeadTime + "\n" +
                "\t\t\tmin-end-time=" + statistics.durationStatistics.minEndTime + "\n" +
                "\t\t\tmax-end-time=" + statistics.durationStatistics.maxEndTime + "\n" +
                "\t\t\tsum-end-time=" + statistics.durationStatistics.sumEndTime + "\n" +
                "\t\t\tavg-end-time=" + statistics.durationStatistics.averageEndTime + "\n" +
                "\t\t\tvariance-end-time=" + statistics.durationStatistics.varianceEndTime + "\n" +
                "\t\t\tsd-end-time=" + statistics.durationStatistics.sdEndTime + "\n" +
                "\t\t" + ")" + "\n" +
                "\t\t" + "original-size-left=" + statistics.originalSizeLeft + "\n" +
                "\t\t" + "original-size-right=" + statistics.originalSizeRight + "\n" +
                "\t\t" + "binary-match-norm-frequency-left=" + statistics.binaryMatchNormalizedFrequencyLeft + "\n" +
                "\t\t" + "binary-match-norm-frequency-right=" + statistics.binaryMatchNormalizedFrequencyRight + "\n" +
                "\t\t" + "coverage-left=" + statistics.coverageLeft() + "\n" +
                "\t\t" + "coverage-right=" + statistics.coverageRight() + "\n" +
                "\t\t" + "lift=" + statistics.lift() + "\n" +
                "\t)\n" +
                "\t" + "item-set=" + itemSet.toString() + "\n" +
                ")";
    }


    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();

        jsonGen.writeNumberField("set-id",itemSetID);

        //append item-set-statistics;
        statistics.writeJson(jsonGen);

        //append item-set
        itemSet.writeJson(jsonGen);

        jsonGen.writeEndObject();
    }

    static <T> DiscriminatoryItemSet<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        long setID = jsonNode.get("set-id").asLong();

        // <== ====== START FREQUENT SEQUENCE STATISTICS ====== ==>

        DiscriminatoryItemSetStatistics diss = DiscriminatoryItemSetStatistics.fromJson(jsonNode);

        // <== ====== END FREQUENT SEQUENCE STATISTICS ====== ==>
        ItemSet<T> itemSet = ItemSet.fromJson(jsonNode);

        return new DiscriminatoryItemSet<>(itemSet,diss,setID);
    }
}
