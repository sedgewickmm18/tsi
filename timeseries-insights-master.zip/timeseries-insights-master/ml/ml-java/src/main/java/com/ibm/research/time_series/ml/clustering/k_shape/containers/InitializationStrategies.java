package com.ibm.research.time_series.ml.clustering.k_shape.containers;

/**
 * Initialization strategy for K-Shape clustering
 */
public enum InitializationStrategies {
    /**
     * Initialize centroids with random samples from data set
     */
    Random,
    /**
     * Initialize centroids using K-Means++ automatic centroid computation
     */
    PlusPlus,
    /**
     * Initialize centroids with all 0s
     */
    Zero
}
