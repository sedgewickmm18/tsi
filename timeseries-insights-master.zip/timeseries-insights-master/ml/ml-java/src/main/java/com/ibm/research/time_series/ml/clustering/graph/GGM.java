package com.ibm.research.time_series.ml.clustering.graph;

import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.transform.BinaryReducer;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.ml.clustering.graph.containers.GraphClusteringModel;
import com.ibm.research.time_series.ml.clustering.k_means.functions.DistanceComputer;
import com.ibm.research.time_series.ml.ggm.GraphCluster;
import com.ibm.research.time_series.ml.ggm.GraphicalGaussianModel;
import org.apache.commons.math3.linear.RealMatrix;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class GGM {
    public static <K> TimeSeriesClusteringModel<Double> run(
            MultiTimeSeries<K,Double> mts,
            BinaryReducer<Double, Double, Double> reducer,
            int numSingularValues,
            double covarianceThreshold,
            double clusterThreshold) {
        final Set<K> originalKeys = mts.getTimeSeriesMap().keySet();
        Map<K, Integer> mapping = new HashMap<>(originalKeys.size());
        Map<Integer, K> revMapping = new HashMap<>(originalKeys.size());

        for (K k : originalKeys) {
            final int index = mapping.size();
            mapping.put(k, index);
            revMapping.put(index, k);
        }

        final MultiTimeSeries<Integer, Double> mappedMts = mts.mapSeriesKey(mapping::get);
        final RealMatrix covMatrix = GraphicalGaussianModel.compute(mappedMts, reducer, numSingularValues, covarianceThreshold);
        GraphCluster graphCluster = new GraphCluster(covMatrix);
        final List<ObservationCollection<Double>> clusters = graphCluster.cluster(clusterThreshold).stream().map(set -> {
            return mappedMts.filterSeriesKey(k -> set.contains(k))
                    .aggregateSeries(x -> x.stream().mapToDouble(Double::doubleValue).average())
                    .map(x -> x.orElse(0.0))
                    .collect();
        }).collect(Collectors.toList());

        final List<List<Double>> lists = TimeSeriesClusteringModel.perClusterMetrics(mappedMts, clusters, new DistanceComputer<Double>() {
            @Override
            public Double compute(ObservationCollection<Double> x, ObservationCollection<Double> y) {
                return x.toTimeSeriesStream().reduce(y.toTimeSeriesStream(), reducer);
            }
        });

        return new GraphClusteringModel(
                clusters,
                lists.get(0),
                lists.get(1),
                lists.get(2),
                lists.get(3),
                lists.get(4)
        );
    }
}
