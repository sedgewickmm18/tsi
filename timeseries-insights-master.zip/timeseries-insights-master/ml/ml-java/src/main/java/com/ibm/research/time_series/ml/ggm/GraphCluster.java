package com.ibm.research.time_series.ml.ggm;

import com.ibm.research.time_series.core.utils.Pair;
import org.apache.commons.math3.linear.RealMatrix;

import java.util.*;

public class GraphCluster {

    private Map<Pair<Integer,Integer>, Double> linkMap;
    private Map<Integer, List<Integer>> adjMap;

    public GraphCluster(RealMatrix linkMatrix) {
        this.linkMap = new HashMap<>();
        this.adjMap = new HashMap<>();


        for (int rowI = 0;rowI < linkMatrix.getRowDimension();rowI++) {
            for (int colJ = 0;colJ < linkMatrix.getColumnDimension();colJ++) {
                if (!adjMap.containsKey(rowI)) {
                    adjMap.put(rowI, new ArrayList<>());
                }

                adjMap.get(rowI).add(colJ);
                linkMap.put(new Pair<>(rowI,colJ),linkMatrix.getEntry(rowI,colJ));
            }
        }
    }

    public List<Set<Integer>> cluster(double threshold) {
        Map<Pair<Integer,Integer>,Double> linkMapTracker = new HashMap<>(linkMap);

        List<Set<Integer>> result = new ArrayList<>();

        while (!linkMapTracker.isEmpty()) {
            final Optional<Set<Integer>> optCommunity = createCommunityIfPossible(threshold, linkMapTracker);

            if (!optCommunity.isPresent()) {
                break;
            } else {
                Set<Integer> community = optCommunity.get();

                expand(threshold,community);

                result.add(community);

                for (Integer u : community) {
                    for (Integer v : community) {
                        linkMapTracker.remove(new Pair<>(u,v));
                        linkMapTracker.remove(new Pair<>(v,u));
                    }
                }
            }

        }
        return result;
    }

    private void expand(double threshold, Set<Integer> community) {
        int prevCommunitySize;
        int currCommunitySize;

        do {
            prevCommunitySize = community.size();
            expandOne(threshold, community);
            currCommunitySize = community.size();
        } while (prevCommunitySize < currCommunitySize);
    }

    private void expandOne(double threshold, Set<Integer> community) {

        double[] maxTwoWayAffinity = {-1.0, -1.0};
        int maxTwoWayAffinityNode = -1;

        double maxOneWayAffinity = -1.0;
        int maxOneWayAffinityNode = -1;

        for (Integer u : community) {

            if (adjMap.containsKey(u)) {
                final List<Integer> adjList = adjMap.get(u);

                for (Integer v : adjList) {

                    if (!community.contains(v)) {
                        double[] affinity = getAffinityToCommunity(community,v);

                        if ((affinity[0] > maxTwoWayAffinity[0]) && (affinity[1] > maxTwoWayAffinity[1])) {
                            maxTwoWayAffinity[0] = affinity[0];
                            maxTwoWayAffinity[1] = affinity[1];
                            maxTwoWayAffinityNode = v;
                        }

                        if (affinity[0] > maxOneWayAffinity) {
                            maxOneWayAffinity = affinity[0];
                            maxOneWayAffinityNode = v;
                        }

                    }

                }

            }

        }

        //check on two way affinity
        int nodeToAddToCommunity = -1;
        if ((maxTwoWayAffinityNode != -1) && (maxTwoWayAffinity[0] >= threshold)
                && (maxTwoWayAffinity[1] >= threshold)) {
            nodeToAddToCommunity = maxTwoWayAffinityNode;
        } else if ((maxOneWayAffinityNode != -1) && (maxOneWayAffinity >= threshold)) {
            nodeToAddToCommunity = maxOneWayAffinityNode;
        }

        if (nodeToAddToCommunity != -1) {
            community.add(nodeToAddToCommunity);
        }
    }

    private double[] getAffinityToCommunity(Set<Integer> community, int v) {
        List<Integer> vNbrs = adjMap.get(v);
        double communityToVSum = 0.0;
        double vToCommunitySum = 0.0;

        for (Integer u : vNbrs) {
            if (community.contains(u)) {
                communityToVSum += linkMap.getOrDefault(new Pair<>(u,v), 0.0);
                vToCommunitySum += linkMap.getOrDefault(new Pair<>(v,u), 0.0);
            }
        }

        return new double[]{communityToVSum / community.size(), vToCommunitySum / community.size()};
    }

    private Optional<Set<Integer>> createCommunityIfPossible(
            double threshold,
            Map<Pair<Integer,Integer>,Double> linkMapTracker) {
        double[] maxTwoWayAffinity = {-1.0, -1.0};
        Map.Entry<Pair<Integer,Integer>, Double> maxTwoWayLink = new AbstractMap.SimpleEntry<>(new Pair<>(-1,-1),0.0);

        double maxOneWayAffinity = -1.0;
        Map.Entry<Pair<Integer,Integer>, Double> maxOneWayLink = new AbstractMap.SimpleEntry<>(new Pair<>(-1,-1),0.0);

        for (Map.Entry<Pair<Integer, Integer>, Double> entry : linkMapTracker.entrySet()) {
            Pair<Integer,Integer> link = entry.getKey();

            double[] affinity = {linkMap.getOrDefault(link, 0.0), linkMap.getOrDefault(new Pair<>(link.right,link.left), 0.0)};

            boolean twoWayCheck1 = (affinity[0] > maxTwoWayAffinity[0]) && (affinity[1] >= maxTwoWayAffinity[1]);
            boolean twoWayCheck2 = (affinity[0] >= maxTwoWayAffinity[0]) && (affinity[1] > maxTwoWayAffinity[1]);

            if (twoWayCheck1 || twoWayCheck2) {
                maxTwoWayAffinity[0] = affinity[0];
                maxTwoWayAffinity[1] = affinity[1];
                maxTwoWayLink = entry;
            }

            if (affinity[0] > maxOneWayAffinity) {
                maxOneWayAffinity = affinity[0];
                maxOneWayLink = entry;
            }
        }

        //found the max links
        if ((maxTwoWayLink.getKey().left != -1) && (maxTwoWayAffinity[0] >= threshold)
                && (maxTwoWayAffinity[1] >= threshold)) {
            Set<Integer> result = new HashSet<>();
            result.add(maxTwoWayLink.getKey().left);
            result.add(maxTwoWayLink.getKey().right);
            return Optional.of(result);
        } else if ((maxOneWayLink.getKey().left != -1) && (maxOneWayAffinity >= threshold)) {
            Set<Integer> result = new HashSet<>();
            result.add(maxOneWayLink.getKey().left);
            result.add(maxOneWayLink.getKey().right);
            return Optional.of(result);
        } else {
            return Optional.empty();
        }

    }
}
