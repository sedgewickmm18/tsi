package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;

/**
 * Implementation of {@link KShapeModelBuilder} where the initial centroids are initialized to 0s. This follows the
 * strategy described in http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
 * @param <KEY> the key type per TimeSeries
 */
class ZeroKShapeModelBuilder<KEY> extends KShapeModelBuilder<KEY> {
    private double[][] initialClusters;
    private int numClusters;

    /**
     * Construct a ZeroKShapeModelBuilder with numCluster clusters initialized to 0s
     *
     * @param multiTimeSeries the initial data to mine
     * @param shapeExtractionAggregator the shape extraction strategy to be used in the {@link KShapeModelBuilder}
     * @param numClusters the final number of clusters to be created
     */
    ZeroKShapeModelBuilder(MultiTimeSeries<KEY,Double> multiTimeSeries, ShapeExtraction shapeExtractionAggregator, int numClusters) throws TSException {
        super(multiTimeSeries, shapeExtractionAggregator);
        this.numClusters = numClusters;
        this.initialClusters = new double[numClusters][data[0].length];
        for (int i = 0;i < initialClusters.length;i++) {
            for (int j = 0; j < initialClusters[i].length; j++) {
                initialClusters[i][j] = 0.0;
            }
        }

    }

    @Override
    protected double[][] getInitialClusters() {
        return initialClusters;
    }

    @Override
    protected int getNumClusters() {
        return numClusters;
    }
}
