package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;

import java.util.HashSet;
import java.util.Set;

public class SubSetItemSetMatcherPS<T> implements ItemSetMatcher<T> {

    private static final long serialVersionUID = -3408297557736389977L;
    private double threshold;

    public SubSetItemSetMatcherPS(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public ObservationCollection<T> matches(ItemSet<T> s1, ObservationCollection<T> s2) {

        if (s1.size() * 1.0 / s2.size() * 1.0 < threshold) {
            return null;
        }

        //set of values not found from within the time series initialized to all the values in our item set
        Set<T> notFoundValues = new HashSet<>(s1);

        TSBuilder<T> tsBuilder = Observations.newBuilder();

        //for each observation, add to our result if a value is contained in our set or at least one of our values from
        //our item set has already matched
        for (Observation<T> obs : s2) {

            //if our not found values set contains the current observation value, add this observation to the resulting
            //time series and remove this value from our not found values set
            if (notFoundValues.contains(obs.getValue())) {
                tsBuilder.add(obs);
                notFoundValues.remove(obs.getValue());

                //once all values are found from within our time series, we are done
                if (notFoundValues.isEmpty()) {
                    break;
                }
            }
        }

        //only return a time series if all of our values from within the item set have been found at some point in the
        //time series, otherwise return null
        return (notFoundValues.size() == 0) ? tsBuilder.result() : null;
    }

    @Override
    public String toString() {
        return "matcher(type=itemset match_threshold=" + threshold + " threshold_type=ps)";
    }
}
