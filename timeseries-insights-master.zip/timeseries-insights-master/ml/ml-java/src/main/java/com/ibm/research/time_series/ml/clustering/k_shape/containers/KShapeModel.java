package com.ibm.research.time_series.ml.clustering.k_shape.containers;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.*;

/**
 * Container to hold a K-Shape Model created from the implementation described from
 * http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
 */
public class KShapeModel extends TimeSeriesClusteringModel<Double> implements Serializable {
    private static final long serialVersionUID = -6460140610422464853L;

    /**
     * create a K-Shape Model
     *
     * @param centroids list of {@link ObservationCollection} that denote a list of centroid time series
     * @param intraClusterDistancePerCentroid the average between all points in a cluster from its cluster center
     * @param interClusterDistancePerCentroid the average distance from the second closest centroid for each point
     *                                        grouped by its closest centroid
     * @param silhouetteCoefficientsPerCentroid for each cluster,
     *                                          (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     * @param clusterDistributions for each cluster,
     *                             (number of TimeSeries scored to that a given cluster) / (total number of TimeSeries)
     */
    public KShapeModel(
            List<ObservationCollection<Double>> centroids,
            List<Double> intraClusterDistancePerCentroid,
            List<Double> interClusterDistancePerCentroid,
            List<Double> silhouetteCoefficientsPerCentroid,
            List<Double> clusterDistributions,
            List<Double> clusterSumSquareDistance) {
        super(
                centroids,
                intraClusterDistancePerCentroid,
                interClusterDistancePerCentroid,
                silhouetteCoefficientsPerCentroid,
                clusterDistributions,
                clusterSumSquareDistance
        );
    }

    /**
     * @param ts1 the first {@link ObservationCollection}
     * @param ts2 the second {@link ObservationCollection}
     * @return the distance between 2 collections of observations
     */
    protected double computeDistance(ObservationCollection<Double> ts1,ObservationCollection<Double> ts2) {
        return ts1.toTimeSeriesStream().reduce(ts2.toTimeSeriesStream(), DistanceReducers.sbd());
    }

    /**
     * score the given in memory time series to predict its closest centroid
     *
     * @param realizedTimeSeries in memory time series
     * @return an integer denoting the cluster id the given in memory time series belongs to
     */
    @Override
    public int score(ObservationCollection<Double> realizedTimeSeries) {
        int result = -1;
        double min = Double.MAX_VALUE;
        for (int i = 0; i < centroids.size(); i++) {
            double dist = centroids.get(i).toTimeSeriesStream().reduce(realizedTimeSeries.toTimeSeriesStream(), DistanceReducers.sbdWithShift()).right;
            if (dist < min) {
                min = dist;
                result = i;
            }
        }
        return result;
    }

    @Override
    protected void writeObservationValueToJSON(JsonGenerator jsonGen, Double value) throws IOException{
        jsonGen.writeNumberField("value",value);
    }

    @Override
    protected void writeCustomFieldsToJSON(JsonGenerator jsonGen) throws IOException {
        //nothing to do here
    }

    /**
     * @return a human readable version of this model
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0;i < centroids.size();i++) {
            builder.append("---").append("\n");
            builder.append("Centroid ").append(i).append(":").append("\n");
            builder.append(centroids.get(i).toString()).append("\n");
        }
        return builder.toString();
    }

    /**
     * load a model from an InputStream
     * @param inputStream the given InputStream
     * @return a new KShapeModel
     */
    public static KShapeModel load(InputStream inputStream) {
        String jsonString;
        try {
            jsonString = IOUtils.toString(inputStream,"UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            List<Double> intraClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonIntraDistancePerCluster = jsonNode.get("intra-cluster-distance-per-centroid");
            for (int i = 0;i < jsonIntraDistancePerCluster.size();i++) {
                intraClusterDistancePerCentroid.add(jsonIntraDistancePerCluster.get(i).asDouble());
            }

            List<Double> interClusterDistancePerCentroid = new ArrayList<>();
            JsonNode jsonInterDistancePerCluster = jsonNode.get("inter-cluster-distance-per-centroid");
            for (int i = 0;i < jsonInterDistancePerCluster.size();i++) {
                interClusterDistancePerCentroid.add(jsonInterDistancePerCluster.get(i).asDouble());
            }

            List<Double> silhouetteCoefficientsPerCentroid = new ArrayList<>();
            JsonNode jsonSilhouetteCoefficientsPerCluster = jsonNode.get("silhouette-coefficients-per-centroid");
            for (int i = 0;i < jsonSilhouetteCoefficientsPerCluster.size();i++) {
                silhouetteCoefficientsPerCentroid.add(jsonSilhouetteCoefficientsPerCluster.get(i).asDouble());
            }

            List<Double> clusterDistributionsPerCentroid = new ArrayList<>();
            JsonNode jsonClusterDistributionsPerCentroid = jsonNode.get("cluster-distributions-per-centroid");
            for (int i = 0;i < jsonClusterDistributionsPerCentroid.size();i++) {
                clusterDistributionsPerCentroid.add(jsonClusterDistributionsPerCentroid.get(i).asDouble());
            }

            List<Double> sumSquarePerCentroid = new ArrayList<>();
            JsonNode jsonSumSquarePerCentroid = jsonNode.get("sum-square-per-centroid");
            for (int i = 0;i < jsonSumSquarePerCentroid.size();i++) {
                sumSquarePerCentroid.add(jsonSumSquarePerCentroid.get(i).asDouble());
            }

            JsonNode jsonClusters = jsonNode.get("centroids");

            List<ObservationCollection<Double>> clusters = new ArrayList<>();

            for (int i = 0;i < jsonClusters.size();i++) {
                JsonNode jsonCluster = jsonClusters.get(i);
                TSBuilder<Double> tsBuilder = Observations.newBuilder();
                for (int j = 0;j < jsonCluster.size();j++) {
                    JsonNode jsonObservation = jsonCluster.get(j);
                    tsBuilder.add(new Observation<>(jsonObservation.get("timestamp").asLong(),jsonObservation.get("value").asDouble()));
                }

                clusters.add(tsBuilder.result());
            }

            inputStream.close();

            return new KShapeModel(
                    clusters,
                    intraClusterDistancePerCentroid,
                    interClusterDistancePerCentroid,
                    silhouetteCoefficientsPerCentroid,
                    clusterDistributionsPerCentroid,
                    sumSquarePerCentroid
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new KShapeModel(new ArrayList<>(),null,null,null,null, null);
    }
}
