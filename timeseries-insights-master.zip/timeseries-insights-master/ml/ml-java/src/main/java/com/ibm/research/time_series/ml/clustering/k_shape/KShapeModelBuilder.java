package com.ibm.research.time_series.ml.clustering.k_shape;

import com.ibm.research.time_series.core.exceptions.TSException;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.timeseries.TimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Pair;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import com.ibm.research.time_series.ml.clustering.k_shape.containers.KShapeModel;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;

/**
 * This is a KShapeModel builder
 *
 * It follows the algorithm described in http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf for
 * clustering time series based on time series shape.
 *
 * @param <KEY> the key type for each TimeSeries
 */
abstract class KShapeModelBuilder<KEY> {

    /**
     * the data to mine for clusters
     */
    final double[][] data;

    /**
     * the shape extraction strategy (EigenValue Decomposition or simple averaging)
     *
     * during the shape extraction phase, a mxm multi-dimensional array will be produced where m is the length of the
     * time series. On this matrix, we must get a representation of a single vector that best represents the matrix
     * which can either be using EigenValue Decomposition (more accurate in determining shape) or simple averaging
     * over each column of the matrix (sacrifices accuracy for boost in performance)
     */
    private ShapeExtraction shapeExtraction;

    /**
     * the initial MultiTimeSeries that we will eventually use in retrieving intra / inter cluster distances
     */
    protected MultiTimeSeries<KEY,Double> multiTimeSeries;

    /**
     * Construct K-Shape Model builder
     *
     * This builder is used to construct and run a K-Shape Model pipeline with a single instantiation.
     * Simply call the build method on this builder to produce a new K-Shape Model
     *
     * K-Shape Model builders take a shape extraction as input which is used for deciding the shape extraction strategy
     * (either using eigenvector decomposition or simple averaging)
     *
     * @param multiTimeSeries the data that comes in to mine for K-Shape clusters
     * @param shapeExtraction the shape extraction strategy
     */
    KShapeModelBuilder(MultiTimeSeries<KEY,Double> multiTimeSeries, ShapeExtraction shapeExtraction) throws TSException {
        this.multiTimeSeries = multiTimeSeries;
        this.shapeExtraction = shapeExtraction;

        //data in k-shape only takes observations values in to account, so we put our data into a multi-dimensional
        //double array to be further processed
        //Note: all time series must be of the same size
        final int columns = multiTimeSeries.getTimeSeriesMap().values().iterator().next().collect().size();
        final int rows = multiTimeSeries.getTimeSeriesMap().size();
        this.data = new double[rows][columns];

        int n = 0;
        for (Map.Entry<KEY, TimeSeries<Double>> entry : multiTimeSeries.getTimeSeriesMap().entrySet()) {
            int m = 0;
            ObservationCollection<Double> current = entry.getValue().collect();
            if (current.size() != columns) {
                throw new TSException("all time series must be of the same size");
            }
            for (Observation<Double> obs : current) {
                this.data[n][m] = obs.getValue();
                m++;
            }
            n++;
        }
    }

    /**
     * Build a KShapeModel
     *
     * Step 1: execute the KShape algorithm to produce our final clusters
     * Step 2: create our centroids from a real matrix
     * Step 3: compute the intra-cluster distances
     * Step 4: compute the inter-cluster distances
     * Step 5: compute the silhouette coefficients
     * @return a primed KShape Model
     */
    public KShapeModel build() throws TSException {
        //Step 1: execute k-shape (Algorithm 3 from http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf)
        Pair<List<Integer>,RealMatrix> kShapeResult = execute();

        //Step 2: create our centroids from a real matrix
        //in this case each row will be considered a centroid
        List<ObservationCollection<Double>> centroidList = new ArrayList<>();
        for (int i = 0; i < kShapeResult.right.getRowDimension(); i++) {
            TimeSeries<Double> ts = TimeSeries.list(
                    DoubleStream.of(kShapeResult.right.getRow(i)).boxed().collect(Collectors.toList())
            );
            centroidList.add(ts.collect());
        }

        //Step (3,4,5):
        //3)compute the intra-cluster distance for each centroid and for the model as a whole
        //we define the intra cluster distance for each centroid as the average between all points in a cluster from its
        //cluster center
        //4)compute the inter-cluster distance for each centroid
        //we define the inter cluster distance per centroid as the average distance from the second closest centroid
        //for each point grouped by its closest centriod
        //For all ci in C_1i, the inter cluster distance per centroid C_1i is computed as avg(distance(ci,C_2i)) where
        //where ci is a time series in a cluster with centroid C_1i and C_2i is the second closest cluster centroid to
        //ci
        //5)compute the silhouette coefficient per centroid
        //For all ci in C_1i, the inter cluster distance per centroid is computed as
        //(avg(distance(ci,C_2i)) - avg(distance(ci,C_1i))) / avg(distance(ci,C_2i)), where ci is a time series in a
        //cluster with centroid C_1i and C_2i is the second closest cluster centroid to ci
        List<List<Double>> intraInterSilhouettes = TimeSeriesClusteringModel.perClusterMetrics(
                multiTimeSeries,
                centroidList,
                (x,y) -> x.toTimeSeriesStream().reduce(y.toTimeSeriesStream(), DistanceReducers.sbdWithShift()).right
        );

        return new KShapeModel(
                centroidList,
                intraInterSilhouettes.get(0),
                intraInterSilhouettes.get(1),
                intraInterSilhouettes.get(2),
                intraInterSilhouettes.get(3),
                intraInterSilhouettes.get(4)
        );
    }

    /**
     * implementation of algorithm 3 from http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
     *
     * Step 1: randomly choose initial cluster id's for IDX (nx1 vector containing the assignment of n time series to k clusters)
     * Step 2: initialize matrix C (k-by-m matrix containing k centroids of length m) either using a random sampling strategy
     * in the case of {@link RandomSampleKShapeModelBuilder}, a reference set strategy in the case of
     * {@link InitializedKShapeModelBuilder} or a matrix filled with 0s in the case of {@link ZeroKShapeModelBuilder}
     * Step 3: perform iteratively the computation of clusters
     * @return
     */
    private Pair<List<Integer>,RealMatrix> execute() throws TSException {
        if (data.length == 0) {
            throw new TSException("tried to run kshape on an empty set of data");
        }

        final int rows = data.length;

        RealMatrix X = MatrixUtils.createRealMatrix(data);

        //Step 1: randomly choose initial cluster Id's for IDX
        List<Integer> IDX = new ArrayList<>();
        Random random = new Random();
        for (int i = 0;i < rows;i++) {
            IDX.add(random.nextInt(getNumClusters()));
        }

        //Step 2: initialize the matrix C depending on the current implementation of this abstract class
        RealMatrix C = MatrixUtils.createRealMatrix(getInitialClusters());

        //IDX_prime is the current iterations version of IDX
        List<Integer> IDX_prime = new ArrayList<>();

        //Step 3: iteratively compute clusters
        int iter = 0;
        while (!IDX_prime.equals(IDX) && iter < 100) {
            IDX_prime = new ArrayList<>(IDX);

            //perform the refinement step from algorithm 3 of http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
            for (int j = 0;j < getNumClusters();j++) {
                List<double[]> X_prime = new ArrayList<>();
                for (int i = 0;i < rows;i++) {
                    if (IDX.get(i) == j) {
                        X_prime.add(X.getRow(i));
                    }
                }
                if (!X_prime.isEmpty()) {
                    //perform shape extraction (algorithm 2 of http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf)
                    RealVector extractedShape = extractShape(
                            MatrixUtils.createRealMatrix(X_prime.toArray(new double[X_prime.size()][X_prime.get(0).length])),
                            C.getRowVector(j)
                    );
                    C.setRowVector(j,extractedShape);
                }
            }

            //perform the assignment step from algorithm 3 of http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
            for (int i = 0; i < rows;i++) {
                double minDist = Double.MAX_VALUE;
                TimeSeries<Double> xTS = TimeSeries.list(DoubleStream.of(X.getRow(i)).boxed().collect(Collectors.toList()));
                for (int j = 0;j < getNumClusters();j++) {
                    TimeSeries<Double> cTS = TimeSeries.list(DoubleStream.of(C.getRow(j)).boxed().collect(Collectors.toList()));

                    //perform shape based distance (algorithm 1 http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf)
                    Pair<List<Double>,Double> sbdPair = cTS.reduce(xTS, DistanceReducers.sbdWithShift());
                    double dist = sbdPair.right;
                    if (dist < minDist) {
                        minDist = dist;
                        IDX.set(i,j);
                    }
                }
            }

            iter++;
        }

        //IDX is an n-by-1 vector containing the assignment of n time series to k clusters.
        //C is a k-by-m matrix containing k centroids of length m
        return new Pair<>(IDX,C);

    }

    /**
     * @return the initial clusters (see variable C from algorithm 3 of
     * http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf)
     */
    protected abstract double[][] getInitialClusters();

    /**
     * @return the number of clusters
     */
    protected abstract int getNumClusters();

    /**
     * implementation of algorithm 2 from http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf
     *
     * Step 1: for each row in our matrix x (n-by-m matrix with z-normalized time series), perform shape based distance
     * with respect to c (1-by-m vector with the reference sequence against which time series of X are aligned)
     *
     * Step 2: perform the shape extraction step of algorithm 2. In the case of
     * from http://www1.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf, EigenVector decomposition is used, but
     * we also provide simple averaging over each column of the matrix for performance purposes
     *
     * @param x n-by-m matrix with z-normalized time series
     * @param c 1-by-m vector with the reference sequence against which time series of X are aligned
     * @return an extracted shape of the matrix
     */
    private RealVector extractShape(RealMatrix x,RealVector c){
        double[][] data = new double[x.getRowDimension()][x.getColumnDimension()];

        //Step 1: perform shape based distance between each row of x and c
        TimeSeries<Double> reference = TimeSeries.list(DoubleStream.of(c.toArray()).boxed().collect(Collectors.toList()));
        for (int n = 0;n < x.getRowDimension();n++) {
            TimeSeries<Double> ts = TimeSeries.list(DoubleStream.of(x.getRow(n)).boxed().collect(Collectors.toList()));
            List<Double> shiftedVector = reference.reduce(ts, DistanceReducers.sbdWithShift()).left;
            for (int m = 0;m < shiftedVector.size();m++) {
                data[n][m] = shiftedVector.get(m);
            }
        }

        RealMatrix X_prime = MatrixUtils.createRealMatrix(data);

        //perform shape extraction step of algorithm 2
        return shapeExtraction.apply(X_prime);

    }
}
