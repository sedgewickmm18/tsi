package com.ibm.research.time_series.ml.sequence_mining.functions;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSetSequence;

import java.util.ArrayList;
import java.util.List;

public class SubSeqSequenceMatcherPM<T> implements SequenceMatcher<T> {
    private static final long serialVersionUID = -8948387952130864842L;
    private double threshold;

    public SubSeqSequenceMatcherPM(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public ObservationCollection<ItemSet<T>> matches(ItemSetSequence<T> pattern, ObservationCollection<ItemSet<T>> series) {
        List<Observation<ItemSet<T>>> observationsList = new ArrayList<>(series.toCollection());

        TSBuilder<ItemSet<T>> tsBuilder = Observations.newBuilder();

        int currentIndex = 0;
        long matches = 0;

        for (ItemSet<T> sequence : pattern.itemsets) {
            boolean found = false;
            for (int i = currentIndex;i < observationsList.size();i++) {
                if (isSubset(sequence,observationsList.get(i).getValue())) {
                    found = true;
                    currentIndex = i + 1;
                    tsBuilder.add(observationsList.get(i));
                    matches++;
                    break;
                } else {
                    if (!tsBuilder.isEmpty()) matches++;
                }
            }
            //if we didn't find for the given sequence, then we are done and can just return null
            if (!found) {
                return null;
            }
        }

        final ObservationCollection<ItemSet<T>> result = tsBuilder.result();

        return (pattern.itemsets.size() * 1.0 / matches * 1.0 >= threshold) ? result : null;
    }

    private boolean isSubset(ItemSet<T> itemsToCheck,ItemSet<T> itemsAgainstCheck) {
        for (T item : itemsToCheck) {
            if (!itemsAgainstCheck.contains(item)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "matcher(type=subseq match_threshold=" + threshold + " threshold_type=pm)";
    }
}
