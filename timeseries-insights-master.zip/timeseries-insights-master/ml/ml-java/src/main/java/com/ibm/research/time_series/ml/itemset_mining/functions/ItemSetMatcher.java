package com.ibm.research.time_series.ml.itemset_mining.functions;

import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.sequence_mining.containers.ItemSet;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.Base64;

/**
 * Matcher function for {@link ItemSet} where given an ItemSet and a time-series, if the ItemSet matches in the
 * time-series, return a time series, otherwise if there is no match, return null
 * @param <T> type of item
 */
public interface ItemSetMatcher<T> extends Serializable, JsonIO {
    /**
     * Matcher function for {@link ItemSet} where given an ItemSet and a time-series, if the ItemSet matches in the
     * time-series, return a time series, otherwise if there is no match, return null
     * @param s1 the item-set
     * @param s2 the time-series
     * @return a time-series, if the ItemSet matches, otherwise if there is no match, return null
     */
    ObservationCollection<T> matches(ItemSet<T> s1, ObservationCollection<T> s2);

    @Override
    default void writeJson(JsonGenerator jsonGen) throws IOException {
        ByteArrayOutputStream baStreamMatcher = new ByteArrayOutputStream();
        ObjectOutputStream ooStreamMatcher = new ObjectOutputStream(baStreamMatcher);
        ooStreamMatcher.writeObject(this);
        ooStreamMatcher.close();
        ooStreamMatcher.close();
        jsonGen.writeBinaryField("matcher", baStreamMatcher.toByteArray());
    }

    static <T> ItemSetMatcher<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        byte[] bArrayMatcher = Base64.getDecoder().decode(jsonNode.get("matcher").asText().getBytes("UTF-8"));
        ByteArrayInputStream baStreamMatcher = new ByteArrayInputStream(bArrayMatcher);
        ObjectInputStream oStreamMatcher = new ObjectInputStream(baStreamMatcher);
        return (ItemSetMatcher<T>)oStreamMatcher.readObject();
    }
}
