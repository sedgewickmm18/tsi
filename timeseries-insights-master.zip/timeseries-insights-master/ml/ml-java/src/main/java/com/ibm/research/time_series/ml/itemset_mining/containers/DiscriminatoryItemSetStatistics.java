package com.ibm.research.time_series.ml.itemset_mining.containers;

import com.ibm.research.time_series.ml.sequence_mining.containers.DiscriminatorySubSequenceStatistics;
import com.ibm.research.time_series.ml.sequence_mining.containers.JsonIO;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;

/**
 * This class provides various statistics on the item-set, this is associated with a Discriminatory ItemSet Mining Algorithm.
 * Statistics range from (1) Coverage, (2) Lift, (3) Length statistics
 *
 * All immutable variables can be accessed as public variables, e.g. diss.originalSizeLeft
 *
 * <p>Created on 1/3/18.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DiscriminatoryItemSetStatistics implements Serializable,Comparable<DiscriminatoryItemSetStatistics>, JsonIO {
    private static final long serialVersionUID = 3298209778329490949L;

    /**
     * indicating the number of sequences in L-set that match the itemset
     */
    public final long originalSizeLeft;
    /**
     * indicating the number of sequences in R-set that match the itemset
     */
    public final long originalSizeRight;
    /**
     * indicating the ratio of match to the L-set (# matches / total # of itemsets)
     */
    public final long binaryMatchNormalizedFrequencyLeft;
    /**
     * indicating the ratio of match to the R-set (# matches / total # of itemsets)
     */
    public final long binaryMatchNormalizedFrequencyRight;
    /**
     * Inter-arrival statistics (timing) for the DSM itemset
     */
    public final DurationStatistics durationStatistics;

    public long originalSizeLeft() {
        return originalSizeLeft;
    }

    public long originalSizeRight() {
         return originalSizeRight;
    }

    public long binaryMatchNormalizedFrequencyLeft() {
        return binaryMatchNormalizedFrequencyLeft;
    }

    public long binaryMatchNormalizedFrequencyRight() {
        return binaryMatchNormalizedFrequencyRight;
    }

    public DurationStatistics durationStatistics() {
        return durationStatistics;
    }

    /**
     * Construct a Discriminatory Sequence Statistics
     *
     * @param originalSizeLeft Immutable variable, indicating the number of sequences in L-set that match the itemset
     * @param originalSizeRight Immutable variable, indicating the number of sequences in R-set that match the itemset
     * @param binaryMatchNormalizedFrequencyLeft Immutable variable, indicating the ratio of match to the L-set (# matches / total # of itemsets)
     * @param binaryMatchNormalizedFrequencyRight Immutable variable, indicating the ratio of match to the R-set (# matches / total # of itemsets)
     * @param durationStatistics Length statistics for the Discriminatory ItemSet
     */
    public DiscriminatoryItemSetStatistics(
            long originalSizeLeft,
            long originalSizeRight,
            long binaryMatchNormalizedFrequencyLeft,
            long binaryMatchNormalizedFrequencyRight,
            DurationStatistics durationStatistics) {
        this.originalSizeLeft = originalSizeLeft;
        this.originalSizeRight = originalSizeRight;
        this.binaryMatchNormalizedFrequencyLeft = binaryMatchNormalizedFrequencyLeft;
        this.binaryMatchNormalizedFrequencyRight = binaryMatchNormalizedFrequencyRight;
        this.durationStatistics = durationStatistics;
    }

    /**
     * @return The coverage of the L-set for the itemset.
     */
    public double coverageLeft() {
        return binaryMatchNormalizedFrequencyLeft * 1.0 / originalSizeLeft * 1.0;
    }

    /**
     * @return The coverage of the R-set the itemset.
     */
    public double coverageRight() {
        return binaryMatchNormalizedFrequencyRight * 1.0 / originalSizeRight * 1.0;
    }

    /**
     * @return Lift, a measure indicating how many times the itemset is more likely to occur
     *         in L-set than R-set.
     */
    public double lift() {
        return coverageLeft() / coverageRight();
    }

    /**
     * @return A string representation of this statistics.
     */
    @Override
    public String toString() {
        return "discriminatory-item-set-statistics(" + "\n" +
                "\t" + "duration-statistics=" + "duration-statistics(" + "\n" +
                "\t\tmin=" + durationStatistics.min + "\n" +
                "\t\tmax=" + durationStatistics.max + "\n" +
                "\t\tsum=" + durationStatistics.sum + "\n" +
                "\t\tavg=" + durationStatistics.average + "\n" +
                "\t\tvariance=" + durationStatistics.variance + "\n" +
                "\t\tsd=" + durationStatistics.sd + "\n" +
                "\t\tmin-lead-time=" + durationStatistics.minLeadTime + "\n" +
                "\t\tmax-lead-time=" + durationStatistics.maxLeadTime + "\n" +
                "\t\tsum-lead-time=" + durationStatistics.sumLeadTime + "\n" +
                "\t\tavg-lead-time=" + durationStatistics.averageLeadTime + "\n" +
                "\t\tvariance-lead-time=" + durationStatistics.varianceLeadTime + "\n" +
                "\t\tsd-lead-time=" + durationStatistics.sdLeadTime + "\n" +
                "\t\tmin-end-time=" + durationStatistics.minEndTime + "\n" +
                "\t\tmax-end-time=" + durationStatistics.maxEndTime + "\n" +
                "\t\tsum-end-time=" + durationStatistics.sumEndTime + "\n" +
                "\t\tavg-end-time=" + durationStatistics.averageEndTime + "\n" +
                "\t\tvariance-end-time=" + durationStatistics.varianceEndTime + "\n" +
                "\t\tsd-end-time=" + durationStatistics.sdEndTime + "\n" +
                "\t" + ")" + "\n" +
                "\t" + "original-size-left=" + originalSizeLeft + "\n" +
                "\t" + "original-size-right=" + originalSizeRight + "\n" +
                "\t" + "binary-match-norm-frequency-left=" + binaryMatchNormalizedFrequencyLeft + "\n" +
                "\t" + "binary-match-norm-frequency-right=" + binaryMatchNormalizedFrequencyRight + "\n" +
                "\t" + "coverage-left=" + coverageLeft() + "\n" +
                "\t" + "coverage-right=" +coverageRight() + "\n" +
                "\t" + "lift=" + lift() + "\n" +
                ")\n";
    }

    /**
     * @param o the other Discriminatory ItemSet Statistics object
     * @return double comparison of this objects lift and another {@link DiscriminatoryItemSetStatistics} lift
     */
    @Override
    public int compareTo(DiscriminatoryItemSetStatistics o) {
        return Double.compare(lift(), o.lift());
    }

    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeFieldName("discriminatory-item-set-statistics");
        jsonGen.writeStartObject();

        //append item-set-statistics;
        durationStatistics.writeJson(jsonGen);

        //append the original size
        jsonGen.writeNumberField("original-size-left", originalSizeLeft);
        jsonGen.writeNumberField("original-size-right", originalSizeRight);

        //append binary match norm frequency
        jsonGen.writeNumberField(
                "binary-match-normalized-frequency-left", binaryMatchNormalizedFrequencyLeft
        );

        //append multi match norm frequency
        jsonGen.writeNumberField(
                "binary-match-normalized-frequency-right", binaryMatchNormalizedFrequencyRight
        );

        jsonGen.writeEndObject();//end frequent-sequence-statistics
    }

    static DiscriminatoryItemSetStatistics fromJson(JsonNode jsonNode) {
        //get our statistics
        JsonNode statisticsObj = jsonNode.get("discriminatory-item-set-statistics");

        //get our inter arrival statistics
        DurationStatistics durationStatistics = DurationStatistics.fromJson(statisticsObj);

        //get all of our fields
        int binFreqLeft = statisticsObj.get("binary-match-normalized-frequency-left").asInt();
        int binFreqRight = statisticsObj.get("binary-match-normalized-frequency-right").asInt();
        long originalSizeLeft = statisticsObj.get("original-size-left").asLong();
        long originalSizeRight = statisticsObj.get("original-size-right").asLong();

        return new DiscriminatoryItemSetStatistics(
                originalSizeLeft,
                originalSizeRight,
                binFreqLeft,
                binFreqRight,
                durationStatistics
        );
    }
}
