package com.ibm.research.time_series.ml.clustering.k_means.containers;

import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;
import com.ibm.research.time_series.ml.clustering.TimeSeriesClusteringModel;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * This is the abstract class to represent a generic KMeans Model
 *
 * This implementation takes care of simple writing to JSON for both {@link ConstraintKMeansModel} and
 * {@link NonConstraintKMeansModel}. It also provides a simple static helper method for loading centroids from JSON
 *
 * @param <T> model value type
 */
abstract class KMeansModel<T> extends TimeSeriesClusteringModel<T>{

    /**
     * Construct a KMeansModel from centroids and intra/inter/silhouette-coefficient metrics
     *
     * @param centroids list of {@link ObservationCollection} that denote a list of centroid time series
     * @param intraClusterDistances the average between all points in a cluster from its cluster center
     * @param interClusterDistances the average distance from the second closest centroid for each point
     *                              grouped by its closest centroid
     * @param silhouetteCoefficients for each cluster,
     *                               (interClusterDistance(i) - intraClusterDistance(i)) /  interClusterDistance(i)
     */
    KMeansModel(
            List<ObservationCollection<T>> centroids,
            List<Double> intraClusterDistances,
            List<Double> interClusterDistances,
            List<Double> silhouetteCoefficients,
            List<Double> clusterDistributions,
            List<Double> sumSquares) {
        super(centroids, intraClusterDistances, interClusterDistances, silhouetteCoefficients,clusterDistributions,sumSquares);
    }

    /**
     * given a json generator and a value, write th value to a json as a byte array
     *
     * @param jsonGen json generator
     * @param value value to write
     * @throws IOException
     */
    @Override
    protected void writeObservationValueToJSON(JsonGenerator jsonGen, T value) throws IOException {
        ByteArrayOutputStream baStream = new ByteArrayOutputStream();
        ObjectOutputStream ooStream = new ObjectOutputStream(baStream);
        ooStream.writeObject(value);
        ooStream.close();
        baStream.close();
        jsonGen.writeBinaryField("value",baStream.toByteArray());
    }

    /**
     * load centroids from a json object
     *
     * @param jsonObject json object
     * @param <T> observation value type
     * @return list of {@link ObservationCollection}
     * @throws IOException
     * @throws ClassNotFoundException
     */
    static <T> List<ObservationCollection<T>> loadCentroids(JsonNode jsonObject) throws IOException, ClassNotFoundException {
        List<ObservationCollection<T>> loadedCentroids = new ArrayList<>();
        JsonNode jsonCentroidArray = jsonObject.get("centroids");
        for (int i = 0;i < jsonCentroidArray.size();i++) {
            JsonNode centroidObj = jsonCentroidArray.get(i);
            TSBuilder<T> tsBuilder = Observations.newBuilder();
            for (int j = 0;j < centroidObj.size();j++) {
                JsonNode observationObj = centroidObj.get(j);

                long timestamp = observationObj.get("timestamp").asLong();
                byte[] bArrayValue = Base64.getDecoder().decode(observationObj.get("value").toString().getBytes("UTF-8"));
                ByteArrayInputStream baStreamValue = new ByteArrayInputStream(bArrayValue);
                ObjectInputStream oStreamValue = new ObjectInputStream(baStreamValue);
                T value = (T)oStreamValue.readObject();
                tsBuilder.add(new Observation<>(timestamp,value));
            }
            loadedCentroids.add(tsBuilder.result());
        }
        return loadedCentroids;
    }
}
