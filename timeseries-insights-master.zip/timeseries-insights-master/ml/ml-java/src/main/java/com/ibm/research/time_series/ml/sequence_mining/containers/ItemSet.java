/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import com.ibm.research.time_series.ml.itemset_mining.functions.ItemSetMatcher;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.*;
import java.util.*;

/**
 * A holder class for an ItemSet.
 *
 * This will be used as input to the {@link ItemSetMatcher} and
 * {@link com.ibm.research.time_series.ml.sequence_mining.functions.SequenceMatcher} functions.
 *
 * A ItemSet essentially is an {@link ArrayList} of items
 *
 * <p>Created on 8/29/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class ItemSet<ITEM> extends ArrayList<ITEM> implements JsonIO {
    private static final long serialVersionUID = 9196922279457347165L;

    /**
     * Construct a itemset from a list
     *
     * @param itemSet list of items
     */
    public ItemSet(Collection<? extends ITEM> itemSet) {
        super(itemSet);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ItemSet))
            return false;

        ItemSet<ITEM> other = (ItemSet<ITEM>)o;

        return super.equals(other);
    }

    @Override
    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeArrayFieldStart("items");
        for (ITEM item : this) {
            ByteArrayOutputStream baStream = new ByteArrayOutputStream();
            ObjectOutputStream ooStream = new ObjectOutputStream(baStream);
            ooStream.writeObject(item);
            ooStream.close();
            baStream.close();
            jsonGen.writeBinary(baStream.toByteArray());
        }
        jsonGen.writeEndArray();
    }
    //todo this is really only meant for the developer but because it is being used in both sequence mining and item-set mining it is public. May just create a utils for this that is not open to users
    public static <T> ItemSet<T> fromJson(JsonNode jsonNode) throws IOException, ClassNotFoundException {
        JsonNode items = jsonNode.get("items");
        List<T> itemSet = new ArrayList<>();
        for (int k = 0;k < items.size();k++) {
            byte[] bArray = Base64.getDecoder().decode((items.get(k).asText()).getBytes("UTF-8"));
            ByteArrayInputStream baStream = new ByteArrayInputStream(bArray);
            ObjectInputStream oStream = new ObjectInputStream(baStream);
            itemSet.add((T)oStream.readObject());
        }
        return new ItemSet<>(itemSet);
    }
}
