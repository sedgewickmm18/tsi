package com.ibm.research.time_series.ml.anomaly_detection;

import java.util.HashSet;
import java.util.Set;

public class DrillDownSchema {

    DrillDownNode drillDownNode;
    private Set<String> allNodeNames;
    private Set<String> leaves;

    public DrillDownSchema(DrillDownNode drillDownNode) {
           this.drillDownNode = drillDownNode;
           this.leaves = new HashSet<>();
           this.allNodeNames = new HashSet<>();
           updateLevels(drillDownNode, 0);
    }

    Set<String> getLeaves() {
        return leaves;
    }

    @Override
    public String toString() {
        return drillDownNode.toString();
    }

    private void updateLevels(DrillDownNode drillDownNode, int level) {
        if (allNodeNames.contains(drillDownNode.getName())) throw new IllegalStateException("Cannot have 2 nodes with the same name: " + drillDownNode.getName());
        allNodeNames.add(drillDownNode.getName());
        if (drillDownNode.isLeaf()) {
            leaves.add(drillDownNode.getName());
            drillDownNode.setLevel(level);
        } else {
            drillDownNode.setLevel(level);
            drillDownNode.getChildren().forEach(child -> updateLevels(child, level + 1));
        }
    }


}
