/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.sequence_mining.containers;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonNode;

import java.io.IOException;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.stream.Collectors;

/**
 * A holder class for holding a single discriminatory subsequence. This is used by the model class, [[DiscriminatorySubSequenceModel]].
 *
 * Immutable variables can be accessed directly, e.g., dss.dssArray (Scala), dss.dssArray (Java).
 *
 * <p>Created on 4/24/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class DiscriminatorySubSequence<T> implements Serializable, JsonIO{
    private static final long serialVersionUID = -8998372926408239479L;
    //todo make these all private, no real need for them to be public

    /**
     * holder of the subsequence created by the DSM algorithm
     */
    public final ItemSetSequence<T> sequence;
    /**
     * holder of the statistics for this subsequence
     */
    public final DiscriminatorySubSequenceStatistics statistics;

    /**
     * unique identifier for this DiscriminatorySubSequence in the {@link DiscriminatorySubSequenceModel}
     */
    public final long sequenceID;

    /**
     * @param sequence Immutable variable, holder of the subsequence created by the DSM algorithm
     * @param statistics Immutable variable, holder of the statistics for this subsequence
     * @param sequenceID Immutable variable, unique id for this DiscriminatorySubSequence in the {@link DiscriminatorySubSequenceModel}
     */
    public DiscriminatorySubSequence(
            ItemSetSequence<T> sequence,
            DiscriminatorySubSequenceStatistics statistics,
            long sequenceID) {
        this.sequence = sequence;
        this.statistics = statistics;
        this.sequenceID = sequenceID;
    }

    /**
     * @return the itemset sequence in this DiscriminatorySubSequence
     */
    public ItemSetSequence<T> sequence() {
        return sequence;
    }

    /**
     * @return the statistics in this DiscriminatorySubSequence
     */
    public DiscriminatorySubSequenceStatistics statistics() {
        return statistics;
    }

    /**
     * @return the unique identifier for this DiscriminatorySubSequence in the {@link DiscriminatorySubSequenceModel}
     */
    public long sequenceID() {
        return sequenceID;
    }

    @Override
    public String toString() {
        return "discriminatory-sub-sequence(" + "\n" +
                "\t" + "sequence-id=" + sequenceID + "\n" +
                "\t" + "statistics=" + "discriminatory-sub-sequence-statistics(" + "\n" +
                "\t\t" + "inter-arrival-statistics=" + ((statistics.interArrivalStatistics != null) ? "(\n" + statistics.interArrivalStatistics.stream().map(x -> "\t\t\t" + x.toString()).collect(Collectors.joining("\n")) + "\n\t\t)\n" : "None\n") +
                "\t\t" + "original-size-left=" + statistics.originalSizeLeft + "\n" +
                "\t\t" + "original-size-right=" + statistics.originalSizeRight + "\n" +
                "\t\t" + "binary-match-norm-frequency-left=" + statistics.binaryMatchNormalizedFrequencyLeft + "\n" +
                "\t\t" + "binary-match-norm-frequency-right=" + statistics.binaryMatchNormalizedFrequencyRight + "\n" +
                "\t\t" + "coverage-left=" + statistics.coverageLeft() + "\n" +
                "\t\t" + "coverage-right=" + statistics.coverageRight() + "\n" +
                "\t\t" + "lift=" + statistics.lift() + "\n" +
                "\t\t" + "lift-sequence=" + ((statistics.lifts != null) ? statistics.lifts.stream().map(x -> x.toString()).collect(Collectors.joining(",","[","]")) : "lift sequence not supported by this model") + "\n" +
                "\t)\n" +
                "\t" + "sequence=" + sequence.toString() + "\n" +
                ")";
    }

    @Override
    public int hashCode() {
        //todo this may clash later, might want to change this to some model hashcode + sequenceID
        return Long.hashCode(sequenceID) +
                sequence.itemsets.stream().mapToInt(AbstractList::hashCode).sum() +
                statistics.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        //make sure other isn't null
        if(o == null){
            return false;
        }

        //if other's reference is this, they are definitely equal
        if(o == this){
            return true;
        }

        if (!(o instanceof DiscriminatorySubSequence)) {
            return false;
        }

        DiscriminatorySubSequence<T> other = (DiscriminatorySubSequence<T>)o;

        if (other.sequenceID != sequenceID) {
            return false;
        }

        if (!other.sequence.itemsets.equals(sequence.itemsets)) {
            return false;
        }

        if (!other.statistics.equals(statistics)) {
            return false;
        }

        return true;
    }

    public void writeJson(JsonGenerator jsonGen) throws IOException {
        jsonGen.writeStartObject();
        jsonGen.writeNumberField("sequence-id",sequenceID);
        statistics.writeJson(jsonGen);
        sequence.writeJson(jsonGen);
        jsonGen.writeEndObject();
    }

    static <T> DiscriminatorySubSequence<T> fromJson(JsonNode seqObj) throws IOException, ClassNotFoundException {
        DiscriminatorySubSequenceStatistics discriminatorySubSequenceStatistics = DiscriminatorySubSequenceStatistics.fromJson(seqObj);
        long sequenceID = seqObj.get("sequence-id").asLong();

        //get our itemsets
        final ItemSetSequence<T> iss = ItemSetSequence.fromJson(seqObj);

        return new DiscriminatorySubSequence<>(
                iss,
                discriminatorySubSequenceStatistics,
                sequenceID
        );
    }
}
