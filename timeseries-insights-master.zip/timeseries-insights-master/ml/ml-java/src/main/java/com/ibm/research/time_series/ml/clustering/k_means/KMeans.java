package com.ibm.research.time_series.ml.clustering.k_means;

import com.ibm.research.time_series.core.functions.BinaryMapFunction;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.ml.clustering.k_means.containers.ConstraintKMeansModel;
import com.ibm.research.time_series.ml.clustering.k_means.containers.NonConstraintKMeansModel;
import com.ibm.research.time_series.ml.clustering.k_means.functions.WeightedSumFunction;
import com.ibm.research.time_series.transforms.reducers.distance.DistanceReducers;
import com.ibm.research.time_series.transforms.reducers.distance.dtw.algorithm.IObjectDistanceCalculator;

import java.util.List;

/**
 * Entry point to creating a {@link ConstraintKMeansModel} and {@link NonConstraintKMeansModel}
 */
public class KMeans {
    /**
     * train a {@link ConstraintKMeansModel} using KMeans given initial centroids
     *
     * Note: Constraint implies that TimeSeries must all be of the same size
     *
     * @param multiTimeSeries the set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to mine for
     *                        clusters
     * @param distanceOp a distance operation between 2 time series values
     * @param weightedSumOp a {@link WeightedSumFunction}
     * @param initialCentroids the initial centroids to be used in KMeans
     * @param maxIterations the maximum number of iterations to run
     * @param minShiftDistance the minimum shift distance
     * @param <T> the observation value type
     * @return a new {@link ConstraintKMeansModel}
     */
    public static <T> ConstraintKMeansModel<T> trainConstraint(
            MultiTimeSeries<?,T> multiTimeSeries,
            IObjectDistanceCalculator<T> distanceOp,
            WeightedSumFunction<T> weightedSumOp,
            List<ObservationCollection<T>> initialCentroids,
            int maxIterations,
            double minShiftDistance) {
        return new ConstraintKMeans<>(distanceOp).train(multiTimeSeries,initialCentroids,weightedSumOp,maxIterations,minShiftDistance);
    }

    /**
     * train a {@link NonConstraintKMeansModel} using KMeans given initial centroids
     *
     * Note: NonConstraint implies that TimeSeries need not all be of the same size
     *
     * @param multiTimeSeries the set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to mine for
     *                        clusters
     * @param distanceOp a distance operation between 2 time series
     * @param weightedSumOp a {@link WeightedSumFunction}
     * @param initialCentroids the initial centroids to be used in KMeans
     * @param maxIterations the maximum number of iterations to run
     * @param minShiftDistance the minimum shift distance
     * @param <T> the observation value type
     * @return a new {@link NonConstraintKMeansModel}
     */
    public static <T> NonConstraintKMeansModel<T> trainNonConstraint(
            MultiTimeSeries<?,T> multiTimeSeries,
            BinaryMapFunction<ObservationCollection<T>,ObservationCollection<T>,Double> distanceOp,
            WeightedSumFunction<T> weightedSumOp,
            List<ObservationCollection<T>> initialCentroids,
            int maxIterations,
            double minShiftDistance) {
        return new NonConstraintKMeans<>(distanceOp).train(multiTimeSeries,initialCentroids,weightedSumOp,maxIterations,minShiftDistance);
    }

    /**
     * train a {@link ConstraintKMeansModel} using KMeans++
     *
     * Note: Constraint implies that TimeSeries must all be of the same size
     *
     * @param multiTimeSeries the set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to mine for
     *                        clusters
     * @param distanceOp a distance operation between 2 time series values
     * @param weightedSumOp a {@link WeightedSumFunction}
     * @param numCentroids the final number of centroids to be produced
     * @param maxIterations the maximum number of iterations to run
     * @param minShiftDistance the minimum shift distance
     * @param <T> the observation value type
     * @return a new {@link ConstraintKMeansModel}
     */
    public static <T> ConstraintKMeansModel<T> trainConstraint(
            MultiTimeSeries<?,T> multiTimeSeries,
            IObjectDistanceCalculator<T> distanceOp,
            WeightedSumFunction<T> weightedSumOp,
            int numCentroids,
            int maxIterations,
            double minShiftDistance) {
        List<ObservationCollection<T>> initialCentroids = KMeansUtils.computeSeedCentroids(
                multiTimeSeries,
                (x,y) -> x.toTimeSeriesStream().reduce(y.toTimeSeriesStream(), DistanceReducers.nonTimewarpedDtw(distanceOp)),
                numCentroids
        );

        return new ConstraintKMeans<>(distanceOp).train(multiTimeSeries,initialCentroids,weightedSumOp,maxIterations,minShiftDistance);
    }

    /**
     * train a {@link NonConstraintKMeansModel} using KMeans++
     *
     * Note: NonConstraint implies that TimeSeries need not all be of the same size
     *
     * @param multiTimeSeries the set of {@link com.ibm.research.time_series.core.timeseries.TimeSeries} to mine for
     *                        clusters
     * @param distanceOp a distance operation between 2 time series
     * @param weightedSumOp a {@link WeightedSumFunction}
     * @param numCentroids the final number of centroids to be produced
     * @param maxIterations the maximum number of iterations to run
     * @param minShiftDistance the minimum shift distance
     * @param <T> the observation value type
     * @return a new {@link NonConstraintKMeansModel}
     */
    public static <T> NonConstraintKMeansModel<T> trainNonConstraint(
            MultiTimeSeries<?,T> multiTimeSeries,
            BinaryMapFunction<ObservationCollection<T>,ObservationCollection<T>,Double> distanceOp,
            WeightedSumFunction<T> weightedSumOp,
            int numCentroids,
            int maxIterations,
            double minShiftDistance) {
        List<ObservationCollection<T>> initialCentroids = KMeansUtils.computeSeedCentroids(
                multiTimeSeries,
                distanceOp::evaluate,
                numCentroids
        );

        return new NonConstraintKMeans<>(distanceOp).train(multiTimeSeries,initialCentroids,weightedSumOp,maxIterations,minShiftDistance);
    }
}
