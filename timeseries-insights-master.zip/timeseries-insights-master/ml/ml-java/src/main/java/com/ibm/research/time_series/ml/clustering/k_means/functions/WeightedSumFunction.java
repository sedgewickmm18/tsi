/*
 * ************* Begin Copyright - Do not add comments here **************
 *  * Licensed Materials - Property of IBM
 *  *
 *  *   OCO Source Materials
 *  *
 *  *   (C) Copyright IBM Corp. 2017, All Rights Reserved
 *  *
 *  * The source code for this program is not published or other-
 *  * wise divested of its trade secrets, irrespective of what has
 *  * been deposited with the U.S. Copyright Office.
 *  ***************************** End Copyright ***************************
 */

package com.ibm.research.time_series.ml.clustering.k_means.functions;

import java.io.Serializable;

/**
 * Interface for computing the weighted sum function over two generic values
 *
 * This will be used in creation of
 * {@link com.ibm.research.time_series.ml.clustering.k_means.containers.ConstraintKMeansModel} and
 * {@link com.ibm.research.time_series.ml.clustering.k_means.containers.NonConstraintKMeansModel}
 *
 * <p>Created on 8/30/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public interface WeightedSumFunction<T> extends Serializable{
    /**
     * apply a weighted sum function against 2 generic values to produce a new value
     *
     * The idea behind this function is to produce a single value that possesses the aspects of two generic values,
     * where each generic value may be weighted differently.
     *
     * @param value1 first generic value
     * @param value2 second generic value
     * @param weight1 first generic value's weight
     * @param weight2 second generic value's weight
     * @return a generic value that is the product of this function
     */
    T apply(T value1,T value2,double weight1,double weight2);
}
