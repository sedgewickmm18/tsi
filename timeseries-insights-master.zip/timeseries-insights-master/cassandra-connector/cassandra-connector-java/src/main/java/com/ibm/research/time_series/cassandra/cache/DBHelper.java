package com.ibm.research.time_series.cassandra.cache;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

import java.io.ByteArrayOutputStream;

class DBHelper {
    Kryo kryo = new Kryo();//kryo serializer

    /**
     * serialize an object using kryo
     * @param object the object to serialize
     * @return a byte array representing the serialized object
     */
    public byte[] serialize(Object object){
        kryo.register(object.getClass());
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        Output output = new Output(bytes);
        kryo.writeClassAndObject(output,object);
        return output.toBytes();
    }

    /**
     * deserialize a byte[] using kryo
     * @param bytes the byte array to deserialize
     * @return an object representing the deserialize byte array
     */
    public Object deserialize(byte[] bytes) {
        Input input = new Input(bytes);
        Object result = kryo.readClassAndObject(input);
        return result;
    }

}