package com.ibm.research.time_series.cassandra.timeseries;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.io.TimeSeriesReader;

import java.util.HashMap;
import java.util.Map;

/**
 * Abstract class to handle the generation of CassandraSensorReaders.
 * <p>One may consider using this class if they have multiple sensor time series stored by key in a cassandraDB</p>
 * <p>To create a CassandraMultiTimeSeriesReader, one must implement the extractTimeStampSensor(Row row) method. For each key in the table,
 * a new TimeSeriesReader will be generated and stored into the TimeSeriesReader mapWindow</p>
 * <p>Created on 5/5/16.</p>
 *
 * @param <PRIMARY_TYPE> - type of value of TimeSeriesReader
 * @author Joshua Rosenkranz
 */
public class CassandraMultiTimeSeriesReader<PRIMARY_TYPE> extends MultiTimeSeriesReader<PRIMARY_TYPE, Row> {

    private String keySpace;
    private String tableName;
    private String primaryName;
    private Cluster cluster;
    private Session session;
    private UnaryMapFunction<Row,Long> rowToTimeStamp;

    /**
     * Constructor for a CassandraMultiTimeSeriesReader
     * @param host host for connection to cassandraDB
     * @param port port for connection to cassandraDB
     * @param keySpace keyspace to use
     * @param tableName table name to use
     * @param primaryName primary name to use
     */
    public CassandraMultiTimeSeriesReader(String host, int port, String keySpace, String tableName, String primaryName, UnaryMapFunction<Row,Long> rowToTimeStamp){
        this.tableName = tableName;
        this.primaryName = primaryName;
        this.keySpace = keySpace;
        this.rowToTimeStamp = rowToTimeStamp;

        PoolingOptions poolingOptions = new PoolingOptions();

        poolingOptions.setHeartbeatIntervalSeconds(10000);

        cluster = Cluster.builder()
                .addContactPoint(host)
                .withPort(port)
                .withPoolingOptions(poolingOptions)
                .build();
        session = cluster.connect(this.keySpace);
    }

    /**
     * populates the TimeSeriesReader mapWindow with a new CassandraTimeSeriesReader for each key in the table.
     *
     * <p>For example: If each key is a new sensor id, a new Cassandra reader will be created for each sensor id at which point
     * it is placed in the TimeSeriesReader mapWindow readerMap</p>
     */
    @Override
    protected Map<PRIMARY_TYPE,TimeSeriesReader<Row>> populateMap() {
        Map<PRIMARY_TYPE,TimeSeriesReader<Row>> result = new HashMap<>();
        Statement statement = QueryBuilder.select().distinct().column(primaryName)
                .from(keySpace,tableName);

        ResultSet rs = session.execute(statement);

        rs.forEach(x -> {

            PRIMARY_TYPE key = (PRIMARY_TYPE)x.getObject(primaryName);
            if (!result.containsKey(key)) {
                TimeSeriesReader<Row> cassandra = new CassandraTimeSeriesReader<>(session,keySpace,tableName,primaryName,key,rowToTimeStamp);
                result.put(key,cassandra);
            }

        });

        return result;
    }

    @Override
    public void close() {
        cluster.close();
    }
}
