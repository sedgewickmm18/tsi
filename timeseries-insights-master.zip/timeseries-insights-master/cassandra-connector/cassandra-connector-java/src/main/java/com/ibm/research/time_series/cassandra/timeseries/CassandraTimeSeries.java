package com.ibm.research.time_series.cassandra.timeseries;

import com.datastax.driver.core.Row;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.timeseries.TimeSeries;

import java.util.concurrent.atomic.AtomicLong;

/**
 * <p>Created on 3/31/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class CassandraTimeSeries {
    public static <PRIMARY_TYPE> TimeSeries<Row> cassandraDB(
            String host,
            int port,
            String keySpace,
            String tableName,
            String primaryName,
            PRIMARY_TYPE primaryKey){
        AtomicLong l = new AtomicLong(0);
        return TimeSeries.reader(
                new CassandraTimeSeriesReader<>(
                        host,
                        port,
                        keySpace,
                        tableName,
                        primaryName,
                        primaryKey,
                        row -> l.getAndAdd(1)
                )
        ).cache();
    }

    public static <PRIMARY_TYPE> TimeSeries<Row> cassandraDB(
            String host,
            int port,
            String keySpace,
            String tableName,
            String primaryName,
            PRIMARY_TYPE primaryKey,
            UnaryMapFunction<Row,Long> rowToTimestamp) {
        return TimeSeries.reader(
                new CassandraTimeSeriesReader<>(
                        host,
                        port,
                        keySpace,
                        tableName,
                        primaryName,
                        primaryKey,
                        rowToTimestamp
                )
        ).cache();
    }

    public static <PRIMARY_TYPE> TimeSeries<Row> cassandraDB(
            String host,
            int port,
            String keySpace,
            String tableName,
            String primaryName,
            PRIMARY_TYPE primaryKey,
            UnaryMapFunction<Row,Long> rowToTimestamp,
            long start,
            long end) {
        return TimeSeries.reader(
                new CassandraTimeSeriesReader<>(
                        host,
                        port,
                        keySpace,
                        tableName,
                        primaryName,
                        primaryKey,
                        rowToTimestamp,
                        start,
                        end
                )
        ).cache();
    }
}
