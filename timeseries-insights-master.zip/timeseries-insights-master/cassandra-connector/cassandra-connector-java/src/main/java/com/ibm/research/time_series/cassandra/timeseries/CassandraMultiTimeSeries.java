package com.ibm.research.time_series.cassandra.timeseries;

import com.datastax.driver.core.Row;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.MultiTimeSeriesReader;
import com.ibm.research.time_series.core.timeseries.MultiTimeSeries;

/**
 * <p>Created on 3/31/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class CassandraMultiTimeSeries {
    public static <PRIMARY_TYPE> MultiTimeSeries<PRIMARY_TYPE,Row> cassandraDB(String host, int port, String keySpace, String tableName, String primaryName, UnaryMapFunction<Row,Long> rowToTimestamp){
        MultiTimeSeriesReader<PRIMARY_TYPE,Row> multiTimeSeriesReader = new CassandraMultiTimeSeriesReader<>(
                host,
                port,
                keySpace,
                tableName,
                primaryName,
                rowToTimestamp
        );
        return MultiTimeSeries.reader(multiTimeSeriesReader);
    }
}
