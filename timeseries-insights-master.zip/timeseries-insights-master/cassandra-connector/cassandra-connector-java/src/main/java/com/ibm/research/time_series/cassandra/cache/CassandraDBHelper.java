package com.ibm.research.time_series.cassandra.cache;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.utils.Bytes;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import com.ibm.research.time_series.core.utils.Observations;
import com.ibm.research.time_series.core.utils.TSBuilder;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * <p>Created on 3/31/17.</p>
 *
 * @author Joshua Rosenkranz
 */
public class CassandraDBHelper<T> extends DBHelper {
    /**
     * given a Row from a ResultSet, build a Observation
     * @param row single row from a ResultSet
     * @return a Observation for the given row
     */
    public Observation<T> buildObservation(Row row){
        //get the mapWindow
//        Map<String,String> map = row.getMap("metadata",String.class,String.class);
//        Set<String> map_keys = map.keySet();
//        Properties p = new Properties();
//        for(String key : map_keys){
//            p.put(key,map.get(key));
//        }

        T value = (T)this.deserialize(Bytes.getArray(row.getBytes("value")));

        long timestamp = row.getLong("timestamp");

        Observation<T> result = new Observation<>(timestamp,value);
        return result;
    }

    /**
     * given a ResultSet, build a TreeSet of TimeStampSensors
     * @param resultSet the ResultSet result from a table query
     * @return a TreeSet of TimeStampSensors for the given ResultSet
     */
    public ObservationCollection<T> buildObservationCollection(ResultSet resultSet){
        TSBuilder<T> tsBuilder = Observations.newBuilder();

        List<Row> rows = resultSet.all();

        for(Row row : rows){
            Observation<T> tss = buildObservation(row);
            tsBuilder.add(tss);
        }
        return tsBuilder.result();
    }
}
