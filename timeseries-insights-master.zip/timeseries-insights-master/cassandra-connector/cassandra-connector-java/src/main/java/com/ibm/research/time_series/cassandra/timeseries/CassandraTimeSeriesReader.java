package com.ibm.research.time_series.cassandra.timeseries;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.Ordering;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.ibm.research.time_series.core.functions.UnaryMapFunction;
import com.ibm.research.time_series.core.io.TimeSeriesReader;
import com.ibm.research.time_series.core.observation.Observation;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This is the Cassandra DB TimeSeriesReader implementation of TimeSeriesReader.
 * <p>In order to extend this class, one must implement the buildObservation method and
 * one must create a constructor which calls super(String host,int port,String keySpace,String tableName,String primaryKey,String primaryName)</p>
 * <p>Created on 1/22/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class CassandraTimeSeriesReader<PRIMARY_TYPE> implements TimeSeriesReader<Row> {

    private String keySpace;
    private String tableName;
    private PRIMARY_TYPE primaryKey;
    private String primaryName;
    private Session session;
    private UnaryMapFunction<Row,Long> rowToTimestamp;
    private long start = -1;
    private long end = -1;

    /**
     * construct a Cassandra DB TimeSeriesReader with default keyspace 'sensor_information'
     * @param host host name
     * @param port port number
     * @param tableName table to use
     * @param primaryName primary name
     * @param primaryKey key to search on
     */
    public CassandraTimeSeriesReader(String host, int port, String tableName, String primaryName, PRIMARY_TYPE primaryKey, UnaryMapFunction<Row,Long> rowToTimestamp){
        this.tableName = tableName;
        this.primaryKey = primaryKey;
        this.primaryName = primaryName;
        this.keySpace = "sensor_information";
        this.rowToTimestamp = rowToTimestamp;

        Cluster cluster = Cluster.builder().addContactPoint(host).withPort(port).build();
        session = cluster.connect(this.keySpace);
    }

    public CassandraTimeSeriesReader(
            Session session,
            String keySpace,
            String tableName,
            String primaryName,
            PRIMARY_TYPE primaryKey,
            UnaryMapFunction<Row,Long> rowToTimestamp) {
        this.tableName = tableName;
        this.primaryKey = primaryKey;
        this.primaryName = primaryName;
        this.keySpace = keySpace;
        this.rowToTimestamp = rowToTimestamp;
        this.session = session;
    }

    /**
     * construct a Cassandra DB TimeSeriesReader overriding the default key space
     * @param host host name
     * @param port port number
     * @param keySpace key space to use
     * @param tableName table to use
     * @param primaryName primary name
     * @param primaryKey key to search on
     */
    public CassandraTimeSeriesReader(String host, int port, String keySpace, String tableName, String primaryName, PRIMARY_TYPE primaryKey, UnaryMapFunction<Row,Long> rowToTimestamp){
        this.tableName = tableName;
        this.primaryKey = primaryKey;
        this.primaryName = primaryName;
        this.keySpace = keySpace;
        this.rowToTimestamp = rowToTimestamp;

        Cluster cluster = Cluster.builder().addContactPoint(host).withPort(port).build();
        session = cluster.connect(this.keySpace);
    }

    public CassandraTimeSeriesReader(String host, int port, String keySpace, String tableName, String primaryName, PRIMARY_TYPE primaryKey, UnaryMapFunction<Row,Long> rowToTimestamp,long start,long end){
        this.tableName = tableName;
        this.primaryKey = primaryKey;
        this.primaryName = primaryName;
        this.keySpace = keySpace;
        this.rowToTimestamp = rowToTimestamp;
        this.start = start;
        this.end = end;

        Cluster cluster = Cluster.builder().addContactPoint(host).withPort(port).build();
        session = cluster.connect(this.keySpace);
    }

    /**
     * read our values from cassandraDB between t1 and t2
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return an iterator to the set of Observation values
     */
    @Override
    public Iterator<Observation<Row>> read(long t1, long t2, boolean inclusive) {
        Statement statement;

        if (start() == t1 && end() == t2) {
            statement = QueryBuilder.select()
                    .all()
                    .from(keySpace,tableName)
                    .where(QueryBuilder.eq(primaryName,primaryKey));
        } else {
            long lower = (inclusive) ? t1 - 1 : t1;
            long upper = (inclusive) ? t2 + 1 : t2;
            statement = QueryBuilder.select()
                    .all()
                    .from(keySpace,tableName)
                    .where(QueryBuilder.eq(primaryName,primaryKey))
                    .and(QueryBuilder.gte("timestamp",lower))
                    .and(QueryBuilder.lte("timestamp",upper));//todo this is hardcoded, need to fix
        }
        ResultSet rs = session.execute(statement);

        return buildObservationsIterator(rs);
    }

    /**
     * closes the cassandraDB session
     */
    @Override
    public void close() {
        session.close();
    }

    @Override
    public long start() {
        //start has been initialized either through setting or a query
        if (start != -1)
            return start;
        //start was not initialized so query
        else {
            Statement statement = QueryBuilder
                    .select()
                    .all()
                    .from(keySpace,tableName)
                    .where(QueryBuilder.eq(primaryName,primaryKey))//todo timestamp is hardcoded
                    .limit(1);

            ResultSet rs = session.execute(statement);
            Row row = rs.one();
            start = rowToTimestamp.evaluate(row);
            return start;
        }
    }

    @Override
    public long end() {
        //end has been initialized either through setting or a query
        if (end != -1)
            return end;
        //end was not initialized so query
        else {
            Statement statement = QueryBuilder
                    .select()
                    .all()
                    .from(keySpace,tableName)
                    .where(QueryBuilder.eq(primaryName,primaryKey))
                    .orderBy(QueryBuilder.desc("timestamp"))//todo timestamp is hardcoded
                    .limit(1);

            ResultSet rs = session.execute(statement);
            Row row = rs.one();
            end = rowToTimestamp.evaluate(row);
            return end;
        }

    }

//    @Override
//    public long start() {
//        Statement statement = QueryBuilder.select()
//                .column("timestamp")
//                .from(keySpace,tableName)
//                .limit(1);
//
//        ResultSet rs = session.execute(statement);
//        return rs.one().getLong("timestamp");
//    }

    //todo this needs to be fixed
    /*@Override
    public long end() {
        Statement statement = QueryBuilder.select()
                .column("timestamp")
                .from(keySpace,tableName)
                .orderBy(QueryBuilder.asc("timestamp"))
                .limit(1);
        ResultSet rs = session.execute(statement);
        return rs.one().getLong("timestamp");
    }*/

    /**
     * given a scanner, build a TreeSet of Observation
     * @param resultSet the ResultSet result from a table query
     * @return a TreeSet of Observation values for the given ResultSet
     */
    private Iterator<Observation<Row>> buildObservationsIterator(ResultSet resultSet){

        Iterator<Row> row = resultSet.iterator();

        return new Iterator<Observation<Row>>() {
            @Override
            public boolean hasNext() {
                return row.hasNext();
            }

            @Override
            public Observation<Row> next() {
                if(hasNext()){
                    Row r = row.next();
                    return new Observation<>(rowToTimestamp.evaluate(r),r);
                }else{
                    throw new NoSuchElementException("no more rows exist");
                }
            }
        };
    }

}
