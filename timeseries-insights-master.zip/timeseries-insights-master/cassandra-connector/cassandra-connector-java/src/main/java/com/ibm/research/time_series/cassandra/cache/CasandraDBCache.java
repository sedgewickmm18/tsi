package com.ibm.research.time_series.cassandra.cache;

import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.ibm.research.time_series.core.cache.DBCache;
import com.ibm.research.time_series.core.observation.Observation;
import com.ibm.research.time_series.core.utils.ObservationCollection;
import org.apache.log4j.Logger;

import java.nio.ByteBuffer;
import java.util.List;

/**
 * This is the class that handles our Cassandra DB cache and extends DBCache
 * <p>Anything that is specific to Cassandra is handled in this class while anything DB general will be handled in our DBCache class</p>
 * <p>Created on 1/7/16.</p>
 *
 * @author Joshua Rosenkranz
 */
public class CasandraDBCache<T> extends DBCache<T> {
    private static final Logger logger = Logger.getLogger(CasandraDBCache.class);

    private CassandraDBHelper<T> cassandraDBHelper = new CassandraDBHelper<>();//database helper class specific to cassandra
    private String tableName;//this is the table we want to use
    private String primaryKey;//this is the attribute we are searching on
    private String keySpace;//this is the keyspace we want to use(default is 'sensor_information')
    private Session session;//session we connect to

    /**
     * constructor for CassandraDBCache with default keyspace 'sensor_information'
     * @param host host name
     * @param port port number
     * @param tableName table we want to use in 'sensor_information' key_space
     * @param primaryKey primary key in table to access timestamps, this will usually be the sensor reading you want(acceleration, latitude, etc...)
     */
    public CasandraDBCache(String host, int port, String tableName, String primaryKey,int maxSize){
        super(maxSize,2);
        this.tableName = tableName;
        this.primaryKey = primaryKey;

        this.keySpace = "sensor_information";

        Cluster cluster = Cluster.builder().addContactPoint(host).withPort(port).build();
        session = cluster.connect(this.keySpace);

        String truncate_q = "TRUNCATE " + tableName + ";";
        session.execute(truncate_q);
    }

    /**
     * constructor for CassandraDBCache overriding the default key_space
     * @param host host name
     * @param port port number
     * @param keySpace key space we would like to use
     * @param tableName table we want to use in 'sensor_information' key_space
     * @param primaryKey primary key in table to access timestamps, this will usually be the sensor reading you want(acceleration, latitude, etc...)
     */
    public CasandraDBCache(String host, int port, String keySpace, String tableName, String primaryKey,int maxSize){
        super(maxSize,2);
        this.tableName = tableName;
        this.primaryKey = primaryKey;

        this.keySpace = keySpace;

        Cluster cluster = Cluster.builder().addContactPoint(host).withPort(port).build();
        session = cluster.connect(this.keySpace);

        String truncate_q = "TRUNCATE " + tableName + ";";
        session.execute(truncate_q);
    }

    /**
     * add a row to the table with Observation information
     * @param tss Observation information to add
     */
    @Override
    public void addRow(Observation<T> tss){
        logger.debug("performing insert into cassandra table:<" + keySpace + "> <" + tableName + ">" + "<" + primaryKey + ">");
        byte[] value = cassandraDBHelper.serialize(tss.getValue());

        Statement statement = QueryBuilder.insertInto(keySpace,tableName)
                .value("datagroup",primaryKey)
                .value("timestamp",tss.getTimeTick())
                .value("value",ByteBuffer.wrap(value));
        session.execute(statement);
    }

    /**
     * removes the front half of the table up until max_size
     */
    @Override
    public void shrinkCache(){
        logger.debug("shrinking cassandra cache by a factor of 2");

        //cannot do range deletes, will investigate this later...
        Statement query_statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey));

        ResultSet rs = session.execute(query_statement);

        List<Row> rows = rs.all();

        for(Row r : rows){
            if(r.getLong("timestamp") == first().getTimeTick()){
                break;
            }
            Statement delete_statement = QueryBuilder.delete()
                    .from(keySpace,tableName)
                    .where(QueryBuilder.eq("datagroup",primaryKey))
                    .and(QueryBuilder.eq("timestamp",r.getLong("timestamp")));
            session.execute(delete_statement);
        }
    }

    /**
     * checks if the table contains a row with key of given Observation - timestamp
     * @param tss Observation to check for timestamp
     * @return true if the table contains the row key with Observation - timestamp
     */
    @Override
    public boolean contains(Observation<T> tss){
        Statement statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.eq("timestamp",tss.getTimeTick()));

        ResultSet rs = session.execute(statement);

        return rs.all().size() != 0;
    }

    /**
     * gets the first value in the table
     * @return a Observation to first row in table
     */
    @Override
    public Observation<T> first() {
        Statement statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.eq("timestamp",firstRow));

        ResultSet rs = session.execute(statement);

        Row row = rs.one();

        return cassandraDBHelper.buildObservation(row);

    }

    /**
     * gets the last value in the table
     * @return a Observation to last row in table
     */
    @Override
    public Observation<T> last() {
        Statement statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.eq("timestamp",lastRow));

        ResultSet rs = session.execute(statement);

        Row row = rs.one();

        return cassandraDBHelper.buildObservation(row);

    }

    /**
     * gets the entire set of Observation values in the table
     * @return a SortedSet of all Observation values in the table
     */
    @Override
    public ObservationCollection<T> getCache() {
        Statement statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.gte("timestamp",0));

        ResultSet rs = session.execute(statement);

        ObservationCollection<T> result = cassandraDBHelper.buildObservationCollection(rs);

        return result;
    }

    /**
     * gets the TimeStampSensors in range of table row key, t1 and t2 from our table
     * @param t1 timestamp start
     * @param t2 timestamp end
     * @return the SortedSet of Observation values between the given t1 and t2 timestamp range
     */
    @Override
    public ObservationCollection<T> getCacheInRange(long t1, long t2,boolean inclusive) {

        long lower = (inclusive) ? t1 - 1 : t1;
        long upper = (inclusive) ? t2 + 1 : t2;

        //todo query needs to be looking for 1 value to left of t1 and 1 to the right of t2 if they aren't found
        Statement statement = QueryBuilder.select()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.gte("timestamp",lower))
                .and(QueryBuilder.lte("timestamp",upper));

        ResultSet rs = session.execute(statement);

        return cassandraDBHelper.buildObservationCollection(rs);
    }

    @Override
    public void clear() {
        Statement statement = QueryBuilder.delete()
                .all()
                .from(keySpace,tableName)
                .where(QueryBuilder.eq("datagroup",primaryKey))
                .and(QueryBuilder.gte("timestamp",0));

        session.execute(statement);
    }


}
