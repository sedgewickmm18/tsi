package com.ibm.research.time_series.cassandra.scala_api

import com.datastax.driver.core.Row
import com.ibm.research.time_series.cassandra.timeseries.{CassandraMultiTimeSeries, CassandraTimeSeries}
import com.ibm.research.time_series.core.functions.UnaryMapFunction
import com.ibm.research.time_series.core.scala_api.TSFunctionUtils
import com.ibm.research.time_series.core.scala_api.multi_timeseries.ScalaMultiTimeSeries
import com.ibm.research.time_series.core.scala_api.timeseries.ScalaTimeSeries
import com.ibm.research.time_series.core.scala_api.utils.Implicits._

object CassandraImplicits {

  object CassandraFunctions {
    def cassandraDB[T]
        (
          host: String,
          port: Int,
          keySpace: String,
          tableName: String,
          primaryName: String,
          primaryKey: T,
          extractTimestampOp: Option[Row => Long] = None,
          start: Long = -1,
          end: Long = -1
        ): ScalaTimeSeries[Row] = {
      if (extractTimestampOp.isEmpty) {
        CassandraTimeSeries.cassandraDB(host,port,keySpace,tableName,primaryName,primaryKey).asScala
      } else {
        CassandraTimeSeries.cassandraDB(
          host,
          port,
          keySpace,
          tableName,
          primaryName,
          primaryKey,
          TSFunctionUtils.uMapFunction(x => extractTimestampOp.get.apply(x)),
          start,
          end
        ).asScala
      }
    }
  }

  object CassandraMultiFunctions {
    def cassandraDB[PRIMARY_TYPE]
        (
          host: String,
          port: Int,
          keySpace: String,
          tableName: String,
          primaryName: String,
          rowToTimestamp: Row => Long
        ): ScalaMultiTimeSeries[PRIMARY_TYPE, Row] = {

      new ScalaMultiTimeSeries[PRIMARY_TYPE,Row](
        CassandraMultiTimeSeries.cassandraDB(
          host,
          port,
          keySpace,
          tableName,
          primaryName,
          TSFunctionUtils
            .uMapFunction(rowToTimestamp)
            .asInstanceOf[UnaryMapFunction[Row,java.lang.Long]]
        )
      )
    }
  }

  implicit def fromScalaTimeSeriesObject(tsEntry:TimeSeries.type): CassandraFunctions.type = {
    CassandraFunctions
  }

  implicit def fromScalaMultiTimeSeriesObject(mtsEntry: MultiTimeSeries.type): CassandraMultiFunctions.type = {
    CassandraMultiFunctions
  }
}
