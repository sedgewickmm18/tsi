import abc


class DataSink(object):
    """
    interface to represent a data-sink for a single time-series
    """
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def dump(self, observations):
        """
        dump an observation-collection to an output source
        """
        pass