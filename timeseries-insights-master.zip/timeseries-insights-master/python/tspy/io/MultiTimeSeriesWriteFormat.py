import abc

class MultiTimeSeriesWriteFormat:
    """
    Format which denotes how to write a multi-time-series to a data-source
    """
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def write(self, observations_dict, encode_key_func, encode_value_func, options):
        """
        Given a dict of (key, observations), a key encoder, a value encoder, and options created from time-series-writer,
        write to an outside data-source

        Parameters
        ----------
        observations_dict : dict
            the in-memory observations to write to an outside data-source
        encode_key_func : func
            function to encode a key to a String, by default __str__ is used
        encode_value_func : func
            function to encode a value to a String, by default __str__ is used
        options : dict
            key-value string pair in map of options to be used in writing
        """
        pass
