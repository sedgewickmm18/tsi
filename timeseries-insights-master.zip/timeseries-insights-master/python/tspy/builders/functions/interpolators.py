"""
main entry point for time-series interpolators
"""


def linear(fill_value=None, history_size=1, future_size=1):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.linear(fill_value, history_size, future_size)


def cubic(fill_value=None, history_size=1, future_size=1):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.cubic(fill_value, history_size, future_size)


def next(default_value=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.next(default_value)


def prev(default_value=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.prev(default_value)


def nearest(default_value=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.nearest(default_value)


def fill(value):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.fill(value)


def nullify():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.interpolators.nullify()
