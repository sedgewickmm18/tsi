"""
main entry point for all segmentation transforms (given time-series return new segment-time-series)
"""


def static_threshold(threshold):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.segment_transforms.static_threshold(threshold)


def dynamic_threshold(alpha, factor, threshold):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.segment_transforms.dynamic_threshold(alpha, factor, threshold)


def regression(max_error, skip, use_relative=False):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.segment_transforms.regression(max_error, skip, use_relative)


def statistical_changepoint(min_segment_size=2, threshold=2.0):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.segment_transforms.statistical_changepoint(min_segment_size, threshold)


def cusum(threshold):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.segment_transforms.cusum(threshold)
