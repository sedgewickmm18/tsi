"""
main entry point for all transformers (given time-series, return new time-series)
"""


def z_score():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.z_score()


def difference():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.difference()


def detect_anomalies(forecasting_model, confidence, update_model=False, info=False):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.detect_anomalies(forecasting_model, confidence, update_model, info)


def awgn(mean=None, sd=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.awgn(mean, sd)


def mwgn(mean=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.mwgn(mean)

def augmented_dickey_fuller(window, step, lag, p_value):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.stat_transforms.augmented_dickey_fuller(window, step, lag, p_value)

def granger_causality(window, step, lag):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.stat_transforms.granger_causality(window, step, lag)

def ljung_box(window, step, num_lags, period):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.stat_transforms.ljung_box(window, step, num_lags, period)

def remove_consecutive_duplicate_values():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.duplicate_transforms.remove_consecutive_duplicate_values()

def combine_duplicate_time_ticks(combine_strategy):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.duplicate_transforms.combine_duplicate_time_ticks(combine_strategy)

def paa(m):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.paa(m)

def sax(min_value, max_value, num_bins):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.sax(min_value, max_value, num_bins)

def ema(window):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.ema(window)

def decompose(samples_per_season, multiplicative):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_transforms.decompose(samples_per_season, multiplicative)
