"""
main entry-point for creation of :class:`~tspy.time_series.MultiTimeSeries.MultiTimeSeries`
"""


def from_observations(list_key_observation_pairs):
    """
    create a multi-time-series from a list of tuples (key, observation)

    Parameters
    ----------
    list_key_observation_pairs : list
        list of (key, observations) tuples

    Returns
    -------
    :class:`~tspy.time_series.MultiTimeSeries.MultiTimeSeries`
        a new multi-time-series

    Notes
    -----
    each time-series will be created from a group by operation on the key.

    Examples
    --------
    create a list of (key, observation) tuples

    >>> observations = [("a", tspy.observation(2,1)), ("b", tspy.observation(1,8)), ("a", tspy.observation(1,7)), ("b", tspy.observation(4,6)), ("c", tspy.observation(1,5))]
    >>> observations
    [('a', TimeStamp: 2     Value: 1), ('b', TimeStamp: 1     Value: 8), ('a', TimeStamp: 1     Value: 7), ('b', TimeStamp: 4     Value: 6), ('c', TimeStamp: 1     Value: 5)]

    create a multi-time-series from observations

    >>> mts = tspy.multi_time_series.from_observations(observations)
    >>> mts
    a time series
    ------------------------------
    TimeStamp: 1     Value: 7
    TimeStamp: 2     Value: 1
    b time series
    ------------------------------
    TimeStamp: 1     Value: 8
    TimeStamp: 4     Value: 6
    c time series
    ------------------------------
    TimeStamp: 1     Value: 5
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.multi_time_series.from_observations(list_key_observation_pairs)


def df_instants(pdf, key_columns=None, ts_column=None, granularity=None, start_time=None):
    """
    create a multi-time-series from a pandas dataframe in instants format. Instants format is defined as each
    time-series key being a separate column of the dataframe.

    Parameters
    ----------
    pdf : pandas dataframe
        the dataframe to convert to a multi-time-series
    key_columns : list, optional
        columns to use in multi-time-series creation (default is all columns)
    ts_column : string, optional
        column name containing time-ticks (default is time-tick based on index into dataframe)
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.MultiTimeSeries.MultiTimeSeries`
        a new multi-time-series

    Examples
    --------
    create a simple df with a single index

    >>> import numpy as np
    >>> import pandas as pd
    >>> data = np.array([['', 'letters', 'timestamp', "numbers"],
                 ...['', "a", 1, 27],
                 ...['', "b", 3, 4],
                 ...['', "a", 5, 17],
                 ...['', "a", 3, 7],
                 ...['', "b", 2, 45]
                ...])
    >>> df = pd.DataFrame(data=data[1:, 1:],
                  ...columns=data[0, 1:]).astype(dtype={'letters': 'object', 'timestamp': 'int64', 'numbers': 'float64'})
      letters  timestamp  numbers
    0       a          1     27.0
    1       b          3      4.0
    2       a          5     17.0
    3       a          3      7.0
    4       b          2     45.0

    create a multi-time-series from a df using instants format

    >>> mts = tspy.multi_time_series.df_instants(df, ts_column='timestamp')
    >>> mts
    numbers time series
    ------------------------------
    TimeStamp: 1     Value: 27.0
    TimeStamp: 2     Value: 45.0
    TimeStamp: 3     Value: 4.0
    TimeStamp: 3     Value: 7.0
    TimeStamp: 5     Value: 17.0
    letters time series
    ------------------------------
    TimeStamp: 1     Value: a
    TimeStamp: 2     Value: b
    TimeStamp: 3     Value: b
    TimeStamp: 3     Value: a
    TimeStamp: 5     Value: a
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.multi_time_series.df_instants(pdf, key_columns, ts_column, granularity, start_time)


def df_observations(pdf, key_column, ts_column=None, value_column=None, granularity=None, start_time=None):
    """
    create a multi-time-series from a pandas dataframe in observations format. Observations format is defined as each
    record in the dataframe having a key, where each time-series is created by grouping unique keys.

    Parameters
    ----------
    pdf : pandas dataframe
        the dataframe to convert to a multi-time-series
    key_column : string
        column name containing the key
    ts_column : string, optional
        column name containing time-ticks (default is time-tick based on index into dataframe)
    value_column : list or string, optional
        column name(s) containing values (default is all columns)
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.MultiTimeSeries.MultiTimeSeries`
        a new multi-time-series

    Examples
    --------
    create a simple df with a single index

    >>> import numpy as np
    >>> import pandas as pd
    >>> data = np.array([['', 'letters', 'timestamp', "numbers"],
                 ...['', "a", 1, 27],
                 ...['', "b", 3, 4],
                 ...['', "a", 5, 17],
                 ...['', "a", 3, 7],
                 ...['', "b", 2, 45]
                ...])
    >>> df = pd.DataFrame(data=data[1:, 1:],
                  ...columns=data[0, 1:]).astype(dtype={'letters': 'object', 'timestamp': 'int64', 'numbers': 'float64'})
      letters  timestamp  numbers
    0       a          1     27.0
    1       b          3      4.0
    2       a          5     17.0
    3       a          3      7.0
    4       b          2     45.0

    create a multi-time-series from a df using observations format where the key is letters

    >>> mts = tspy.multi_time_series.df_observations(df, key_column="letters", ts_column='timestamp')
    a time series
    ------------------------------
    TimeStamp: 1     Value: {numbers=27.0}
    TimeStamp: 3     Value: {numbers=7.0}
    TimeStamp: 5     Value: {numbers=17.0}
    b time series
    ------------------------------
    TimeStamp: 2     Value: {numbers=45.0}
    TimeStamp: 3     Value: {numbers=4.0}
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.multi_time_series.df_observations(pdf, key_column, ts_column, value_column, granularity, start_time)


def dict(ts_dict, granularity=None, start_time=None):
    """
    create a time-series from a dict where the values are either collections of observations or time-series

    Parameters
    ----------
    ts_dict : dict
        dict where one key per :class:`~tspy.time_series.ObservationCollection.ObservationCollection` or :class:`~tspy.time_series.TimeSeries.TimeSeries`
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.MultiTimeSeries.MultiTimeSeries`
        a new multi-time-series

    Examples
    --------
    create a dict with observation-collection values

    >>> import tspy
    >>> my_dict = {"ts1": tspy.time_series.list([1,2,3]).collect(), "ts2": tspy.time_series.list([4,5,6]).collect()}
    >>> my_dict
    {'ts1': [(0,1),(1,2),(2,3)], 'ts2': [(0,4),(1,5),(2,6)]}

    create a multi-time-series from dict without a time-reference-system

    >>> mts = tspy.multi_time_series.dict(my_dict)
    >>> mts
    ts2 time series
    ------------------------------
    TimeStamp: 0     Value: 4
    TimeStamp: 1     Value: 5
    TimeStamp: 2     Value: 6
    ts1 time series
    ------------------------------
    TimeStamp: 0     Value: 1
    TimeStamp: 1     Value: 2
    TimeStamp: 2     Value: 3

    create a multi-time-series from dict containing a time-reference-system

    >>> import datetime
    >>> start_time = datetime.datetime(1990,7,6)
    >>> granularity = datetime.timedelta(days=1)
    >>> mts = tspy.multi_time_series.dict(my_dict, start_time=start_time, granularity=granularity)
    >>> mts
    ts2 time series
    ------------------------------
    TimeStamp: 1990-07-06T00:00Z     Value: 4
    TimeStamp: 1990-07-07T00:00Z     Value: 5
    TimeStamp: 1990-07-08T00:00Z     Value: 6
    ts1 time series
    ------------------------------
    TimeStamp: 1990-07-06T00:00Z     Value: 1
    TimeStamp: 1990-07-07T00:00Z     Value: 2
    TimeStamp: 1990-07-08T00:00Z     Value: 3
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.multi_time_series.dict(ts_dict, granularity, start_time)
