"""
main entry-point for creation of :class:`~tspy.time_series.StreamTimeSeries.StreamTimeSeries`
"""

def reader(stream_time_series_reader, granularity=None, start_time=None):
    """
    create a stream-time-series from a stream-time-series-reader

    Parameters
    ----------
    stream_time_series_reader : :class:`~tspy.io.PullStreamTimeSeriesReader` or :class:`~tspy.io.PushStreamTimeSeriesReader`
        a user-implemented stream-time-series-reader
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamTimeSeries.StreamTimeSeries`
        a new stream-time-series
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_time_series.reader(stream_time_series_reader, granularity, start_time)


def text_file(path, map_func, granularity=None, start_time=None):
    """
    create a stream-time-series from a text file

    Parameters
    ----------
    path : string
        path to file
    map_func : func
        function from a single line of a file to an :class:`~tspy.time_series.Observation.Observation` or None
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamTimeSeries.StreamTimeSeries`
        a new stream-time-series
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_time_series.text_file(path, map_func, granularity, start_time)


def queue(observation_queue, granularity=None, start_time=None):
    """
    create a stream-time-series from a queue of observations

    Parameters
    ----------
    observation_queue : queue.Queue
        queue of :class:`~tspy.time_series.Observation.Observation`
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamTimeSeries.StreamTimeSeries`
        a new stream-time-series

    Examples
    --------
    create a simple queue

    >>> import queue
    >>> observation_queue = queue.Queue()

    create a simple stream-time-series from a queue

    >>> import tspy
    >>> sts = tspy.stream_time_series.queue(observation_queue)
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_time_series.queue(observation_queue, granularity, start_time)
