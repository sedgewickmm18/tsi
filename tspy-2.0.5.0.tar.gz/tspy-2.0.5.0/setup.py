from setuptools import setup, find_packages
import os
from shutil import copyfile, rmtree, copytree

if "TSPY_NO_JAR" in os.environ:
    no_jar = True if os.environ['TSPY_NO_JAR'].lower() == "true" else False
else:
    no_jar = False

if no_jar:
    setup(
        name='tspy',
        version='2.0.5.0',
        author='',
        description='time series capabilities for python',
        license='LICENSE.txt',
        install_requires=['pytz'],
        packages=[
            'tspy',
            'tspy.bin',
            'tspy.forecasting',
            'tspy.io',
            'tspy.ml',
            'tspy.ml.clustering',
            'tspy.ml.data_preparation',
            'tspy.ml.itemset_mining',
            'tspy.ml.sequence_mining',
            'tspy.time_series',
            'tspy.transforms',
            'tspy.utils',
            'tspy.builders',
            'tspy.builders.functions',
            'tspy.exceptions'
        ],
        # package source directory
        package_dir={
            'tspy': 'tspy'
        },
    )
else:
    TS_HOME = os.path.abspath("../")
    JARS_PATH = os.path.join(TS_HOME, "assembly/assembly-python/target/")
    TEMP_PATH = "tspy/deps"

    JARS_TARGET = os.path.join(TEMP_PATH, "jars")

    is_local = os.path.isfile("../core/core-java/src/main/java/com/ibm/research/time_series/core/timeseries/TimeSeries.java")

    if is_local:
        try:
            os.makedirs(TEMP_PATH)
        except OSError:
            pass

    try:

        if is_local:
            if getattr(os, "symlink", None) is not None:
                os.symlink(JARS_PATH, JARS_TARGET)
            else:
                copytree(JARS_PATH, JARS_TARGET)
            # open(os.path.join(TEMP_PATH, "__init__.py"), 'w').close()
            # open(os.path.join(JARS_TARGET, "__init__.py"), 'w').close()

        setup(
            name='tspy',
            version='2.0.5.0',
            author='',
            description='time series capabilities for python',
            license='LICENSE.txt',
            keywords="",
            packages=[
                'tspy',
                'tspy.jars',
                'tspy.bin',
                'tspy.forecasting',
                'tspy.io',
                'tspy.ml',
                'tspy.ml.clustering',
                'tspy.ml.data_preparation',
                'tspy.ml.itemset_mining',
                'tspy.ml.sequence_mining',
                'tspy.time_series',
                'tspy.transforms',
                'tspy.utils',
                'tspy.builders',
                'tspy.builders.functions',
                'tspy.exceptions'
            ],
            # package source directory
            package_dir={
                'tspy': 'tspy',
                'tspy.jars': 'tspy/deps/jars'
            },
            package_data={
                'tspy.jars': ['*.jar']
            },
            include_package_data=True,
            # configure the default test suite
            test_suite='tests.suite', install_requires=['pytz']
        )
    finally:
        if is_local:
            if getattr(os, "symlink", None) is not None:
                os.remove(JARS_TARGET)
            else:
                rmtree(JARS_TARGET)
            # os.remove(os.path.join(TEMP_PATH, "__init__.py"))
            os.rmdir(TEMP_PATH)

