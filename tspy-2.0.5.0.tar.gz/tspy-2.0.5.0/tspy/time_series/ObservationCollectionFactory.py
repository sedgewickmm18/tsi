from tspy.time_series.ObservationCollection import ObservationCollection


class Factory:

    def __init__(self, tsc):
        self._tsc = tsc

    def empty(self):
        return ObservationCollection(self._tsc)

    def builder(self):
        j_ts_builder = self._tsc._jvm.com.ibm.research.time_series.core.utils.Observations.newBuilder()
        from tspy.utils.TSBuilder import TSBuilder
        return TSBuilder(self._tsc, j_ts_builder)

    def of(self, *observations):
        builder = self.builder()
        for obs in observations:
            builder.add(obs)
        return builder.result()
