from tspy.time_series.StreamTimeSeries import StreamTimeSeries


class SegmentStreamTimeSeries(StreamTimeSeries):
    """
    A special form of stream-time-series that consists of observations with a value of type
    :class:`~tspy.time_series.Segment.Segment`
    """
    def __init__(self, tsc, j_stream_time_series, trs=None):
        super().__init__(tsc, j_stream_time_series, trs)
        self._tsc = tsc
        self._j_segment_ts = j_stream_time_series

    def transform(self, reducer):
        """
        transform this stream-time-series of segments into a stream-time-series of values

        Parameters
        ----------
        reducer : reducer transform
            a reducer transform as seen in :class:`~tspy.builders.functions.reducers`

        Returns
        -------
        :class:`~tspy.time_series.StreamTimeSeries.StreamTimeSeries`
            a new stream-time-series

        Notes
        -----
        Because this observation values are of segment type, a reducer will be used (transform from segment to value)
        """
        return StreamTimeSeries(
            self._tsc,
            self._j_stream_time_series.transform(reducer),
            self._trs
        )

    def filter(self, func):
        if hasattr(func, '__call__'):
            from tspy.utils import utils
            func = utils.FilterFunction(self._tsc, func)
        else:
            func = self._tsc._jvm.com.ibm.research.time_series.transforms.utils.python.Expressions.toFilterFunction(func)

        return SegmentStreamTimeSeries(
            self._tsc,
            self._j_stream_time_series.filter(func),
            self._trs
        )

    def transform_segments(self, transform):
        """
        produce a new segment-stream-time-series where each segment is transformed to a new segment using a unary
        transform

        Parameters
        ----------
        transform : UnaryTransform
            the transformation to apply on each segment of this segment-stream-time-series

        Returns
        -------
        :class:`~tspy.time_series.SegmentStreamTimeSeries.SegmentStreamTimeSeries`
            a new segment-stream-time-series
        """
        return SegmentStreamTimeSeries(
            self._tsc,
            self._j_stream_time_series.transformSegments(transform),
            self._trs
        )