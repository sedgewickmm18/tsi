import datetime

from tspy.time_series.Observation import Observation


class ObservationCollection:
    """
    A special form of materialized time-series (sorted collection) whose values are of type
    :class:`~tspy.time_series.Observation.Observation`.

    An observation-collection has the following properties:

    1. Sorted by observation time-tick
    2. Support for observations with duplicate time-ticks
    3. Duplicate time-ticks will keep ordering

    Examples
    --------
    create an observation-collection

    >>> import tspy
    >>> ts_builder = tspy.observations.builder()
    >>> ts_builder.add(tspy.observation(1,1))
    >>> ts_builder.add(tspy.observation(2,2))
    >>> ts_builder.add(tspy.observation(1,3))
    >>> observations = ts_builder.result()
    >>> observations
    [(1,1),(1,3),(2,2)]

    iterate through this collection

    >>> for o in observations:
        ...print(o.time_tick, ",", o.value)
    1 , 1
    1 , 3
    2 , 2
    """

    def __init__(self, tsc, j_observations=None):
        self._tsc = tsc
        self._obj_type = None
        self._j_observations = j_observations

    @property
    def trs(self):
        """
        Returns
        -------
        TRS : :class:`~tspy.utils.TRS.TRS`
            this time-series time-reference-system
        """
        return self._j_observations.getTRS()

    def contains(self, time_tick):
        """
        Checks for containment of time-tick within the collection

        Parameters
        ----------
        time_tick : int
            the time-tick

        Returns
        -------
        bool
            True if an observation in this collection has the given time-tick, otherwise False
        """
        return self._j_observations.contains(time_tick)

    def ceiling(self, time_tick):
        """
        get the ceiling observation for the given time-tick. The ceiling is defined as the the observation which bares
        the same time-tick as the given time-tick, or if one does not exist, the next higher observation. If no such
        observation exists that satisfies these arguments, in the collection, None will be returned.

        Parameters
        ----------
        time_tick : int
            the time-tick

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the ceiling observation
        """
        return self.__obs_as_py(self._j_observations.ceiling(time_tick))

    def floor(self, time_tick):
        """
        get the floor observation for the given time-tick. The floor is defined as the the observation which bares
        the same time-tick as the given time-tick, or if one does not exist, the next lower observation. If no such
        observation exists that satisfies these arguments, in the collection, None will be returned.

        Parameters
        ----------
        time_tick : int
            the time-tick

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the floor observation
        """
        return self.__obs_as_py(self._j_observations.floor(time_tick))

    def higher(self, time_tick):
        """
        get the higher observation for the given time-tick. The higher is defined as the the observation which bares
        a time-tick greater than the given time-tick. If no such observation exists that satisfies these arguments, in
        the collection, None will be returned.

        Parameters
        ----------
        time_tick : int
            the time-tick

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the floor observation
        """
        return self.__obs_as_py(self._j_observations.higher(time_tick))

    def lower(self, time_tick):
        """
        get the lower observation for the given time-tick. The lower is defined as the the observation which bares
        a time-tick less than the given time-tick. If no such observation exists that satisfies these arguments, in
        the collection, None will be returned.

        Parameters
        ----------
        time_tick : int
            the time-tick

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the floor observation
        """
        return self.__obs_as_py(self._j_observations.lower(time_tick))

    def first(self):
        """
        get the first observation in this collection. The first observation is that observation which has the lowest
        timestamp in the collection. If 2 observations have the same timestamp, the first observation that was in the
        collection will be the one returned.

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the first observation in this collection
        """
        return self.__obs_as_py(self._j_observations.first())

    def last(self):
        """
        get the last observation in this collection. The last observation is that observation which has the highest
        timestamp in the collection. If 2 observations have the same timestamp, the last observation that was in the
        collection will be the one returned.

        Returns
        -------
        :class:`~tspy.time_series.Observation.Observation`
            the last observation in this collection
        """
        return self.__obs_as_py(self._j_observations.last())

    def is_empty(self):
        """
        Returns
        -------
        bool
            True if no observations exist in this collection, otherwise False
        """
        return self._j_observations.isEmpty()

    def __obs_as_py(self, j_observation):
        from tspy.utils import utils
        py_obj, obj_type = utils.cast_to_py_if_necessary(self._tsc, j_observation.getValue(), self._obj_type)
        self._obj_type = obj_type
        return Observation(self._tsc, j_observation.getTimeTick(), py_obj)

    def to_time_series(self, granularity=None, start_time=None):
        """
        convert this collection to a time-series

        Parameters
        ----------
        granularity : datetime.timedelta, optional
            the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
        start_time : datetime, optional
            the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

        Returns
        -------
        :class:`~tspy.time_series.TimeSeries.TimeSeries`
            a new time-series
        """
        from tspy.time_series.TimeSeries import TimeSeries
        if granularity is None and start_time is None:
            return TimeSeries(self._tsc, self._j_observations.toTimeSeriesStream())
        else:
            if granularity is None:
                granularity = datetime.timedelta(milliseconds=1)
            if start_time is None:
                start_time = datetime.datetime(1970, 1, 1, 0, 0, 0, 0)
            # from tspy.time_series.TimeSeriesFactory import Factory
            from tspy.utils.TRS import TRS
            trs = TRS(self._tsc, granularity, start_time)
            return TimeSeries(self._tsc, self._j_observations.toTimeSeriesStream(trs._j_trs), trs)

    @property
    def size(self):
        """
        Returns
        -------
        int
            the number of observations in this collection
        """
        return self._j_observations.size()

    def __iter__(self):
        from tspy.utils import utils
        j_iterator = self._j_observations.iterator()
        while j_iterator.hasNext():
            j_obs = j_iterator.next()
            py_obj, obj_type = utils.cast_to_py_if_necessary(self._tsc, j_obs.getValue(), self._obj_type)
            self._obj_type = obj_type
            yield Observation(self._tsc, j_obs.getTimeTick(), py_obj)

    def __str__(self):
        return self._j_observations.toString()

    def __repr__(self):
        return self._j_observations.toString()

    def __eq__(self, other):
        return self._j_observations.equals(other._j_observations)

    def __len__(self):
        return self.size

    class Java:
        implements = ['com.ibm.research.time_series.core.utils.ObservationCollection']
