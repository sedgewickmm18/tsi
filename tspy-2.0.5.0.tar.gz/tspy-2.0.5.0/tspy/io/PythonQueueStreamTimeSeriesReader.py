from tspy.io.PullStreamTimeSeriesReader import PullStreamTimeSeriesReader


class PythonQueueStreamTimeSeriesReader(PullStreamTimeSeriesReader):
    def __init__(self, py_queue):
        super().__init__()
        self._py_queue = py_queue

    def poll(self):
        res = []
        for i in range(0, self._py_queue.qsize()):
            res.append(self._py_queue.get(block=False)._j_observation)
        return res

    def parse(self, message):
        return message
