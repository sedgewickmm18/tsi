import abc

from tspy.utils import utils


class PushStreamMultiTimeSeriesReader(object):
    """
    interface to represent reading stream-multi-time-series data at motion from a data-source where data is being pushed
    to the reader

    Notes
    -----
    When implementing this reader, you will typically use the
    :func:`~tspy.io.PushStreamMultiTimeSeriesReader.PushStreamMultiTimeSeriesReader.callback` method in your own
    callback of the streaming platform you are using. Callback accepts a single message.
    """
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        from tspy.context import get_or_create
        self._tsc = get_or_create()
        self._j_reader = self._tsc._jvm.com.ibm.research.time_series.streaming.io.PythonPushStreamMultiTimeSeriesReader(
            utils.UnaryMapFunctionTupleResultingInOptional(self._tsc, self.parse)
        )

    def callback(self, message):
        """
        Accepts the next message to process

        Parameters
        ----------
        message : any
            a single message
        """
        self._j_reader.callback(message)

    def _parse(self, message):
        return self._j_reader.parse(message)

    def _read(self):
        return self._j_reader.read()

    @abc.abstractmethod
    def parse(self, message):
        """
        parse a message

        Parameters
        ----------
        message : Any
            a message

        Returns
        -------
        tuple
            a single tuple of (key, :class:`~tspy.time_series.Observation.Observation`) or None if parsing has failed
        """
        return
