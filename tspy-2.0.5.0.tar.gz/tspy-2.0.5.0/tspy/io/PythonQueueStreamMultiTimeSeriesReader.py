from tspy.io.PullStreamMultiTimeSeriesReader import PullStreamMultiTimeSeriesReader


class PythonQueueStreamMultiTimeSeriesReader(PullStreamMultiTimeSeriesReader):
    def __init__(self, py_queue):
        super().__init__()
        self._py_queue = py_queue

    def parse(self, message):
        return message

    def poll(self):
        res = []
        for i in range(0, self._py_queue.qsize()):
            (key, py_obs) = self._py_queue.get(block=False)
            j_pair = self._tsc._jvm.com.ibm.research.time_series.core.utils.Pair(key, py_obs._j_observation)
            res.append(j_pair)
        return res