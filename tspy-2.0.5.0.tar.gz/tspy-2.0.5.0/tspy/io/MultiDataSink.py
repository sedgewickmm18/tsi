import abc


class MultiDataSink(object):
    """
    interface to represent a data-sink for multiple time-series keys
    """
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def dump(self, observations_dict):
        """
        dump a dictionary of observation-collection to an output source
        """
        pass