class TSBuilder:
    """
    a mutable builder for creating an :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
    """
    def __init__(self, tsc, j_ts_builder):
        self._tsc = tsc
        self._j_ts_builder = j_ts_builder

    def add(self, observation):
        """
        add an observation to the builder

        Parameters
        ----------
        observation : :class:`~tspy.time_series.Observation.Observation`
            the observation to add

        Returns
        -------
        :class:`~tspy.utils.TSBuilder.TSBuilder`
            this TSBuilder
        """
        self._j_ts_builder.add(observation._j_observation)
        return self

    def __len__(self):
        return self._j_ts_builder.size()

    def result(self, granularity=None, start_time=None):
        """
        get an observation-collection from the observations in this builder

        Parameters
        ----------
        granularity : datetime.timedelta, optional
            the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
        start_time : datetime, optional
            the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

        Returns
        -------
        :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
            a new observation-collection
        """
        if granularity is None and start_time is None:
            from tspy.time_series import ObservationCollection
            return ObservationCollection.ObservationCollection(self._tsc, self._j_ts_builder.result())
        else:
            from tspy.time_series import ObservationCollection
            import datetime
            from tspy.utils.TRS import TRS
            if granularity is None:
                granularity = datetime.timedelta(milliseconds=1)
            if start_time is None:
                start_time = datetime.datetime(1970, 1, 1, 0, 0, 0, 0)
            trs = TRS(self._tsc, granularity, start_time)
            return ObservationCollection.ObservationCollection(self._tsc, self._j_ts_builder.result(trs._j_trs))

    def clear(self):
        """
        clear the observations in this builder

        Returns
        -------
        :class:`~tspy.utils.TSBuilder.TSBuilder`
            this TSBuilder
        """
        self._j_ts_builder.clear()
        return self

    def is_empty(self):
        """
        Returns
        -------
        bool
            True if no observations exist in this builder, otherwise false
        """
        return self._j_ts_builder.isEmpty()

    def add_all(self, observations):
        """
        add all observations in an observation-collection to this builder

        Parameters
        ----------
        observations : :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
            the observations to add

        Returns
        -------
        :class:`~tspy.utils.TSBuilder.TSBuilder`
            this TSBuilder
        """
        from tspy.time_series import ObservationCollection
        return self._j_ts_builder.addAll(
            ObservationCollection.ObservationCollection(self._tsc, observations._j_observations))

