"""
Entry point to time-series data-structure creation functions
"""

from tspy.context import TSContext
from tspy.builders import observations, multi_time_series, time_series, forecasters, stream_time_series, stream_multi_time_series, models

if 'TSContext._active' not in globals():
    TSContext._active = None

def observation(time_tick, value):
    """
    create an observation

    Parameters
    ----------
    time_tick : int
        observations time-tick
    value : any
        observations value

    Returns
    -------
    :class:`~tspy.time_series.Observation.Observation`
    """
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.observation(time_tick, value)

def record(**kwargs):
    """
    create a record type (similar to dict)

    Parameters
    ----------
    kwargs : named args
        key/value arguments

    Returns
    -------
    record
        a dict-like structure that is handled for high performance in time-series
    """
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.record(**kwargs)
