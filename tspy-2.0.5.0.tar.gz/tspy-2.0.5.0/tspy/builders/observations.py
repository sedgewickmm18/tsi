"""
main entry-point for creation of :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
"""

def empty():
    """
    create an empty observation-collection

    Returns
    -------
    :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
        a new observation-collection
    """
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.observations.empty()


def builder():
    """
    create a time-series builder

    Returns
    -------
    :class:`~tspy.utils.TSBuilder.TSBuilder`
        a new time-series builder
    """
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.observations.builder()


def of(*observations):
    """
    create a observation-collection from a variable number of observations
    Parameters
    ----------
    observations : varargs
        a variable number of observations

    Returns
    -------
    :class:`~tspy.time_series.ObservationCollection.ObservationCollection`
        a new observation-collection
    """
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.observations.of(*observations)

