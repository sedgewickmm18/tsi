"""
main entry-point for creation of :class:`~tspy.time_series.StreamMultiTimeSeries.StreamMultiTimeSeries`
"""

def reader(stream_reader, granularity=None, start_time=None):
    """
    create a stream-multi-time-series from a stream-multi-time-series-reader

    Parameters
    ----------
    stream_time_series_reader : :class:`~tspy.io.PullStreamMultiTimeSeriesReader` or :class:`~tspy.io.PushStreamMultiTimeSeriesReader`
        a user-implemented stream-multi-time-series-reader
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamMultiTimeSeries.StreamMultiTimeSeries`
        a new stream-multi-time-series
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_multi_time_series.reader(stream_reader, granularity, start_time)

def text_file(path, map_func, granularity=None, start_time=None):
    """
    create a stream-multi-time-series from a text file

    Parameters
    ----------
    path : string
        path to file
    map_func : func
        function from a single line of a file to a tuple of (key, :class:`~tspy.time_series.Observation.Observation`) or
        None
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamMultiTimeSeries.StreamMultiTimeSeries`
        a new stream-multi-time-series
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_multi_time_series.text_file(path, map_func, granularity, start_time)

def queue(key_observation_queue, granularity=None, start_time=None):
    """
    create a stream-multi-time-series from a queue of observations

    Parameters
    ----------
    key_observation_queue : queue.Queue
        queue of tuples of type (key, :class:`~tspy.time_series.Observation.Observation`)
    granularity : datetime.timedelta, optional
        the granularity for use in time-series :class:`~tspy.utils.TRS` (default is None if no start_time, otherwise 1ms)
    start_time : datetime, optional
        the starting date-time of the time-series (default is None if no granularity, otherwise 1970-01-01 UTC)

    Returns
    -------
    :class:`~tspy.time_series.StreamMultiTimeSeries.StreamMultiTimeSeries`
        a new stream-multi-time-series

    Examples
    --------
    create a simple queue

    >>> import queue
    >>> observation_queue = queue.Queue()

    create a simple stream-multi-time-series from a queue

    >>> import tspy
    >>> sts = tspy.stream_multi_time_series.queue(observation_queue)
    """
    from tspy.context import get_or_create

    tsc = get_or_create()
    return tsc.stream_multi_time_series.queue(key_observation_queue, granularity, start_time)