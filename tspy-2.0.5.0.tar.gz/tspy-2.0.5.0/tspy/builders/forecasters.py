"""
main entry-point for creation of :class:`~tspy.forecasting.ForecastingModel.ForecastingModel`
"""

def load(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.load(path)


def bats(training_sample_size, box_cox_transform=False):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.bats(training_sample_size, box_cox_transform)


# def hws(samples_per_season, initial_training_seasons, algorithm_type="additive", compute_seasonality=None,
#         error_history_length=1, use_full_error_history=True):
#     from tspy.context import get_or_create
#     tsc = get_or_create()
#     return tsc.forecasters.hws(samples_per_season, initial_training_seasons, algorithm_type, compute_seasonality, error_history_length, use_full_error_history)
def hws(**kwargs):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.hws(**kwargs)



def arima(error_horizon_length=1, use_full_error_history=True, force_model=False, min_training_data=-1, p_min=0,
          p_max=-1, d=-1, q_min=0, q_max=-1):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.arima(error_horizon_length, use_full_error_history, force_model, min_training_data, p_min, p_max, d, q_min, q_max)


def arma(min_training_data=-1, p_min=0, p_max=5, q_min=0, q_max=5):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.arma(min_training_data, p_min, p_max, q_min, q_max)


def auto(min_training_data, error_history_length=1):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.auto(min_training_data, error_history_length)


def anomaly_detector(confidence):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.anomaly_detector(confidence)

def season_selector(sub_season_percent_delta=0.0, max_season_length=None):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.forecasters.season_selector(sub_season_percent_delta, max_season_length)