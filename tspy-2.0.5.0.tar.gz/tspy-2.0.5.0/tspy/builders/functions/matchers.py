"""
main entry point for all sequence and item-set matchers
"""


def subset(threshold=0.0, matcher_threshold="PS"):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ism.item_set_matchers.subset(threshold, matcher_threshold)

def seq():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ssm.sequence_matchers.seq()


def subseq(threshold=0.0, matcher_threshold="PS"):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ssm.sequence_matchers.subseq(threshold, matcher_threshold)


def sublist(threshold=0.0):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ssm.sequence_matchers.sublist(threshold)