"""
main entry point for all time-series reducers (given segment, return value)

Notes
-----
if used on a segment-time-series, you must call transform as the output will be a time-series.

if used on a non-segment-time-series, you must call reduce as the output will be a single value.
"""


def sum():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.sum()


def average():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.average()


def correlation():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.correlation()


def cross_correlation():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.cross_correlation()


def auto_correlation():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.auto_correlation()


def convolve():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.convolve()


def fft():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.fft()


def standard_deviation():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.standard_deviation()


def skewness():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.skewness()


def kurtosis():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.kurtosis()


def min():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.min()


def max():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.max()


def percentile(quantile):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.percentile(quantile)


def describe():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.describe()


def adf(lag=None, p_value=-3.45):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.stat_reducers.adf(lag, p_value)


def granger(lag):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.stat_reducers.granger(lag)


def dl(func):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.dl(func)


def sbd():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.sbd()


def dtw(func):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.dtw(func)


def sakoe_chiba_dtw(func, constraint):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.sakoe_chiba_dtw(func, constraint)


def itakura_parralelogram_dtw(func, constraint, center_offset_percentage):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.itakura_parralelogram_dtw(func, constraint, center_offset_percentage)


def manhattan(func):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.distance_reducers.manhattan(func)

def entropy():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.entropy()

def distance_variance():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.distance_variance()

def distance_covariance():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.distance_covariance()

def distance_correlation():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.distance_correlation()

def mutual_information():
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.mutual_information()

def histogram(min, max, num_divisions, normalize=False):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.math_reducers.histogram(min, max, num_divisions, normalize)
