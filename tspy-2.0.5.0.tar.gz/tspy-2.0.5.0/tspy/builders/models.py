"""
main entry-point for time-series model loading
"""


def load_dsm(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ssm.dss_model.load(path)


def load_fsm(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ssm.fss_model.load(path)


def load_dim(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ism.dim_model.load(path)


def load_fim(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.ism.fim_model.load(path)


def load_k_shape(path):
    from tspy.context import get_or_create
    tsc = get_or_create()
    return tsc.ml.clustering.k_shape.load(path)
