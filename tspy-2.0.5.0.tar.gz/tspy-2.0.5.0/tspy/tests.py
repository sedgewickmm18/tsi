import numpy as np
import unittest

import pandas as pd
from py4j.java_gateway import is_instance_of

from tspy import context
from tspy.time_series.Segment import Segment
from tspy.transforms.BinaryTransform import BinaryTransform
from tspy.builders.functions import expressions as exp


def verify_multi_series(unit_test, expected_mts, actual_mts):
    collected_actual_mts = actual_mts.collect()
    for key, series in expected_mts.collect().items():
        verify_series(unit_test, series.to_time_series(), collected_actual_mts[key].to_time_series())

def verify_series(unit_test, expected_ts, actual_ts):
    expected = expected_ts.collect()
    actual = actual_ts.collect()

    unit_test.assertEqual(expected.size, actual.size)

    actual_iter = iter(actual)

    for expected_obs in expected:
        actual_obs = next(actual_iter)

        unit_test.assertEqual(expected_obs.time_tick, actual_obs.time_tick)
        if is_instance_of(expected_ts._tsc._gateway, expected_obs.value, "com.ibm.research.time_series.core.utils.Record"):
            unit_test.assertEqual(sum(1 for _ in expected_obs.value.keys()), sum(1 for _ in actual_obs.value.keys()))
            for k in expected_obs.value.keys():
                unit_test.assertEqual(expected_obs.value.get(k), actual_obs.value.get(k))
        else:
            unit_test.assertEqual(str(expected_obs), str(actual_obs))


class DummyBinaryTransform(BinaryTransform):

    def evaluate(self, time_series_left, time_series_right, start, end, inclusive_bounds):
        return time_series_left\
            .inner_join(time_series_right, lambda x, y: x + y)\
            .get_values(start, end, inclusive_bounds)

class ExpressionTest(unittest.TestCase):

    def setUp(self):
        self._tsc = context.TSContext()

    def tearDown(self):
        self._tsc.stop()

    def test_logical_not(self):
        self.assertEqual(True, exp.logical_not(exp.gt(4, 5)).evaluate(1))

    def test_logical_and(self):
        self.assertEqual(True, exp.logical_and(exp.gt(5, 4), exp.gt(5, 4)).evaluate(1))
        self.assertEqual(False, exp.logical_and(exp.gt(5, 4), exp.gt(4, 5)).evaluate(1))
        self.assertEqual(False, exp.logical_and(exp.gt(4, 5), exp.gt(5, 4)).evaluate(1))
        self.assertEqual(False, exp.logical_and(exp.gt(4, 5), exp.gt(4, 5)).evaluate(1))

    def test_logical_or(self):
        self.assertEqual(True, exp.logical_or(exp.gt(5, 4), exp.gt(5, 4)).evaluate(1))
        self.assertEqual(True, exp.logical_or(exp.gt(5, 4), exp.gt(4, 5)).evaluate(1))
        self.assertEqual(True, exp.logical_or(exp.gt(4, 5), exp.gt(5, 4)).evaluate(1))
        self.assertEqual(False, exp.logical_or(exp.gt(4, 5), exp.gt(4, 5)).evaluate(1))

    def test_eq(self):
        self.assertEqual(True, exp.eq(exp.id(), "hey").evaluate("hey"))
        self.assertEqual(False, exp.eq(exp.id(), "hey").evaluate("hey2"))
        self.assertEqual(True, exp.eq(exp.id(), 1.0).evaluate(1.0))
        self.assertEqual(False, exp.eq(exp.id(), 1).evaluate("hi"))

    def test_gt(self):
        self.assertEqual(True, exp.gt(exp.id(), 2.0).evaluate(3.0))
        self.assertEqual(False, exp.gt(exp.id(), 2.0).evaluate(2.0))

    def test_gte(self):
        self.assertEqual(True, exp.gte(exp.id(), 2.0).evaluate(3.0))
        self.assertEqual(True, exp.gte(exp.id(), 2.0).evaluate(2.0))
        self.assertEqual(False, exp.gte(exp.id(), 2.0).evaluate(1.0))

    def test_lt(self):
        self.assertEqual(True, exp.lt(2.0, exp.id()).evaluate(3.0))
        self.assertEqual(False, exp.lt(2.0, exp.id()).evaluate(2.0))

    def test_lte(self):
        self.assertEqual(True, exp.lte(2.0, exp.id()).evaluate(3.0))
        self.assertEqual(True, exp.lte(2.0, exp.id()).evaluate(2.0))
        self.assertEqual(False, exp.lte(2.0, exp.id()).evaluate(1.0))

    def test_divisible_by(self):
        self.assertEqual(True, exp.divisible_by(4, exp.id()).evaluate(2))
        self.assertEqual(False, exp.divisible_by(4, exp.id()).evaluate(3))

    def test_contains(self):
        self.assertEqual(True, exp.contains("joshua", exp.id()).evaluate("josh"))
        self.assertEqual(False, exp.contains("josh", exp.id()).evaluate("joshua"))

    def test_starts_with(self):
        self.assertEqual(True, exp.starts_with("abc", exp.id()).evaluate("ab"))
        self.assertEqual(False, exp.starts_with("abc", exp.id()).evaluate("bc"))

    def test_ends_with(self):
        self.assertEqual(False, exp.ends_with("abc", exp.id()).evaluate("ab"))
        self.assertEqual(True, exp.ends_with("abc", exp.id()).evaluate("bc"))

    def test_matches(self):
        self.assertTrue(exp.matches("abc", exp.id()).evaluate("[a-c]*"))
        self.assertFalse(exp.matches("abc", exp.id()).evaluate("[b-z]*"))

    def test_add(self):
        self.assertEqual(5.0, exp.add(1.0, exp.id()).evaluate(4.0))

    def test_sub(self):
        self.assertEqual(-3.0, exp.sub(1.0, exp.id()).evaluate(4.0))

    def test_div(self):
        self.assertEqual(1.5, exp.div(3.0, exp.id()).evaluate(2.0))

    def test_mul(self):
        self.assertEqual(6.0, exp.mul(3.0, 2.0).evaluate(3.0))

    def test_abs(self):
        self.assertEqual(1.0, exp.abs(exp.id("a")).evaluate(self._tsc.record(a=-1.0, b="hello")._j_obj))


class MultiTimeSeriesTest(unittest.TestCase):

    def setUp(self):
        self._tsc = context.TSContext()

        self.mts = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([0.0, 1.0, 2.0, 3.0, 4.0]).collect(),
            "b": self._tsc.time_series.list([5.0, 6.0, 7.0, 8.0]).collect()
        })

        self.left_mts = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                self._tsc.observation(2, 1.0),
                self._tsc.observation(3, 2.0),
                self._tsc.observation(8, 5.0),
                self._tsc.observation(10, 6.0),
                self._tsc.observation(11, 4.0)
            ),
            "b": self._tsc.observations.of(
                self._tsc.observation(2, 2.0),
                self._tsc.observation(3, 3.0),
                self._tsc.observation(8, 6.0),
                self._tsc.observation(10, 7.0),
                self._tsc.observation(11, 5.0)
            )
        })

        self.right_mts = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                self._tsc.observation(3, 3.0),
                self._tsc.observation(4, 4.0),
                self._tsc.observation(6, 6.0),
                self._tsc.observation(9, 9.0),
                self._tsc.observation(10, 10.0),
                self._tsc.observation(12, 12.0)
            ),
            "b": self._tsc.observations.of(
                self._tsc.observation(1, 1.0),
                self._tsc.observation(3, 3.0),
                self._tsc.observation(4, 4.0),
                self._tsc.observation(5, 5.0),
                self._tsc.observation(8, 8.0),
                self._tsc.observation(10, 10.0)
            )
        })

    def tearDown(self):
        self._tsc.stop()

    def test_df_instants(self):
        expected = self._tsc.multi_time_series.dict({
            "key": self._tsc.time_series.list(["a", "b", "a", "a", "b"]).collect(),
            "timestamp": self._tsc.time_series.list([1, 3, 5, 3, 2]).collect(),
            "name": self._tsc.time_series.list(["josh", "john", "bob", "fred", "ryan"]).collect(),
            "age": self._tsc.time_series.list([27, 4, 17, 7, 45]).collect()
        })

        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         [0, "a", 1, "josh", 27],
                         [1, "b", 3, "john", 4],
                         [2, "a", 5, "bob", 17],
                         [3, "a", 3, "fred", 7],
                         [4, "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        actual = self._tsc.multi_time_series.df_instants(df)
        verify_multi_series(self, expected, actual)

    def test_df_instants_with_timestamp_column(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "key": self._tsc.observations.of(Obs(1, "a"), Obs(2, "b"), Obs(3, "b"), Obs(3, "a"), Obs(5, "a")),
            "name": self._tsc.observations.of(Obs(1, "josh"), Obs(2, "ryan"), Obs(3, "john"), Obs(3, "fred"), Obs(5, "bob")),
            "age": self._tsc.observations.of(Obs(1, 27), Obs(2, 45), Obs(3, 4), Obs(3, 7), Obs(5, 17))
        })

        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         [0, "a", 1, "josh", 27],
                         [1, "b", 3, "john", 4],
                         [2, "a", 5, "bob", 17],
                         [3, "a", 3, "fred", 7],
                         [4, "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        actual = self._tsc.multi_time_series.df_instants(df, ts_column='timestamp')
        verify_multi_series(self, expected, actual)

    def test_df_observations(self):
        Record = self._tsc.record()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([
                Record(timestamp=1, name="josh", age=27),
                Record(timestamp=5, name="bob", age=17),
                Record(timestamp=3, name="fred", age=7)
            ]).collect(),
            "b": self._tsc.time_series.list([
                Record(timestamp=3, name="john", age=4),
                Record(timestamp=2, name="ryan", age=45)
            ]).collect()
        })

        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         [0, "a", 1, "josh", 27],
                         [1, "b", 3, "john", 4],
                         [2, "a", 5, "bob", 17],
                         [3, "a", 3, "fred", 7],
                         [4, "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        actual = self._tsc.multi_time_series.df_observations(df, key_column="key")

        verify_multi_series(self, expected, actual)

    def test_df_observations_with_timestamp_column(self):
        Obs = self._tsc.observation()
        Record = self._tsc.record()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                Obs(1, Record(name="josh", age=27)),
                Obs(3, Record(name="fred", age=7)),
                Obs(5, Record(name="bob", age=17))
            ),
            "b": self._tsc.observations.of(
                Obs(2, Record(name="ryan", age=45)),
                Obs(3, Record(name="john", age=4))
            )
        })

        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         [0, "a", 1, "josh", 27],
                         [1, "b", 3, "john", 4],
                         [2, "a", 5, "bob", 17],
                         [3, "a", 3, "fred", 7],
                         [4, "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        actual = self._tsc.multi_time_series.df_observations(df, key_column="key", ts_column="timestamp")
        verify_multi_series(self, expected, actual)

    def test_df_observations_with_value_column(self):
        Obs = self._tsc.observation()
        Record = self._tsc.record()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                Obs(1, 27),
                Obs(3, 7),
                Obs(5, 17)
            ),
            "b": self._tsc.observations.of(
                Obs(2, 45),
                Obs(3, 4)
            )
        })

        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         [0, "a", 1, "josh", 27],
                         [1, "b", 3, "john", 4],
                         [2, "a", 5, "bob", 17],
                         [3, "a", 3, "fred", 7],
                         [4, "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        actual = self._tsc.multi_time_series.df_observations(df, key_column="key", ts_column="timestamp", value_column="age")

        verify_multi_series(self, expected, actual)

    def test_map_series(self):
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([1.0, 2.0, 3.0, 4.0, 5.0]).collect(),
            "b": self._tsc.time_series.list([6.0, 7.0, 8.0, 9.0]).collect()
        })
        actual = self.mts.map_series(lambda series: series.to_time_series().map(lambda x: x + 1).collect())
        verify_multi_series(self, expected, actual)

    def test_map_series_with_key(self):
        Record = self._tsc.record()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([Record(num=0.0, key="a"), Record(num=1.0, key="a"), Record(num=2.0, key="a"), Record(num=3.0, key="a"), Record(num=4.0, key="a")]).collect(),
            "b": self._tsc.time_series.list([Record(num=5.0, key="b"), Record(num=6.0, key="b"), Record(num=7.0, key="b"), Record(num=8.0, key="b")]).collect()
        })
        actual = self.mts.map_series_with_key(lambda key, series: series.to_time_series().map(lambda x: Record(num=x, key=key)).collect())
        verify_multi_series(self, expected, actual)

    def test_map_series_value(self):
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([1.0, 2.0, 3.0, 4.0, 5.0]).collect(),
            "b": self._tsc.time_series.list([6.0, 7.0, 8.0, 9.0]).collect()
        })
        actual = self.mts.map(lambda x: x + 1)
        verify_multi_series(self, expected, actual)

    def test_unary_transform_series(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(1, 1.0), Obs(2, 1.0), Obs(3, 1.0), Obs(4, 1.0)),
            "b": self._tsc.observations.of(Obs(1, 1.0), Obs(2, 1.0), Obs(3, 1.0))
        })
        actual = self.mts.transform(self._tsc.math_transforms.difference())
        verify_multi_series(self, expected, actual)

    def test_binary_transform_series_with_ts(self):
        right_ts = self._tsc.time_series.list([2.0, 4.0, 5.0])
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([2.0, 5.0, 7.0]).collect(),
            "b": self._tsc.time_series.list([7.0, 10.0, 12.0]).collect()
        })
        actual = self.mts.transform(right_ts, DummyBinaryTransform())
        verify_multi_series(self, expected, actual)

    def test_binary_transform_series_with_mts(self):
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([0.0, 2.0, 4.0, 6.0, 8.0]).collect(),
            "b": self._tsc.time_series.list([10.0, 12.0, 14.0, 16.0]).collect()
        })
        actual = self.mts.transform(self.mts, DummyBinaryTransform())
        verify_multi_series(self, expected, actual)

    def test_pair_wise_transform(self):
        pkg = self._tsc._jvm.com.ibm.research.time_series.core.utils
        expected = self._tsc.multi_time_series.dict({
            pkg.Pair("a", "a"): self._tsc.time_series.list([0.0, 2.0, 4.0, 6.0, 8.0]).collect(),
            pkg.Pair("a", "b"): self._tsc.time_series.list([5.0, 7.0, 9.0, 11.0]).collect(),
            pkg.Pair("b", "a"): self._tsc.time_series.list([5.0, 7.0, 9.0, 11.0]).collect(),
            pkg.Pair("b", "b"): self._tsc.time_series.list([10.0, 12.0, 14.0, 16.0]).collect()
        })
        actual = self.mts.pair_wise_transform(DummyBinaryTransform())
        verify_multi_series(self, expected, actual)

    def test_interpolate_series(self):
        Obs = self._tsc.observation()
        mts_with_holes = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(1, 1.0), Obs(3, 2.0), Obs(5, 3.0), Obs(8, 4.0)),
            "b": self._tsc.observations.of(Obs(1, 1.0), Obs(4, 2.0), Obs(5, 3.0))
        })
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(1, 1.0), Obs(2, 1.0), Obs(3, 2.0), Obs(4, 2.0), Obs(5, 3.0), Obs(6, 3.0), Obs(7, 4.0), Obs(8, 4.0)),
            "b": self._tsc.observations.of(Obs(1, 1.0), Obs(2, 1.0), Obs(3, 2.0), Obs(4, 2.0), Obs(5, 3.0))
        })

        actual = mts_with_holes.resample(1, self._tsc.interpolators.nearest())
        verify_multi_series(self, expected, actual)

    def test_filter_series_value(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(0, 0.0), Obs(2, 2.0), Obs(4, 4.0)),
            "b": self._tsc.observations.of(Obs(1, 6.0), Obs(3, 8.0))
        })
        actual = self.mts.filter(lambda x: x % 2 == 0)
        verify_multi_series(self, expected, actual)

    def test_filter_series_by_key(self):
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([0.0, 1.0, 2.0, 3.0, 4.0]).collect()
        })
        actual = self.mts.filter_series_key(lambda k: k == "a")
        verify_multi_series(self, expected, actual)

    def test_filter_series(self):
        expected = self._tsc.multi_time_series.dict({
            "b": self._tsc.time_series.list([5.0, 6.0, 7.0, 8.0]).collect()
        })
        actual = self.mts.filter_series(lambda s: s.count() < 5)
        verify_multi_series(self, expected, actual)

    def test_segment_series(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.time_series.list([
                Segment(self._tsc, self._tsc.observations.of(Obs(0, 0.0), Obs(1, 1.0))._j_observations),
                Segment(self._tsc, self._tsc.observations.of(Obs(1, 1.0), Obs(2, 2.0))._j_observations),
                Segment(self._tsc, self._tsc.observations.of(Obs(2, 2.0), Obs(3, 3.0))._j_observations),
                Segment(self._tsc, self._tsc.observations.of(Obs(3, 3.0), Obs(4, 4.0))._j_observations)
            ]).collect(),
            "b": self._tsc.time_series.list([
                Segment(self._tsc, self._tsc.observations.of(Obs(0, 5.0), Obs(1, 6.0))._j_observations),
                Segment(self._tsc, self._tsc.observations.of(Obs(1, 6.0), Obs(2, 7.0))._j_observations),
                Segment(self._tsc, self._tsc.observations.of(Obs(2, 7.0), Obs(3, 8.0))._j_observations)
            ]).collect()
        })
        actual = self.mts.segment(2)
        verify_multi_series(self, expected, actual)

    def test_segment_series_by_time(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                Obs(0, Segment(self._tsc, self._tsc.observations.of(Obs(0, 0.0), Obs(1, 1.0))._j_observations)),
                Obs(2, Segment(self._tsc, self._tsc.observations.of(Obs(2, 2.0), Obs(3, 3.0))._j_observations)),
                Obs(4, Segment(self._tsc, self._tsc.observations.of(Obs(4, 4.0))._j_observations, 4, 5))
            ),
            "b": self._tsc.observations.of(
                Obs(0, Segment(self._tsc, self._tsc.observations.of(Obs(0, 5.0), Obs(1, 6.0))._j_observations)),
                Obs(2, Segment(self._tsc, self._tsc.observations.of(Obs(2, 7.0), Obs(3, 8.0))._j_observations))
            )
        })
        actual = self.mts.segment_by_time(2, 2)
        # verify_multi_series(self, expected, actual)
        self.assertEqual(str(expected), str(actual))

    def test_segment_series_by_anchor(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                Obs(0, Segment(self._tsc, self._tsc.observations.of(Obs(0, 0.0), Obs(1, 1.0))._j_observations, -1, 1)),
                Obs(2, Segment(self._tsc, self._tsc.observations.of(Obs(1, 1.0), Obs(2, 2.0), Obs(3, 3.0))._j_observations, 1, 3)),
                Obs(4, Segment(self._tsc, self._tsc.observations.of(Obs(3, 3.0), Obs(4, 4.0))._j_observations, 3, 5))
            ),
            "b": self._tsc.observations.of(
                Obs(1, Segment(self._tsc,self._tsc.observations.of(Obs(0, 5.0), Obs(1, 6.0), Obs(2, 7.0))._j_observations, 0, 2)),
                Obs(3, Segment(self._tsc,self._tsc.observations.of(Obs(2, 7.0), Obs(3, 8.0))._j_observations, 2, 4))
            )
        })
        actual = self.mts.segment_by_anchor(lambda v: v % 2.0 == 0, 1, 1)
        # verify_multi_series(self, expected, actual)
        self.assertEqual(str(expected), str(actual))

    def test_segment_series_by(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(
                Obs(0, Segment(self._tsc, self._tsc.observations.of(Obs(0, 0.0), Obs(2, 2.0), Obs(4, 4.0))._j_observations)),
                Obs(1, Segment(self._tsc, self._tsc.observations.of(Obs(1, 1.0), Obs(3, 3.0))._j_observations))
            ),
            "b": self._tsc.observations.of(
                Obs(0, Segment(self._tsc, self._tsc.observations.of(Obs(0, 5.0), Obs(2, 7.0))._j_observations)),
                Obs(1, Segment(self._tsc, self._tsc.observations.of(Obs(1, 6.0), Obs(3, 8.0))._j_observations))
            )
        })
        actual = self.mts.segment_by(lambda o: o.time_tick % 2 is 0)
        self.assertEqual(str(expected), str(actual))
        # verify_multi_series(self, expected, actual)

    def test_reduce_series_lambda(self):
        expected = {"a": 5, "b": 4}
        actual = self.mts.reduce(lambda s: len(s))
        self.assertDictEqual(expected, actual)

    def test_reduce_series_reducer(self):
        expected = {"a": 10.0, "b": 26.0}
        actual = self.mts.reduce(self._tsc.math_reducers.sum())
        self.assertDictEqual(expected, actual)

    def test_inner_align_series(self):
        Obs = self._tsc.observation()
        expected_left = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(3, 2.0), Obs(10, 6.0)),
            "b": self._tsc.observations.of(Obs(3, 3.0), Obs(8, 6.0), Obs(10, 7.0))
        })

        expected_right = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(3, 3.0), Obs(10, 10.0)),
            "b": self._tsc.observations.of(Obs(3, 3.0), Obs(8, 8.0), Obs(10, 10.0))
        })

        actual_left, actual_right = self.left_mts.inner_align(self.right_mts)
        verify_multi_series(self, expected_left, actual_left)
        verify_multi_series(self, expected_right, actual_right)

    def test_inner_join_series(self):
        Obs = self._tsc.observation()
        expected = self._tsc.multi_time_series.dict({
            "a": self._tsc.observations.of(Obs(3, 5.0), Obs(10, 16.0)),
            "b": self._tsc.observations.of(Obs(3, 6.0), Obs(8, 14.0), Obs(10, 17.0))
        })
        actual = self.left_mts.inner_join(self.right_mts, lambda l, r: l + r)
        verify_multi_series(self, expected, actual)


class TimeSeriesTest(unittest.TestCase):

    def test_from_df_with_ts_column(self):
        Obs = self._tsc.observation()
        Record = self._tsc.record()
        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         ['Row1', "a", 1, "josh", 27],
                         ['Row2', "b", 3, "john", 4],
                         ['Row3', "a", 5, "bob", 17],
                         ['Row4', "a", 3, "fred", 7],
                         ['Row5', "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]
                          ).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        expected = self._tsc.observations.of(
            Obs(1, Record(key='a', name="josh", age=27)),
            Obs(2, Record(key='b', name="ryan", age=45)),
            Obs(3, Record(key='b', name="john", age=4)),
            Obs(3, Record(key='a', name="fred", age=7)),
            Obs(5, Record(key='a', name="bob", age=17))
        ).to_time_series()
        actual = self._tsc.time_series.df(df, 'timestamp')
        verify_series(self, expected, actual)

    def test_from_df(self):
        Obs = self._tsc.observation()
        Record = self._tsc.record()
        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         ['Row1', "a", 1, "josh", 27],
                         ['Row2', "b", 3, "john", 4],
                         ['Row3', "a", 5, "bob", 17],
                         ['Row4', "a", 3, "fred", 7],
                         ['Row5', "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        expected = self._tsc.observations.of(
            Obs(0, Record(key='a', timestamp=1, name="josh", age=27)),
            Obs(1, Record(key='b', timestamp=3, name="john", age=4)),
            Obs(2, Record(key='a', timestamp=5, name="bob", age=17)),
            Obs(3, Record(key='a', timestamp=3, name="fred", age=7)),
            Obs(4, Record(key='b', timestamp=2, name="ryan", age=45))
        ).to_time_series()
        actual = self._tsc.time_series.df(df)
        verify_series(self, expected, actual)

    def test_from_df_with_value_column(self):
        Obs = self._tsc.observation()
        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         ['Row1', "a", 1, "josh", 27],
                         ['Row2', "b", 3, "john", 4],
                         ['Row3', "a", 5, "bob", 17],
                         ['Row4', "a", 3, "fred", 7],
                         ['Row5', "b", 2, "ryan", 45]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:]).astype(dtype={'key': 'object', 'timestamp': 'int64', 'name': 'object', 'age': 'int64'})

        expected = self._tsc.observations.of(
            Obs(1, 27),
            Obs(2, 45),
            Obs(3, 4),
            Obs(3, 7),
            Obs(5, 17)
        ).to_time_series()
        actual = self._tsc.time_series.df(df, 'timestamp', 'age')
        verify_series(self, expected, actual)

    def test_to_df(self):
        from pandas.util.testing import assert_frame_equal
        data = np.array([['', 'key', 'timestamp', "name", "age"],
                         ["0", "a", "1", "josh", "27"],
                         ["1", "b", "3", "john", "4"],
                         ["2", "a", "5", "bob",  "17"],
                         ["3", "a", "3", "fred", "7"],
                         ["4", "b", "2", "ryan", "45"]
                         ])

        df = pd.DataFrame(data=data[1:, 1:],
                          index=data[1:, 0],
                          columns=data[0, 1:])

        actual_df = self._tsc.time_series.df(df).to_df()

        print(actual_df)

        expected_data = np.array([['', 'key', 'timestamp', "name", "age", "timestamp.1"],
                             ["0", "a", 0, "josh", "27", "1"],
                             ["1", "b", 1, "john", "4", "3"],
                             ["2", "a", 2, "bob", "17", "5"],
                             ["3", "a", 3, "fred", "7", "3"],
                             ["4", "b", 4, "ryan", "45", "2"]
                            ])

        expected_df = pd.DataFrame(data=expected_data[1:, 1:],
                          index=range(0, 5),
                          columns=expected_data[0, 1:])

        print(expected_df)

        assert_frame_equal(
            expected_df.sort_values("timestamp.1", axis=0).applymap(lambda x: str(x)), # todo types were having issues, so mapped to string, will have to revisit
            actual_df.sort_values("timestamp.1", axis=0).applymap(lambda x: str(x)), # todo types were having issues, so mapped to string, will have to revisit
            check_like=True
        )

    def test_map(self):
        expected = self._tsc.time_series.list([1, 2, 3, 4, 5])
        actual = self.int_ts.map(lambda x: x + 1)
        verify_series(self, expected, actual)

    def test_map_with_index(self):
        expected = self._tsc.time_series.list([
            self.Record(value=0, index=0),
            self.Record(value=1, index=1),
            self.Record(value=2, index=2),
            self.Record(value=3, index=3),
            self.Record(value=4, index=4)
        ])
        actual = self.int_ts.map_with_index(lambda x, index: self.Record(value=x, index=index))
        verify_series(self, expected, actual)

    def test_flatmap(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, 0), self._tsc.observation(0, 1),
            self._tsc.observation(1, 1), self._tsc.observation(1, 2),
            self._tsc.observation(2, 2), self._tsc.observation(2, 3),
            self._tsc.observation(3, 3), self._tsc.observation(3, 4),
            self._tsc.observation(4, 4), self._tsc.observation(4, 5)
        ))
        actual = self.int_ts.flatmap(lambda x: [x, x + 1])
        verify_series(self, expected, actual)

    def test_filter(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, 0),
            self._tsc.observation(2, 2),
            self._tsc.observation(4, 4)
        ))

        actual = self.int_ts.filter(lambda x: x % 2 is 0)
        verify_series(self, expected, actual)

    def test_interpolate(self):
        ts = self._tsc.observations.of(
            self._tsc.observation(1, 4.0),
            self._tsc.observation(3, 9.0)
        ).to_time_series()

        actual = ts.resample(1, self._tsc.interpolators.linear(-1.0))

        expected = self._tsc.observations.of(
            self._tsc.observation(1, 4.0),
            self._tsc.observation(2, 6.5),
            self._tsc.observation(3, 9.0)
        ).to_time_series()
        verify_series(self, expected, actual)

    def test_fillna(self):
        ts = self._tsc.observations.of(
            self._tsc.observation(1, 4.0),
            self._tsc.observation(2, 6.5),
            self._tsc.observation(3, 9.0),
            self._tsc.observation(4, 5.0),
            self._tsc.observation(5, 6.0)
        ).to_time_series()

        actual = ts.shift(1).fillna(self._tsc.interpolators.fill(-1.0))

        expected = self._tsc.observations.of(
            self._tsc.observation(1, -1.0),
            self._tsc.observation(2, 4.0),
            self._tsc.observation(3, 6.5),
            self._tsc.observation(4, 9.0),
            self._tsc.observation(5, 5.0)
        ).to_time_series()
        verify_series(self, expected, actual)

    def test_unary_transform(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, 1.0),
            self._tsc.observation(2, 1.0),
            self._tsc.observation(3, 1.0),
            self._tsc.observation(4, 1.0)
        ))

        actual = self.float_ts.transform(self._tsc.math_transforms.difference())
        verify_series(self, expected, actual)

    def test_binary_transform(self):
        expected = self._tsc.time_series.list([0.0, 2.0, 4.0, 6.0, 8.0])
        actual = self.float_ts.transform(self.float_ts, DummyBinaryTransform())
        verify_series(self, expected, actual)

    def test_segment(self):
        expected = self._tsc.time_series.list([
            Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 0), self._tsc.observation(1, 1))._j_observations),
            Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 1), self._tsc.observation(2, 2))._j_observations),
            Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(2, 2), self._tsc.observation(3, 3))._j_observations),
            Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(3, 3), self._tsc.observation(4, 4))._j_observations)
        ])

        actual = self.int_ts.segment(2)
        verify_series(self, expected, actual)

    def test_segment_by(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 0), self._tsc.observation(2, 2), self._tsc.observation(4, 4))._j_observations)),
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 1), self._tsc.observation(3, 3))._j_observations))
        ))

        actual = self.int_ts.segment_by(lambda obs: obs.value % 2 is 0)
        self.assertEqual(str(expected), str(actual))

    def test_segment_by_time(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 0), self._tsc.observation(1, 1))._j_observations)),
            self._tsc.observation(2, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(2, 2), self._tsc.observation(3, 3))._j_observations))
        ))

        actual = self.int_ts.segment_by_time(2, 2)
        self.assertEqual(str(expected), str(actual))

    def test_segment_by_anchor(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 0))._j_observations, -1, 0)),
            self._tsc.observation(2, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 1), self._tsc.observation(2, 2))._j_observations, 1, 2)),
            self._tsc.observation(4, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(3, 3), self._tsc.observation(4, 4))._j_observations, 3, 4)),
        ))

        actual = self.int_ts.segment_by_anchor(lambda x: x % 2 is 0, 1, 0)
        self.assertEqual(str(expected), str(actual))

    def test_lag(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(2, 2),
            self._tsc.observation(3, 3),
            self._tsc.observation(4, 4)
        ))
        actual = self.int_ts.lag(2)
        verify_series(self, expected, actual)

    def test_shift(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, None),
            self._tsc.observation(1, None),
            self._tsc.observation(2, 0),
            self._tsc.observation(3, 1),
            self._tsc.observation(4, 2)
        ))
        actual = self.int_ts.shift(2)
        verify_series(self, expected, actual)

    def test_built_in_interpolate(self):

        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, 1),
            self._tsc.observation(2, 0),
            self._tsc.observation(3, 3),
            self._tsc.observation(4, 0),
            self._tsc.observation(5, 5)
        ))

        actual = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, 1),
            self._tsc.observation(3, 3),
            self._tsc.observation(5, 5)
        )).resample(1, self._tsc.interpolators.fill(0))

        verify_series(self, expected, actual)

    def test_user_def_interpolate(self):

        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, 1),
            self._tsc.observation(2, 3),
            self._tsc.observation(3, 3),
            self._tsc.observation(4, 5),
            self._tsc.observation(5, 5)
        ))

        actual = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, 1),
            self._tsc.observation(3, 3),
            self._tsc.observation(5, 5)
        )).resample(1, lambda h, f, t: f.first().value)

        verify_series(self, expected, actual)

    def test_full_join_without_interpolate(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, None]),
            self._tsc.observation(2, [None, 3.0]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(4, [None, 9.0]),
            self._tsc.observation(7, [5.0, None]),
            self._tsc.observation(8, [8.0, None]),
            self._tsc.observation(9, [None, 6.0]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(12, [11.0, None]),
            self._tsc.observation(13, [None, 17.0]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.full_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_full_join_with_interpolate(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, -1.0]),
            self._tsc.observation(2, [2.5, 3.0]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(4, [3.5, 9.0]),
            self._tsc.observation(7, [5.0, 7.2]),
            self._tsc.observation(8, [8.0, 6.6]),
            self._tsc.observation(9, [6.5, 6.0]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(12, [11.0, 15.5]),
            self._tsc.observation(13, [6.0, 17.0]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.full_join(
            self.right_ts,
            left_interp_func=self._tsc.interpolators.linear(-1.0),
            right_interp_func=self._tsc.interpolators.linear(-1.0)
        )
        verify_series(self, expected, actual)

    def test_inner_join(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.inner_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_left_join_without_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, None]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(7, [5.0, None]),
            self._tsc.observation(8, [8.0, None]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(12, [11.0, None]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.left_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_left_join_with_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, -1.0]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(7, [5.0, 7.2]),
            self._tsc.observation(8, [8.0, 6.6]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(12, [11.0, 15.5]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.left_join(
            self.right_ts,
            interp_func=self._tsc.interpolators.linear(-1.0)
        )
        verify_series(self, expected, actual)

    def test_right_join_without_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(2, [None, 3.0]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(4, [None, 9.0]),
            self._tsc.observation(9, [None, 6.0]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(13, [None, 17.0]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.right_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_right_join_with_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(2, [2.5, 3.0]),
            self._tsc.observation(3, [3.0, 5.0]),
            self._tsc.observation(4, [3.5, 9.0]),
            self._tsc.observation(9, [6.5, 6.0]),
            self._tsc.observation(10, [5.0, 13.0]),
            self._tsc.observation(11, [9.0, 14.0]),
            self._tsc.observation(13, [6.0, 17.0]),
            self._tsc.observation(14, [1.0, 21.0])
        ))

        actual = self.left_ts.right_join(
            self.right_ts,
            interp_func=self._tsc.interpolators.linear()
        )
        verify_series(self, expected, actual)

    def test_left_outer_join_without_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, None]),
            self._tsc.observation(7, [5.0, None]),
            self._tsc.observation(8, [8.0, None]),
            self._tsc.observation(12, [11.0, None])
        ))

        actual = self.left_ts.left_outer_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_left_outer_join_with_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, [2.0, -1.0]),
            self._tsc.observation(7, [5.0, 7.2]),
            self._tsc.observation(8, [8.0, 6.6]),
            self._tsc.observation(12, [11.0, 15.5])
        ))

        actual = self.left_ts.left_outer_join(
            self.right_ts,
            interp_func=self._tsc.interpolators.linear(-1.0)
        )
        verify_series(self, expected, actual)

    def test_right_outer_join_without_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(2, [None, 3.0]),
            self._tsc.observation(4, [None, 9.0]),
            self._tsc.observation(9, [None, 6.0]),
            self._tsc.observation(13, [None, 17.0])
        ))

        actual = self.left_ts.right_outer_join(self.right_ts)
        verify_series(self, expected, actual)

    def test_right_outer_join_with_interpolation(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(2, [2.5, 3.0]),
            self._tsc.observation(4, [3.5, 9.0]),
            self._tsc.observation(9, [6.5, 6.0]),
            self._tsc.observation(13, [6.0, 17.0])
        ))

        actual = self.left_ts.right_outer_join(
            self.right_ts,
            interp_func=self._tsc.interpolators.linear(-1.0)
        )
        verify_series(self, expected, actual)

    def test_forecast(self):
        expected = self._tsc.observations.of(
            self._tsc.observation(100, 100.0),
            self._tsc.observation(101, 101.0),
            self._tsc.observation(102, 102.0),
            self._tsc.observation(103, 103.0),
            self._tsc.observation(104, 104.0)
        ).to_time_series()

        actual = self._tsc.time_series.list([float(i) for i in range(0, 100)]).forecast(5, self._tsc.forecasters.auto(10)) \
            .to_time_series() \
            .map(lambda r: float(round(r['value'])))

        verify_series(self, expected, actual)

    def test_segment_by_single_marker_no_require_two(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2))._j_observations)),
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2), self._tsc.observation(1, 2))._j_observations)),
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2), self._tsc.observation(2, 4))._j_observations)),
            self._tsc.observation(2, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(2, 4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(marker=lambda x: x % 2 == 0)

        self.assertEqual(str(expected), str(actual))

    def test_segment_by_single_marker_require_two(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2), self._tsc.observation(1, 2))._j_observations)),
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2), self._tsc.observation(2, 4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(marker=lambda x: x % 2 == 0, requires_start_and_end=True)

        self.assertEqual(str(expected), str(actual))

    def test_segment_by_single_marker_no_require_two_args(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2))._j_observations)),
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2), self._tsc.observation(1, 2))._j_observations)),
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2), self._tsc.observation(2, 4))._j_observations)),
            self._tsc.observation(2, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(2, 4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(lambda x: x % 2 == 0)

        self.assertEqual(str(expected), str(actual))

    def test_segment_by_single_marker_require_two_args(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(0, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(0, 2), self._tsc.observation(1, 2))._j_observations)),
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2), self._tsc.observation(2, 4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(lambda x: x % 2 == 0, True, True, True)

        self.assertEqual(str(expected), str(actual))

    def test_segment_by_bi_marker(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2),self._tsc.observation(2,4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(start_marker=lambda x: x == 2, end_marker=lambda x: x == 4)

        self.assertEqual(str(expected), str(actual))

    def test_segment_by_bi_marker_args(self):
        expected = self._tsc.time_series.from_observations(self._tsc.observations.of(
            self._tsc.observation(1, Segment(self._tsc, self._tsc.observations.of(self._tsc.observation(1, 2),self._tsc.observation(2,4))._j_observations))
        ))

        actual = self._tsc.time_series.list([2, 2, 4]).segment_by_marker(lambda x: x == 2, lambda x: x == 4)

        self.assertEqual(str(expected), str(actual))

    def setUp(self):
        self._tsc = context.TSContext()
        self.Record = self._tsc.record()
        self.int_ts = self._tsc.time_series.list([0, 1, 2, 3, 4])
        self.float_ts = self._tsc.time_series.list([0.0, 1.0, 2.0, 3.0, 4.0])

        self.left_ts = self._tsc.time_series.from_observations(
            self._tsc.observations.of(
                self._tsc.observation(1, 2.0),
                self._tsc.observation(3, 3.0),
                self._tsc.observation(7, 5.0),
                self._tsc.observation(8, 8.0),
                self._tsc.observation(10, 5.0),
                self._tsc.observation(11, 9.0),
                self._tsc.observation(12, 11.0),
                self._tsc.observation(14, 1.0)
            )
        )

        self.right_ts = self._tsc.time_series.from_observations(
            self._tsc.observations.of(
                self._tsc.observation(2, 3.0),
                self._tsc.observation(3, 5.0),
                self._tsc.observation(4, 9.0),
                self._tsc.observation(9, 6.0),
                self._tsc.observation(10, 13.0),
                self._tsc.observation(11, 14.0),
                self._tsc.observation(13, 17.0),
                self._tsc.observation(14, 21.0)
            )
        )

    def tearDown(self):
        self._tsc.stop()


if __name__ == '__main__':
    unittest.main()
