class TSError(Exception):
    """
    The base time-series error which will occur if an exception is raised when using tspy
    """
    pass


class TSErrorWithMessage(TSError):
    """
    an extension to the base time-series error which contains a message
    """
    def __init__(self, message=""):
        self._message = message

    def __str__(self):
        return self._message
