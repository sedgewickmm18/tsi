from py4j.java_gateway import JavaGateway, CallbackServerParameters, GatewayParameters, launch_gateway

from tspy.time_series.Segment import Segment

from tspy.forecasting.AnomalyDetector import AnomalyDetector
from tspy.ml import MLFactory
from tspy.time_series import TimeSeriesFactory, StreamTimeSeriesFactory, StreamMultiTimeSeriesFactory
from tspy.time_series import MultiTimeseriesFactory
from tspy.time_series import ObservationCollectionFactory
from tspy.forecasting import ForecastingModelFactory
from tspy.time_series.Observation import Observation
from tspy.transforms import MathReducerFactory, StatTransformerFactory, SegmentationTransformerFactory, \
    DuplicateTransformerFactory, StatReducerFactory
from tspy.transforms import MathTransformerFactory
from tspy.transforms import DistanceReducerFactory
from tspy.transforms import InterpolatorFactory
from tspy.builders.functions import expressions
from tspy.utils.utils import Record


def get_or_create():
    if TSContext._active == None:
        return TSContext(daemonize=True)
    else:
        return TSContext._active


class TSContext(object):

    def __init__(self, gateway=None, jvm=None, always_on_caching=True, kill_gateway_on_exception=False, port=0, callback_server_port=0, daemonize=False):
        self._always_on_cache = always_on_caching
        self._kill_gateway_on_exception = kill_gateway_on_exception
        if jvm is None and gateway is None:
            import os
            if os.environ.get("PY4J_PATH") is None:
                jarpath = ""
            else:
                jarpath = os.environ['PY4J_PATH']

            if os.environ.get('TS_HOME') is None:
                import pkg_resources
                classpath = pkg_resources.resource_filename("tspy",
                                                            'jars/time-series-assembly-python-2.0.5-jar-with-dependencies.jar')
            else:
                classpath = os.environ['TS_HOME']

            _port = launch_gateway(
                port=port,
                classpath=classpath,
                jarpath=jarpath,
                die_on_exit=True
            )

            self._gateway = JavaGateway(
                gateway_parameters=GatewayParameters(port=_port),
                callback_server_parameters=CallbackServerParameters(port=callback_server_port, daemonize=daemonize, daemonize_connections=daemonize),
                python_proxy_port=callback_server_port,
                start_callback_server=True
            )

            self._gateway.java_gateway_server.resetCallbackClient(
                self._gateway.java_gateway_server.getCallbackClient().getAddress(),
                self._gateway.get_callback_server().get_listening_port()
            )

            self._jvm = self._gateway.jvm
            self._port = _port
            self._callback_server_port = self._gateway.get_callback_server().get_listening_port()
        elif jvm is None:
            raise Exception("if jvm is none, gateway must be none")
        elif gateway is None:
            raise Exception("if gateway is none, jvm must be none")
        else:
            self._jvm = jvm
            self._gateway = gateway

            # added callback server to gateway which allows for lambdas on single machine
            if not hasattr(self._gateway.gateway_parameters, 'auth_token'):  # in 2.3 and below, there is no token
                self._gateway.start_callback_server(
                    CallbackServerParameters(port=callback_server_port, daemonize=daemonize,
                                             daemonize_connections=daemonize))
            else:  # in 2.4+ there is a token that must be included
                self._gateway.start_callback_server(
                    CallbackServerParameters(port=callback_server_port, daemonize=daemonize,
                                             daemonize_connections=daemonize,
                                             auth_token=self._gateway.gateway_parameters.auth_token))
            self._gateway.java_gateway_server.resetCallbackClient(
                self._gateway.java_gateway_server.getCallbackClient().getAddress(),
                self._gateway.get_callback_server().get_listening_port()
            )
            self._port = self._gateway._gateway_client.port
            self._callback_server_port = self._gateway.get_callback_server().get_listening_port()
        TSContext._active = self

    def stop(self):
        self._gateway.close_callback_server()
        self._gateway.close()
        self._gateway.shutdown_callback_server()
        self._gateway.shutdown()
        TSContext._active = None

    @property
    def exp(self):
        return expressions.Factory(self)

    def segment(self, observations, start=None, end=None):
        """
        NOTE: Use at own risk, this is mostly for use of development inside library
        :param observations:
        :param start:
        :param end:
        :return:
        """
        return Segment(self, observations._j_observations, start, end)

    def observation(self, timestamp=-1, value=None):
        return Observation(self, timestamp, value)

    def record(self, **kwargs):
        return Record(self, None, **kwargs)

    def second(self, duration, unit="s"):
        from tspy.utils import utils
        return utils.second(self._jvm, duration, unit)

    def minute(self, duration, unit="s"):
        from tspy.utils import utils
        return utils.minute(self._jvm, duration, unit)

    def hour(self, duration, unit="s"):
        from tspy.utils import utils
        return utils.hour(self._jvm, duration, unit)

    def day(self, duration, unit="s"):
        from tspy.utils import utils
        return utils.day(self._jvm, duration, unit)

    @property
    def stream_time_series(self):
        return StreamTimeSeriesFactory.Factory(self)

    @property
    def stream_multi_time_series(self):
        return StreamMultiTimeSeriesFactory.Factory(self)

    @property
    def ml(self):
        return MLFactory.Factory(self)

    @property
    def time_series(self):
        return TimeSeriesFactory.Factory(self)

    @property
    def multi_time_series(self):
        return MultiTimeseriesFactory.Factory(self)

    @property
    def observations(self):
        return ObservationCollectionFactory.Factory(self)

    @property
    def forecasters(self):
        return ForecastingModelFactory.Factory(self)

    def anomaly_detector(self, confidence):
        return AnomalyDetector(self._jvm, confidence)

    @property
    def math_transforms(self):
        return MathTransformerFactory.Factory(self._jvm)

    @property
    def math_reducers(self):
        return MathReducerFactory.Factory(self._jvm)

    @property
    def distance_reducers(self):
        return DistanceReducerFactory.Factory(self)

    @property
    def stat_transforms(self):
        return StatTransformerFactory.Factory(self._jvm)

    @property
    def stat_reducers(self):
        return StatReducerFactory.Factory(self._jvm)

    @property
    def segment_transforms(self):
        return SegmentationTransformerFactory.Factory(self._jvm)

    @property
    def duplicate_transforms(self):
        return DuplicateTransformerFactory.Factory(self)

    @property
    def interpolators(self):
        return InterpolatorFactory.Factory(self)
