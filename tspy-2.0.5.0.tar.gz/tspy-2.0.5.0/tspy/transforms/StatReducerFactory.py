class Factory(object):

    def __init__(self, jvm):
        self._jvm = jvm

    def adf(self, lag=None, p_value=-3.45):
        if lag is None:
            return self._jvm.com.ibm.research.time_series.transforms.reducers.stats.StatReducers.adf(p_value)
        else:
            return self._jvm.com.ibm.research.time_series.transforms.reducers.stats.StatReducers.adf(lag, p_value)

    def granger(self, lag):
        return self._jvm.com.ibm.research.time_series.transforms.reducers.stats.StatReducers.granger(lag)
