import abc


class UnaryTransform:
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def evaluate(self, time_series, start, end, inclusive_bounds):
        """given a time_series return a realized time series (ObservationCollection)"""
        return