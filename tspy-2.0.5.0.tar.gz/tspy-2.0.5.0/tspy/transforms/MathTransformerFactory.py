class Factory(object):

    def __init__(self, jvm):
        self._jvm = jvm

    def z_score(self):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.zscore()

    def difference(self):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.difference()

    def detect_anomalies(self, forecasting_model, confidence, update_model=False, info=False):
        if info:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.detectAnomaliesWithInfo(
                forecasting_model._j_fm,
                confidence,
                update_model
            )
        else:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.detectAnomalies(
                forecasting_model._j_fm,
                confidence,
                update_model
            )

    def awgn(self, mean=None, sd=None):
        if mean is None and sd is None:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.awgn()
        elif sd is None:
            j_sd = self._jvm.java.lang.Double.NaN
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.awgn(mean, j_sd)
        elif mean is None:
            j_mean = self._jvm.java.lang.Double.NaN
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.awgn(j_mean, sd)
        else:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.awgn(mean, sd)

    def mwgn(self, mean=None):
        if mean is None:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.mwgn()
        else:
            return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.mwgn(mean)

    def paa(self, m):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.paa(m)

    def sax(self, min_value, max_value, num_bins):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.sax(min_value, max_value, num_bins)

    def ema(self, window):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.MathTransformers.ema(window)

    def decompose(self, samples_per_season, multiplicative):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.math.PythonMathTransformers.decompose(
            samples_per_season,
            multiplicative
        )

