import abc


class BinaryTransform:
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def evaluate(self, time_series_left, time_series_right, start, end, inclusive_bounds):
        """given a time_series return a realized time series (ObservationCollection)"""
        return