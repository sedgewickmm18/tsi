class Factory(object):

    def __init__(self, jvm):
        self._jvm = jvm

    def augmented_dickey_fuller(self, window, step, lag, p_value):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.stats.StatTransformers.augmentedDickeyFuller(
            window,
            step,
            lag,
            p_value
        )

    def granger_causality(self, window, step, lag):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.stats.StatTransformers.grangerCausality(
            window,
            step,
            lag
        )

    def ljung_box(self, window, step, num_lags, period):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.stats.StatTransformers.ljungBox(
            window,
            step,
            num_lags,
            period
        )
