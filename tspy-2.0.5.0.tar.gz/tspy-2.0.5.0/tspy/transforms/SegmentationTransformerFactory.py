class Factory(object):

    def __init__(self, jvm):
        self._jvm = jvm

    def static_threshold(self, threshold):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.segmentation.SegmentationTransformers.staticThreshold(threshold)

    def dynamic_threshold(self, alpha, factor, threshold):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.segmentation.SegmentationTransformers.dynamicThreshold(
            alpha,
            factor,
            threshold
        )

    def regression(self, max_error, skip, use_relative=False):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.segmentation.SegmentationTransformers.regression(max_error, skip, use_relative)

    def statistical_changepoint(self, min_segment_size=2, threshold=2.0):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.segmentation.SegmentationTransformers.statisticalChangePoint(min_segment_size, threshold)

    def cusum(self, threshold):
        return self._jvm.com.ibm.research.time_series.transforms.transformers.segmentation.SegmentationTransformers.cusum(threshold)
