from tspy.ml.clustering.TimeSeriesClusteringModel import TimeSeriesClusteringModel


class KShapeModel(TimeSeriesClusteringModel):

    def __init__(self, tsc, j_model):
        super().__init__(tsc, j_model)

    def save(self, path):
        if isinstance(path, str):
            self._j_model.save(self._tsc._jvm.java.io.FileOutputStream(path))
        else:
            self._j_model.save(path)
