import abc

from tspy.time_series.ObservationCollection import ObservationCollection


class TimeSeriesClusteringModel:
    __metaclass__ = abc.ABCMeta

    def __init__(self, tsc, j_model):
        self._tsc = tsc
        self._j_model = j_model
        _centroids = {}
        c = 0
        for j_centroid in self._j_model.centroids():
            _centroids[str(c)] = ObservationCollection(self._tsc, j_centroid)
            c = c + 1
        self._centroids = _centroids

    def score(self, observations, with_silhouette=False):
        if with_silhouette is not True:
            return self._j_model.score(observations._j_observations)
        else:
            pair = self._j_model.scoreWithSilhouette(observations._j_observations)
            return pair.left(), pair.right()

    @property
    def intra_cluster_distances(self):
        return self._j_model.intraClusterDistances()

    @property
    def inter_cluster_distances(self):
        return self._j_model.interClusterDistances()

    @property
    def centroids(self):
        return self._centroids

    @property
    def silhouette_coefficients(self):
        return self._j_model.silhouetteCoefficients()

    @property
    def sum_squares(self):
        return self._j_model.sumSquares()

    @abc.abstractmethod
    def save(self, path):
        """Save this model"""
        return




