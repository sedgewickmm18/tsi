from tspy.ml.clustering import KShapeFactory


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    @property
    def k_shape(self):
        return KShapeFactory.Factory(self._tsc)

