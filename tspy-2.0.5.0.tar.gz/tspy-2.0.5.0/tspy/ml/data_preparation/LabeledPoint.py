class LabeledPoint:

    def __init__(self, label, feature_vector):
        self._label = label
        self._feature_vector = feature_vector

    @property
    def label(self):
        return self._label

    @property
    def feature_vector(self):
        return self._feature_vector

    def __str__(self):
        return "LabeledPoint(label=" + str(self._label) + ", feature_vector=" + str(self._feature_vector) + ")"
