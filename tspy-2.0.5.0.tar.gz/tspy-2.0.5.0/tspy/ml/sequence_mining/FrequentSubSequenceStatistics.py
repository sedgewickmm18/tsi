from tspy.ml.sequence_mining.InterArrivalStatistics import InterArrivalStatistics


class FrequentSubSequenceStatistics:

    def __init__(self, j_statistics):
        self._j_statistics = j_statistics
        inter_arrival_statistics = []
        for j_iat in self._j_statistics.interArrivalStatistics():
            inter_arrival_statistics.append(InterArrivalStatistics(j_iat))
        self._inter_arrival_statistics = inter_arrival_statistics

    @property
    def original_size(self):
        return self._j_statistics.originalSize()

    @property
    def binary_match_normalized_frequency(self):
        return self._j_statistics.binaryMatchNormalizedFrequency()

    @property
    def coverage(self):
        return self._j_statistics.coverage()

    @property
    def inter_arrival_statistics(self):
        return self._inter_arrival_statistics

    def __str__(self):
        return self._j_statistics.toString()
