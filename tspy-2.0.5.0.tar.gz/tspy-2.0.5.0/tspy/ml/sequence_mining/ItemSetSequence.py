class ItemSetSequence:
    def __init__(self, j_itemset_sequence):
        self._j_itemset_sequence = j_itemset_sequence
        sequence = []
        for itemset in j_itemset_sequence.itemsets():
            itemset_i = []
            for item in itemset:
                itemset_i.append(item)
            sequence.append(itemset_i)
        self._sequence = sequence

    def __iter__(self):
        return self._sequence.__iter__()

    @property
    def sequence(self):
        return self._sequence

