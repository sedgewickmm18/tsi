from tspy.time_series.Observation import Observation

from tspy.time_series.ObservationCollection import ObservationCollection


class SequenceMatcher:
    def __init__(self, tsc, j_matcher):
        self._tsc = tsc
        self._j_matcher = j_matcher

    def matches(self, py_itemset_sequence, series):
        from py4j.java_collections import JavaList
        if len(series) is not 0 and isinstance(series.first().value, JavaList):
            result = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.functions.PythonListMatcher(
                self._j_matcher, series._j_observations).matches(py_itemset_sequence._j_itemset_sequence)
        else:
            result = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.functions.PythonSingletonMatcher(
                self._j_matcher, series._j_observations).matches(py_itemset_sequence._j_itemset_sequence)
        if result is None:
            return result
        else:
            return ObservationCollection(self._tsc, result)