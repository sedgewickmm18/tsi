from tspy.ml.sequence_mining.DiscriminatorySubSequenceStatistics import DiscriminatorySubSequenceStatistics
from tspy.ml.sequence_mining.ItemSetSequence import ItemSetSequence


class DiscriminatorySubSequence:
    def __init__(self, j_dss):
        self._j_dss = j_dss
        self._sequence = ItemSetSequence(j_dss.sequence())
        self._statistics = DiscriminatorySubSequenceStatistics(j_dss.statistics())

    @property
    def sequence(self):
        return self._sequence

    @property
    def sequence_id(self):
        return self._j_dss.sequenceID()

    @property
    def statistics(self):
        return self._statistics

    def __str__(self):
        return self._j_dss.toString()
