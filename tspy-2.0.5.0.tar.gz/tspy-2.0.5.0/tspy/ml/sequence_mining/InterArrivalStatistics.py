class InterArrivalStatistics:

    def __init__(self, j_iat):
        self._j_iat = j_iat

    @property
    def min(self):
        return self._j_iat.min()

    @property
    def max(self):
        return self._j_iat.max()

    @property
    def sum(self):
        return self._j_iat.sum()

    @property
    def count(self):
        return self._j_iat.count()

    @property
    def average(self):
        return self._j_iat.average()

    @property
    def sd(self):
        return self._j_iat.sd()

    def __str__(self):
        return self._j_iat.toString()