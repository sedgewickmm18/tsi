from tspy.ml.sequence_mining.FrequentSubSequence import FrequentSubSequence
from tspy.ml.sequence_mining.SequenceMatcher import SequenceMatcher


class FrequentSubSequenceModel:

    def __init__(self, tsc, j_model):
        self._tsc = tsc
        self._j_model = j_model
        fss_list = []
        for fss in self._j_model.frequentSubSequences():
            fss_list.append(FrequentSubSequence(fss))
        self._fss_list = fss_list

    @property
    def min_support(self):
        return self._j_model.minSupport()

    @property
    def creation_date(self):
        return self._j_model.creationDate().toString()

    @property
    def metadata(self):
        return self._j_model.metadata()

    @property
    def frequent_sub_sequences(self):
        return self._fss_list

    @property
    def sequence_matcher(self):
        return SequenceMatcher(self._tsc, self._j_model.sequenceMatcher())

    def save(self, path):
        if isinstance(path, str):
            self._j_model.save(self._tsc._jvm.java.io.FileOutputStream(path))
        else:
            self._j_model.save(path)

    def score(self, series):
        return self._j_model.score(series._j_observations)

    def __str__(self):
        return self._j_model.toString()


