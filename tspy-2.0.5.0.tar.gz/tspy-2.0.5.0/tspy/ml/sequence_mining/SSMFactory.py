from tspy.ml.sequence_mining import SequenceMatcherFactory, DSMModelFactory, FSMModelFactory


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    @property
    def dss_model(self):
        return DSMModelFactory.Factory(self._tsc)

    @property
    def fss_model(self):
        return FSMModelFactory.Factory(self._tsc)

    @property
    def sequence_matchers(self):
        return SequenceMatcherFactory.Factory(self._tsc)
