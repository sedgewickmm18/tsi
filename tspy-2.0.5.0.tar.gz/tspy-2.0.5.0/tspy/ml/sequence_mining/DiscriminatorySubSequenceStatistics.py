from tspy.ml.sequence_mining.InterArrivalStatistics import InterArrivalStatistics


class DiscriminatorySubSequenceStatistics:

    def __init__(self, j_statistics):
        self._j_statistics = j_statistics
        inter_arrival_statistics = []
        for j_iat in self._j_statistics.interArrivalStatistics():
            inter_arrival_statistics.append(InterArrivalStatistics(j_iat))
        self._inter_arrival_statistics = inter_arrival_statistics

    @property
    def original_size_left(self):
        return self._j_statistics.originalSizeLeft()

    @property
    def original_size_right(self):
        return self._j_statistics.originalSizeRight()

    @property
    def binary_match_normalized_frequency_left(self):
        return self._j_statistics.binaryMatchNormalizedFrequencyLeft()

    @property
    def binary_match_normalized_frequency_right(self):
        return self._j_statistics.binaryMatchNormalizedFrequencyRight()

    @property
    def coverage_left(self):
        return self._j_statistics.coverageLeft()

    @property
    def coverage_right(self):
        return self._j_statistics.coverageRight()

    @property
    def lift(self):
        return self._j_statistics.lift()

    @property
    def inter_arrival_statistics(self):
        return self._inter_arrival_statistics

    def __str__(self):
        return self._j_statistics.toString()
