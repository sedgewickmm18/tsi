from tspy.ml.sequence_mining.DiscriminatorySubSequenceModel import DiscriminatorySubSequenceModel


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    def load(self, path):
        # todo this will need changing since str does not always imply it should be FileInputStream
        if isinstance(path, str):
            input_stream = self._tsc._jvm.java.io.FileInputStream(path)
        else:
            input_stream = path

        j_model = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.containers.DiscriminatorySubSequenceModel.load(input_stream)
        return DiscriminatorySubSequenceModel(self._tsc, j_model)
