from tspy.ml.sequence_mining.FrequentSubSequenceStatistics import FrequentSubSequenceStatistics
from tspy.ml.sequence_mining.ItemSetSequence import ItemSetSequence


class FrequentSubSequence:
    def __init__(self, j_fss):
        self._j_fss = j_fss
        self._sequence = ItemSetSequence(j_fss.sequence())
        self._statistics = FrequentSubSequenceStatistics(j_fss.statistics())

    @property
    def sequence(self):
        return self._sequence

    @property
    def sequence_id(self):
        return self._j_fss.sequenceID()

    @property
    def statistics(self):
        return self._statistics

    def __str__(self):
        return self._j_fss.toString()
