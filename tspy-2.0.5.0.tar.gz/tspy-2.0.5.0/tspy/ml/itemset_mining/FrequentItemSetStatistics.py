from tspy.ml.itemset_mining.DurationStatistics import DurationStatistics


class FrequentItemSetStatistics:

    def __init__(self, j_statistics):
        self._j_statistics = j_statistics
        self._duration_statistics = DurationStatistics(j_statistics.durationStatistics())

    @property
    def original_size(self):
        return self._j_statistics.originalSize()

    @property
    def duration_statistics(self):
        return self._duration_statistics

    @property
    def multi_match_norm_frequency(self):
        return self._j_statistics.multiMatchNormFrequency()

    @property
    def binary_match_norm_frequency(self):
        return self._j_statistics.binaryMatchNormFrequency()

    @property
    def coverage(self):
        return self._j_statistics.coverage()

    def __str__(self):
        return self._j_statistics.toString()
