from tspy.ml.itemset_mining.ItemSetMatcher import ItemSetMatcher


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    def subset(self, threshold=0.0, matcher_threshold="PS"):
        if matcher_threshold.lower() == "ps":
            j_mt = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold.PS
        elif matcher_threshold.lower() == "pm":
            j_mt = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold.PM
        elif matcher_threshold.lower() == "ms":
            j_mt = self._tsc._jvm.com.ibm.research.time_series.ml.sequence_mining.containers.MatcherThreshold.MS
        else:
            raise Exception("must be one of ps, pm, ms")
        return ItemSetMatcher(self._tsc, self._tsc._jvm.com.ibm.research.time_series.ml.itemset_mining.functions.ItemSetMatchers.subset(threshold, j_mt))