from tspy.ml.itemset_mining.DiscriminatoryItemSetStatistics import DiscriminatoryItemSetStatistics


class DiscriminatoryItemSet:
    def __init__(self, j_dis):
        self._j_dis = j_dis

        items = []
        for item in j_dis.itemSet():
            items.append(item)

        self._item_set = items
        self._statistics = DiscriminatoryItemSetStatistics(j_dis.statistics())

    @property
    def statistics(self):
        return self._statistics

    @property
    def item_set(self):
        return self._item_set

    @property
    def item_set_id(self):
        return self._j_dis.itemSetID()

    def __str__(self):
        return self._j_dis.toString()
