from tspy.ml.itemset_mining.DurationStatistics import DurationStatistics


class DiscriminatoryItemSetStatistics:

    def __init__(self, j_statistics):
        self._j_statistics = j_statistics
        self._duration_statistics = DurationStatistics(j_statistics.durationStatistics())

    @property
    def original_size_left(self):
        return self._j_statistics.originalSizeLeft()

    @property
    def original_size_right(self):
        return self._j_statistics.originalSizeRight()

    @property
    def duration_statistics(self):
        return self._duration_statistics

    @property
    def binary_match_norm_frequency_left(self):
        return self._j_statistics.binaryMatchNormFrequencyLeft()

    @property
    def binary_match_norm_frequency_right(self):
        return self._j_statistics.binaryMatchNormFrequencyRight()

    @property
    def coverage_left(self):
        return self._j_statistics.coverageLeft()

    @property
    def coverage_right(self):
        return self._j_statistics.coverageRight()

    @property
    def lift(self):
        return self._j_statistics.lift()

    def __str__(self):
        return self._j_statistics.toString()
