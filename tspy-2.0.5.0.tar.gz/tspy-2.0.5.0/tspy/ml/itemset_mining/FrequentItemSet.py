from tspy.ml.itemset_mining.FrequentItemSetStatistics import FrequentItemSetStatistics


class FrequentItemSet:
    def __init__(self, j_fis):
        self._j_fis = j_fis

        items = []
        for item in j_fis.itemSet():
            items.append(item)

        self._item_set = items
        self._statistics = FrequentItemSetStatistics(j_fis.statistics())

    @property
    def statistics(self):
        return self._statistics

    @property
    def item_set(self):
        return self._item_set

    @property
    def item_set_id(self):
        return self._j_fis.itemSetID()

    def __str__(self):
        return self._j_fis.toString()
