from tspy.time_series.ObservationCollection import ObservationCollection


class ItemSetMatcher:
    def __init__(self, tsc, j_matcher):
        self._tsc = tsc
        self._j_matcher = j_matcher

    def matches(self, itemset, py_series):
        from tspy.ml.itemset_mining.FrequentItemSet import FrequentItemSet
        if isinstance(itemset, FrequentItemSet):
            result = self._j_matcher.matches(itemset._j_fis.itemSet(), py_series._j_observations)
        else:
            result = self._j_matcher.matches(itemset._j_dis.itemSet(), py_series._j_observations)
        if result is None:
            return result
        else:
            return ObservationCollection(self._tsc, result)
