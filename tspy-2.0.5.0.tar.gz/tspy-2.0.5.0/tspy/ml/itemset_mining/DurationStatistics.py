class DurationStatistics:

    def __init__(self, j_duration_statistics):
        self._j_duration_statistics = j_duration_statistics

    @property
    def min(self):
        return self._j_duration_statistics.min()

    @property
    def max(self):
        return self._j_duration_statistics.max()

    @property
    def sum(self):
        return self._j_duration_statistics.sum()

    @property
    def count(self):
        return self._j_duration_statistics.count()

    @property
    def average(self):
        return self._j_duration_statistics.average()

    @property
    def sd(self):
        return self._j_duration_statistics.sd()

    @property
    def min_lead_time(self):
        return self._j_duration_statistics.minLeadTime()

    @property
    def max_lead_time(self):
        return self._j_duration_statistics.maxLeadTime()

    @property
    def sum_lead_time(self):
        return self._j_duration_statistics.sumLeadTime()

    @property
    def average_lead_time(self):
        return self._j_duration_statistics.averageLeadTime()

    @property
    def sd_lead_time(self):
        return self._j_duration_statistics.sdLeadTime()

    @property
    def min_end_time(self):
        return self._j_duration_statistics.minEndTime()

    @property
    def max_end_time(self):
        return self._j_duration_statistics.maxEndTime()

    @property
    def sum_end_time(self):
        return self._j_duration_statistics.sumEndTime()

    @property
    def average_end_time(self):
        return self._j_duration_statistics.averageEndTime()

    @property
    def sd_end_time(self):
        return self._j_duration_statistics.sdEndTime()

    @property
    def variance(self):
        return self._j_duration_statistics.variance()

    @property
    def variance_lead_time(self):
        return self._j_duration_statistics.varianceLeadTime()

    @property
    def variance_end_time(self):
        return self._j_duration_statistics.varianceEndTime()

    def __str__(self):
        return self._j_duration_statistics.toString()
