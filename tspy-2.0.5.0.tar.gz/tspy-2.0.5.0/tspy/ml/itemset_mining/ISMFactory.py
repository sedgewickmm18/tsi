from tspy.ml.itemset_mining import FISModelFactory, ItemSetMatcherFactory, DISModelFactory


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    @property
    def fim_model(self):
        return FISModelFactory.Factory(self._tsc)

    @property
    def dim_model(self):
        return DISModelFactory.Factory(self._tsc)

    @property
    def item_set_matchers(self):
        return ItemSetMatcherFactory.Factory(self._tsc)
