from tspy.ml.itemset_mining.DiscriminatoryItemSet import DiscriminatoryItemSet


class DiscriminatoryItemSetModel:

    def __init__(self, tsc, j_model):
        self._tsc = tsc
        self._j_model = j_model
        dis_list = []
        for dis in self._j_model.discriminatoryItemSets():
            dis_list.append(DiscriminatoryItemSet(dis))
        self._dis_list = dis_list

    @property
    def min_support(self):
        return self._j_model.minSupport()

    @property
    def item_set_matcher(self):
        # todo make this python-like
        return self._j_model.itemSetMatcher()

    @property
    def creation_date(self):
        return self._j_model.creationDate().toString()

    @property
    def discriminatory_item_sets(self):
        return self._dis_list

    @property
    def metadata(self):
        return self._j_model.metadata()

    def score(self, series):
        return self._j_model.score(series._j_observations)

    def save(self, path):
        if isinstance(path, str):
            self._j_model.save(self._tsc._jvm.java.io.FileOutputStream(path))
        else:
            self._j_model.save(path)

    def __str__(self):
        return self._j_model.toString()

