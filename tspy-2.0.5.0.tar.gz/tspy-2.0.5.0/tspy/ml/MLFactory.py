from tspy.ml.clustering import ClusteringFactory
from tspy.ml.itemset_mining import ISMFactory
from tspy.ml.sequence_mining import SSMFactory


class Factory(object):

    def __init__(self, tsc):
        self._tsc = tsc

    @property
    def ssm(self):
        return SSMFactory.Factory(self._tsc)

    @property
    def ism(self):
        return ISMFactory.Factory(self._tsc)

    @property
    def clustering(self):
        return ClusteringFactory.Factory(self._tsc)
